import { g as f } from "./app-config-C_GZsF2i.js";
class w {
  constructor(e) {
    this.options = e, this.modifierMode = "alt_option", this.modifierPressed = !1, this.hoverTimer = null, this.handleKeyDown = (t) => {
      if (this.modifierMode === "cmd_ctrl") {
        this.modifierPressed = t.metaKey || t.ctrlKey;
        return;
      }
      this.modifierPressed = t.altKey;
    }, this.handleKeyUp = () => {
      this.modifierPressed = !1, this.options.onModifierReleased();
    }, this.handleMouseMove = (t) => {
      if (!this.modifierPressed)
        return;
      const o = t.target;
      o instanceof Element && (this.hoverTimer !== null && window.clearTimeout(this.hoverTimer), this.hoverTimer = window.setTimeout(() => {
        this.options.onHoverIntent(o, t.clientX, t.clientY);
      }, this.options.hoverDebounceMs));
    }, this.handleAuthBridgeMessage = (t) => {
      if (t.source !== window || !this.options.trustedAuthBridgeOrigins.includes(t.origin) || typeof t.data != "object" || t.data === null) return;
      const o = t.data;
      if (!(o.source !== "tap-and-know-auth" || o.type !== "SUPABASE_JWT" && o.type !== "SUPABASE_LOGOUT")) {
        if (o.type === "SUPABASE_JWT") {
          if (typeof o.token != "string" || o.token.length === 0)
            return;
          this.options.onAuthBridgeEvent({ type: "jwt", token: o.token });
          return;
        }
        this.options.onAuthBridgeEvent({ type: "logout" });
      }
    };
  }
  setModifierMode(e) {
    this.modifierMode = e;
  }
  start() {
    window.addEventListener("keydown", this.handleKeyDown), window.addEventListener("keyup", this.handleKeyUp), window.addEventListener("mousemove", this.handleMouseMove), window.addEventListener("message", this.handleAuthBridgeMessage);
  }
}
class y {
  constructor() {
    this.overlayHost = null, this.shadowRootRef = null;
  }
  clear() {
    this.shadowRootRef && (this.shadowRootRef.innerHTML = "");
  }
  render(e) {
    const t = this.ensureOverlayRoot();
    t.innerHTML = "";
    const o = document.createElement("style");
    o.textContent = `
      :host { all: initial; }
      .popup {
        pointer-events: auto;
        position: fixed;
        width: 300px;
        max-width: calc(100vw - 24px);
        border-radius: 16px;
        background: #18181b;
        border: 1px solid rgba(255,255,255,0.12);
        padding: 14px 16px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(99,102,241,0.2);
        font-family: 'Pretendard Variable', 'Pretendard', system-ui, sans-serif;
        animation: fadeIn 0.15s ease;
      }
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(4px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .word {
        font-size: 16px;
        font-weight: 900;
        color: #f4f4f5;
        margin: 0 0 8px 0;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .badge {
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        padding: 2px 8px;
        border-radius: 999px;
        background: rgba(99,102,241,0.2);
        color: #818cf8;
        border: 1px solid rgba(99,102,241,0.35);
      }
      .divider {
        height: 1px;
        background: rgba(255,255,255,0.08);
        margin: 8px 0;
      }
      .meanings {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      .meaning-item {
        font-size: 13px;
        color: #a1a1aa;
        line-height: 1.6;
        padding: 3px 0;
        display: flex;
        gap: 8px;
      }
      .meaning-item::before {
        content: '•';
        color: #6366f1;
        flex-shrink: 0;
      }
      .fomo {
        margin-top: 10px;
        padding: 8px 10px;
        border-radius: 8px;
        background: rgba(239,68,68,0.1);
        border: 1px solid rgba(239,68,68,0.25);
        font-size: 12px;
        font-weight: 700;
        color: #fca5a5;
      }
      .loading {
        font-size: 13px;
        color: #52525b;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .spinner {
        width: 12px;
        height: 12px;
        border: 2px solid rgba(99,102,241,0.3);
        border-top-color: #6366f1;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
      }
      @keyframes spin { to { transform: rotate(360deg); } }
    `, t.appendChild(o);
    const r = document.createElement("div");
    r.className = "popup";
    const n = window.innerWidth, d = window.innerHeight;
    let s = e.x + 12, a = e.y + 12;
    s + 300 > n && (s = e.x - 312), a + 160 > d && (a = e.y - 170), r.style.left = `${s}px`, r.style.top = `${a}px`;
    const l = e.meanings.length === 1 && e.meanings[0] === "조회 중...";
    r.innerHTML = `
      <p class="word">
        ${e.word}
        <span class="badge">Flow Reader</span>
      </p>
      <div class="divider"></div>
      ${l ? '<div class="loading"><div class="spinner"></div> AI가 문맥을 분석 중...</div>' : `<ul class="meanings">${e.meanings.map((h) => `<li class="meaning-item">${h}</li>`).join("")}</ul>`}
      ${e.fomoMessage ? `<div class="fomo">${e.fomoMessage}</div>` : ""}
    `, t.appendChild(r);
  }
  ensureOverlayRoot() {
    if (this.overlayHost && this.shadowRootRef)
      return this.shadowRootRef;
    const e = document.createElement("div");
    e.id = "flow-reader-overlay-host", Object.assign(e.style, {
      position: "fixed",
      left: "0",
      top: "0",
      zIndex: "2147483647",
      pointerEvents: "none"
    }), document.documentElement.appendChild(e);
    const t = e.attachShadow({ mode: "open" });
    return this.overlayHost = e, this.shadowRootRef = t, t;
  }
}
class x {
  constructor(e = "flow-reader:ext:", t = 100) {
    this.storageKeyPrefix = e, this.maxEntries = t;
  }
  get(e) {
    const t = this.getStorageKey(e);
    try {
      const o = window.localStorage.getItem(t);
      if (!o) return null;
      const r = JSON.parse(o);
      return !Array.isArray(r.meanings) || typeof r.expiresAt != "number" || r.expiresAt < Date.now() ? (window.localStorage.removeItem(t), null) : r;
    } catch {
      return window.localStorage.removeItem(t), null;
    }
  }
  set(e, t) {
    try {
      this.pruneExpiredEntries(), this.trimToCapacity(), window.localStorage.setItem(this.getStorageKey(e), JSON.stringify(t));
    } catch {
    }
  }
  getStorageKey(e) {
    return `${this.storageKeyPrefix}${e}`;
  }
  collectRecords() {
    const e = [], t = [];
    for (let o = 0; o < window.localStorage.length; o += 1) {
      const r = window.localStorage.key(o);
      !r || !r.startsWith(this.storageKeyPrefix) || t.push(r);
    }
    for (const o of t) {
      const r = window.localStorage.getItem(o);
      if (r)
        try {
          const n = JSON.parse(r);
          if (!Array.isArray(n.meanings) || typeof n.expiresAt != "number") {
            window.localStorage.removeItem(o);
            continue;
          }
          e.push({ storageKey: o, entry: n });
        } catch {
          window.localStorage.removeItem(o);
        }
    }
    return e;
  }
  pruneExpiredEntries() {
    const e = Date.now();
    for (const t of this.collectRecords())
      t.entry.expiresAt < e && window.localStorage.removeItem(t.storageKey);
  }
  trimToCapacity() {
    const e = this.collectRecords().sort(
      (t, o) => t.entry.expiresAt - o.entry.expiresAt
    );
    for (; e.length >= this.maxEntries; ) {
      const t = e.shift();
      if (!t)
        return;
      window.localStorage.removeItem(t.storageKey);
    }
  }
}
function v(i) {
  const e = ["gmail.", "bank", "docs.", "localhost"], t = i.toLowerCase();
  return e.some((o) => t.includes(o));
}
async function g(i) {
  const t = new TextEncoder().encode(i), o = await crypto.subtle.digest("SHA-256", t);
  return Array.from(new Uint8Array(o)).map((r) => r.toString(16).padStart(2, "0")).join("");
}
class M {
  constructor(e) {
    this.options = e, this.recentRequestTimestamps = [], this.lastLookupKey = null, this.overlay = new y(), this.cache = new x();
  }
  async lookupFromElement(e, t, o) {
    var p;
    const r = this.extractWord(e), n = this.extractContext(e);
    if (!r || !n)
      return;
    const d = r.toLowerCase().trim(), s = await g(n), a = `${d}:${s}`;
    if (this.lastLookupKey === a)
      return;
    if (v(window.location.hostname)) {
      this.renderOverlay({
        word: r,
        meanings: ["이 페이지에서는 개인정보 보호를 위해 조회가 비활성화됩니다."],
        x: t,
        y: o,
        fomoMessage: null
      });
      return;
    }
    if (!this.canRequest()) {
      this.renderOverlay({
        word: r,
        meanings: ["요청이 너무 많습니다. 잠시 후 다시 시도해 주세요."],
        x: t,
        y: o,
        fomoMessage: null
      });
      return;
    }
    this.lastLookupKey = a;
    const l = this.cache.get(a);
    if (l) {
      this.renderOverlay({
        word: r,
        meanings: l.meanings,
        x: t,
        y: o,
        fomoMessage: null
      });
      return;
    }
    this.renderOverlay({ word: r, meanings: ["조회 중..."], x: t, y: o, fomoMessage: null });
    const h = await g(window.location.pathname);
    let u;
    try {
      u = await chrome.runtime.sendMessage({
        type: "FLOW_LOOKUP",
        payload: {
          word: r,
          sentence: n,
          term: r,
          context: n,
          sourceDomain: window.location.hostname,
          sourcePathHash: h
        }
      });
    } catch (m) {
      this.lastLookupKey = null, this.renderOverlay({
        word: r,
        meanings: ["조회 요청을 보내지 못했습니다. 잠시 후 다시 시도해 주세요."],
        x: t,
        y: o,
        fomoMessage: null
      }), console.warn("Flow Reader lookup request failed.", m);
      return;
    }
    const c = this.extractLookupResult(u, r, t, o);
    if (!c) {
      this.lastLookupKey = null;
      return;
    }
    this.cache.set(a, {
      meanings: c.meanings,
      expiresAt: Date.now() + this.options.cacheTtlMs
    }), this.renderOverlay({
      word: r,
      meanings: c.meanings,
      x: t,
      y: o,
      fomoMessage: ((p = c.guestStats) == null ? void 0 : p.fomoMessage) ?? null
    });
  }
  clearOverlay() {
    this.overlay.clear(), this.lastLookupKey = null;
  }
  extractLookupResult(e, t, o, r) {
    return e.ok ? "meanings" in e.data ? e.data : null : (this.renderOverlay({
      word: t,
      meanings: [e.error.message || "조회에 실패했습니다."],
      x: o,
      y: r,
      fomoMessage: null
    }), null);
  }
  extractWord(e) {
    var r;
    const o = (((r = e.textContent) == null ? void 0 : r.trim()) ?? "").match(/[A-Za-z][A-Za-z'-]*/);
    return (o == null ? void 0 : o[0]) ?? "";
  }
  extractContext(e) {
    var r, n, d;
    return ([
      ((r = e.closest("p, li, h1, h2, h3, h4, h5, h6, article")) == null ? void 0 : r.textContent) ?? "",
      ((n = e.closest("p, div, article, section")) == null ? void 0 : n.textContent) ?? "",
      ((d = e.closest("label, button, span")) == null ? void 0 : d.textContent) ?? "",
      e.textContent ?? ""
    ].map((s) => s.replace(/\s+/g, " ").trim()).find((s) => s.length > 0) ?? "").slice(0, 300);
  }
  canRequest() {
    const e = Date.now(), t = e - 6e4;
    return this.recentRequestTimestamps = this.recentRequestTimestamps.filter(
      (o) => o > t
    ), this.recentRequestTimestamps.length >= this.options.maxRequestsPerMinute ? !1 : (this.recentRequestTimestamps.push(e), !0);
  }
  renderOverlay(e) {
    this.overlay.render(e);
  }
}
const k = 200, R = 10, b = 1440 * 60 * 1e3, E = f();
class A {
  constructor() {
    this.eventManager = new w({
      trustedAuthBridgeOrigins: E,
      hoverDebounceMs: k,
      onHoverIntent: (e, t, o) => {
        this.lookupCoordinator.lookupFromElement(e, t, o);
      },
      onModifierReleased: () => {
        this.lookupCoordinator.clearOverlay();
      },
      onAuthBridgeEvent: (e) => {
        this.persistAuthBridgeEvent(e);
      }
    }), this.lookupCoordinator = new M({
      cacheTtlMs: b,
      maxRequestsPerMinute: R
    });
  }
  async start() {
    this.eventManager.setModifierMode(await this.loadModifierFromBackground()), this.eventManager.start();
  }
  async loadModifierFromBackground() {
    try {
      const e = await chrome.runtime.sendMessage({
        type: "FLOW_GET_MODIFIER"
      });
      if (e.ok && "modifier" in e.data)
        return e.data.modifier;
    } catch (e) {
      console.warn("Flow Reader modifier load failed, using default.", e);
    }
    return "alt_option";
  }
  async persistAuthBridgeEvent(e) {
    if (e.type === "jwt") {
      await chrome.runtime.sendMessage({
        type: "FLOW_SET_JWT",
        payload: { token: e.token }
      });
      return;
    }
    await chrome.runtime.sendMessage({
      type: "FLOW_CLEAR_JWT"
    });
  }
}
const S = new A();
S.start();
