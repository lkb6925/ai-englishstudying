import { r as y, a as g } from "./app-config-C_GZsF2i.js";
const s = {
  apiBaseUrl: "flow_reader_api_base_url",
  modifier: "flow_reader_modifier",
  jwt: "supabase_jwt",
  guestStats: "flow_reader_guest_stats"
};
async function c(e, t) {
  return (await e.get(t))[t] ?? null;
}
async function l(e, t, o) {
  await e.set({ [t]: o });
}
async function p(e, t) {
  await e.remove(t);
}
const k = g(), m = y();
function _(e) {
  return Array.isArray(e) && e.every((t) => typeof t == "string");
}
function S(e) {
  return !e || typeof e != "object" ? !1 : _(e.contextual_meanings);
}
function L(e) {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.persisted != "boolean" || typeof t.promoted != "boolean" || typeof t.totalLookupCount != "number" ? !1 : t.reason === void 0 || t.reason === "unauthorized" || t.reason === "excluded_domain";
}
async function j(e, t) {
  try {
    const o = await e.json();
    if (typeof o.error == "string" && o.error.length > 0)
      return o.error;
    if (typeof o.details == "string" && o.details.length > 0)
      return o.details;
  } catch {
  }
  return t;
}
async function h() {
  const e = await c(
    chrome.storage.sync,
    s.apiBaseUrl
  );
  return typeof e == "string" && e.length > 0 ? e.replace(/\/$/, "") : m;
}
async function O() {
  const e = await c(
    chrome.storage.session,
    s.jwt
  );
  if (typeof e == "string" && e.length > 0)
    return e;
  const t = await c(
    chrome.storage.local,
    s.jwt
  );
  return typeof t == "string" && t.length > 0 ? t : null;
}
async function v() {
  const e = await O(), t = { "Content-Type": "application/json" };
  return e && (t.Authorization = `Bearer ${e}`), t;
}
async function A() {
  const e = await c(
    chrome.storage.local,
    s.guestStats
  );
  if (typeof e != "object" || e === null)
    return { total: 0, terms: {}, shownCount: 0 };
  const t = e;
  return {
    total: typeof t.total == "number" ? t.total : 0,
    terms: typeof t.terms == "object" && t.terms !== null ? t.terms : {},
    shownCount: typeof t.shownCount == "number" ? t.shownCount : 0
  };
}
function b(e, t, o, r) {
  return o >= 3 || !(e >= 25 || t >= 3 || e >= 10) ? null : t >= 3 ? `'${r}'를 ${t}번 다시 찾았습니다` : `🚨 ${e}개는 아직 익숙하지 않습니다`;
}
async function C(e) {
  const t = e.toLowerCase().trim(), o = await A(), r = (o.terms[t] ?? 0) + 1, a = o.total + 1, n = b(
    a,
    r,
    o.shownCount,
    e
  );
  return await l(chrome.storage.local, s.guestStats, {
    total: a,
    terms: { ...o.terms, [t]: r },
    shownCount: n ? o.shownCount + 1 : o.shownCount
  }), { total: a, termCount: r, fomoMessage: n };
}
async function T(e) {
  const t = await h(), o = await v(), r = await fetch(`${t}/api/lookup`, {
    method: "POST",
    headers: o,
    body: JSON.stringify({ word: e.word, sentence: e.sentence })
  });
  if (!r.ok)
    return {
      ok: !1,
      error: {
        message: await j(
          r,
          `Lookup failed with status ${r.status}`
        )
      }
    };
  const a = await r.json();
  if (!S(a))
    return {
      ok: !1,
      error: { message: "Lookup response shape was invalid." }
    };
  const n = a, i = await fetch(`${t}/api/lookup-event`, {
    method: "POST",
    headers: o,
    body: JSON.stringify({
      term: e.term,
      context: e.context,
      meanings: n.contextual_meanings,
      sourceDomain: e.sourceDomain,
      sourcePathHash: e.sourcePathHash
    })
  });
  let u = null, d = null;
  if (i.ok) {
    const f = await i.json();
    L(f) ? u = f : console.warn("Flow Reader lookup-event response shape was invalid.", f), u && !u.persisted && u.reason === "unauthorized" && (d = await C(e.term));
  }
  return {
    ok: !0,
    data: {
      meanings: n.contextual_meanings,
      lookupEvent: u,
      guestStats: d
    }
  };
}
async function w() {
  const e = await c(
    chrome.storage.sync,
    s.modifier
  );
  return e === "cmd_ctrl" || e === "alt_option" ? e : "alt_option";
}
async function U() {
  await p(chrome.storage.session, s.jwt), await p(chrome.storage.local, s.jwt);
}
chrome.runtime.onMessage.addListener(
  (e, t, o) => ((async (a) => {
    if (a.type === "FLOW_LOOKUP")
      return T(a.payload);
    if (a.type === "FLOW_GET_MODIFIER")
      return { ok: !0, data: { modifier: await w() } };
    if (a.type === "FLOW_GET_RUNTIME_CONFIG") {
      const n = await w(), i = await h();
      return {
        ok: !0,
        data: {
          modifier: n,
          appUrl: i || k,
          apiBaseUrl: i || m
        }
      };
    }
    return a.type === "FLOW_SET_MODIFIER" ? (await l(
      chrome.storage.sync,
      s.modifier,
      a.payload.modifier
    ), { ok: !0, data: { modifier: a.payload.modifier } }) : a.type === "FLOW_SET_JWT" ? (await l(
      chrome.storage.session,
      s.jwt,
      a.payload.token
    ), await l(
      chrome.storage.local,
      s.jwt,
      a.payload.token
    ), { ok: !0, data: { saved: !0 } }) : a.type === "FLOW_CLEAR_JWT" ? (await U(), { ok: !0, data: { saved: !0 } }) : { ok: !1, error: { message: "Unknown message type." } };
  })(e).then(o).catch((a) => {
    const n = a instanceof Error ? a.message : "Background request failed";
    o({ ok: !1, error: { message: n } });
  }), !0)
);
