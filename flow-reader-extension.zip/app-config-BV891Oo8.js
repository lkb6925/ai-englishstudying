const c = "http://localhost:3000";
function u(r) {
  return null;
}
function l(r) {
  try {
    const t = new URL(r);
    return t.hostname === "localhost" || t.hostname === "127.0.0.1";
  } catch {
    return !1;
  }
}
function o(r, t, n = "3000") {
  const s = r == null ? void 0 : r.trim(), e = t == null ? void 0 : t.trim();
  return !s || !e ? null : `https://${s}-${n}.${e}`;
}
function i(r, t, n) {
  const s = u(), e = o(
    t,
    n
  );
  return s && !l(s) ? s : e || (s ?? c);
}
function p(r, t, n, s) {
  const e = u();
  return e && !l(e) ? e : o(n, s) ?? e ?? i(t, n, s);
}
function a(r, t, n) {
  return [i(r, t, n)];
}
function h(r, t, n) {
  return `${i(r, t, n)}/wordbook`;
}
export {
  p as a,
  h as b,
  a as g,
  i as r
};
