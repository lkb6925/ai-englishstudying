import { r as d, a as c, b as p } from "./app-config-BV891Oo8.js";
const l = d(
  void 0,
  "improved-space-happiness-97p7j4gv9jv5274g",
  "app.github.dev"
), o = c(
  void 0,
  void 0,
  "improved-space-happiness-97p7j4gv9jv5274g",
  "app.github.dev"
), s = p(
  void 0,
  "improved-space-happiness-97p7j4gv9jv5274g",
  "app.github.dev"
);
function i(e) {
  const t = document.getElementById("modifier-text"), n = document.querySelector(".key-icon");
  !t || !n || (t.textContent = e === "cmd_ctrl" ? "Cmd / Ctrl + 마우스 올리기" : "Alt / Option + 마우스 올리기", n.textContent = e === "cmd_ctrl" ? "⌘" : "⌥");
}
function r(e) {
  const t = document.getElementById("api-base-url");
  t && (t.textContent = `API: ${e}`);
}
function a(e) {
  const t = document.getElementById("wordbook-btn");
  t && t.addEventListener("click", () => {
    chrome.tabs.create({ url: e.replace(/\/$/, "") + "/wordbook" });
  });
}
async function u() {
  const e = await chrome.runtime.sendMessage({
    type: "FLOW_GET_RUNTIME_CONFIG"
  });
  if (!(e != null && e.ok) || !e.data || !("modifier" in e.data))
    throw new Error("Runtime config was unavailable.");
  return e.data;
}
async function m() {
  try {
    const t = await u();
    i(t.modifier), r(t.apiBaseUrl || o), a(t.appUrl || l);
  } catch (t) {
    console.warn("Flow Reader popup failed to load runtime config.", t), i("alt_option"), r(o), a(s.replace(/\/wordbook$/, ""));
  }
  const e = document.getElementById("options-btn");
  e == null || e.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}
m();
