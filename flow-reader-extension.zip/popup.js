import { r as c, a as l, b as d } from "./app-config-C_GZsF2i.js";
const s = l(), n = c(), m = d();
function r(t) {
  const e = document.getElementById("modifier-text"), o = document.querySelector(".key-icon");
  !e || !o || (e.textContent = t === "cmd_ctrl" ? "Cmd / Ctrl + 마우스 올리기" : "Alt / Option + 마우스 올리기", o.textContent = t === "cmd_ctrl" ? "⌘" : "⌥");
}
function a(t) {
  const e = document.getElementById("api-base-url");
  e && (e.textContent = `API: ${t}`);
}
function i(t) {
  const e = document.getElementById("wordbook-btn");
  e && e.addEventListener("click", () => {
    chrome.tabs.create({ url: t.replace(/\/$/, "") + "/wordbook" });
  });
}
async function u() {
  const t = await chrome.runtime.sendMessage({
    type: "FLOW_GET_RUNTIME_CONFIG"
  });
  if (!(t != null && t.ok) || !t.data || !("modifier" in t.data))
    throw new Error("Runtime config was unavailable.");
  return t.data;
}
async function f() {
  try {
    const e = await u();
    r(e.modifier), a(e.apiBaseUrl || n), i(e.appUrl || s);
  } catch (e) {
    console.warn("Flow Reader popup failed to load runtime config.", e), r("alt_option"), a(n), i(m.replace(/\/wordbook$/, ""));
  }
  const t = document.getElementById("options-btn");
  t == null || t.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}
f();
