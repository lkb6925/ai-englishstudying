const e = "http://localhost:3000";
function t(r) {
  return null;
}
function n(r) {
  return t() ?? e;
}
function a(r, o) {
  return t() ?? n();
}
function l(r) {
  return [n()];
}
function i(r) {
  return `${n()}/wordbook`;
}
export {
  n as a,
  i as b,
  l as g,
  a as r
};
