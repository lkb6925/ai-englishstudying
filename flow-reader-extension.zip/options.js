import { r as Xe } from "./app-config-C_GZsF2i.js";
var ye = { exports: {} }, ce = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Le;
function Ke() {
  if (Le) return ce;
  Le = 1;
  var w = Symbol.for("react.transitional.element"), i = Symbol.for("react.fragment");
  function x(g, T, O) {
    var L = null;
    if (O !== void 0 && (L = "" + O), T.key !== void 0 && (L = "" + T.key), "key" in T) {
      O = {};
      for (var P in T)
        P !== "key" && (O[P] = T[P]);
    } else O = T;
    return T = O.ref, {
      $$typeof: w,
      type: g,
      key: L,
      ref: T !== void 0 ? T : null,
      props: O
    };
  }
  return ce.Fragment = i, ce.jsx = x, ce.jsxs = x, ce;
}
var le = {}, ve = { exports: {} }, f = {};
/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var De;
function Ve() {
  if (De) return f;
  De = 1;
  var w = Symbol.for("react.transitional.element"), i = Symbol.for("react.portal"), x = Symbol.for("react.fragment"), g = Symbol.for("react.strict_mode"), T = Symbol.for("react.profiler"), O = Symbol.for("react.consumer"), L = Symbol.for("react.context"), P = Symbol.for("react.forward_ref"), J = Symbol.for("react.suspense"), ue = Symbol.for("react.memo"), D = Symbol.for("react.lazy"), z = Symbol.for("react.activity"), $ = Symbol.iterator;
  function H(t) {
    return t === null || typeof t != "object" ? null : (t = $ && t[$] || t["@@iterator"], typeof t == "function" ? t : null);
  }
  var B = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, ee = Object.assign, G = {};
  function I(t, n, s) {
    this.props = t, this.context = n, this.refs = G, this.updater = s || B;
  }
  I.prototype.isReactComponent = {}, I.prototype.setState = function(t, n) {
    if (typeof t != "object" && typeof t != "function" && t != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, t, n, "setState");
  }, I.prototype.forceUpdate = function(t) {
    this.updater.enqueueForceUpdate(this, t, "forceUpdate");
  };
  function F() {
  }
  F.prototype = I.prototype;
  function te(t, n, s) {
    this.props = t, this.context = n, this.refs = G, this.updater = s || B;
  }
  var Q = te.prototype = new F();
  Q.constructor = te, ee(Q, I.prototype), Q.isPureReactComponent = !0;
  var N = Array.isArray;
  function re() {
  }
  var h = { H: null, A: null, T: null, S: null }, se = Object.prototype.hasOwnProperty;
  function A(t, n, s) {
    var a = s.ref;
    return {
      $$typeof: w,
      type: t,
      key: n,
      ref: a !== void 0 ? a : null,
      props: s
    };
  }
  function X(t, n) {
    return A(t.type, n, t.props);
  }
  function ne(t) {
    return typeof t == "object" && t !== null && t.$$typeof === w;
  }
  function b(t) {
    var n = { "=": "=0", ":": "=2" };
    return "$" + t.replace(/[=:]/g, function(s) {
      return n[s];
    });
  }
  var K = /\/+/g;
  function U(t, n) {
    return typeof t == "object" && t !== null && t.key != null ? b("" + t.key) : n.toString(36);
  }
  function M(t) {
    switch (t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw t.reason;
      default:
        switch (typeof t.status == "string" ? t.then(re, re) : (t.status = "pending", t.then(
          function(n) {
            t.status === "pending" && (t.status = "fulfilled", t.value = n);
          },
          function(n) {
            t.status === "pending" && (t.status = "rejected", t.reason = n);
          }
        )), t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw t.reason;
        }
    }
    throw t;
  }
  function C(t, n, s, a, p) {
    var v = typeof t;
    (v === "undefined" || v === "boolean") && (t = null);
    var l = !1;
    if (t === null) l = !0;
    else
      switch (v) {
        case "bigint":
        case "string":
        case "number":
          l = !0;
          break;
        case "object":
          switch (t.$$typeof) {
            case w:
            case i:
              l = !0;
              break;
            case D:
              return l = t._init, C(
                l(t._payload),
                n,
                s,
                a,
                p
              );
          }
      }
    if (l)
      return p = p(t), l = a === "" ? "." + U(t, 0) : a, N(p) ? (s = "", l != null && (s = l.replace(K, "$&/") + "/"), C(p, n, s, "", function(q) {
        return q;
      })) : p != null && (ne(p) && (p = X(
        p,
        s + (p.key == null || t && t.key === p.key ? "" : ("" + p.key).replace(
          K,
          "$&/"
        ) + "/") + l
      )), n.push(p)), 1;
    l = 0;
    var k = a === "" ? "." : a + ":";
    if (N(t))
      for (var S = 0; S < t.length; S++)
        a = t[S], v = k + U(a, S), l += C(
          a,
          n,
          s,
          v,
          p
        );
    else if (S = H(t), typeof S == "function")
      for (t = S.call(t), S = 0; !(a = t.next()).done; )
        a = a.value, v = k + U(a, S++), l += C(
          a,
          n,
          s,
          v,
          p
        );
    else if (v === "object") {
      if (typeof t.then == "function")
        return C(
          M(t),
          n,
          s,
          a,
          p
        );
      throw n = String(t), Error(
        "Objects are not valid as a React child (found: " + (n === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : n) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return l;
  }
  function Y(t, n, s) {
    if (t == null) return t;
    var a = [], p = 0;
    return C(t, a, "", "", function(v) {
      return n.call(s, v, p++);
    }), a;
  }
  function V(t) {
    if (t._status === -1) {
      var n = t._result;
      n = n(), n.then(
        function(s) {
          (t._status === 0 || t._status === -1) && (t._status = 1, t._result = s);
        },
        function(s) {
          (t._status === 0 || t._status === -1) && (t._status = 2, t._result = s);
        }
      ), t._status === -1 && (t._status = 0, t._result = n);
    }
    if (t._status === 1) return t._result.default;
    throw t._result;
  }
  var W = typeof reportError == "function" ? reportError : function(t) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var n = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
        error: t
      });
      if (!window.dispatchEvent(n)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", t);
      return;
    }
    console.error(t);
  }, oe = {
    map: Y,
    forEach: function(t, n, s) {
      Y(
        t,
        function() {
          n.apply(this, arguments);
        },
        s
      );
    },
    count: function(t) {
      var n = 0;
      return Y(t, function() {
        n++;
      }), n;
    },
    toArray: function(t) {
      return Y(t, function(n) {
        return n;
      }) || [];
    },
    only: function(t) {
      if (!ne(t))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return t;
    }
  };
  return f.Activity = z, f.Children = oe, f.Component = I, f.Fragment = x, f.Profiler = T, f.PureComponent = te, f.StrictMode = g, f.Suspense = J, f.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = h, f.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(t) {
      return h.H.useMemoCache(t);
    }
  }, f.cache = function(t) {
    return function() {
      return t.apply(null, arguments);
    };
  }, f.cacheSignal = function() {
    return null;
  }, f.cloneElement = function(t, n, s) {
    if (t == null)
      throw Error(
        "The argument must be a React element, but you passed " + t + "."
      );
    var a = ee({}, t.props), p = t.key;
    if (n != null)
      for (v in n.key !== void 0 && (p = "" + n.key), n)
        !se.call(n, v) || v === "key" || v === "__self" || v === "__source" || v === "ref" && n.ref === void 0 || (a[v] = n[v]);
    var v = arguments.length - 2;
    if (v === 1) a.children = s;
    else if (1 < v) {
      for (var l = Array(v), k = 0; k < v; k++)
        l[k] = arguments[k + 2];
      a.children = l;
    }
    return A(t.type, p, a);
  }, f.createContext = function(t) {
    return t = {
      $$typeof: L,
      _currentValue: t,
      _currentValue2: t,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, t.Provider = t, t.Consumer = {
      $$typeof: O,
      _context: t
    }, t;
  }, f.createElement = function(t, n, s) {
    var a, p = {}, v = null;
    if (n != null)
      for (a in n.key !== void 0 && (v = "" + n.key), n)
        se.call(n, a) && a !== "key" && a !== "__self" && a !== "__source" && (p[a] = n[a]);
    var l = arguments.length - 2;
    if (l === 1) p.children = s;
    else if (1 < l) {
      for (var k = Array(l), S = 0; S < l; S++)
        k[S] = arguments[S + 2];
      p.children = k;
    }
    if (t && t.defaultProps)
      for (a in l = t.defaultProps, l)
        p[a] === void 0 && (p[a] = l[a]);
    return A(t, v, p);
  }, f.createRef = function() {
    return { current: null };
  }, f.forwardRef = function(t) {
    return { $$typeof: P, render: t };
  }, f.isValidElement = ne, f.lazy = function(t) {
    return {
      $$typeof: D,
      _payload: { _status: -1, _result: t },
      _init: V
    };
  }, f.memo = function(t, n) {
    return {
      $$typeof: ue,
      type: t,
      compare: n === void 0 ? null : n
    };
  }, f.startTransition = function(t) {
    var n = h.T, s = {};
    h.T = s;
    try {
      var a = t(), p = h.S;
      p !== null && p(s, a), typeof a == "object" && a !== null && typeof a.then == "function" && a.then(re, W);
    } catch (v) {
      W(v);
    } finally {
      n !== null && s.types !== null && (n.types = s.types), h.T = n;
    }
  }, f.unstable_useCacheRefresh = function() {
    return h.H.useCacheRefresh();
  }, f.use = function(t) {
    return h.H.use(t);
  }, f.useActionState = function(t, n, s) {
    return h.H.useActionState(t, n, s);
  }, f.useCallback = function(t, n) {
    return h.H.useCallback(t, n);
  }, f.useContext = function(t) {
    return h.H.useContext(t);
  }, f.useDebugValue = function() {
  }, f.useDeferredValue = function(t, n) {
    return h.H.useDeferredValue(t, n);
  }, f.useEffect = function(t, n) {
    return h.H.useEffect(t, n);
  }, f.useEffectEvent = function(t) {
    return h.H.useEffectEvent(t);
  }, f.useId = function() {
    return h.H.useId();
  }, f.useImperativeHandle = function(t, n, s) {
    return h.H.useImperativeHandle(t, n, s);
  }, f.useInsertionEffect = function(t, n) {
    return h.H.useInsertionEffect(t, n);
  }, f.useLayoutEffect = function(t, n) {
    return h.H.useLayoutEffect(t, n);
  }, f.useMemo = function(t, n) {
    return h.H.useMemo(t, n);
  }, f.useOptimistic = function(t, n) {
    return h.H.useOptimistic(t, n);
  }, f.useReducer = function(t, n, s) {
    return h.H.useReducer(t, n, s);
  }, f.useRef = function(t) {
    return h.H.useRef(t);
  }, f.useState = function(t) {
    return h.H.useState(t);
  }, f.useSyncExternalStore = function(t, n, s) {
    return h.H.useSyncExternalStore(
      t,
      n,
      s
    );
  }, f.useTransition = function() {
    return h.H.useTransition();
  }, f.version = "19.2.4", f;
}
var fe = { exports: {} };
/**
 * @license React
 * react.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
fe.exports;
var Ie;
function Ze() {
  return Ie || (Ie = 1, (function(w, i) {
    process.env.NODE_ENV !== "production" && (function() {
      function x(e, r) {
        Object.defineProperty(O.prototype, e, {
          get: function() {
            console.warn(
              "%s(...) is deprecated in plain JavaScript React classes. %s",
              r[0],
              r[1]
            );
          }
        });
      }
      function g(e) {
        return e === null || typeof e != "object" ? null : (e = Re && e[Re] || e["@@iterator"], typeof e == "function" ? e : null);
      }
      function T(e, r) {
        e = (e = e.constructor) && (e.displayName || e.name) || "ReactClass";
        var o = e + "." + r;
        we[o] || (console.error(
          "Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.",
          r,
          e
        ), we[o] = !0);
      }
      function O(e, r, o) {
        this.props = e, this.context = r, this.refs = he, this.updater = o || Te;
      }
      function L() {
      }
      function P(e, r, o) {
        this.props = e, this.context = r, this.refs = he, this.updater = o || Te;
      }
      function J() {
      }
      function ue(e) {
        return "" + e;
      }
      function D(e) {
        try {
          ue(e);
          var r = !1;
        } catch {
          r = !0;
        }
        if (r) {
          r = console;
          var o = r.error, u = typeof Symbol == "function" && Symbol.toStringTag && e[Symbol.toStringTag] || e.constructor.name || "Object";
          return o.call(
            r,
            "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",
            u
          ), ue(e);
        }
      }
      function z(e) {
        if (e == null) return null;
        if (typeof e == "function")
          return e.$$typeof === $e ? null : e.displayName || e.name || null;
        if (typeof e == "string") return e;
        switch (e) {
          case t:
            return "Fragment";
          case s:
            return "Profiler";
          case n:
            return "StrictMode";
          case l:
            return "Suspense";
          case k:
            return "SuspenseList";
          case be:
            return "Activity";
        }
        if (typeof e == "object")
          switch (typeof e.tag == "number" && console.error(
            "Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."
          ), e.$$typeof) {
            case oe:
              return "Portal";
            case p:
              return e.displayName || "Context";
            case a:
              return (e._context.displayName || "Context") + ".Consumer";
            case v:
              var r = e.render;
              return e = e.displayName, e || (e = r.displayName || r.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
            case S:
              return r = e.displayName || null, r !== null ? r : z(e.type) || "Memo";
            case q:
              r = e._payload, e = e._init;
              try {
                return z(e(r));
              } catch {
              }
          }
        return null;
      }
      function $(e) {
        if (e === t) return "<>";
        if (typeof e == "object" && e !== null && e.$$typeof === q)
          return "<...>";
        try {
          var r = z(e);
          return r ? "<" + r + ">" : "<...>";
        } catch {
          return "<...>";
        }
      }
      function H() {
        var e = _.A;
        return e === null ? null : e.getOwner();
      }
      function B() {
        return Error("react-stack-top-frame");
      }
      function ee(e) {
        if (de.call(e, "key")) {
          var r = Object.getOwnPropertyDescriptor(e, "key").get;
          if (r && r.isReactWarning) return !1;
        }
        return e.key !== void 0;
      }
      function G(e, r) {
        function o() {
          Ae || (Ae = !0, console.error(
            "%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",
            r
          ));
        }
        o.isReactWarning = !0, Object.defineProperty(e, "key", {
          get: o,
          configurable: !0
        });
      }
      function I() {
        var e = z(this.type);
        return je[e] || (je[e] = !0, console.error(
          "Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."
        )), e = this.props.ref, e !== void 0 ? e : null;
      }
      function F(e, r, o, u, c, m) {
        var d = o.ref;
        return e = {
          $$typeof: W,
          type: e,
          key: r,
          props: o,
          _owner: u
        }, (d !== void 0 ? d : null) !== null ? Object.defineProperty(e, "ref", {
          enumerable: !1,
          get: I
        }) : Object.defineProperty(e, "ref", { enumerable: !1, value: null }), e._store = {}, Object.defineProperty(e._store, "validated", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: 0
        }), Object.defineProperty(e, "_debugInfo", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: null
        }), Object.defineProperty(e, "_debugStack", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: c
        }), Object.defineProperty(e, "_debugTask", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: m
        }), Object.freeze && (Object.freeze(e.props), Object.freeze(e)), e;
      }
      function te(e, r) {
        return r = F(
          e.type,
          r,
          e.props,
          e._owner,
          e._debugStack,
          e._debugTask
        ), e._store && (r._store.validated = e._store.validated), r;
      }
      function Q(e) {
        N(e) ? e._store && (e._store.validated = 1) : typeof e == "object" && e !== null && e.$$typeof === q && (e._payload.status === "fulfilled" ? N(e._payload.value) && e._payload.value._store && (e._payload.value._store.validated = 1) : e._store && (e._store.validated = 1));
      }
      function N(e) {
        return typeof e == "object" && e !== null && e.$$typeof === W;
      }
      function re(e) {
        var r = { "=": "=0", ":": "=2" };
        return "$" + e.replace(/[=:]/g, function(o) {
          return r[o];
        });
      }
      function h(e, r) {
        return typeof e == "object" && e !== null && e.key != null ? (D(e.key), re("" + e.key)) : r.toString(36);
      }
      function se(e) {
        switch (e.status) {
          case "fulfilled":
            return e.value;
          case "rejected":
            throw e.reason;
          default:
            switch (typeof e.status == "string" ? e.then(J, J) : (e.status = "pending", e.then(
              function(r) {
                e.status === "pending" && (e.status = "fulfilled", e.value = r);
              },
              function(r) {
                e.status === "pending" && (e.status = "rejected", e.reason = r);
              }
            )), e.status) {
              case "fulfilled":
                return e.value;
              case "rejected":
                throw e.reason;
            }
        }
        throw e;
      }
      function A(e, r, o, u, c) {
        var m = typeof e;
        (m === "undefined" || m === "boolean") && (e = null);
        var d = !1;
        if (e === null) d = !0;
        else
          switch (m) {
            case "bigint":
            case "string":
            case "number":
              d = !0;
              break;
            case "object":
              switch (e.$$typeof) {
                case W:
                case oe:
                  d = !0;
                  break;
                case q:
                  return d = e._init, A(
                    d(e._payload),
                    r,
                    o,
                    u,
                    c
                  );
              }
          }
        if (d) {
          d = e, c = c(d);
          var R = u === "" ? "." + h(d, 0) : u;
          return Oe(c) ? (o = "", R != null && (o = R.replace(Pe, "$&/") + "/"), A(c, r, o, "", function(Z) {
            return Z;
          })) : c != null && (N(c) && (c.key != null && (d && d.key === c.key || D(c.key)), o = te(
            c,
            o + (c.key == null || d && d.key === c.key ? "" : ("" + c.key).replace(
              Pe,
              "$&/"
            ) + "/") + R
          ), u !== "" && d != null && N(d) && d.key == null && d._store && !d._store.validated && (o._store.validated = 2), c = o), r.push(c)), 1;
        }
        if (d = 0, R = u === "" ? "." : u + ":", Oe(e))
          for (var y = 0; y < e.length; y++)
            u = e[y], m = R + h(u, y), d += A(
              u,
              r,
              o,
              m,
              c
            );
        else if (y = g(e), typeof y == "function")
          for (y === e.entries && (xe || console.warn(
            "Using Maps as children is not supported. Use an array of keyed ReactElements instead."
          ), xe = !0), e = y.call(e), y = 0; !(u = e.next()).done; )
            u = u.value, m = R + h(u, y++), d += A(
              u,
              r,
              o,
              m,
              c
            );
        else if (m === "object") {
          if (typeof e.then == "function")
            return A(
              se(e),
              r,
              o,
              u,
              c
            );
          throw r = String(e), Error(
            "Objects are not valid as a React child (found: " + (r === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead."
          );
        }
        return d;
      }
      function X(e, r, o) {
        if (e == null) return e;
        var u = [], c = 0;
        return A(e, u, "", "", function(m) {
          return r.call(o, m, c++);
        }), u;
      }
      function ne(e) {
        if (e._status === -1) {
          var r = e._ioInfo;
          r != null && (r.start = r.end = performance.now()), r = e._result;
          var o = r();
          if (o.then(
            function(c) {
              if (e._status === 0 || e._status === -1) {
                e._status = 1, e._result = c;
                var m = e._ioInfo;
                m != null && (m.end = performance.now()), o.status === void 0 && (o.status = "fulfilled", o.value = c);
              }
            },
            function(c) {
              if (e._status === 0 || e._status === -1) {
                e._status = 2, e._result = c;
                var m = e._ioInfo;
                m != null && (m.end = performance.now()), o.status === void 0 && (o.status = "rejected", o.reason = c);
              }
            }
          ), r = e._ioInfo, r != null) {
            r.value = o;
            var u = o.displayName;
            typeof u == "string" && (r.name = u);
          }
          e._status === -1 && (e._status = 0, e._result = o);
        }
        if (e._status === 1)
          return r = e._result, r === void 0 && console.error(
            `lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`,
            r
          ), "default" in r || console.error(
            `lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`,
            r
          ), r.default;
        throw e._result;
      }
      function b() {
        var e = _.H;
        return e === null && console.error(
          `Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`
        ), e;
      }
      function K() {
        _.asyncTransitions--;
      }
      function U(e) {
        if (pe === null)
          try {
            var r = ("require" + Math.random()).slice(0, 7);
            pe = (w && w[r]).call(
              w,
              "timers"
            ).setImmediate;
          } catch {
            pe = function(u) {
              Me === !1 && (Me = !0, typeof MessageChannel > "u" && console.error(
                "This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."
              ));
              var c = new MessageChannel();
              c.port1.onmessage = u, c.port2.postMessage(void 0);
            };
          }
        return pe(e);
      }
      function M(e) {
        return 1 < e.length && typeof AggregateError == "function" ? new AggregateError(e) : e[0];
      }
      function C(e, r) {
        r !== _e - 1 && console.error(
          "You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "
        ), _e = r;
      }
      function Y(e, r, o) {
        var u = _.actQueue;
        if (u !== null)
          if (u.length !== 0)
            try {
              V(u), U(function() {
                return Y(e, r, o);
              });
              return;
            } catch (c) {
              _.thrownErrors.push(c);
            }
          else _.actQueue = null;
        0 < _.thrownErrors.length ? (u = M(_.thrownErrors), _.thrownErrors.length = 0, o(u)) : r(e);
      }
      function V(e) {
        if (!ge) {
          ge = !0;
          var r = 0;
          try {
            for (; r < e.length; r++) {
              var o = e[r];
              do {
                _.didUsePromise = !1;
                var u = o(!1);
                if (u !== null) {
                  if (_.didUsePromise) {
                    e[r] = o, e.splice(0, r);
                    return;
                  }
                  o = u;
                } else break;
              } while (!0);
            }
            e.length = 0;
          } catch (c) {
            e.splice(0, r + 1), _.thrownErrors.push(c);
          } finally {
            ge = !1;
          }
        }
      }
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var W = Symbol.for("react.transitional.element"), oe = Symbol.for("react.portal"), t = Symbol.for("react.fragment"), n = Symbol.for("react.strict_mode"), s = Symbol.for("react.profiler"), a = Symbol.for("react.consumer"), p = Symbol.for("react.context"), v = Symbol.for("react.forward_ref"), l = Symbol.for("react.suspense"), k = Symbol.for("react.suspense_list"), S = Symbol.for("react.memo"), q = Symbol.for("react.lazy"), be = Symbol.for("react.activity"), Re = Symbol.iterator, we = {}, Te = {
        isMounted: function() {
          return !1;
        },
        enqueueForceUpdate: function(e) {
          T(e, "forceUpdate");
        },
        enqueueReplaceState: function(e) {
          T(e, "replaceState");
        },
        enqueueSetState: function(e) {
          T(e, "setState");
        }
      }, Se = Object.assign, he = {};
      Object.freeze(he), O.prototype.isReactComponent = {}, O.prototype.setState = function(e, r) {
        if (typeof e != "object" && typeof e != "function" && e != null)
          throw Error(
            "takes an object of state variables to update or a function which returns an object of state variables."
          );
        this.updater.enqueueSetState(this, e, r, "setState");
      }, O.prototype.forceUpdate = function(e) {
        this.updater.enqueueForceUpdate(this, e, "forceUpdate");
      };
      var j = {
        isMounted: [
          "isMounted",
          "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."
        ],
        replaceState: [
          "replaceState",
          "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."
        ]
      };
      for (ie in j)
        j.hasOwnProperty(ie) && x(ie, j[ie]);
      L.prototype = O.prototype, j = P.prototype = new L(), j.constructor = P, Se(j, O.prototype), j.isPureReactComponent = !0;
      var Oe = Array.isArray, $e = Symbol.for("react.client.reference"), _ = {
        H: null,
        A: null,
        T: null,
        S: null,
        actQueue: null,
        asyncTransitions: 0,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      }, de = Object.prototype.hasOwnProperty, ke = console.createTask ? console.createTask : function() {
        return null;
      };
      j = {
        react_stack_bottom_frame: function(e) {
          return e();
        }
      };
      var Ae, Ce, je = {}, Be = j.react_stack_bottom_frame.bind(
        j,
        B
      )(), Ge = ke($(B)), xe = !1, Pe = /\/+/g, Ne = typeof reportError == "function" ? reportError : function(e) {
        if (typeof window == "object" && typeof window.ErrorEvent == "function") {
          var r = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
            error: e
          });
          if (!window.dispatchEvent(r)) return;
        } else if (typeof process == "object" && typeof process.emit == "function") {
          process.emit("uncaughtException", e);
          return;
        }
        console.error(e);
      }, Me = !1, pe = null, _e = 0, me = !1, ge = !1, Ye = typeof queueMicrotask == "function" ? function(e) {
        queueMicrotask(function() {
          return queueMicrotask(e);
        });
      } : U;
      j = Object.freeze({
        __proto__: null,
        c: function(e) {
          return b().useMemoCache(e);
        }
      });
      var ie = {
        map: X,
        forEach: function(e, r, o) {
          X(
            e,
            function() {
              r.apply(this, arguments);
            },
            o
          );
        },
        count: function(e) {
          var r = 0;
          return X(e, function() {
            r++;
          }), r;
        },
        toArray: function(e) {
          return X(e, function(r) {
            return r;
          }) || [];
        },
        only: function(e) {
          if (!N(e))
            throw Error(
              "React.Children.only expected to receive a single React element child."
            );
          return e;
        }
      };
      i.Activity = be, i.Children = ie, i.Component = O, i.Fragment = t, i.Profiler = s, i.PureComponent = P, i.StrictMode = n, i.Suspense = l, i.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = _, i.__COMPILER_RUNTIME = j, i.act = function(e) {
        var r = _.actQueue, o = _e;
        _e++;
        var u = _.actQueue = r !== null ? r : [], c = !1;
        try {
          var m = e();
        } catch (y) {
          _.thrownErrors.push(y);
        }
        if (0 < _.thrownErrors.length)
          throw C(r, o), e = M(_.thrownErrors), _.thrownErrors.length = 0, e;
        if (m !== null && typeof m == "object" && typeof m.then == "function") {
          var d = m;
          return Ye(function() {
            c || me || (me = !0, console.error(
              "You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"
            ));
          }), {
            then: function(y, Z) {
              c = !0, d.then(
                function(ae) {
                  if (C(r, o), o === 0) {
                    try {
                      V(u), U(function() {
                        return Y(
                          ae,
                          y,
                          Z
                        );
                      });
                    } catch (Qe) {
                      _.thrownErrors.push(Qe);
                    }
                    if (0 < _.thrownErrors.length) {
                      var Fe = M(
                        _.thrownErrors
                      );
                      _.thrownErrors.length = 0, Z(Fe);
                    }
                  } else y(ae);
                },
                function(ae) {
                  C(r, o), 0 < _.thrownErrors.length && (ae = M(
                    _.thrownErrors
                  ), _.thrownErrors.length = 0), Z(ae);
                }
              );
            }
          };
        }
        var R = m;
        if (C(r, o), o === 0 && (V(u), u.length !== 0 && Ye(function() {
          c || me || (me = !0, console.error(
            "A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"
          ));
        }), _.actQueue = null), 0 < _.thrownErrors.length)
          throw e = M(_.thrownErrors), _.thrownErrors.length = 0, e;
        return {
          then: function(y, Z) {
            c = !0, o === 0 ? (_.actQueue = u, U(function() {
              return Y(
                R,
                y,
                Z
              );
            })) : y(R);
          }
        };
      }, i.cache = function(e) {
        return function() {
          return e.apply(null, arguments);
        };
      }, i.cacheSignal = function() {
        return null;
      }, i.captureOwnerStack = function() {
        var e = _.getCurrentStack;
        return e === null ? null : e();
      }, i.cloneElement = function(e, r, o) {
        if (e == null)
          throw Error(
            "The argument must be a React element, but you passed " + e + "."
          );
        var u = Se({}, e.props), c = e.key, m = e._owner;
        if (r != null) {
          var d;
          e: {
            if (de.call(r, "ref") && (d = Object.getOwnPropertyDescriptor(
              r,
              "ref"
            ).get) && d.isReactWarning) {
              d = !1;
              break e;
            }
            d = r.ref !== void 0;
          }
          d && (m = H()), ee(r) && (D(r.key), c = "" + r.key);
          for (R in r)
            !de.call(r, R) || R === "key" || R === "__self" || R === "__source" || R === "ref" && r.ref === void 0 || (u[R] = r[R]);
        }
        var R = arguments.length - 2;
        if (R === 1) u.children = o;
        else if (1 < R) {
          d = Array(R);
          for (var y = 0; y < R; y++)
            d[y] = arguments[y + 2];
          u.children = d;
        }
        for (u = F(
          e.type,
          c,
          u,
          m,
          e._debugStack,
          e._debugTask
        ), c = 2; c < arguments.length; c++)
          Q(arguments[c]);
        return u;
      }, i.createContext = function(e) {
        return e = {
          $$typeof: p,
          _currentValue: e,
          _currentValue2: e,
          _threadCount: 0,
          Provider: null,
          Consumer: null
        }, e.Provider = e, e.Consumer = {
          $$typeof: a,
          _context: e
        }, e._currentRenderer = null, e._currentRenderer2 = null, e;
      }, i.createElement = function(e, r, o) {
        for (var u = 2; u < arguments.length; u++)
          Q(arguments[u]);
        u = {};
        var c = null;
        if (r != null)
          for (y in Ce || !("__self" in r) || "key" in r || (Ce = !0, console.warn(
            "Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform"
          )), ee(r) && (D(r.key), c = "" + r.key), r)
            de.call(r, y) && y !== "key" && y !== "__self" && y !== "__source" && (u[y] = r[y]);
        var m = arguments.length - 2;
        if (m === 1) u.children = o;
        else if (1 < m) {
          for (var d = Array(m), R = 0; R < m; R++)
            d[R] = arguments[R + 2];
          Object.freeze && Object.freeze(d), u.children = d;
        }
        if (e && e.defaultProps)
          for (y in m = e.defaultProps, m)
            u[y] === void 0 && (u[y] = m[y]);
        c && G(
          u,
          typeof e == "function" ? e.displayName || e.name || "Unknown" : e
        );
        var y = 1e4 > _.recentlyCreatedOwnerStacks++;
        return F(
          e,
          c,
          u,
          H(),
          y ? Error("react-stack-top-frame") : Be,
          y ? ke($(e)) : Ge
        );
      }, i.createRef = function() {
        var e = { current: null };
        return Object.seal(e), e;
      }, i.forwardRef = function(e) {
        e != null && e.$$typeof === S ? console.error(
          "forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...))."
        ) : typeof e != "function" ? console.error(
          "forwardRef requires a render function but was given %s.",
          e === null ? "null" : typeof e
        ) : e.length !== 0 && e.length !== 2 && console.error(
          "forwardRef render functions accept exactly two parameters: props and ref. %s",
          e.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."
        ), e != null && e.defaultProps != null && console.error(
          "forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?"
        );
        var r = { $$typeof: v, render: e }, o;
        return Object.defineProperty(r, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return o;
          },
          set: function(u) {
            o = u, e.name || e.displayName || (Object.defineProperty(e, "name", { value: u }), e.displayName = u);
          }
        }), r;
      }, i.isValidElement = N, i.lazy = function(e) {
        e = { _status: -1, _result: e };
        var r = {
          $$typeof: q,
          _payload: e,
          _init: ne
        }, o = {
          name: "lazy",
          start: -1,
          end: -1,
          value: null,
          owner: null,
          debugStack: Error("react-stack-top-frame"),
          debugTask: console.createTask ? console.createTask("lazy()") : null
        };
        return e._ioInfo = o, r._debugInfo = [{ awaited: o }], r;
      }, i.memo = function(e, r) {
        e == null && console.error(
          "memo: The first argument must be a component. Instead received: %s",
          e === null ? "null" : typeof e
        ), r = {
          $$typeof: S,
          type: e,
          compare: r === void 0 ? null : r
        };
        var o;
        return Object.defineProperty(r, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return o;
          },
          set: function(u) {
            o = u, e.name || e.displayName || (Object.defineProperty(e, "name", { value: u }), e.displayName = u);
          }
        }), r;
      }, i.startTransition = function(e) {
        var r = _.T, o = {};
        o._updatedFibers = /* @__PURE__ */ new Set(), _.T = o;
        try {
          var u = e(), c = _.S;
          c !== null && c(o, u), typeof u == "object" && u !== null && typeof u.then == "function" && (_.asyncTransitions++, u.then(K, K), u.then(J, Ne));
        } catch (m) {
          Ne(m);
        } finally {
          r === null && o._updatedFibers && (e = o._updatedFibers.size, o._updatedFibers.clear(), 10 < e && console.warn(
            "Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."
          )), r !== null && o.types !== null && (r.types !== null && r.types !== o.types && console.error(
            "We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."
          ), r.types = o.types), _.T = r;
        }
      }, i.unstable_useCacheRefresh = function() {
        return b().useCacheRefresh();
      }, i.use = function(e) {
        return b().use(e);
      }, i.useActionState = function(e, r, o) {
        return b().useActionState(
          e,
          r,
          o
        );
      }, i.useCallback = function(e, r) {
        return b().useCallback(e, r);
      }, i.useContext = function(e) {
        var r = b();
        return e.$$typeof === a && console.error(
          "Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?"
        ), r.useContext(e);
      }, i.useDebugValue = function(e, r) {
        return b().useDebugValue(e, r);
      }, i.useDeferredValue = function(e, r) {
        return b().useDeferredValue(e, r);
      }, i.useEffect = function(e, r) {
        return e == null && console.warn(
          "React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), b().useEffect(e, r);
      }, i.useEffectEvent = function(e) {
        return b().useEffectEvent(e);
      }, i.useId = function() {
        return b().useId();
      }, i.useImperativeHandle = function(e, r, o) {
        return b().useImperativeHandle(e, r, o);
      }, i.useInsertionEffect = function(e, r) {
        return e == null && console.warn(
          "React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), b().useInsertionEffect(e, r);
      }, i.useLayoutEffect = function(e, r) {
        return e == null && console.warn(
          "React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), b().useLayoutEffect(e, r);
      }, i.useMemo = function(e, r) {
        return b().useMemo(e, r);
      }, i.useOptimistic = function(e, r) {
        return b().useOptimistic(e, r);
      }, i.useReducer = function(e, r, o) {
        return b().useReducer(e, r, o);
      }, i.useRef = function(e) {
        return b().useRef(e);
      }, i.useState = function(e) {
        return b().useState(e);
      }, i.useSyncExternalStore = function(e, r, o) {
        return b().useSyncExternalStore(
          e,
          r,
          o
        );
      }, i.useTransition = function() {
        return b().useTransition();
      }, i.version = "19.2.4", typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    })();
  })(fe, fe.exports)), fe.exports;
}
var Ue;
function qe() {
  return Ue || (Ue = 1, process.env.NODE_ENV === "production" ? ve.exports = Ve() : ve.exports = Ze()), ve.exports;
}
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var ze;
function Je() {
  return ze || (ze = 1, process.env.NODE_ENV !== "production" && (function() {
    function w(t) {
      if (t == null) return null;
      if (typeof t == "function")
        return t.$$typeof === ne ? null : t.displayName || t.name || null;
      if (typeof t == "string") return t;
      switch (t) {
        case G:
          return "Fragment";
        case F:
          return "Profiler";
        case I:
          return "StrictMode";
        case re:
          return "Suspense";
        case h:
          return "SuspenseList";
        case X:
          return "Activity";
      }
      if (typeof t == "object")
        switch (typeof t.tag == "number" && console.error(
          "Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."
        ), t.$$typeof) {
          case ee:
            return "Portal";
          case Q:
            return t.displayName || "Context";
          case te:
            return (t._context.displayName || "Context") + ".Consumer";
          case N:
            var n = t.render;
            return t = t.displayName, t || (t = n.displayName || n.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
          case se:
            return n = t.displayName || null, n !== null ? n : w(t.type) || "Memo";
          case A:
            n = t._payload, t = t._init;
            try {
              return w(t(n));
            } catch {
            }
        }
      return null;
    }
    function i(t) {
      return "" + t;
    }
    function x(t) {
      try {
        i(t);
        var n = !1;
      } catch {
        n = !0;
      }
      if (n) {
        n = console;
        var s = n.error, a = typeof Symbol == "function" && Symbol.toStringTag && t[Symbol.toStringTag] || t.constructor.name || "Object";
        return s.call(
          n,
          "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",
          a
        ), i(t);
      }
    }
    function g(t) {
      if (t === G) return "<>";
      if (typeof t == "object" && t !== null && t.$$typeof === A)
        return "<...>";
      try {
        var n = w(t);
        return n ? "<" + n + ">" : "<...>";
      } catch {
        return "<...>";
      }
    }
    function T() {
      var t = b.A;
      return t === null ? null : t.getOwner();
    }
    function O() {
      return Error("react-stack-top-frame");
    }
    function L(t) {
      if (K.call(t, "key")) {
        var n = Object.getOwnPropertyDescriptor(t, "key").get;
        if (n && n.isReactWarning) return !1;
      }
      return t.key !== void 0;
    }
    function P(t, n) {
      function s() {
        C || (C = !0, console.error(
          "%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",
          n
        ));
      }
      s.isReactWarning = !0, Object.defineProperty(t, "key", {
        get: s,
        configurable: !0
      });
    }
    function J() {
      var t = w(this.type);
      return Y[t] || (Y[t] = !0, console.error(
        "Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."
      )), t = this.props.ref, t !== void 0 ? t : null;
    }
    function ue(t, n, s, a, p, v) {
      var l = s.ref;
      return t = {
        $$typeof: B,
        type: t,
        key: n,
        props: s,
        _owner: a
      }, (l !== void 0 ? l : null) !== null ? Object.defineProperty(t, "ref", {
        enumerable: !1,
        get: J
      }) : Object.defineProperty(t, "ref", { enumerable: !1, value: null }), t._store = {}, Object.defineProperty(t._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      }), Object.defineProperty(t, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      }), Object.defineProperty(t, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: p
      }), Object.defineProperty(t, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: v
      }), Object.freeze && (Object.freeze(t.props), Object.freeze(t)), t;
    }
    function D(t, n, s, a, p, v) {
      var l = n.children;
      if (l !== void 0)
        if (a)
          if (U(l)) {
            for (a = 0; a < l.length; a++)
              z(l[a]);
            Object.freeze && Object.freeze(l);
          } else
            console.error(
              "React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead."
            );
        else z(l);
      if (K.call(n, "key")) {
        l = w(t);
        var k = Object.keys(n).filter(function(q) {
          return q !== "key";
        });
        a = 0 < k.length ? "{key: someKey, " + k.join(": ..., ") + ": ...}" : "{key: someKey}", oe[l + a] || (k = 0 < k.length ? "{" + k.join(": ..., ") + ": ...}" : "{}", console.error(
          `A props object containing a "key" prop is being spread into JSX:
  let props = %s;
  <%s {...props} />
React keys must be passed directly to JSX without using spread:
  let props = %s;
  <%s key={someKey} {...props} />`,
          a,
          l,
          k,
          l
        ), oe[l + a] = !0);
      }
      if (l = null, s !== void 0 && (x(s), l = "" + s), L(n) && (x(n.key), l = "" + n.key), "key" in n) {
        s = {};
        for (var S in n)
          S !== "key" && (s[S] = n[S]);
      } else s = n;
      return l && P(
        s,
        typeof t == "function" ? t.displayName || t.name || "Unknown" : t
      ), ue(
        t,
        l,
        s,
        T(),
        p,
        v
      );
    }
    function z(t) {
      $(t) ? t._store && (t._store.validated = 1) : typeof t == "object" && t !== null && t.$$typeof === A && (t._payload.status === "fulfilled" ? $(t._payload.value) && t._payload.value._store && (t._payload.value._store.validated = 1) : t._store && (t._store.validated = 1));
    }
    function $(t) {
      return typeof t == "object" && t !== null && t.$$typeof === B;
    }
    var H = qe(), B = Symbol.for("react.transitional.element"), ee = Symbol.for("react.portal"), G = Symbol.for("react.fragment"), I = Symbol.for("react.strict_mode"), F = Symbol.for("react.profiler"), te = Symbol.for("react.consumer"), Q = Symbol.for("react.context"), N = Symbol.for("react.forward_ref"), re = Symbol.for("react.suspense"), h = Symbol.for("react.suspense_list"), se = Symbol.for("react.memo"), A = Symbol.for("react.lazy"), X = Symbol.for("react.activity"), ne = Symbol.for("react.client.reference"), b = H.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, K = Object.prototype.hasOwnProperty, U = Array.isArray, M = console.createTask ? console.createTask : function() {
      return null;
    };
    H = {
      react_stack_bottom_frame: function(t) {
        return t();
      }
    };
    var C, Y = {}, V = H.react_stack_bottom_frame.bind(
      H,
      O
    )(), W = M(g(O)), oe = {};
    le.Fragment = G, le.jsx = function(t, n, s) {
      var a = 1e4 > b.recentlyCreatedOwnerStacks++;
      return D(
        t,
        n,
        s,
        !1,
        a ? Error("react-stack-top-frame") : V,
        a ? M(g(t)) : W
      );
    }, le.jsxs = function(t, n, s) {
      var a = 1e4 > b.recentlyCreatedOwnerStacks++;
      return D(
        t,
        n,
        s,
        !0,
        a ? Error("react-stack-top-frame") : V,
        a ? M(g(t)) : W
      );
    };
  })()), le;
}
var He;
function et() {
  return He || (He = 1, process.env.NODE_ENV === "production" ? ye.exports = Ke() : ye.exports = Je()), ye.exports;
}
var E = et(), We = qe();
const Ee = Xe();
function rt() {
  const [w, i] = We.useState({
    modifier: "alt_option",
    apiBaseUrl: Ee,
    saved: !1
  });
  We.useEffect(() => {
    chrome.storage.sync.get(["flow_reader_modifier", "flow_reader_api_base_url"]).then((g) => {
      i((T) => ({
        ...T,
        modifier: g.flow_reader_modifier || "alt_option",
        apiBaseUrl: g.flow_reader_api_base_url || Ee
      }));
    });
  }, []);
  const x = async () => {
    await chrome.storage.sync.set({
      flow_reader_modifier: w.modifier,
      flow_reader_api_base_url: w.apiBaseUrl
    }), i((g) => ({ ...g, saved: !0 })), setTimeout(() => i((g) => ({ ...g, saved: !1 })), 2e3);
  };
  return /* @__PURE__ */ E.jsx("div", { style: {
    fontFamily: "'Pretendard Variable', 'Pretendard', system-ui, sans-serif",
    background: "#0a0a0f",
    minHeight: "100vh",
    color: "#f4f4f5",
    padding: "40px 20px"
  }, children: /* @__PURE__ */ E.jsxs("div", { style: { maxWidth: "480px", margin: "0 auto" }, children: [
    /* @__PURE__ */ E.jsxs("div", { style: { marginBottom: "32px" }, children: [
      /* @__PURE__ */ E.jsxs("div", { style: {
        display: "inline-flex",
        alignItems: "center",
        gap: "10px",
        marginBottom: "8px"
      }, children: [
        /* @__PURE__ */ E.jsx("div", { style: {
          width: "32px",
          height: "32px",
          borderRadius: "10px",
          background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "16px"
        }, children: "📖" }),
        /* @__PURE__ */ E.jsx("h1", { style: { margin: 0, fontSize: "20px", fontWeight: 900 }, children: "Flow Reader 설정" })
      ] }),
      /* @__PURE__ */ E.jsx("p", { style: { margin: 0, color: "#71717a", fontSize: "14px" }, children: "단축키 및 서버 주소를 설정하세요." })
    ] }),
    /* @__PURE__ */ E.jsxs("div", { style: {
      background: "rgba(255,255,255,0.04)",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: "16px",
      padding: "24px",
      marginBottom: "16px"
    }, children: [
      /* @__PURE__ */ E.jsx("h2", { style: { margin: "0 0 6px 0", fontSize: "16px", fontWeight: 700 }, children: "🎯 단어 조회 단축키" }),
      /* @__PURE__ */ E.jsx("p", { style: { margin: "0 0 20px 0", color: "#71717a", fontSize: "13px" }, children: "이 키를 누른 상태에서 단어 위에 마우스를 올리면 뜻이 표시됩니다." }),
      /* @__PURE__ */ E.jsx("div", { style: { display: "flex", flexDirection: "column", gap: "10px" }, children: [
        {
          value: "alt_option",
          label: "Alt / Option 키",
          desc: "Windows: Alt | Mac: Option",
          icon: "⌥"
        },
        {
          value: "cmd_ctrl",
          label: "Cmd / Ctrl 키",
          desc: "Windows: Ctrl | Mac: Cmd",
          icon: "⌘"
        }
      ].map((g) => /* @__PURE__ */ E.jsxs(
        "label",
        {
          style: {
            display: "flex",
            alignItems: "center",
            gap: "14px",
            padding: "14px 16px",
            borderRadius: "12px",
            cursor: "pointer",
            background: w.modifier === g.value ? "rgba(99,102,241,0.15)" : "rgba(255,255,255,0.03)",
            border: `1px solid ${w.modifier === g.value ? "rgba(99,102,241,0.5)" : "rgba(255,255,255,0.06)"}`,
            transition: "all 0.15s ease"
          },
          children: [
            /* @__PURE__ */ E.jsx(
              "input",
              {
                type: "radio",
                name: "modifier",
                value: g.value,
                checked: w.modifier === g.value,
                onChange: () => i((T) => ({ ...T, modifier: g.value })),
                style: { display: "none" }
              }
            ),
            /* @__PURE__ */ E.jsx("div", { style: {
              width: "40px",
              height: "40px",
              borderRadius: "10px",
              flexShrink: 0,
              background: w.modifier === g.value ? "rgba(99,102,241,0.25)" : "rgba(255,255,255,0.06)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "20px"
            }, children: g.icon }),
            /* @__PURE__ */ E.jsxs("div", { children: [
              /* @__PURE__ */ E.jsx("div", { style: { fontWeight: 700, fontSize: "14px" }, children: g.label }),
              /* @__PURE__ */ E.jsx("div", { style: { color: "#71717a", fontSize: "12px", marginTop: "2px" }, children: g.desc })
            ] }),
            w.modifier === g.value && /* @__PURE__ */ E.jsx("div", { style: { marginLeft: "auto", color: "#818cf8", fontSize: "18px" }, children: "✓" })
          ]
        },
        g.value
      )) })
    ] }),
    /* @__PURE__ */ E.jsxs("div", { style: {
      background: "rgba(255,255,255,0.04)",
      border: "1px solid rgba(255,255,255,0.08)",
      borderRadius: "16px",
      padding: "24px",
      marginBottom: "24px"
    }, children: [
      /* @__PURE__ */ E.jsx("h2", { style: { margin: "0 0 6px 0", fontSize: "16px", fontWeight: 700 }, children: "🌐 서버 주소" }),
      /* @__PURE__ */ E.jsx("p", { style: { margin: "0 0 16px 0", color: "#71717a", fontSize: "13px" }, children: "Flow Reader 서버의 주소를 입력하세요." }),
      /* @__PURE__ */ E.jsx(
        "input",
        {
          type: "url",
          value: w.apiBaseUrl,
          onChange: (g) => i((T) => ({ ...T, apiBaseUrl: g.target.value })),
          placeholder: "http://localhost:3000",
          style: {
            width: "100%",
            boxSizing: "border-box",
            padding: "12px 14px",
            borderRadius: "10px",
            background: "rgba(255,255,255,0.06)",
            border: "1px solid rgba(255,255,255,0.1)",
            color: "#f4f4f5",
            fontSize: "14px",
            outline: "none",
            fontFamily: "monospace"
          }
        }
      ),
      /* @__PURE__ */ E.jsxs("p", { style: { margin: "8px 0 0 0", color: "#52525b", fontSize: "12px" }, children: [
        "기본값: ",
        Ee
      ] })
    ] }),
    /* @__PURE__ */ E.jsx(
      "button",
      {
        onClick: x,
        style: {
          width: "100%",
          padding: "14px",
          borderRadius: "14px",
          background: w.saved ? "rgba(16,185,129,0.8)" : "linear-gradient(135deg, #6366f1, #8b5cf6)",
          color: "white",
          fontWeight: 700,
          fontSize: "15px",
          border: "none",
          cursor: "pointer",
          transition: "all 0.2s ease",
          boxShadow: "0 0 30px rgba(99,102,241,0.3)"
        },
        children: w.saved ? "✓ 저장되었습니다!" : "설정 저장"
      }
    ),
    /* @__PURE__ */ E.jsx("div", { style: {
      marginTop: "24px",
      padding: "16px",
      borderRadius: "12px",
      background: "rgba(99,102,241,0.08)",
      border: "1px solid rgba(99,102,241,0.2)"
    }, children: /* @__PURE__ */ E.jsxs("p", { style: { margin: 0, fontSize: "13px", color: "#a5b4fc", lineHeight: 1.6 }, children: [
      "💡 ",
      /* @__PURE__ */ E.jsx("strong", { children: "사용법:" }),
      " 영어 웹페이지에서 선택한 키를 누른 채로",
      /* @__PURE__ */ E.jsx("br", {}),
      "모르는 단어 위에 마우스를 0.2초 올려두면 뜻이 팝업으로 표시됩니다."
    ] }) })
  ] }) });
}
export {
  rt as default
};
