const l = "http://localhost:3000";
function s(n) {
  return null;
}
function a(n) {
  try {
    const r = new URL(n);
    return r.hostname === "localhost" || r.hostname === "127.0.0.1";
  } catch {
    return !1;
  }
}
function u(n, r, t = "3000") {
  const e = n?.trim(), i = r?.trim();
  return !e || !i ? null : `https://${e}-${t}.${i}`;
}
function o(n, r, t) {
  const e = s(), i = u(
    r,
    t
  );
  return e && !a(e) ? e : i || (e ?? l);
}
function c(n, r, t, e) {
  const i = s();
  return i && !a(i) ? i : u(t, e) ?? i ?? o(r, t, e);
}
function p(n, r, t) {
  return [o(n, r, t)];
}
function f(n, r, t) {
  return `${o(n, r, t)}/wordbook`;
}
export {
  c as a,
  f as b,
  p as g,
  o as r
};
