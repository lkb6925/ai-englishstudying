import { r as y, a as g } from "./app-config-DuchQk2N.js";
const n = {
  appUrl: "flow_reader_app_url",
  apiBaseUrl: "flow_reader_api_base_url",
  modifier: "flow_reader_modifier",
  jwt: "supabase_jwt",
  guestStats: "flow_reader_guest_stats"
};
async function u(e, t) {
  return (await e.get(t))[t] ?? null;
}
async function l(e, t, o) {
  await e.set({ [t]: o });
}
async function p(e, t) {
  await e.remove(t);
}
const _ = y(
  void 0,
  "",
  ""
);
async function k() {
  const e = await u(
    chrome.storage.sync,
    n.appUrl
  );
  return typeof e == "string" && e.trim().length > 0 ? e.trim().replace(/\/$/, "") : _;
}
const w = g(
  void 0,
  void 0,
  "",
  ""
);
function L(e) {
  chrome.runtime.sendMessage({
    type: "FLOW_MODIFIER_CHANGED",
    payload: { modifier: e }
  }).catch(() => {
  });
}
function S(e) {
  return Array.isArray(e) && e.every((t) => typeof t == "string");
}
function A(e) {
  return !e || typeof e != "object" ? !1 : S(e.contextual_meanings);
}
function O(e) {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.persisted != "boolean" || typeof t.promoted != "boolean" || typeof t.totalLookupCount != "number" ? !1 : t.reason === void 0 || t.reason === "unauthorized" || t.reason === "excluded_domain";
}
async function v(e, t) {
  try {
    const o = await e.json();
    if (typeof o.error == "string" && o.error.length > 0)
      return o.error;
    if (typeof o.details == "string" && o.details.length > 0)
      return o.details;
  } catch {
  }
  return t;
}
async function h() {
  const e = await u(
    chrome.storage.sync,
    n.apiBaseUrl
  );
  return typeof e == "string" && e.length > 0 ? e.replace(/\/$/, "") : w;
}
async function C() {
  const e = await u(
    chrome.storage.session,
    n.jwt
  );
  if (typeof e == "string" && e.length > 0)
    return e;
  const t = await u(
    chrome.storage.local,
    n.jwt
  );
  return typeof t == "string" && t.length > 0 ? t : null;
}
async function j() {
  const e = await C(), t = { "Content-Type": "application/json" };
  return e && (t.Authorization = `Bearer ${e}`), t;
}
async function U() {
  const e = await u(
    chrome.storage.local,
    n.guestStats
  );
  if (typeof e != "object" || e === null)
    return { total: 0, terms: {}, shownCount: 0 };
  const t = e;
  return {
    total: typeof t.total == "number" ? t.total : 0,
    terms: typeof t.terms == "object" && t.terms !== null ? t.terms : {},
    shownCount: typeof t.shownCount == "number" ? t.shownCount : 0
  };
}
function b(e, t, o, a) {
  return o >= 3 || !(e >= 25 || t >= 3 || e >= 10) ? null : t >= 3 ? `'${a}'를 ${t}번 다시 찾았습니다` : `🚨 ${e}개는 아직 익숙하지 않습니다`;
}
async function E(e) {
  const t = e.toLowerCase().trim(), o = await U(), a = (o.terms[t] ?? 0) + 1, r = o.total + 1, s = b(
    r,
    a,
    o.shownCount,
    e
  );
  return await l(chrome.storage.local, n.guestStats, {
    total: r,
    terms: { ...o.terms, [t]: a },
    shownCount: s ? o.shownCount + 1 : o.shownCount
  }), { total: r, termCount: a, fomoMessage: s };
}
async function T(e) {
  const t = await h(), o = await j(), a = await fetch(`${t}/api/lookup`, {
    method: "POST",
    headers: o,
    body: JSON.stringify({ word: e.word, sentence: e.sentence })
  });
  if (!a.ok)
    return {
      ok: !1,
      error: {
        message: await v(
          a,
          `Lookup failed with status ${a.status}`
        )
      }
    };
  const r = await a.json();
  if (!A(r))
    return {
      ok: !1,
      error: { message: "Lookup response shape was invalid." }
    };
  const s = r, c = await fetch(`${t}/api/lookup-event`, {
    method: "POST",
    headers: o,
    body: JSON.stringify({
      term: e.term,
      context: e.context,
      meanings: s.contextual_meanings,
      sourceDomain: e.sourceDomain,
      sourcePathHash: e.sourcePathHash
    })
  });
  let i = null, d = null;
  if (c.ok) {
    const f = await c.json();
    O(f) ? i = f : console.warn("AI English Study lookup-event response shape was invalid.", f), i && !i.persisted && i.reason === "unauthorized" && (d = await E(e.term));
  }
  return {
    ok: !0,
    data: {
      meanings: s.contextual_meanings,
      lookupEvent: i,
      guestStats: d
    }
  };
}
async function m() {
  const e = await u(
    chrome.storage.sync,
    n.modifier
  );
  return e === "cmd_ctrl" || e === "alt_option" ? e : "alt_option";
}
async function F() {
  await p(chrome.storage.session, n.jwt), await p(chrome.storage.local, n.jwt);
}
chrome.storage.onChanged.addListener((e, t) => {
  if (t !== "sync")
    return;
  const o = e[n.modifier];
  if (!o)
    return;
  const a = o.newValue;
  (a === "alt_option" || a === "cmd_ctrl") && L(a);
});
chrome.runtime.onMessage.addListener(
  (e, t, o) => ((async (r) => {
    if (r.type === "FLOW_LOOKUP")
      return T(r.payload);
    if (r.type === "FLOW_GET_MODIFIER")
      return { ok: !0, data: { modifier: await m() } };
    if (r.type === "FLOW_GET_RUNTIME_CONFIG") {
      const s = await m(), [c, i] = await Promise.all([
        k(),
        h()
      ]);
      return {
        ok: !0,
        data: {
          modifier: s,
          appUrl: c,
          apiBaseUrl: i || w
        }
      };
    }
    return r.type === "FLOW_SET_MODIFIER" ? (await l(
      chrome.storage.sync,
      n.modifier,
      r.payload.modifier
    ), { ok: !0, data: { modifier: r.payload.modifier } }) : r.type === "FLOW_SET_JWT" ? (await l(
      chrome.storage.session,
      n.jwt,
      r.payload.token
    ), await l(
      chrome.storage.local,
      n.jwt,
      r.payload.token
    ), { ok: !0, data: { saved: !0 } }) : r.type === "FLOW_CLEAR_JWT" ? (await F(), { ok: !0, data: { saved: !0 } }) : { ok: !1, error: { message: "Unknown message type." } };
  })(e).then(o).catch((r) => {
    const s = r instanceof Error ? r.message : "Background request failed";
    o({ ok: !1, error: { message: s } });
  }), !0)
);
