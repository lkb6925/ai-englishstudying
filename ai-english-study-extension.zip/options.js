import { a as P1 } from "./app-config-DuchQk2N.js";
var fi = { exports: {} }, re = {};
var oy;
function lm() {
  if (oy) return re;
  oy = 1;
  var A = /* @__PURE__ */ Symbol.for("react.transitional.element"), G = /* @__PURE__ */ Symbol.for("react.fragment");
  function Q(o, C, Z) {
    var ol = null;
    if (Z !== void 0 && (ol = "" + Z), C.key !== void 0 && (ol = "" + C.key), "key" in C) {
      Z = {};
      for (var _l in C)
        _l !== "key" && (Z[_l] = C[_l]);
    } else Z = C;
    return C = Z.ref, {
      $$typeof: A,
      type: o,
      key: ol,
      ref: C !== void 0 ? C : null,
      props: Z
    };
  }
  return re.Fragment = G, re.jsx = Q, re.jsxs = Q, re;
}
var gy;
function tm() {
  return gy || (gy = 1, fi.exports = lm()), fi.exports;
}
var B = tm(), ci = { exports: {} }, q = {};
var Sy;
function am() {
  if (Sy) return q;
  Sy = 1;
  var A = /* @__PURE__ */ Symbol.for("react.transitional.element"), G = /* @__PURE__ */ Symbol.for("react.portal"), Q = /* @__PURE__ */ Symbol.for("react.fragment"), o = /* @__PURE__ */ Symbol.for("react.strict_mode"), C = /* @__PURE__ */ Symbol.for("react.profiler"), Z = /* @__PURE__ */ Symbol.for("react.consumer"), ol = /* @__PURE__ */ Symbol.for("react.context"), _l = /* @__PURE__ */ Symbol.for("react.forward_ref"), U = /* @__PURE__ */ Symbol.for("react.suspense"), T = /* @__PURE__ */ Symbol.for("react.memo"), k = /* @__PURE__ */ Symbol.for("react.lazy"), R = /* @__PURE__ */ Symbol.for("react.activity"), yl = Symbol.iterator;
  function Wl(d) {
    return d === null || typeof d != "object" ? null : (d = yl && d[yl] || d["@@iterator"], typeof d == "function" ? d : null);
  }
  var jl = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, Cl = Object.assign, Dt = {};
  function $l(d, E, M) {
    this.props = d, this.context = E, this.refs = Dt, this.updater = M || jl;
  }
  $l.prototype.isReactComponent = {}, $l.prototype.setState = function(d, E) {
    if (typeof d != "object" && typeof d != "function" && d != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, d, E, "setState");
  }, $l.prototype.forceUpdate = function(d) {
    this.updater.enqueueForceUpdate(this, d, "forceUpdate");
  };
  function $t() {
  }
  $t.prototype = $l.prototype;
  function Rl(d, E, M) {
    this.props = d, this.context = E, this.refs = Dt, this.updater = M || jl;
  }
  var ft = Rl.prototype = new $t();
  ft.constructor = Rl, Cl(ft, $l.prototype), ft.isPureReactComponent = !0;
  var Et = Array.isArray;
  function Yl() {
  }
  var W = { H: null, A: null, T: null, S: null }, Gl = Object.prototype.hasOwnProperty;
  function Tt(d, E, M) {
    var p = M.ref;
    return {
      $$typeof: A,
      type: d,
      key: E,
      ref: p !== void 0 ? p : null,
      props: M
    };
  }
  function Qa(d, E) {
    return Tt(d.type, E, d.props);
  }
  function At(d) {
    return typeof d == "object" && d !== null && d.$$typeof === A;
  }
  function Xl(d) {
    var E = { "=": "=0", ":": "=2" };
    return "$" + d.replace(/[=:]/g, function(M) {
      return E[M];
    });
  }
  var Ea = /\/+/g;
  function Ut(d, E) {
    return typeof d == "object" && d !== null && d.key != null ? Xl("" + d.key) : E.toString(36);
  }
  function St(d) {
    switch (d.status) {
      case "fulfilled":
        return d.value;
      case "rejected":
        throw d.reason;
      default:
        switch (typeof d.status == "string" ? d.then(Yl, Yl) : (d.status = "pending", d.then(
          function(E) {
            d.status === "pending" && (d.status = "fulfilled", d.value = E);
          },
          function(E) {
            d.status === "pending" && (d.status = "rejected", d.reason = E);
          }
        )), d.status) {
          case "fulfilled":
            return d.value;
          case "rejected":
            throw d.reason;
        }
    }
    throw d;
  }
  function b(d, E, M, p, j) {
    var V = typeof d;
    (V === "undefined" || V === "boolean") && (d = null);
    var ll = !1;
    if (d === null) ll = !0;
    else
      switch (V) {
        case "bigint":
        case "string":
        case "number":
          ll = !0;
          break;
        case "object":
          switch (d.$$typeof) {
            case A:
            case G:
              ll = !0;
              break;
            case k:
              return ll = d._init, b(
                ll(d._payload),
                E,
                M,
                p,
                j
              );
          }
      }
    if (ll)
      return j = j(d), ll = p === "" ? "." + Ut(d, 0) : p, Et(j) ? (M = "", ll != null && (M = ll.replace(Ea, "$&/") + "/"), b(j, E, M, "", function(Ou) {
        return Ou;
      })) : j != null && (At(j) && (j = Qa(
        j,
        M + (j.key == null || d && d.key === j.key ? "" : ("" + j.key).replace(
          Ea,
          "$&/"
        ) + "/") + ll
      )), E.push(j)), 1;
    ll = 0;
    var ql = p === "" ? "." : p + ":";
    if (Et(d))
      for (var gl = 0; gl < d.length; gl++)
        p = d[gl], V = ql + Ut(p, gl), ll += b(
          p,
          E,
          M,
          V,
          j
        );
    else if (gl = Wl(d), typeof gl == "function")
      for (d = gl.call(d), gl = 0; !(p = d.next()).done; )
        p = p.value, V = ql + Ut(p, gl++), ll += b(
          p,
          E,
          M,
          V,
          j
        );
    else if (V === "object") {
      if (typeof d.then == "function")
        return b(
          St(d),
          E,
          M,
          p,
          j
        );
      throw E = String(d), Error(
        "Objects are not valid as a React child (found: " + (E === "[object Object]" ? "object with keys {" + Object.keys(d).join(", ") + "}" : E) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return ll;
  }
  function _(d, E, M) {
    if (d == null) return d;
    var p = [], j = 0;
    return b(d, p, "", "", function(V) {
      return E.call(M, V, j++);
    }), p;
  }
  function x(d) {
    if (d._status === -1) {
      var E = d._result;
      E = E(), E.then(
        function(M) {
          (d._status === 0 || d._status === -1) && (d._status = 1, d._result = M);
        },
        function(M) {
          (d._status === 0 || d._status === -1) && (d._status = 2, d._result = M);
        }
      ), d._status === -1 && (d._status = 0, d._result = E);
    }
    if (d._status === 1) return d._result.default;
    throw d._result;
  }
  var ul = typeof reportError == "function" ? reportError : function(d) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var E = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof d == "object" && d !== null && typeof d.message == "string" ? String(d.message) : String(d),
        error: d
      });
      if (!window.dispatchEvent(E)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", d);
      return;
    }
    console.error(d);
  }, cl = {
    map: _,
    forEach: function(d, E, M) {
      _(
        d,
        function() {
          E.apply(this, arguments);
        },
        M
      );
    },
    count: function(d) {
      var E = 0;
      return _(d, function() {
        E++;
      }), E;
    },
    toArray: function(d) {
      return _(d, function(E) {
        return E;
      }) || [];
    },
    only: function(d) {
      if (!At(d))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return d;
    }
  };
  return q.Activity = R, q.Children = cl, q.Component = $l, q.Fragment = Q, q.Profiler = C, q.PureComponent = Rl, q.StrictMode = o, q.Suspense = U, q.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = W, q.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(d) {
      return W.H.useMemoCache(d);
    }
  }, q.cache = function(d) {
    return function() {
      return d.apply(null, arguments);
    };
  }, q.cacheSignal = function() {
    return null;
  }, q.cloneElement = function(d, E, M) {
    if (d == null)
      throw Error(
        "The argument must be a React element, but you passed " + d + "."
      );
    var p = Cl({}, d.props), j = d.key;
    if (E != null)
      for (V in E.key !== void 0 && (j = "" + E.key), E)
        !Gl.call(E, V) || V === "key" || V === "__self" || V === "__source" || V === "ref" && E.ref === void 0 || (p[V] = E[V]);
    var V = arguments.length - 2;
    if (V === 1) p.children = M;
    else if (1 < V) {
      for (var ll = Array(V), ql = 0; ql < V; ql++)
        ll[ql] = arguments[ql + 2];
      p.children = ll;
    }
    return Tt(d.type, j, p);
  }, q.createContext = function(d) {
    return d = {
      $$typeof: ol,
      _currentValue: d,
      _currentValue2: d,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, d.Provider = d, d.Consumer = {
      $$typeof: Z,
      _context: d
    }, d;
  }, q.createElement = function(d, E, M) {
    var p, j = {}, V = null;
    if (E != null)
      for (p in E.key !== void 0 && (V = "" + E.key), E)
        Gl.call(E, p) && p !== "key" && p !== "__self" && p !== "__source" && (j[p] = E[p]);
    var ll = arguments.length - 2;
    if (ll === 1) j.children = M;
    else if (1 < ll) {
      for (var ql = Array(ll), gl = 0; gl < ll; gl++)
        ql[gl] = arguments[gl + 2];
      j.children = ql;
    }
    if (d && d.defaultProps)
      for (p in ll = d.defaultProps, ll)
        j[p] === void 0 && (j[p] = ll[p]);
    return Tt(d, V, j);
  }, q.createRef = function() {
    return { current: null };
  }, q.forwardRef = function(d) {
    return { $$typeof: _l, render: d };
  }, q.isValidElement = At, q.lazy = function(d) {
    return {
      $$typeof: k,
      _payload: { _status: -1, _result: d },
      _init: x
    };
  }, q.memo = function(d, E) {
    return {
      $$typeof: T,
      type: d,
      compare: E === void 0 ? null : E
    };
  }, q.startTransition = function(d) {
    var E = W.T, M = {};
    W.T = M;
    try {
      var p = d(), j = W.S;
      j !== null && j(M, p), typeof p == "object" && p !== null && typeof p.then == "function" && p.then(Yl, ul);
    } catch (V) {
      ul(V);
    } finally {
      E !== null && M.types !== null && (E.types = M.types), W.T = E;
    }
  }, q.unstable_useCacheRefresh = function() {
    return W.H.useCacheRefresh();
  }, q.use = function(d) {
    return W.H.use(d);
  }, q.useActionState = function(d, E, M) {
    return W.H.useActionState(d, E, M);
  }, q.useCallback = function(d, E) {
    return W.H.useCallback(d, E);
  }, q.useContext = function(d) {
    return W.H.useContext(d);
  }, q.useDebugValue = function() {
  }, q.useDeferredValue = function(d, E) {
    return W.H.useDeferredValue(d, E);
  }, q.useEffect = function(d, E) {
    return W.H.useEffect(d, E);
  }, q.useEffectEvent = function(d) {
    return W.H.useEffectEvent(d);
  }, q.useId = function() {
    return W.H.useId();
  }, q.useImperativeHandle = function(d, E, M) {
    return W.H.useImperativeHandle(d, E, M);
  }, q.useInsertionEffect = function(d, E) {
    return W.H.useInsertionEffect(d, E);
  }, q.useLayoutEffect = function(d, E) {
    return W.H.useLayoutEffect(d, E);
  }, q.useMemo = function(d, E) {
    return W.H.useMemo(d, E);
  }, q.useOptimistic = function(d, E) {
    return W.H.useOptimistic(d, E);
  }, q.useReducer = function(d, E, M) {
    return W.H.useReducer(d, E, M);
  }, q.useRef = function(d) {
    return W.H.useRef(d);
  }, q.useState = function(d) {
    return W.H.useState(d);
  }, q.useSyncExternalStore = function(d, E, M) {
    return W.H.useSyncExternalStore(
      d,
      E,
      M
    );
  }, q.useTransition = function() {
    return W.H.useTransition();
  }, q.version = "19.2.5", q;
}
var by;
function mi() {
  return by || (by = 1, ci.exports = am()), ci.exports;
}
var Wt = mi(), ii = { exports: {} }, ze = {}, si = { exports: {} }, di = {};
var ry;
function um() {
  return ry || (ry = 1, (function(A) {
    function G(b, _) {
      var x = b.length;
      b.push(_);
      l: for (; 0 < x; ) {
        var ul = x - 1 >>> 1, cl = b[ul];
        if (0 < C(cl, _))
          b[ul] = _, b[x] = cl, x = ul;
        else break l;
      }
    }
    function Q(b) {
      return b.length === 0 ? null : b[0];
    }
    function o(b) {
      if (b.length === 0) return null;
      var _ = b[0], x = b.pop();
      if (x !== _) {
        b[0] = x;
        l: for (var ul = 0, cl = b.length, d = cl >>> 1; ul < d; ) {
          var E = 2 * (ul + 1) - 1, M = b[E], p = E + 1, j = b[p];
          if (0 > C(M, x))
            p < cl && 0 > C(j, M) ? (b[ul] = j, b[p] = x, ul = p) : (b[ul] = M, b[E] = x, ul = E);
          else if (p < cl && 0 > C(j, x))
            b[ul] = j, b[p] = x, ul = p;
          else break l;
        }
      }
      return _;
    }
    function C(b, _) {
      var x = b.sortIndex - _.sortIndex;
      return x !== 0 ? x : b.id - _.id;
    }
    if (A.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
      var Z = performance;
      A.unstable_now = function() {
        return Z.now();
      };
    } else {
      var ol = Date, _l = ol.now();
      A.unstable_now = function() {
        return ol.now() - _l;
      };
    }
    var U = [], T = [], k = 1, R = null, yl = 3, Wl = !1, jl = !1, Cl = !1, Dt = !1, $l = typeof setTimeout == "function" ? setTimeout : null, $t = typeof clearTimeout == "function" ? clearTimeout : null, Rl = typeof setImmediate < "u" ? setImmediate : null;
    function ft(b) {
      for (var _ = Q(T); _ !== null; ) {
        if (_.callback === null) o(T);
        else if (_.startTime <= b)
          o(T), _.sortIndex = _.expirationTime, G(U, _);
        else break;
        _ = Q(T);
      }
    }
    function Et(b) {
      if (Cl = !1, ft(b), !jl)
        if (Q(U) !== null)
          jl = !0, Yl || (Yl = !0, Xl());
        else {
          var _ = Q(T);
          _ !== null && St(Et, _.startTime - b);
        }
    }
    var Yl = !1, W = -1, Gl = 5, Tt = -1;
    function Qa() {
      return Dt ? !0 : !(A.unstable_now() - Tt < Gl);
    }
    function At() {
      if (Dt = !1, Yl) {
        var b = A.unstable_now();
        Tt = b;
        var _ = !0;
        try {
          l: {
            jl = !1, Cl && (Cl = !1, $t(W), W = -1), Wl = !0;
            var x = yl;
            try {
              t: {
                for (ft(b), R = Q(U); R !== null && !(R.expirationTime > b && Qa()); ) {
                  var ul = R.callback;
                  if (typeof ul == "function") {
                    R.callback = null, yl = R.priorityLevel;
                    var cl = ul(
                      R.expirationTime <= b
                    );
                    if (b = A.unstable_now(), typeof cl == "function") {
                      R.callback = cl, ft(b), _ = !0;
                      break t;
                    }
                    R === Q(U) && o(U), ft(b);
                  } else o(U);
                  R = Q(U);
                }
                if (R !== null) _ = !0;
                else {
                  var d = Q(T);
                  d !== null && St(
                    Et,
                    d.startTime - b
                  ), _ = !1;
                }
              }
              break l;
            } finally {
              R = null, yl = x, Wl = !1;
            }
            _ = void 0;
          }
        } finally {
          _ ? Xl() : Yl = !1;
        }
      }
    }
    var Xl;
    if (typeof Rl == "function")
      Xl = function() {
        Rl(At);
      };
    else if (typeof MessageChannel < "u") {
      var Ea = new MessageChannel(), Ut = Ea.port2;
      Ea.port1.onmessage = At, Xl = function() {
        Ut.postMessage(null);
      };
    } else
      Xl = function() {
        $l(At, 0);
      };
    function St(b, _) {
      W = $l(function() {
        b(A.unstable_now());
      }, _);
    }
    A.unstable_IdlePriority = 5, A.unstable_ImmediatePriority = 1, A.unstable_LowPriority = 4, A.unstable_NormalPriority = 3, A.unstable_Profiling = null, A.unstable_UserBlockingPriority = 2, A.unstable_cancelCallback = function(b) {
      b.callback = null;
    }, A.unstable_forceFrameRate = function(b) {
      0 > b || 125 < b ? console.error(
        "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
      ) : Gl = 0 < b ? Math.floor(1e3 / b) : 5;
    }, A.unstable_getCurrentPriorityLevel = function() {
      return yl;
    }, A.unstable_next = function(b) {
      switch (yl) {
        case 1:
        case 2:
        case 3:
          var _ = 3;
          break;
        default:
          _ = yl;
      }
      var x = yl;
      yl = _;
      try {
        return b();
      } finally {
        yl = x;
      }
    }, A.unstable_requestPaint = function() {
      Dt = !0;
    }, A.unstable_runWithPriority = function(b, _) {
      switch (b) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          b = 3;
      }
      var x = yl;
      yl = b;
      try {
        return _();
      } finally {
        yl = x;
      }
    }, A.unstable_scheduleCallback = function(b, _, x) {
      var ul = A.unstable_now();
      switch (typeof x == "object" && x !== null ? (x = x.delay, x = typeof x == "number" && 0 < x ? ul + x : ul) : x = ul, b) {
        case 1:
          var cl = -1;
          break;
        case 2:
          cl = 250;
          break;
        case 5:
          cl = 1073741823;
          break;
        case 4:
          cl = 1e4;
          break;
        default:
          cl = 5e3;
      }
      return cl = x + cl, b = {
        id: k++,
        callback: _,
        priorityLevel: b,
        startTime: x,
        expirationTime: cl,
        sortIndex: -1
      }, x > ul ? (b.sortIndex = x, G(T, b), Q(U) === null && b === Q(T) && (Cl ? ($t(W), W = -1) : Cl = !0, St(Et, x - ul))) : (b.sortIndex = cl, G(U, b), jl || Wl || (jl = !0, Yl || (Yl = !0, Xl()))), b;
    }, A.unstable_shouldYield = Qa, A.unstable_wrapCallback = function(b) {
      var _ = yl;
      return function() {
        var x = yl;
        yl = _;
        try {
          return b.apply(this, arguments);
        } finally {
          yl = x;
        }
      };
    };
  })(di)), di;
}
var zy;
function em() {
  return zy || (zy = 1, si.exports = um()), si.exports;
}
var yi = { exports: {} }, xl = {};
var Ey;
function nm() {
  if (Ey) return xl;
  Ey = 1;
  var A = mi();
  function G(U) {
    var T = "https://react.dev/errors/" + U;
    if (1 < arguments.length) {
      T += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var k = 2; k < arguments.length; k++)
        T += "&args[]=" + encodeURIComponent(arguments[k]);
    }
    return "Minified React error #" + U + "; visit " + T + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function Q() {
  }
  var o = {
    d: {
      f: Q,
      r: function() {
        throw Error(G(522));
      },
      D: Q,
      C: Q,
      L: Q,
      m: Q,
      X: Q,
      S: Q,
      M: Q
    },
    p: 0,
    findDOMNode: null
  }, C = /* @__PURE__ */ Symbol.for("react.portal");
  function Z(U, T, k) {
    var R = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: C,
      key: R == null ? null : "" + R,
      children: U,
      containerInfo: T,
      implementation: k
    };
  }
  var ol = A.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function _l(U, T) {
    if (U === "font") return "";
    if (typeof T == "string")
      return T === "use-credentials" ? T : "";
  }
  return xl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = o, xl.createPortal = function(U, T) {
    var k = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!T || T.nodeType !== 1 && T.nodeType !== 9 && T.nodeType !== 11)
      throw Error(G(299));
    return Z(U, T, null, k);
  }, xl.flushSync = function(U) {
    var T = ol.T, k = o.p;
    try {
      if (ol.T = null, o.p = 2, U) return U();
    } finally {
      ol.T = T, o.p = k, o.d.f();
    }
  }, xl.preconnect = function(U, T) {
    typeof U == "string" && (T ? (T = T.crossOrigin, T = typeof T == "string" ? T === "use-credentials" ? T : "" : void 0) : T = null, o.d.C(U, T));
  }, xl.prefetchDNS = function(U) {
    typeof U == "string" && o.d.D(U);
  }, xl.preinit = function(U, T) {
    if (typeof U == "string" && T && typeof T.as == "string") {
      var k = T.as, R = _l(k, T.crossOrigin), yl = typeof T.integrity == "string" ? T.integrity : void 0, Wl = typeof T.fetchPriority == "string" ? T.fetchPriority : void 0;
      k === "style" ? o.d.S(
        U,
        typeof T.precedence == "string" ? T.precedence : void 0,
        {
          crossOrigin: R,
          integrity: yl,
          fetchPriority: Wl
        }
      ) : k === "script" && o.d.X(U, {
        crossOrigin: R,
        integrity: yl,
        fetchPriority: Wl,
        nonce: typeof T.nonce == "string" ? T.nonce : void 0
      });
    }
  }, xl.preinitModule = function(U, T) {
    if (typeof U == "string")
      if (typeof T == "object" && T !== null) {
        if (T.as == null || T.as === "script") {
          var k = _l(
            T.as,
            T.crossOrigin
          );
          o.d.M(U, {
            crossOrigin: k,
            integrity: typeof T.integrity == "string" ? T.integrity : void 0,
            nonce: typeof T.nonce == "string" ? T.nonce : void 0
          });
        }
      } else T == null && o.d.M(U);
  }, xl.preload = function(U, T) {
    if (typeof U == "string" && typeof T == "object" && T !== null && typeof T.as == "string") {
      var k = T.as, R = _l(k, T.crossOrigin);
      o.d.L(U, k, {
        crossOrigin: R,
        integrity: typeof T.integrity == "string" ? T.integrity : void 0,
        nonce: typeof T.nonce == "string" ? T.nonce : void 0,
        type: typeof T.type == "string" ? T.type : void 0,
        fetchPriority: typeof T.fetchPriority == "string" ? T.fetchPriority : void 0,
        referrerPolicy: typeof T.referrerPolicy == "string" ? T.referrerPolicy : void 0,
        imageSrcSet: typeof T.imageSrcSet == "string" ? T.imageSrcSet : void 0,
        imageSizes: typeof T.imageSizes == "string" ? T.imageSizes : void 0,
        media: typeof T.media == "string" ? T.media : void 0
      });
    }
  }, xl.preloadModule = function(U, T) {
    if (typeof U == "string")
      if (T) {
        var k = _l(T.as, T.crossOrigin);
        o.d.m(U, {
          as: typeof T.as == "string" && T.as !== "script" ? T.as : void 0,
          crossOrigin: k,
          integrity: typeof T.integrity == "string" ? T.integrity : void 0
        });
      } else o.d.m(U);
  }, xl.requestFormReset = function(U) {
    o.d.r(U);
  }, xl.unstable_batchedUpdates = function(U, T) {
    return U(T);
  }, xl.useFormState = function(U, T, k) {
    return ol.H.useFormState(U, T, k);
  }, xl.useFormStatus = function() {
    return ol.H.useHostTransitionStatus();
  }, xl.version = "19.2.5", xl;
}
var Ty;
function fm() {
  if (Ty) return yi.exports;
  Ty = 1;
  function A() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A);
      } catch (G) {
        console.error(G);
      }
  }
  return A(), yi.exports = nm(), yi.exports;
}
var Ay;
function cm() {
  if (Ay) return ze;
  Ay = 1;
  var A = em(), G = mi(), Q = fm();
  function o(l) {
    var t = "https://react.dev/errors/" + l;
    if (1 < arguments.length) {
      t += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var a = 2; a < arguments.length; a++)
        t += "&args[]=" + encodeURIComponent(arguments[a]);
    }
    return "Minified React error #" + l + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function C(l) {
    return !(!l || l.nodeType !== 1 && l.nodeType !== 9 && l.nodeType !== 11);
  }
  function Z(l) {
    var t = l, a = l;
    if (l.alternate) for (; t.return; ) t = t.return;
    else {
      l = t;
      do
        t = l, (t.flags & 4098) !== 0 && (a = t.return), l = t.return;
      while (l);
    }
    return t.tag === 3 ? a : null;
  }
  function ol(l) {
    if (l.tag === 13) {
      var t = l.memoizedState;
      if (t === null && (l = l.alternate, l !== null && (t = l.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function _l(l) {
    if (l.tag === 31) {
      var t = l.memoizedState;
      if (t === null && (l = l.alternate, l !== null && (t = l.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function U(l) {
    if (Z(l) !== l)
      throw Error(o(188));
  }
  function T(l) {
    var t = l.alternate;
    if (!t) {
      if (t = Z(l), t === null) throw Error(o(188));
      return t !== l ? null : l;
    }
    for (var a = l, u = t; ; ) {
      var e = a.return;
      if (e === null) break;
      var n = e.alternate;
      if (n === null) {
        if (u = e.return, u !== null) {
          a = u;
          continue;
        }
        break;
      }
      if (e.child === n.child) {
        for (n = e.child; n; ) {
          if (n === a) return U(e), l;
          if (n === u) return U(e), t;
          n = n.sibling;
        }
        throw Error(o(188));
      }
      if (a.return !== u.return) a = e, u = n;
      else {
        for (var f = !1, c = e.child; c; ) {
          if (c === a) {
            f = !0, a = e, u = n;
            break;
          }
          if (c === u) {
            f = !0, u = e, a = n;
            break;
          }
          c = c.sibling;
        }
        if (!f) {
          for (c = n.child; c; ) {
            if (c === a) {
              f = !0, a = n, u = e;
              break;
            }
            if (c === u) {
              f = !0, u = n, a = e;
              break;
            }
            c = c.sibling;
          }
          if (!f) throw Error(o(189));
        }
      }
      if (a.alternate !== u) throw Error(o(190));
    }
    if (a.tag !== 3) throw Error(o(188));
    return a.stateNode.current === a ? l : t;
  }
  function k(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l;
    for (l = l.child; l !== null; ) {
      if (t = k(l), t !== null) return t;
      l = l.sibling;
    }
    return null;
  }
  var R = Object.assign, yl = /* @__PURE__ */ Symbol.for("react.element"), Wl = /* @__PURE__ */ Symbol.for("react.transitional.element"), jl = /* @__PURE__ */ Symbol.for("react.portal"), Cl = /* @__PURE__ */ Symbol.for("react.fragment"), Dt = /* @__PURE__ */ Symbol.for("react.strict_mode"), $l = /* @__PURE__ */ Symbol.for("react.profiler"), $t = /* @__PURE__ */ Symbol.for("react.consumer"), Rl = /* @__PURE__ */ Symbol.for("react.context"), ft = /* @__PURE__ */ Symbol.for("react.forward_ref"), Et = /* @__PURE__ */ Symbol.for("react.suspense"), Yl = /* @__PURE__ */ Symbol.for("react.suspense_list"), W = /* @__PURE__ */ Symbol.for("react.memo"), Gl = /* @__PURE__ */ Symbol.for("react.lazy"), Tt = /* @__PURE__ */ Symbol.for("react.activity"), Qa = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), At = Symbol.iterator;
  function Xl(l) {
    return l === null || typeof l != "object" ? null : (l = At && l[At] || l["@@iterator"], typeof l == "function" ? l : null);
  }
  var Ea = /* @__PURE__ */ Symbol.for("react.client.reference");
  function Ut(l) {
    if (l == null) return null;
    if (typeof l == "function")
      return l.$$typeof === Ea ? null : l.displayName || l.name || null;
    if (typeof l == "string") return l;
    switch (l) {
      case Cl:
        return "Fragment";
      case $l:
        return "Profiler";
      case Dt:
        return "StrictMode";
      case Et:
        return "Suspense";
      case Yl:
        return "SuspenseList";
      case Tt:
        return "Activity";
    }
    if (typeof l == "object")
      switch (l.$$typeof) {
        case jl:
          return "Portal";
        case Rl:
          return l.displayName || "Context";
        case $t:
          return (l._context.displayName || "Context") + ".Consumer";
        case ft:
          var t = l.render;
          return l = l.displayName, l || (l = t.displayName || t.name || "", l = l !== "" ? "ForwardRef(" + l + ")" : "ForwardRef"), l;
        case W:
          return t = l.displayName || null, t !== null ? t : Ut(l.type) || "Memo";
        case Gl:
          t = l._payload, l = l._init;
          try {
            return Ut(l(t));
          } catch {
          }
      }
    return null;
  }
  var St = Array.isArray, b = G.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, _ = Q.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, x = {
    pending: !1,
    data: null,
    method: null,
    action: null
  }, ul = [], cl = -1;
  function d(l) {
    return { current: l };
  }
  function E(l) {
    0 > cl || (l.current = ul[cl], ul[cl] = null, cl--);
  }
  function M(l, t) {
    cl++, ul[cl] = l.current, l.current = t;
  }
  var p = d(null), j = d(null), V = d(null), ll = d(null);
  function ql(l, t) {
    switch (M(V, t), M(j, l), M(p, null), t.nodeType) {
      case 9:
      case 11:
        l = (l = t.documentElement) && (l = l.namespaceURI) ? Yd(l) : 0;
        break;
      default:
        if (l = t.tagName, t = t.namespaceURI)
          t = Yd(t), l = Gd(t, l);
        else
          switch (l) {
            case "svg":
              l = 1;
              break;
            case "math":
              l = 2;
              break;
            default:
              l = 0;
          }
    }
    E(p), M(p, l);
  }
  function gl() {
    E(p), E(j), E(V);
  }
  function Ou(l) {
    l.memoizedState !== null && M(ll, l);
    var t = p.current, a = Gd(t, l.type);
    t !== a && (M(j, l), M(p, a));
  }
  function Ee(l) {
    j.current === l && (E(p), E(j)), ll.current === l && (E(ll), oe._currentValue = x);
  }
  var Qn, hi;
  function Ta(l) {
    if (Qn === void 0)
      try {
        throw Error();
      } catch (a) {
        var t = a.stack.trim().match(/\n( *(at )?)/);
        Qn = t && t[1] || "", hi = -1 < a.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < a.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
    return `
` + Qn + l + hi;
  }
  var Zn = !1;
  function Vn(l, t) {
    if (!l || Zn) return "";
    Zn = !0;
    var a = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var u = {
        DetermineComponentFrameRoot: function() {
          try {
            if (t) {
              var z = function() {
                throw Error();
              };
              if (Object.defineProperty(z.prototype, "props", {
                set: function() {
                  throw Error();
                }
              }), typeof Reflect == "object" && Reflect.construct) {
                try {
                  Reflect.construct(z, []);
                } catch (g) {
                  var h = g;
                }
                Reflect.construct(l, [], z);
              } else {
                try {
                  z.call();
                } catch (g) {
                  h = g;
                }
                l.call(z.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (g) {
                h = g;
              }
              (z = l()) && typeof z.catch == "function" && z.catch(function() {
              });
            }
          } catch (g) {
            if (g && h && typeof g.stack == "string")
              return [g.stack, h.stack];
          }
          return [null, null];
        }
      };
      u.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var e = Object.getOwnPropertyDescriptor(
        u.DetermineComponentFrameRoot,
        "name"
      );
      e && e.configurable && Object.defineProperty(
        u.DetermineComponentFrameRoot,
        "name",
        { value: "DetermineComponentFrameRoot" }
      );
      var n = u.DetermineComponentFrameRoot(), f = n[0], c = n[1];
      if (f && c) {
        var i = f.split(`
`), m = c.split(`
`);
        for (e = u = 0; u < i.length && !i[u].includes("DetermineComponentFrameRoot"); )
          u++;
        for (; e < m.length && !m[e].includes(
          "DetermineComponentFrameRoot"
        ); )
          e++;
        if (u === i.length || e === m.length)
          for (u = i.length - 1, e = m.length - 1; 1 <= u && 0 <= e && i[u] !== m[e]; )
            e--;
        for (; 1 <= u && 0 <= e; u--, e--)
          if (i[u] !== m[e]) {
            if (u !== 1 || e !== 1)
              do
                if (u--, e--, 0 > e || i[u] !== m[e]) {
                  var S = `
` + i[u].replace(" at new ", " at ");
                  return l.displayName && S.includes("<anonymous>") && (S = S.replace("<anonymous>", l.displayName)), S;
                }
              while (1 <= u && 0 <= e);
            break;
          }
      }
    } finally {
      Zn = !1, Error.prepareStackTrace = a;
    }
    return (a = l ? l.displayName || l.name : "") ? Ta(a) : "";
  }
  function Ny(l, t) {
    switch (l.tag) {
      case 26:
      case 27:
      case 5:
        return Ta(l.type);
      case 16:
        return Ta("Lazy");
      case 13:
        return l.child !== t && t !== null ? Ta("Suspense Fallback") : Ta("Suspense");
      case 19:
        return Ta("SuspenseList");
      case 0:
      case 15:
        return Vn(l.type, !1);
      case 11:
        return Vn(l.type.render, !1);
      case 1:
        return Vn(l.type, !0);
      case 31:
        return Ta("Activity");
      default:
        return "";
    }
  }
  function oi(l) {
    try {
      var t = "", a = null;
      do
        t += Ny(l, a), a = l, l = l.return;
      while (l);
      return t;
    } catch (u) {
      return `
Error generating stack: ` + u.message + `
` + u.stack;
    }
  }
  var Ln = Object.prototype.hasOwnProperty, Kn = A.unstable_scheduleCallback, Jn = A.unstable_cancelCallback, Hy = A.unstable_shouldYield, Ry = A.unstable_requestPaint, kl = A.unstable_now, xy = A.unstable_getCurrentPriorityLevel, gi = A.unstable_ImmediatePriority, Si = A.unstable_UserBlockingPriority, Te = A.unstable_NormalPriority, Cy = A.unstable_LowPriority, bi = A.unstable_IdlePriority, qy = A.log, By = A.unstable_setDisableYieldValue, pu = null, Fl = null;
  function kt(l) {
    if (typeof qy == "function" && By(l), Fl && typeof Fl.setStrictMode == "function")
      try {
        Fl.setStrictMode(pu, l);
      } catch {
      }
  }
  var Il = Math.clz32 ? Math.clz32 : Gy, jy = Math.log, Yy = Math.LN2;
  function Gy(l) {
    return l >>>= 0, l === 0 ? 32 : 31 - (jy(l) / Yy | 0) | 0;
  }
  var Ae = 256, _e = 262144, Me = 4194304;
  function Aa(l) {
    var t = l & 42;
    if (t !== 0) return t;
    switch (l & -l) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return l & 261888;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return l & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return l & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return l;
    }
  }
  function Oe(l, t, a) {
    var u = l.pendingLanes;
    if (u === 0) return 0;
    var e = 0, n = l.suspendedLanes, f = l.pingedLanes;
    l = l.warmLanes;
    var c = u & 134217727;
    return c !== 0 ? (u = c & ~n, u !== 0 ? e = Aa(u) : (f &= c, f !== 0 ? e = Aa(f) : a || (a = c & ~l, a !== 0 && (e = Aa(a))))) : (c = u & ~n, c !== 0 ? e = Aa(c) : f !== 0 ? e = Aa(f) : a || (a = u & ~l, a !== 0 && (e = Aa(a)))), e === 0 ? 0 : t !== 0 && t !== e && (t & n) === 0 && (n = e & -e, a = t & -t, n >= a || n === 32 && (a & 4194048) !== 0) ? t : e;
  }
  function Du(l, t) {
    return (l.pendingLanes & ~(l.suspendedLanes & ~l.pingedLanes) & t) === 0;
  }
  function Xy(l, t) {
    switch (l) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function ri() {
    var l = Me;
    return Me <<= 1, (Me & 62914560) === 0 && (Me = 4194304), l;
  }
  function wn(l) {
    for (var t = [], a = 0; 31 > a; a++) t.push(l);
    return t;
  }
  function Uu(l, t) {
    l.pendingLanes |= t, t !== 268435456 && (l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0);
  }
  function Qy(l, t, a, u, e, n) {
    var f = l.pendingLanes;
    l.pendingLanes = a, l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0, l.expiredLanes &= a, l.entangledLanes &= a, l.errorRecoveryDisabledLanes &= a, l.shellSuspendCounter = 0;
    var c = l.entanglements, i = l.expirationTimes, m = l.hiddenUpdates;
    for (a = f & ~a; 0 < a; ) {
      var S = 31 - Il(a), z = 1 << S;
      c[S] = 0, i[S] = -1;
      var h = m[S];
      if (h !== null)
        for (m[S] = null, S = 0; S < h.length; S++) {
          var g = h[S];
          g !== null && (g.lane &= -536870913);
        }
      a &= ~z;
    }
    u !== 0 && zi(l, u, 0), n !== 0 && e === 0 && l.tag !== 0 && (l.suspendedLanes |= n & ~(f & ~t));
  }
  function zi(l, t, a) {
    l.pendingLanes |= t, l.suspendedLanes &= ~t;
    var u = 31 - Il(t);
    l.entangledLanes |= t, l.entanglements[u] = l.entanglements[u] | 1073741824 | a & 261930;
  }
  function Ei(l, t) {
    var a = l.entangledLanes |= t;
    for (l = l.entanglements; a; ) {
      var u = 31 - Il(a), e = 1 << u;
      e & t | l[u] & t && (l[u] |= t), a &= ~e;
    }
  }
  function Ti(l, t) {
    var a = t & -t;
    return a = (a & 42) !== 0 ? 1 : Wn(a), (a & (l.suspendedLanes | t)) !== 0 ? 0 : a;
  }
  function Wn(l) {
    switch (l) {
      case 2:
        l = 1;
        break;
      case 8:
        l = 4;
        break;
      case 32:
        l = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        l = 128;
        break;
      case 268435456:
        l = 134217728;
        break;
      default:
        l = 0;
    }
    return l;
  }
  function $n(l) {
    return l &= -l, 2 < l ? 8 < l ? (l & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
  }
  function Ai() {
    var l = _.p;
    return l !== 0 ? l : (l = window.event, l === void 0 ? 32 : iy(l.type));
  }
  function _i(l, t) {
    var a = _.p;
    try {
      return _.p = l, t();
    } finally {
      _.p = a;
    }
  }
  var Ft = Math.random().toString(36).slice(2), pl = "__reactFiber$" + Ft, Ql = "__reactProps$" + Ft, Za = "__reactContainer$" + Ft, kn = "__reactEvents$" + Ft, Zy = "__reactListeners$" + Ft, Vy = "__reactHandles$" + Ft, Mi = "__reactResources$" + Ft, Nu = "__reactMarker$" + Ft;
  function Fn(l) {
    delete l[pl], delete l[Ql], delete l[kn], delete l[Zy], delete l[Vy];
  }
  function Va(l) {
    var t = l[pl];
    if (t) return t;
    for (var a = l.parentNode; a; ) {
      if (t = a[Za] || a[pl]) {
        if (a = t.alternate, t.child !== null || a !== null && a.child !== null)
          for (l = Jd(l); l !== null; ) {
            if (a = l[pl]) return a;
            l = Jd(l);
          }
        return t;
      }
      l = a, a = l.parentNode;
    }
    return null;
  }
  function La(l) {
    if (l = l[pl] || l[Za]) {
      var t = l.tag;
      if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3)
        return l;
    }
    return null;
  }
  function Hu(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l.stateNode;
    throw Error(o(33));
  }
  function Ka(l) {
    var t = l[Mi];
    return t || (t = l[Mi] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), t;
  }
  function Ml(l) {
    l[Nu] = !0;
  }
  var Oi = /* @__PURE__ */ new Set(), pi = {};
  function _a(l, t) {
    Ja(l, t), Ja(l + "Capture", t);
  }
  function Ja(l, t) {
    for (pi[l] = t, l = 0; l < t.length; l++)
      Oi.add(t[l]);
  }
  var Ly = RegExp(
    "^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"
  ), Di = {}, Ui = {};
  function Ky(l) {
    return Ln.call(Ui, l) ? !0 : Ln.call(Di, l) ? !1 : Ly.test(l) ? Ui[l] = !0 : (Di[l] = !0, !1);
  }
  function pe(l, t, a) {
    if (Ky(t))
      if (a === null) l.removeAttribute(t);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
            l.removeAttribute(t);
            return;
          case "boolean":
            var u = t.toLowerCase().slice(0, 5);
            if (u !== "data-" && u !== "aria-") {
              l.removeAttribute(t);
              return;
            }
        }
        l.setAttribute(t, "" + a);
      }
  }
  function De(l, t, a) {
    if (a === null) l.removeAttribute(t);
    else {
      switch (typeof a) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          l.removeAttribute(t);
          return;
      }
      l.setAttribute(t, "" + a);
    }
  }
  function Nt(l, t, a, u) {
    if (u === null) l.removeAttribute(a);
    else {
      switch (typeof u) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          l.removeAttribute(a);
          return;
      }
      l.setAttributeNS(t, a, "" + u);
    }
  }
  function ct(l) {
    switch (typeof l) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return l;
      case "object":
        return l;
      default:
        return "";
    }
  }
  function Ni(l) {
    var t = l.type;
    return (l = l.nodeName) && l.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
  }
  function Jy(l, t, a) {
    var u = Object.getOwnPropertyDescriptor(
      l.constructor.prototype,
      t
    );
    if (!l.hasOwnProperty(t) && typeof u < "u" && typeof u.get == "function" && typeof u.set == "function") {
      var e = u.get, n = u.set;
      return Object.defineProperty(l, t, {
        configurable: !0,
        get: function() {
          return e.call(this);
        },
        set: function(f) {
          a = "" + f, n.call(this, f);
        }
      }), Object.defineProperty(l, t, {
        enumerable: u.enumerable
      }), {
        getValue: function() {
          return a;
        },
        setValue: function(f) {
          a = "" + f;
        },
        stopTracking: function() {
          l._valueTracker = null, delete l[t];
        }
      };
    }
  }
  function In(l) {
    if (!l._valueTracker) {
      var t = Ni(l) ? "checked" : "value";
      l._valueTracker = Jy(
        l,
        t,
        "" + l[t]
      );
    }
  }
  function Hi(l) {
    if (!l) return !1;
    var t = l._valueTracker;
    if (!t) return !0;
    var a = t.getValue(), u = "";
    return l && (u = Ni(l) ? l.checked ? "true" : "false" : l.value), l = u, l !== a ? (t.setValue(l), !0) : !1;
  }
  function Ue(l) {
    if (l = l || (typeof document < "u" ? document : void 0), typeof l > "u") return null;
    try {
      return l.activeElement || l.body;
    } catch {
      return l.body;
    }
  }
  var wy = /[\n"\\]/g;
  function it(l) {
    return l.replace(
      wy,
      function(t) {
        return "\\" + t.charCodeAt(0).toString(16) + " ";
      }
    );
  }
  function Pn(l, t, a, u, e, n, f, c) {
    l.name = "", f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" ? l.type = f : l.removeAttribute("type"), t != null ? f === "number" ? (t === 0 && l.value === "" || l.value != t) && (l.value = "" + ct(t)) : l.value !== "" + ct(t) && (l.value = "" + ct(t)) : f !== "submit" && f !== "reset" || l.removeAttribute("value"), t != null ? lf(l, f, ct(t)) : a != null ? lf(l, f, ct(a)) : u != null && l.removeAttribute("value"), e == null && n != null && (l.defaultChecked = !!n), e != null && (l.checked = e && typeof e != "function" && typeof e != "symbol"), c != null && typeof c != "function" && typeof c != "symbol" && typeof c != "boolean" ? l.name = "" + ct(c) : l.removeAttribute("name");
  }
  function Ri(l, t, a, u, e, n, f, c) {
    if (n != null && typeof n != "function" && typeof n != "symbol" && typeof n != "boolean" && (l.type = n), t != null || a != null) {
      if (!(n !== "submit" && n !== "reset" || t != null)) {
        In(l);
        return;
      }
      a = a != null ? "" + ct(a) : "", t = t != null ? "" + ct(t) : a, c || t === l.value || (l.value = t), l.defaultValue = t;
    }
    u = u ?? e, u = typeof u != "function" && typeof u != "symbol" && !!u, l.checked = c ? l.checked : !!u, l.defaultChecked = !!u, f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" && (l.name = f), In(l);
  }
  function lf(l, t, a) {
    t === "number" && Ue(l.ownerDocument) === l || l.defaultValue === "" + a || (l.defaultValue = "" + a);
  }
  function wa(l, t, a, u) {
    if (l = l.options, t) {
      t = {};
      for (var e = 0; e < a.length; e++)
        t["$" + a[e]] = !0;
      for (a = 0; a < l.length; a++)
        e = t.hasOwnProperty("$" + l[a].value), l[a].selected !== e && (l[a].selected = e), e && u && (l[a].defaultSelected = !0);
    } else {
      for (a = "" + ct(a), t = null, e = 0; e < l.length; e++) {
        if (l[e].value === a) {
          l[e].selected = !0, u && (l[e].defaultSelected = !0);
          return;
        }
        t !== null || l[e].disabled || (t = l[e]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function xi(l, t, a) {
    if (t != null && (t = "" + ct(t), t !== l.value && (l.value = t), a == null)) {
      l.defaultValue !== t && (l.defaultValue = t);
      return;
    }
    l.defaultValue = a != null ? "" + ct(a) : "";
  }
  function Ci(l, t, a, u) {
    if (t == null) {
      if (u != null) {
        if (a != null) throw Error(o(92));
        if (St(u)) {
          if (1 < u.length) throw Error(o(93));
          u = u[0];
        }
        a = u;
      }
      a == null && (a = ""), t = a;
    }
    a = ct(t), l.defaultValue = a, u = l.textContent, u === a && u !== "" && u !== null && (l.value = u), In(l);
  }
  function Wa(l, t) {
    if (t) {
      var a = l.firstChild;
      if (a && a === l.lastChild && a.nodeType === 3) {
        a.nodeValue = t;
        return;
      }
    }
    l.textContent = t;
  }
  var Wy = new Set(
    "animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(
      " "
    )
  );
  function qi(l, t, a) {
    var u = t.indexOf("--") === 0;
    a == null || typeof a == "boolean" || a === "" ? u ? l.setProperty(t, "") : t === "float" ? l.cssFloat = "" : l[t] = "" : u ? l.setProperty(t, a) : typeof a != "number" || a === 0 || Wy.has(t) ? t === "float" ? l.cssFloat = a : l[t] = ("" + a).trim() : l[t] = a + "px";
  }
  function Bi(l, t, a) {
    if (t != null && typeof t != "object")
      throw Error(o(62));
    if (l = l.style, a != null) {
      for (var u in a)
        !a.hasOwnProperty(u) || t != null && t.hasOwnProperty(u) || (u.indexOf("--") === 0 ? l.setProperty(u, "") : u === "float" ? l.cssFloat = "" : l[u] = "");
      for (var e in t)
        u = t[e], t.hasOwnProperty(e) && a[e] !== u && qi(l, e, u);
    } else
      for (var n in t)
        t.hasOwnProperty(n) && qi(l, n, t[n]);
  }
  function tf(l) {
    if (l.indexOf("-") === -1) return !1;
    switch (l) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var $y = /* @__PURE__ */ new Map([
    ["acceptCharset", "accept-charset"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"],
    ["crossOrigin", "crossorigin"],
    ["accentHeight", "accent-height"],
    ["alignmentBaseline", "alignment-baseline"],
    ["arabicForm", "arabic-form"],
    ["baselineShift", "baseline-shift"],
    ["capHeight", "cap-height"],
    ["clipPath", "clip-path"],
    ["clipRule", "clip-rule"],
    ["colorInterpolation", "color-interpolation"],
    ["colorInterpolationFilters", "color-interpolation-filters"],
    ["colorProfile", "color-profile"],
    ["colorRendering", "color-rendering"],
    ["dominantBaseline", "dominant-baseline"],
    ["enableBackground", "enable-background"],
    ["fillOpacity", "fill-opacity"],
    ["fillRule", "fill-rule"],
    ["floodColor", "flood-color"],
    ["floodOpacity", "flood-opacity"],
    ["fontFamily", "font-family"],
    ["fontSize", "font-size"],
    ["fontSizeAdjust", "font-size-adjust"],
    ["fontStretch", "font-stretch"],
    ["fontStyle", "font-style"],
    ["fontVariant", "font-variant"],
    ["fontWeight", "font-weight"],
    ["glyphName", "glyph-name"],
    ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
    ["glyphOrientationVertical", "glyph-orientation-vertical"],
    ["horizAdvX", "horiz-adv-x"],
    ["horizOriginX", "horiz-origin-x"],
    ["imageRendering", "image-rendering"],
    ["letterSpacing", "letter-spacing"],
    ["lightingColor", "lighting-color"],
    ["markerEnd", "marker-end"],
    ["markerMid", "marker-mid"],
    ["markerStart", "marker-start"],
    ["overlinePosition", "overline-position"],
    ["overlineThickness", "overline-thickness"],
    ["paintOrder", "paint-order"],
    ["panose-1", "panose-1"],
    ["pointerEvents", "pointer-events"],
    ["renderingIntent", "rendering-intent"],
    ["shapeRendering", "shape-rendering"],
    ["stopColor", "stop-color"],
    ["stopOpacity", "stop-opacity"],
    ["strikethroughPosition", "strikethrough-position"],
    ["strikethroughThickness", "strikethrough-thickness"],
    ["strokeDasharray", "stroke-dasharray"],
    ["strokeDashoffset", "stroke-dashoffset"],
    ["strokeLinecap", "stroke-linecap"],
    ["strokeLinejoin", "stroke-linejoin"],
    ["strokeMiterlimit", "stroke-miterlimit"],
    ["strokeOpacity", "stroke-opacity"],
    ["strokeWidth", "stroke-width"],
    ["textAnchor", "text-anchor"],
    ["textDecoration", "text-decoration"],
    ["textRendering", "text-rendering"],
    ["transformOrigin", "transform-origin"],
    ["underlinePosition", "underline-position"],
    ["underlineThickness", "underline-thickness"],
    ["unicodeBidi", "unicode-bidi"],
    ["unicodeRange", "unicode-range"],
    ["unitsPerEm", "units-per-em"],
    ["vAlphabetic", "v-alphabetic"],
    ["vHanging", "v-hanging"],
    ["vIdeographic", "v-ideographic"],
    ["vMathematical", "v-mathematical"],
    ["vectorEffect", "vector-effect"],
    ["vertAdvY", "vert-adv-y"],
    ["vertOriginX", "vert-origin-x"],
    ["vertOriginY", "vert-origin-y"],
    ["wordSpacing", "word-spacing"],
    ["writingMode", "writing-mode"],
    ["xmlnsXlink", "xmlns:xlink"],
    ["xHeight", "x-height"]
  ]), ky = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function Ne(l) {
    return ky.test("" + l) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : l;
  }
  function Ht() {
  }
  var af = null;
  function uf(l) {
    return l = l.target || l.srcElement || window, l.correspondingUseElement && (l = l.correspondingUseElement), l.nodeType === 3 ? l.parentNode : l;
  }
  var $a = null, ka = null;
  function ji(l) {
    var t = La(l);
    if (t && (l = t.stateNode)) {
      var a = l[Ql] || null;
      l: switch (l = t.stateNode, t.type) {
        case "input":
          if (Pn(
            l,
            a.value,
            a.defaultValue,
            a.defaultValue,
            a.checked,
            a.defaultChecked,
            a.type,
            a.name
          ), t = a.name, a.type === "radio" && t != null) {
            for (a = l; a.parentNode; ) a = a.parentNode;
            for (a = a.querySelectorAll(
              'input[name="' + it(
                "" + t
              ) + '"][type="radio"]'
            ), t = 0; t < a.length; t++) {
              var u = a[t];
              if (u !== l && u.form === l.form) {
                var e = u[Ql] || null;
                if (!e) throw Error(o(90));
                Pn(
                  u,
                  e.value,
                  e.defaultValue,
                  e.defaultValue,
                  e.checked,
                  e.defaultChecked,
                  e.type,
                  e.name
                );
              }
            }
            for (t = 0; t < a.length; t++)
              u = a[t], u.form === l.form && Hi(u);
          }
          break l;
        case "textarea":
          xi(l, a.value, a.defaultValue);
          break l;
        case "select":
          t = a.value, t != null && wa(l, !!a.multiple, t, !1);
      }
    }
  }
  var ef = !1;
  function Yi(l, t, a) {
    if (ef) return l(t, a);
    ef = !0;
    try {
      var u = l(t);
      return u;
    } finally {
      if (ef = !1, ($a !== null || ka !== null) && (bn(), $a && (t = $a, l = ka, ka = $a = null, ji(t), l)))
        for (t = 0; t < l.length; t++) ji(l[t]);
    }
  }
  function Ru(l, t) {
    var a = l.stateNode;
    if (a === null) return null;
    var u = a[Ql] || null;
    if (u === null) return null;
    a = u[t];
    l: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (u = !u.disabled) || (l = l.type, u = !(l === "button" || l === "input" || l === "select" || l === "textarea")), l = !u;
        break l;
      default:
        l = !1;
    }
    if (l) return null;
    if (a && typeof a != "function")
      throw Error(
        o(231, t, typeof a)
      );
    return a;
  }
  var Rt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), nf = !1;
  if (Rt)
    try {
      var xu = {};
      Object.defineProperty(xu, "passive", {
        get: function() {
          nf = !0;
        }
      }), window.addEventListener("test", xu, xu), window.removeEventListener("test", xu, xu);
    } catch {
      nf = !1;
    }
  var It = null, ff = null, He = null;
  function Gi() {
    if (He) return He;
    var l, t = ff, a = t.length, u, e = "value" in It ? It.value : It.textContent, n = e.length;
    for (l = 0; l < a && t[l] === e[l]; l++) ;
    var f = a - l;
    for (u = 1; u <= f && t[a - u] === e[n - u]; u++) ;
    return He = e.slice(l, 1 < u ? 1 - u : void 0);
  }
  function Re(l) {
    var t = l.keyCode;
    return "charCode" in l ? (l = l.charCode, l === 0 && t === 13 && (l = 13)) : l = t, l === 10 && (l = 13), 32 <= l || l === 13 ? l : 0;
  }
  function xe() {
    return !0;
  }
  function Xi() {
    return !1;
  }
  function Zl(l) {
    function t(a, u, e, n, f) {
      this._reactName = a, this._targetInst = e, this.type = u, this.nativeEvent = n, this.target = f, this.currentTarget = null;
      for (var c in l)
        l.hasOwnProperty(c) && (a = l[c], this[c] = a ? a(n) : n[c]);
      return this.isDefaultPrevented = (n.defaultPrevented != null ? n.defaultPrevented : n.returnValue === !1) ? xe : Xi, this.isPropagationStopped = Xi, this;
    }
    return R(t.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var a = this.nativeEvent;
        a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = !1), this.isDefaultPrevented = xe);
      },
      stopPropagation: function() {
        var a = this.nativeEvent;
        a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = !0), this.isPropagationStopped = xe);
      },
      persist: function() {
      },
      isPersistent: xe
    }), t;
  }
  var Ma = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(l) {
      return l.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, Ce = Zl(Ma), Cu = R({}, Ma, { view: 0, detail: 0 }), Fy = Zl(Cu), cf, sf, qu, qe = R({}, Cu, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: yf,
    button: 0,
    buttons: 0,
    relatedTarget: function(l) {
      return l.relatedTarget === void 0 ? l.fromElement === l.srcElement ? l.toElement : l.fromElement : l.relatedTarget;
    },
    movementX: function(l) {
      return "movementX" in l ? l.movementX : (l !== qu && (qu && l.type === "mousemove" ? (cf = l.screenX - qu.screenX, sf = l.screenY - qu.screenY) : sf = cf = 0, qu = l), cf);
    },
    movementY: function(l) {
      return "movementY" in l ? l.movementY : sf;
    }
  }), Qi = Zl(qe), Iy = R({}, qe, { dataTransfer: 0 }), Py = Zl(Iy), lv = R({}, Cu, { relatedTarget: 0 }), df = Zl(lv), tv = R({}, Ma, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), av = Zl(tv), uv = R({}, Ma, {
    clipboardData: function(l) {
      return "clipboardData" in l ? l.clipboardData : window.clipboardData;
    }
  }), ev = Zl(uv), nv = R({}, Ma, { data: 0 }), Zi = Zl(nv), fv = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, cv = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, iv = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function sv(l) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(l) : (l = iv[l]) ? !!t[l] : !1;
  }
  function yf() {
    return sv;
  }
  var dv = R({}, Cu, {
    key: function(l) {
      if (l.key) {
        var t = fv[l.key] || l.key;
        if (t !== "Unidentified") return t;
      }
      return l.type === "keypress" ? (l = Re(l), l === 13 ? "Enter" : String.fromCharCode(l)) : l.type === "keydown" || l.type === "keyup" ? cv[l.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: yf,
    charCode: function(l) {
      return l.type === "keypress" ? Re(l) : 0;
    },
    keyCode: function(l) {
      return l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0;
    },
    which: function(l) {
      return l.type === "keypress" ? Re(l) : l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0;
    }
  }), yv = Zl(dv), vv = R({}, qe, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), Vi = Zl(vv), mv = R({}, Cu, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: yf
  }), hv = Zl(mv), ov = R({}, Ma, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), gv = Zl(ov), Sv = R({}, qe, {
    deltaX: function(l) {
      return "deltaX" in l ? l.deltaX : "wheelDeltaX" in l ? -l.wheelDeltaX : 0;
    },
    deltaY: function(l) {
      return "deltaY" in l ? l.deltaY : "wheelDeltaY" in l ? -l.wheelDeltaY : "wheelDelta" in l ? -l.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), bv = Zl(Sv), rv = R({}, Ma, {
    newState: 0,
    oldState: 0
  }), zv = Zl(rv), Ev = [9, 13, 27, 32], vf = Rt && "CompositionEvent" in window, Bu = null;
  Rt && "documentMode" in document && (Bu = document.documentMode);
  var Tv = Rt && "TextEvent" in window && !Bu, Li = Rt && (!vf || Bu && 8 < Bu && 11 >= Bu), Ki = " ", Ji = !1;
  function wi(l, t) {
    switch (l) {
      case "keyup":
        return Ev.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Wi(l) {
    return l = l.detail, typeof l == "object" && "data" in l ? l.data : null;
  }
  var Fa = !1;
  function Av(l, t) {
    switch (l) {
      case "compositionend":
        return Wi(t);
      case "keypress":
        return t.which !== 32 ? null : (Ji = !0, Ki);
      case "textInput":
        return l = t.data, l === Ki && Ji ? null : l;
      default:
        return null;
    }
  }
  function _v(l, t) {
    if (Fa)
      return l === "compositionend" || !vf && wi(l, t) ? (l = Gi(), He = ff = It = null, Fa = !1, l) : null;
    switch (l) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
          if (t.char && 1 < t.char.length)
            return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Li && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var Mv = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function $i(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t === "input" ? !!Mv[l.type] : t === "textarea";
  }
  function ki(l, t, a, u) {
    $a ? ka ? ka.push(u) : ka = [u] : $a = u, t = Mn(t, "onChange"), 0 < t.length && (a = new Ce(
      "onChange",
      "change",
      null,
      a,
      u
    ), l.push({ event: a, listeners: t }));
  }
  var ju = null, Yu = null;
  function Ov(l) {
    Rd(l, 0);
  }
  function Be(l) {
    var t = Hu(l);
    if (Hi(t)) return l;
  }
  function Fi(l, t) {
    if (l === "change") return t;
  }
  var Ii = !1;
  if (Rt) {
    var mf;
    if (Rt) {
      var hf = "oninput" in document;
      if (!hf) {
        var Pi = document.createElement("div");
        Pi.setAttribute("oninput", "return;"), hf = typeof Pi.oninput == "function";
      }
      mf = hf;
    } else mf = !1;
    Ii = mf && (!document.documentMode || 9 < document.documentMode);
  }
  function l0() {
    ju && (ju.detachEvent("onpropertychange", t0), Yu = ju = null);
  }
  function t0(l) {
    if (l.propertyName === "value" && Be(Yu)) {
      var t = [];
      ki(
        t,
        Yu,
        l,
        uf(l)
      ), Yi(Ov, t);
    }
  }
  function pv(l, t, a) {
    l === "focusin" ? (l0(), ju = t, Yu = a, ju.attachEvent("onpropertychange", t0)) : l === "focusout" && l0();
  }
  function Dv(l) {
    if (l === "selectionchange" || l === "keyup" || l === "keydown")
      return Be(Yu);
  }
  function Uv(l, t) {
    if (l === "click") return Be(t);
  }
  function Nv(l, t) {
    if (l === "input" || l === "change")
      return Be(t);
  }
  function Hv(l, t) {
    return l === t && (l !== 0 || 1 / l === 1 / t) || l !== l && t !== t;
  }
  var Pl = typeof Object.is == "function" ? Object.is : Hv;
  function Gu(l, t) {
    if (Pl(l, t)) return !0;
    if (typeof l != "object" || l === null || typeof t != "object" || t === null)
      return !1;
    var a = Object.keys(l), u = Object.keys(t);
    if (a.length !== u.length) return !1;
    for (u = 0; u < a.length; u++) {
      var e = a[u];
      if (!Ln.call(t, e) || !Pl(l[e], t[e]))
        return !1;
    }
    return !0;
  }
  function a0(l) {
    for (; l && l.firstChild; ) l = l.firstChild;
    return l;
  }
  function u0(l, t) {
    var a = a0(l);
    l = 0;
    for (var u; a; ) {
      if (a.nodeType === 3) {
        if (u = l + a.textContent.length, l <= t && u >= t)
          return { node: a, offset: t - l };
        l = u;
      }
      l: {
        for (; a; ) {
          if (a.nextSibling) {
            a = a.nextSibling;
            break l;
          }
          a = a.parentNode;
        }
        a = void 0;
      }
      a = a0(a);
    }
  }
  function e0(l, t) {
    return l && t ? l === t ? !0 : l && l.nodeType === 3 ? !1 : t && t.nodeType === 3 ? e0(l, t.parentNode) : "contains" in l ? l.contains(t) : l.compareDocumentPosition ? !!(l.compareDocumentPosition(t) & 16) : !1 : !1;
  }
  function n0(l) {
    l = l != null && l.ownerDocument != null && l.ownerDocument.defaultView != null ? l.ownerDocument.defaultView : window;
    for (var t = Ue(l.document); t instanceof l.HTMLIFrameElement; ) {
      try {
        var a = typeof t.contentWindow.location.href == "string";
      } catch {
        a = !1;
      }
      if (a) l = t.contentWindow;
      else break;
      t = Ue(l.document);
    }
    return t;
  }
  function of(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t && (t === "input" && (l.type === "text" || l.type === "search" || l.type === "tel" || l.type === "url" || l.type === "password") || t === "textarea" || l.contentEditable === "true");
  }
  var Rv = Rt && "documentMode" in document && 11 >= document.documentMode, Ia = null, gf = null, Xu = null, Sf = !1;
  function f0(l, t, a) {
    var u = a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
    Sf || Ia == null || Ia !== Ue(u) || (u = Ia, "selectionStart" in u && of(u) ? u = { start: u.selectionStart, end: u.selectionEnd } : (u = (u.ownerDocument && u.ownerDocument.defaultView || window).getSelection(), u = {
      anchorNode: u.anchorNode,
      anchorOffset: u.anchorOffset,
      focusNode: u.focusNode,
      focusOffset: u.focusOffset
    }), Xu && Gu(Xu, u) || (Xu = u, u = Mn(gf, "onSelect"), 0 < u.length && (t = new Ce(
      "onSelect",
      "select",
      null,
      t,
      a
    ), l.push({ event: t, listeners: u }), t.target = Ia)));
  }
  function Oa(l, t) {
    var a = {};
    return a[l.toLowerCase()] = t.toLowerCase(), a["Webkit" + l] = "webkit" + t, a["Moz" + l] = "moz" + t, a;
  }
  var Pa = {
    animationend: Oa("Animation", "AnimationEnd"),
    animationiteration: Oa("Animation", "AnimationIteration"),
    animationstart: Oa("Animation", "AnimationStart"),
    transitionrun: Oa("Transition", "TransitionRun"),
    transitionstart: Oa("Transition", "TransitionStart"),
    transitioncancel: Oa("Transition", "TransitionCancel"),
    transitionend: Oa("Transition", "TransitionEnd")
  }, bf = {}, c0 = {};
  Rt && (c0 = document.createElement("div").style, "AnimationEvent" in window || (delete Pa.animationend.animation, delete Pa.animationiteration.animation, delete Pa.animationstart.animation), "TransitionEvent" in window || delete Pa.transitionend.transition);
  function pa(l) {
    if (bf[l]) return bf[l];
    if (!Pa[l]) return l;
    var t = Pa[l], a;
    for (a in t)
      if (t.hasOwnProperty(a) && a in c0)
        return bf[l] = t[a];
    return l;
  }
  var i0 = pa("animationend"), s0 = pa("animationiteration"), d0 = pa("animationstart"), xv = pa("transitionrun"), Cv = pa("transitionstart"), qv = pa("transitioncancel"), y0 = pa("transitionend"), v0 = /* @__PURE__ */ new Map(), rf = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
    " "
  );
  rf.push("scrollEnd");
  function bt(l, t) {
    v0.set(l, t), _a(t, [l]);
  }
  var je = typeof reportError == "function" ? reportError : function(l) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var t = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof l == "object" && l !== null && typeof l.message == "string" ? String(l.message) : String(l),
        error: l
      });
      if (!window.dispatchEvent(t)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", l);
      return;
    }
    console.error(l);
  }, st = [], lu = 0, zf = 0;
  function Ye() {
    for (var l = lu, t = zf = lu = 0; t < l; ) {
      var a = st[t];
      st[t++] = null;
      var u = st[t];
      st[t++] = null;
      var e = st[t];
      st[t++] = null;
      var n = st[t];
      if (st[t++] = null, u !== null && e !== null) {
        var f = u.pending;
        f === null ? e.next = e : (e.next = f.next, f.next = e), u.pending = e;
      }
      n !== 0 && m0(a, e, n);
    }
  }
  function Ge(l, t, a, u) {
    st[lu++] = l, st[lu++] = t, st[lu++] = a, st[lu++] = u, zf |= u, l.lanes |= u, l = l.alternate, l !== null && (l.lanes |= u);
  }
  function Ef(l, t, a, u) {
    return Ge(l, t, a, u), Xe(l);
  }
  function Da(l, t) {
    return Ge(l, null, null, t), Xe(l);
  }
  function m0(l, t, a) {
    l.lanes |= a;
    var u = l.alternate;
    u !== null && (u.lanes |= a);
    for (var e = !1, n = l.return; n !== null; )
      n.childLanes |= a, u = n.alternate, u !== null && (u.childLanes |= a), n.tag === 22 && (l = n.stateNode, l === null || l._visibility & 1 || (e = !0)), l = n, n = n.return;
    return l.tag === 3 ? (n = l.stateNode, e && t !== null && (e = 31 - Il(a), l = n.hiddenUpdates, u = l[e], u === null ? l[e] = [t] : u.push(t), t.lane = a | 536870912), n) : null;
  }
  function Xe(l) {
    if (50 < ie)
      throw ie = 0, Nc = null, Error(o(185));
    for (var t = l.return; t !== null; )
      l = t, t = l.return;
    return l.tag === 3 ? l.stateNode : null;
  }
  var tu = {};
  function Bv(l, t, a, u) {
    this.tag = l, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = u, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function lt(l, t, a, u) {
    return new Bv(l, t, a, u);
  }
  function Tf(l) {
    return l = l.prototype, !(!l || !l.isReactComponent);
  }
  function xt(l, t) {
    var a = l.alternate;
    return a === null ? (a = lt(
      l.tag,
      t,
      l.key,
      l.mode
    ), a.elementType = l.elementType, a.type = l.type, a.stateNode = l.stateNode, a.alternate = l, l.alternate = a) : (a.pendingProps = t, a.type = l.type, a.flags = 0, a.subtreeFlags = 0, a.deletions = null), a.flags = l.flags & 65011712, a.childLanes = l.childLanes, a.lanes = l.lanes, a.child = l.child, a.memoizedProps = l.memoizedProps, a.memoizedState = l.memoizedState, a.updateQueue = l.updateQueue, t = l.dependencies, a.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, a.sibling = l.sibling, a.index = l.index, a.ref = l.ref, a.refCleanup = l.refCleanup, a;
  }
  function h0(l, t) {
    l.flags &= 65011714;
    var a = l.alternate;
    return a === null ? (l.childLanes = 0, l.lanes = t, l.child = null, l.subtreeFlags = 0, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = a.childLanes, l.lanes = a.lanes, l.child = a.child, l.subtreeFlags = 0, l.deletions = null, l.memoizedProps = a.memoizedProps, l.memoizedState = a.memoizedState, l.updateQueue = a.updateQueue, l.type = a.type, t = a.dependencies, l.dependencies = t === null ? null : {
      lanes: t.lanes,
      firstContext: t.firstContext
    }), l;
  }
  function Qe(l, t, a, u, e, n) {
    var f = 0;
    if (u = l, typeof l == "function") Tf(l) && (f = 1);
    else if (typeof l == "string")
      f = Q1(
        l,
        a,
        p.current
      ) ? 26 : l === "html" || l === "head" || l === "body" ? 27 : 5;
    else
      l: switch (l) {
        case Tt:
          return l = lt(31, a, t, e), l.elementType = Tt, l.lanes = n, l;
        case Cl:
          return Ua(a.children, e, n, t);
        case Dt:
          f = 8, e |= 24;
          break;
        case $l:
          return l = lt(12, a, t, e | 2), l.elementType = $l, l.lanes = n, l;
        case Et:
          return l = lt(13, a, t, e), l.elementType = Et, l.lanes = n, l;
        case Yl:
          return l = lt(19, a, t, e), l.elementType = Yl, l.lanes = n, l;
        default:
          if (typeof l == "object" && l !== null)
            switch (l.$$typeof) {
              case Rl:
                f = 10;
                break l;
              case $t:
                f = 9;
                break l;
              case ft:
                f = 11;
                break l;
              case W:
                f = 14;
                break l;
              case Gl:
                f = 16, u = null;
                break l;
            }
          f = 29, a = Error(
            o(130, l === null ? "null" : typeof l, "")
          ), u = null;
      }
    return t = lt(f, a, t, e), t.elementType = l, t.type = u, t.lanes = n, t;
  }
  function Ua(l, t, a, u) {
    return l = lt(7, l, u, t), l.lanes = a, l;
  }
  function Af(l, t, a) {
    return l = lt(6, l, null, t), l.lanes = a, l;
  }
  function o0(l) {
    var t = lt(18, null, null, 0);
    return t.stateNode = l, t;
  }
  function _f(l, t, a) {
    return t = lt(
      4,
      l.children !== null ? l.children : [],
      l.key,
      t
    ), t.lanes = a, t.stateNode = {
      containerInfo: l.containerInfo,
      pendingChildren: null,
      implementation: l.implementation
    }, t;
  }
  var g0 = /* @__PURE__ */ new WeakMap();
  function dt(l, t) {
    if (typeof l == "object" && l !== null) {
      var a = g0.get(l);
      return a !== void 0 ? a : (t = {
        value: l,
        source: t,
        stack: oi(t)
      }, g0.set(l, t), t);
    }
    return {
      value: l,
      source: t,
      stack: oi(t)
    };
  }
  var au = [], uu = 0, Ze = null, Qu = 0, yt = [], vt = 0, Pt = null, _t = 1, Mt = "";
  function Ct(l, t) {
    au[uu++] = Qu, au[uu++] = Ze, Ze = l, Qu = t;
  }
  function S0(l, t, a) {
    yt[vt++] = _t, yt[vt++] = Mt, yt[vt++] = Pt, Pt = l;
    var u = _t;
    l = Mt;
    var e = 32 - Il(u) - 1;
    u &= ~(1 << e), a += 1;
    var n = 32 - Il(t) + e;
    if (30 < n) {
      var f = e - e % 5;
      n = (u & (1 << f) - 1).toString(32), u >>= f, e -= f, _t = 1 << 32 - Il(t) + e | a << e | u, Mt = n + l;
    } else
      _t = 1 << n | a << e | u, Mt = l;
  }
  function Mf(l) {
    l.return !== null && (Ct(l, 1), S0(l, 1, 0));
  }
  function Of(l) {
    for (; l === Ze; )
      Ze = au[--uu], au[uu] = null, Qu = au[--uu], au[uu] = null;
    for (; l === Pt; )
      Pt = yt[--vt], yt[vt] = null, Mt = yt[--vt], yt[vt] = null, _t = yt[--vt], yt[vt] = null;
  }
  function b0(l, t) {
    yt[vt++] = _t, yt[vt++] = Mt, yt[vt++] = Pt, _t = t.id, Mt = t.overflow, Pt = l;
  }
  var Dl = null, sl = null, $ = !1, la = null, mt = !1, pf = Error(o(519));
  function ta(l) {
    var t = Error(
      o(
        418,
        1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML",
        ""
      )
    );
    throw Zu(dt(t, l)), pf;
  }
  function r0(l) {
    var t = l.stateNode, a = l.type, u = l.memoizedProps;
    switch (t[pl] = l, t[Ql] = u, a) {
      case "dialog":
        K("cancel", t), K("close", t);
        break;
      case "iframe":
      case "object":
      case "embed":
        K("load", t);
        break;
      case "video":
      case "audio":
        for (a = 0; a < de.length; a++)
          K(de[a], t);
        break;
      case "source":
        K("error", t);
        break;
      case "img":
      case "image":
      case "link":
        K("error", t), K("load", t);
        break;
      case "details":
        K("toggle", t);
        break;
      case "input":
        K("invalid", t), Ri(
          t,
          u.value,
          u.defaultValue,
          u.checked,
          u.defaultChecked,
          u.type,
          u.name,
          !0
        );
        break;
      case "select":
        K("invalid", t);
        break;
      case "textarea":
        K("invalid", t), Ci(t, u.value, u.defaultValue, u.children);
    }
    a = u.children, typeof a != "string" && typeof a != "number" && typeof a != "bigint" || t.textContent === "" + a || u.suppressHydrationWarning === !0 || Bd(t.textContent, a) ? (u.popover != null && (K("beforetoggle", t), K("toggle", t)), u.onScroll != null && K("scroll", t), u.onScrollEnd != null && K("scrollend", t), u.onClick != null && (t.onclick = Ht), t = !0) : t = !1, t || ta(l, !0);
  }
  function z0(l) {
    for (Dl = l.return; Dl; )
      switch (Dl.tag) {
        case 5:
        case 31:
        case 13:
          mt = !1;
          return;
        case 27:
        case 3:
          mt = !0;
          return;
        default:
          Dl = Dl.return;
      }
  }
  function eu(l) {
    if (l !== Dl) return !1;
    if (!$) return z0(l), $ = !0, !1;
    var t = l.tag, a;
    if ((a = t !== 3 && t !== 27) && ((a = t === 5) && (a = l.type, a = !(a !== "form" && a !== "button") || Kc(l.type, l.memoizedProps)), a = !a), a && sl && ta(l), z0(l), t === 13) {
      if (l = l.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(o(317));
      sl = Kd(l);
    } else if (t === 31) {
      if (l = l.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(o(317));
      sl = Kd(l);
    } else
      t === 27 ? (t = sl, oa(l.type) ? (l = kc, kc = null, sl = l) : sl = t) : sl = Dl ? ot(l.stateNode.nextSibling) : null;
    return !0;
  }
  function Na() {
    sl = Dl = null, $ = !1;
  }
  function Df() {
    var l = la;
    return l !== null && (Jl === null ? Jl = l : Jl.push.apply(
      Jl,
      l
    ), la = null), l;
  }
  function Zu(l) {
    la === null ? la = [l] : la.push(l);
  }
  var Uf = d(null), Ha = null, qt = null;
  function aa(l, t, a) {
    M(Uf, t._currentValue), t._currentValue = a;
  }
  function Bt(l) {
    l._currentValue = Uf.current, E(Uf);
  }
  function Nf(l, t, a) {
    for (; l !== null; ) {
      var u = l.alternate;
      if ((l.childLanes & t) !== t ? (l.childLanes |= t, u !== null && (u.childLanes |= t)) : u !== null && (u.childLanes & t) !== t && (u.childLanes |= t), l === a) break;
      l = l.return;
    }
  }
  function Hf(l, t, a, u) {
    var e = l.child;
    for (e !== null && (e.return = l); e !== null; ) {
      var n = e.dependencies;
      if (n !== null) {
        var f = e.child;
        n = n.firstContext;
        l: for (; n !== null; ) {
          var c = n;
          n = e;
          for (var i = 0; i < t.length; i++)
            if (c.context === t[i]) {
              n.lanes |= a, c = n.alternate, c !== null && (c.lanes |= a), Nf(
                n.return,
                a,
                l
              ), u || (f = null);
              break l;
            }
          n = c.next;
        }
      } else if (e.tag === 18) {
        if (f = e.return, f === null) throw Error(o(341));
        f.lanes |= a, n = f.alternate, n !== null && (n.lanes |= a), Nf(f, a, l), f = null;
      } else f = e.child;
      if (f !== null) f.return = e;
      else
        for (f = e; f !== null; ) {
          if (f === l) {
            f = null;
            break;
          }
          if (e = f.sibling, e !== null) {
            e.return = f.return, f = e;
            break;
          }
          f = f.return;
        }
      e = f;
    }
  }
  function nu(l, t, a, u) {
    l = null;
    for (var e = t, n = !1; e !== null; ) {
      if (!n) {
        if ((e.flags & 524288) !== 0) n = !0;
        else if ((e.flags & 262144) !== 0) break;
      }
      if (e.tag === 10) {
        var f = e.alternate;
        if (f === null) throw Error(o(387));
        if (f = f.memoizedProps, f !== null) {
          var c = e.type;
          Pl(e.pendingProps.value, f.value) || (l !== null ? l.push(c) : l = [c]);
        }
      } else if (e === ll.current) {
        if (f = e.alternate, f === null) throw Error(o(387));
        f.memoizedState.memoizedState !== e.memoizedState.memoizedState && (l !== null ? l.push(oe) : l = [oe]);
      }
      e = e.return;
    }
    l !== null && Hf(
      t,
      l,
      a,
      u
    ), t.flags |= 262144;
  }
  function Ve(l) {
    for (l = l.firstContext; l !== null; ) {
      if (!Pl(
        l.context._currentValue,
        l.memoizedValue
      ))
        return !0;
      l = l.next;
    }
    return !1;
  }
  function Ra(l) {
    Ha = l, qt = null, l = l.dependencies, l !== null && (l.firstContext = null);
  }
  function Ul(l) {
    return E0(Ha, l);
  }
  function Le(l, t) {
    return Ha === null && Ra(l), E0(l, t);
  }
  function E0(l, t) {
    var a = t._currentValue;
    if (t = { context: t, memoizedValue: a, next: null }, qt === null) {
      if (l === null) throw Error(o(308));
      qt = t, l.dependencies = { lanes: 0, firstContext: t }, l.flags |= 524288;
    } else qt = qt.next = t;
    return a;
  }
  var jv = typeof AbortController < "u" ? AbortController : function() {
    var l = [], t = this.signal = {
      aborted: !1,
      addEventListener: function(a, u) {
        l.push(u);
      }
    };
    this.abort = function() {
      t.aborted = !0, l.forEach(function(a) {
        return a();
      });
    };
  }, Yv = A.unstable_scheduleCallback, Gv = A.unstable_NormalPriority, rl = {
    $$typeof: Rl,
    Consumer: null,
    Provider: null,
    _currentValue: null,
    _currentValue2: null,
    _threadCount: 0
  };
  function Rf() {
    return {
      controller: new jv(),
      data: /* @__PURE__ */ new Map(),
      refCount: 0
    };
  }
  function Vu(l) {
    l.refCount--, l.refCount === 0 && Yv(Gv, function() {
      l.controller.abort();
    });
  }
  var Lu = null, xf = 0, fu = 0, cu = null;
  function Xv(l, t) {
    if (Lu === null) {
      var a = Lu = [];
      xf = 0, fu = Bc(), cu = {
        status: "pending",
        value: void 0,
        then: function(u) {
          a.push(u);
        }
      };
    }
    return xf++, t.then(T0, T0), t;
  }
  function T0() {
    if (--xf === 0 && Lu !== null) {
      cu !== null && (cu.status = "fulfilled");
      var l = Lu;
      Lu = null, fu = 0, cu = null;
      for (var t = 0; t < l.length; t++) (0, l[t])();
    }
  }
  function Qv(l, t) {
    var a = [], u = {
      status: "pending",
      value: null,
      reason: null,
      then: function(e) {
        a.push(e);
      }
    };
    return l.then(
      function() {
        u.status = "fulfilled", u.value = t;
        for (var e = 0; e < a.length; e++) (0, a[e])(t);
      },
      function(e) {
        for (u.status = "rejected", u.reason = e, e = 0; e < a.length; e++)
          (0, a[e])(void 0);
      }
    ), u;
  }
  var A0 = b.S;
  b.S = function(l, t) {
    fd = kl(), typeof t == "object" && t !== null && typeof t.then == "function" && Xv(l, t), A0 !== null && A0(l, t);
  };
  var xa = d(null);
  function Cf() {
    var l = xa.current;
    return l !== null ? l : il.pooledCache;
  }
  function Ke(l, t) {
    t === null ? M(xa, xa.current) : M(xa, t.pool);
  }
  function _0() {
    var l = Cf();
    return l === null ? null : { parent: rl._currentValue, pool: l };
  }
  var iu = Error(o(460)), qf = Error(o(474)), Je = Error(o(542)), we = { then: function() {
  } };
  function M0(l) {
    return l = l.status, l === "fulfilled" || l === "rejected";
  }
  function O0(l, t, a) {
    switch (a = l[a], a === void 0 ? l.push(t) : a !== t && (t.then(Ht, Ht), t = a), t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw l = t.reason, D0(l), l;
      default:
        if (typeof t.status == "string") t.then(Ht, Ht);
        else {
          if (l = il, l !== null && 100 < l.shellSuspendCounter)
            throw Error(o(482));
          l = t, l.status = "pending", l.then(
            function(u) {
              if (t.status === "pending") {
                var e = t;
                e.status = "fulfilled", e.value = u;
              }
            },
            function(u) {
              if (t.status === "pending") {
                var e = t;
                e.status = "rejected", e.reason = u;
              }
            }
          );
        }
        switch (t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw l = t.reason, D0(l), l;
        }
        throw qa = t, iu;
    }
  }
  function Ca(l) {
    try {
      var t = l._init;
      return t(l._payload);
    } catch (a) {
      throw a !== null && typeof a == "object" && typeof a.then == "function" ? (qa = a, iu) : a;
    }
  }
  var qa = null;
  function p0() {
    if (qa === null) throw Error(o(459));
    var l = qa;
    return qa = null, l;
  }
  function D0(l) {
    if (l === iu || l === Je)
      throw Error(o(483));
  }
  var su = null, Ku = 0;
  function We(l) {
    var t = Ku;
    return Ku += 1, su === null && (su = []), O0(su, l, t);
  }
  function Ju(l, t) {
    t = t.props.ref, l.ref = t !== void 0 ? t : null;
  }
  function $e(l, t) {
    throw t.$$typeof === yl ? Error(o(525)) : (l = Object.prototype.toString.call(t), Error(
      o(
        31,
        l === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : l
      )
    ));
  }
  function U0(l) {
    function t(y, s) {
      if (l) {
        var v = y.deletions;
        v === null ? (y.deletions = [s], y.flags |= 16) : v.push(s);
      }
    }
    function a(y, s) {
      if (!l) return null;
      for (; s !== null; )
        t(y, s), s = s.sibling;
      return null;
    }
    function u(y) {
      for (var s = /* @__PURE__ */ new Map(); y !== null; )
        y.key !== null ? s.set(y.key, y) : s.set(y.index, y), y = y.sibling;
      return s;
    }
    function e(y, s) {
      return y = xt(y, s), y.index = 0, y.sibling = null, y;
    }
    function n(y, s, v) {
      return y.index = v, l ? (v = y.alternate, v !== null ? (v = v.index, v < s ? (y.flags |= 67108866, s) : v) : (y.flags |= 67108866, s)) : (y.flags |= 1048576, s);
    }
    function f(y) {
      return l && y.alternate === null && (y.flags |= 67108866), y;
    }
    function c(y, s, v, r) {
      return s === null || s.tag !== 6 ? (s = Af(v, y.mode, r), s.return = y, s) : (s = e(s, v), s.return = y, s);
    }
    function i(y, s, v, r) {
      var N = v.type;
      return N === Cl ? S(
        y,
        s,
        v.props.children,
        r,
        v.key
      ) : s !== null && (s.elementType === N || typeof N == "object" && N !== null && N.$$typeof === Gl && Ca(N) === s.type) ? (s = e(s, v.props), Ju(s, v), s.return = y, s) : (s = Qe(
        v.type,
        v.key,
        v.props,
        null,
        y.mode,
        r
      ), Ju(s, v), s.return = y, s);
    }
    function m(y, s, v, r) {
      return s === null || s.tag !== 4 || s.stateNode.containerInfo !== v.containerInfo || s.stateNode.implementation !== v.implementation ? (s = _f(v, y.mode, r), s.return = y, s) : (s = e(s, v.children || []), s.return = y, s);
    }
    function S(y, s, v, r, N) {
      return s === null || s.tag !== 7 ? (s = Ua(
        v,
        y.mode,
        r,
        N
      ), s.return = y, s) : (s = e(s, v), s.return = y, s);
    }
    function z(y, s, v) {
      if (typeof s == "string" && s !== "" || typeof s == "number" || typeof s == "bigint")
        return s = Af(
          "" + s,
          y.mode,
          v
        ), s.return = y, s;
      if (typeof s == "object" && s !== null) {
        switch (s.$$typeof) {
          case Wl:
            return v = Qe(
              s.type,
              s.key,
              s.props,
              null,
              y.mode,
              v
            ), Ju(v, s), v.return = y, v;
          case jl:
            return s = _f(
              s,
              y.mode,
              v
            ), s.return = y, s;
          case Gl:
            return s = Ca(s), z(y, s, v);
        }
        if (St(s) || Xl(s))
          return s = Ua(
            s,
            y.mode,
            v,
            null
          ), s.return = y, s;
        if (typeof s.then == "function")
          return z(y, We(s), v);
        if (s.$$typeof === Rl)
          return z(
            y,
            Le(y, s),
            v
          );
        $e(y, s);
      }
      return null;
    }
    function h(y, s, v, r) {
      var N = s !== null ? s.key : null;
      if (typeof v == "string" && v !== "" || typeof v == "number" || typeof v == "bigint")
        return N !== null ? null : c(y, s, "" + v, r);
      if (typeof v == "object" && v !== null) {
        switch (v.$$typeof) {
          case Wl:
            return v.key === N ? i(y, s, v, r) : null;
          case jl:
            return v.key === N ? m(y, s, v, r) : null;
          case Gl:
            return v = Ca(v), h(y, s, v, r);
        }
        if (St(v) || Xl(v))
          return N !== null ? null : S(y, s, v, r, null);
        if (typeof v.then == "function")
          return h(
            y,
            s,
            We(v),
            r
          );
        if (v.$$typeof === Rl)
          return h(
            y,
            s,
            Le(y, v),
            r
          );
        $e(y, v);
      }
      return null;
    }
    function g(y, s, v, r, N) {
      if (typeof r == "string" && r !== "" || typeof r == "number" || typeof r == "bigint")
        return y = y.get(v) || null, c(s, y, "" + r, N);
      if (typeof r == "object" && r !== null) {
        switch (r.$$typeof) {
          case Wl:
            return y = y.get(
              r.key === null ? v : r.key
            ) || null, i(s, y, r, N);
          case jl:
            return y = y.get(
              r.key === null ? v : r.key
            ) || null, m(s, y, r, N);
          case Gl:
            return r = Ca(r), g(
              y,
              s,
              v,
              r,
              N
            );
        }
        if (St(r) || Xl(r))
          return y = y.get(v) || null, S(s, y, r, N, null);
        if (typeof r.then == "function")
          return g(
            y,
            s,
            v,
            We(r),
            N
          );
        if (r.$$typeof === Rl)
          return g(
            y,
            s,
            v,
            Le(s, r),
            N
          );
        $e(s, r);
      }
      return null;
    }
    function O(y, s, v, r) {
      for (var N = null, F = null, D = s, X = s = 0, w = null; D !== null && X < v.length; X++) {
        D.index > X ? (w = D, D = null) : w = D.sibling;
        var I = h(
          y,
          D,
          v[X],
          r
        );
        if (I === null) {
          D === null && (D = w);
          break;
        }
        l && D && I.alternate === null && t(y, D), s = n(I, s, X), F === null ? N = I : F.sibling = I, F = I, D = w;
      }
      if (X === v.length)
        return a(y, D), $ && Ct(y, X), N;
      if (D === null) {
        for (; X < v.length; X++)
          D = z(y, v[X], r), D !== null && (s = n(
            D,
            s,
            X
          ), F === null ? N = D : F.sibling = D, F = D);
        return $ && Ct(y, X), N;
      }
      for (D = u(D); X < v.length; X++)
        w = g(
          D,
          y,
          X,
          v[X],
          r
        ), w !== null && (l && w.alternate !== null && D.delete(
          w.key === null ? X : w.key
        ), s = n(
          w,
          s,
          X
        ), F === null ? N = w : F.sibling = w, F = w);
      return l && D.forEach(function(za) {
        return t(y, za);
      }), $ && Ct(y, X), N;
    }
    function H(y, s, v, r) {
      if (v == null) throw Error(o(151));
      for (var N = null, F = null, D = s, X = s = 0, w = null, I = v.next(); D !== null && !I.done; X++, I = v.next()) {
        D.index > X ? (w = D, D = null) : w = D.sibling;
        var za = h(y, D, I.value, r);
        if (za === null) {
          D === null && (D = w);
          break;
        }
        l && D && za.alternate === null && t(y, D), s = n(za, s, X), F === null ? N = za : F.sibling = za, F = za, D = w;
      }
      if (I.done)
        return a(y, D), $ && Ct(y, X), N;
      if (D === null) {
        for (; !I.done; X++, I = v.next())
          I = z(y, I.value, r), I !== null && (s = n(I, s, X), F === null ? N = I : F.sibling = I, F = I);
        return $ && Ct(y, X), N;
      }
      for (D = u(D); !I.done; X++, I = v.next())
        I = g(D, y, X, I.value, r), I !== null && (l && I.alternate !== null && D.delete(I.key === null ? X : I.key), s = n(I, s, X), F === null ? N = I : F.sibling = I, F = I);
      return l && D.forEach(function(I1) {
        return t(y, I1);
      }), $ && Ct(y, X), N;
    }
    function fl(y, s, v, r) {
      if (typeof v == "object" && v !== null && v.type === Cl && v.key === null && (v = v.props.children), typeof v == "object" && v !== null) {
        switch (v.$$typeof) {
          case Wl:
            l: {
              for (var N = v.key; s !== null; ) {
                if (s.key === N) {
                  if (N = v.type, N === Cl) {
                    if (s.tag === 7) {
                      a(
                        y,
                        s.sibling
                      ), r = e(
                        s,
                        v.props.children
                      ), r.return = y, y = r;
                      break l;
                    }
                  } else if (s.elementType === N || typeof N == "object" && N !== null && N.$$typeof === Gl && Ca(N) === s.type) {
                    a(
                      y,
                      s.sibling
                    ), r = e(s, v.props), Ju(r, v), r.return = y, y = r;
                    break l;
                  }
                  a(y, s);
                  break;
                } else t(y, s);
                s = s.sibling;
              }
              v.type === Cl ? (r = Ua(
                v.props.children,
                y.mode,
                r,
                v.key
              ), r.return = y, y = r) : (r = Qe(
                v.type,
                v.key,
                v.props,
                null,
                y.mode,
                r
              ), Ju(r, v), r.return = y, y = r);
            }
            return f(y);
          case jl:
            l: {
              for (N = v.key; s !== null; ) {
                if (s.key === N)
                  if (s.tag === 4 && s.stateNode.containerInfo === v.containerInfo && s.stateNode.implementation === v.implementation) {
                    a(
                      y,
                      s.sibling
                    ), r = e(s, v.children || []), r.return = y, y = r;
                    break l;
                  } else {
                    a(y, s);
                    break;
                  }
                else t(y, s);
                s = s.sibling;
              }
              r = _f(v, y.mode, r), r.return = y, y = r;
            }
            return f(y);
          case Gl:
            return v = Ca(v), fl(
              y,
              s,
              v,
              r
            );
        }
        if (St(v))
          return O(
            y,
            s,
            v,
            r
          );
        if (Xl(v)) {
          if (N = Xl(v), typeof N != "function") throw Error(o(150));
          return v = N.call(v), H(
            y,
            s,
            v,
            r
          );
        }
        if (typeof v.then == "function")
          return fl(
            y,
            s,
            We(v),
            r
          );
        if (v.$$typeof === Rl)
          return fl(
            y,
            s,
            Le(y, v),
            r
          );
        $e(y, v);
      }
      return typeof v == "string" && v !== "" || typeof v == "number" || typeof v == "bigint" ? (v = "" + v, s !== null && s.tag === 6 ? (a(y, s.sibling), r = e(s, v), r.return = y, y = r) : (a(y, s), r = Af(v, y.mode, r), r.return = y, y = r), f(y)) : a(y, s);
    }
    return function(y, s, v, r) {
      try {
        Ku = 0;
        var N = fl(
          y,
          s,
          v,
          r
        );
        return su = null, N;
      } catch (D) {
        if (D === iu || D === Je) throw D;
        var F = lt(29, D, null, y.mode);
        return F.lanes = r, F.return = y, F;
      }
    };
  }
  var Ba = U0(!0), N0 = U0(!1), ua = !1;
  function Bf(l) {
    l.updateQueue = {
      baseState: l.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null
    };
  }
  function jf(l, t) {
    l = l.updateQueue, t.updateQueue === l && (t.updateQueue = {
      baseState: l.baseState,
      firstBaseUpdate: l.firstBaseUpdate,
      lastBaseUpdate: l.lastBaseUpdate,
      shared: l.shared,
      callbacks: null
    });
  }
  function ea(l) {
    return { lane: l, tag: 0, payload: null, callback: null, next: null };
  }
  function na(l, t, a) {
    var u = l.updateQueue;
    if (u === null) return null;
    if (u = u.shared, (P & 2) !== 0) {
      var e = u.pending;
      return e === null ? t.next = t : (t.next = e.next, e.next = t), u.pending = t, t = Xe(l), m0(l, null, a), t;
    }
    return Ge(l, u, t, a), Xe(l);
  }
  function wu(l, t, a) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (a & 4194048) !== 0)) {
      var u = t.lanes;
      u &= l.pendingLanes, a |= u, t.lanes = a, Ei(l, a);
    }
  }
  function Yf(l, t) {
    var a = l.updateQueue, u = l.alternate;
    if (u !== null && (u = u.updateQueue, a === u)) {
      var e = null, n = null;
      if (a = a.firstBaseUpdate, a !== null) {
        do {
          var f = {
            lane: a.lane,
            tag: a.tag,
            payload: a.payload,
            callback: null,
            next: null
          };
          n === null ? e = n = f : n = n.next = f, a = a.next;
        } while (a !== null);
        n === null ? e = n = t : n = n.next = t;
      } else e = n = t;
      a = {
        baseState: u.baseState,
        firstBaseUpdate: e,
        lastBaseUpdate: n,
        shared: u.shared,
        callbacks: u.callbacks
      }, l.updateQueue = a;
      return;
    }
    l = a.lastBaseUpdate, l === null ? a.firstBaseUpdate = t : l.next = t, a.lastBaseUpdate = t;
  }
  var Gf = !1;
  function Wu() {
    if (Gf) {
      var l = cu;
      if (l !== null) throw l;
    }
  }
  function $u(l, t, a, u) {
    Gf = !1;
    var e = l.updateQueue;
    ua = !1;
    var n = e.firstBaseUpdate, f = e.lastBaseUpdate, c = e.shared.pending;
    if (c !== null) {
      e.shared.pending = null;
      var i = c, m = i.next;
      i.next = null, f === null ? n = m : f.next = m, f = i;
      var S = l.alternate;
      S !== null && (S = S.updateQueue, c = S.lastBaseUpdate, c !== f && (c === null ? S.firstBaseUpdate = m : c.next = m, S.lastBaseUpdate = i));
    }
    if (n !== null) {
      var z = e.baseState;
      f = 0, S = m = i = null, c = n;
      do {
        var h = c.lane & -536870913, g = h !== c.lane;
        if (g ? (J & h) === h : (u & h) === h) {
          h !== 0 && h === fu && (Gf = !0), S !== null && (S = S.next = {
            lane: 0,
            tag: c.tag,
            payload: c.payload,
            callback: null,
            next: null
          });
          l: {
            var O = l, H = c;
            h = t;
            var fl = a;
            switch (H.tag) {
              case 1:
                if (O = H.payload, typeof O == "function") {
                  z = O.call(fl, z, h);
                  break l;
                }
                z = O;
                break l;
              case 3:
                O.flags = O.flags & -65537 | 128;
              case 0:
                if (O = H.payload, h = typeof O == "function" ? O.call(fl, z, h) : O, h == null) break l;
                z = R({}, z, h);
                break l;
              case 2:
                ua = !0;
            }
          }
          h = c.callback, h !== null && (l.flags |= 64, g && (l.flags |= 8192), g = e.callbacks, g === null ? e.callbacks = [h] : g.push(h));
        } else
          g = {
            lane: h,
            tag: c.tag,
            payload: c.payload,
            callback: c.callback,
            next: null
          }, S === null ? (m = S = g, i = z) : S = S.next = g, f |= h;
        if (c = c.next, c === null) {
          if (c = e.shared.pending, c === null)
            break;
          g = c, c = g.next, g.next = null, e.lastBaseUpdate = g, e.shared.pending = null;
        }
      } while (!0);
      S === null && (i = z), e.baseState = i, e.firstBaseUpdate = m, e.lastBaseUpdate = S, n === null && (e.shared.lanes = 0), da |= f, l.lanes = f, l.memoizedState = z;
    }
  }
  function H0(l, t) {
    if (typeof l != "function")
      throw Error(o(191, l));
    l.call(t);
  }
  function R0(l, t) {
    var a = l.callbacks;
    if (a !== null)
      for (l.callbacks = null, l = 0; l < a.length; l++)
        H0(a[l], t);
  }
  var du = d(null), ke = d(0);
  function x0(l, t) {
    l = Kt, M(ke, l), M(du, t), Kt = l | t.baseLanes;
  }
  function Xf() {
    M(ke, Kt), M(du, du.current);
  }
  function Qf() {
    Kt = ke.current, E(du), E(ke);
  }
  var tt = d(null), ht = null;
  function fa(l) {
    var t = l.alternate;
    M(Sl, Sl.current & 1), M(tt, l), ht === null && (t === null || du.current !== null || t.memoizedState !== null) && (ht = l);
  }
  function Zf(l) {
    M(Sl, Sl.current), M(tt, l), ht === null && (ht = l);
  }
  function C0(l) {
    l.tag === 22 ? (M(Sl, Sl.current), M(tt, l), ht === null && (ht = l)) : ca();
  }
  function ca() {
    M(Sl, Sl.current), M(tt, tt.current);
  }
  function at(l) {
    E(tt), ht === l && (ht = null), E(Sl);
  }
  var Sl = d(0);
  function Fe(l) {
    for (var t = l; t !== null; ) {
      if (t.tag === 13) {
        var a = t.memoizedState;
        if (a !== null && (a = a.dehydrated, a === null || Wc(a) || $c(a)))
          return t;
      } else if (t.tag === 19 && (t.memoizedProps.revealOrder === "forwards" || t.memoizedProps.revealOrder === "backwards" || t.memoizedProps.revealOrder === "unstable_legacy-backwards" || t.memoizedProps.revealOrder === "together")) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === l) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === l) return null;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return null;
  }
  var jt = 0, Y = null, el = null, zl = null, Ie = !1, yu = !1, ja = !1, Pe = 0, ku = 0, vu = null, Zv = 0;
  function ml() {
    throw Error(o(321));
  }
  function Vf(l, t) {
    if (t === null) return !1;
    for (var a = 0; a < t.length && a < l.length; a++)
      if (!Pl(l[a], t[a])) return !1;
    return !0;
  }
  function Lf(l, t, a, u, e, n) {
    return jt = n, Y = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, b.H = l === null || l.memoizedState === null ? Ss : nc, ja = !1, n = a(u, e), ja = !1, yu && (n = B0(
      t,
      a,
      u,
      e
    )), q0(l), n;
  }
  function q0(l) {
    b.H = Pu;
    var t = el !== null && el.next !== null;
    if (jt = 0, zl = el = Y = null, Ie = !1, ku = 0, vu = null, t) throw Error(o(300));
    l === null || El || (l = l.dependencies, l !== null && Ve(l) && (El = !0));
  }
  function B0(l, t, a, u) {
    Y = l;
    var e = 0;
    do {
      if (yu && (vu = null), ku = 0, yu = !1, 25 <= e) throw Error(o(301));
      if (e += 1, zl = el = null, l.updateQueue != null) {
        var n = l.updateQueue;
        n.lastEffect = null, n.events = null, n.stores = null, n.memoCache != null && (n.memoCache.index = 0);
      }
      b.H = bs, n = t(a, u);
    } while (yu);
    return n;
  }
  function Vv() {
    var l = b.H, t = l.useState()[0];
    return t = typeof t.then == "function" ? Fu(t) : t, l = l.useState()[0], (el !== null ? el.memoizedState : null) !== l && (Y.flags |= 1024), t;
  }
  function Kf() {
    var l = Pe !== 0;
    return Pe = 0, l;
  }
  function Jf(l, t, a) {
    t.updateQueue = l.updateQueue, t.flags &= -2053, l.lanes &= ~a;
  }
  function wf(l) {
    if (Ie) {
      for (l = l.memoizedState; l !== null; ) {
        var t = l.queue;
        t !== null && (t.pending = null), l = l.next;
      }
      Ie = !1;
    }
    jt = 0, zl = el = Y = null, yu = !1, ku = Pe = 0, vu = null;
  }
  function Bl() {
    var l = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return zl === null ? Y.memoizedState = zl = l : zl = zl.next = l, zl;
  }
  function bl() {
    if (el === null) {
      var l = Y.alternate;
      l = l !== null ? l.memoizedState : null;
    } else l = el.next;
    var t = zl === null ? Y.memoizedState : zl.next;
    if (t !== null)
      zl = t, el = l;
    else {
      if (l === null)
        throw Y.alternate === null ? Error(o(467)) : Error(o(310));
      el = l, l = {
        memoizedState: el.memoizedState,
        baseState: el.baseState,
        baseQueue: el.baseQueue,
        queue: el.queue,
        next: null
      }, zl === null ? Y.memoizedState = zl = l : zl = zl.next = l;
    }
    return zl;
  }
  function ln() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function Fu(l) {
    var t = ku;
    return ku += 1, vu === null && (vu = []), l = O0(vu, l, t), t = Y, (zl === null ? t.memoizedState : zl.next) === null && (t = t.alternate, b.H = t === null || t.memoizedState === null ? Ss : nc), l;
  }
  function tn(l) {
    if (l !== null && typeof l == "object") {
      if (typeof l.then == "function") return Fu(l);
      if (l.$$typeof === Rl) return Ul(l);
    }
    throw Error(o(438, String(l)));
  }
  function Wf(l) {
    var t = null, a = Y.updateQueue;
    if (a !== null && (t = a.memoCache), t == null) {
      var u = Y.alternate;
      u !== null && (u = u.updateQueue, u !== null && (u = u.memoCache, u != null && (t = {
        data: u.data.map(function(e) {
          return e.slice();
        }),
        index: 0
      })));
    }
    if (t == null && (t = { data: [], index: 0 }), a === null && (a = ln(), Y.updateQueue = a), a.memoCache = t, a = t.data[t.index], a === void 0)
      for (a = t.data[t.index] = Array(l), u = 0; u < l; u++)
        a[u] = Qa;
    return t.index++, a;
  }
  function Yt(l, t) {
    return typeof t == "function" ? t(l) : t;
  }
  function an(l) {
    var t = bl();
    return $f(t, el, l);
  }
  function $f(l, t, a) {
    var u = l.queue;
    if (u === null) throw Error(o(311));
    u.lastRenderedReducer = a;
    var e = l.baseQueue, n = u.pending;
    if (n !== null) {
      if (e !== null) {
        var f = e.next;
        e.next = n.next, n.next = f;
      }
      t.baseQueue = e = n, u.pending = null;
    }
    if (n = l.baseState, e === null) l.memoizedState = n;
    else {
      t = e.next;
      var c = f = null, i = null, m = t, S = !1;
      do {
        var z = m.lane & -536870913;
        if (z !== m.lane ? (J & z) === z : (jt & z) === z) {
          var h = m.revertLane;
          if (h === 0)
            i !== null && (i = i.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: m.action,
              hasEagerState: m.hasEagerState,
              eagerState: m.eagerState,
              next: null
            }), z === fu && (S = !0);
          else if ((jt & h) === h) {
            m = m.next, h === fu && (S = !0);
            continue;
          } else
            z = {
              lane: 0,
              revertLane: m.revertLane,
              gesture: null,
              action: m.action,
              hasEagerState: m.hasEagerState,
              eagerState: m.eagerState,
              next: null
            }, i === null ? (c = i = z, f = n) : i = i.next = z, Y.lanes |= h, da |= h;
          z = m.action, ja && a(n, z), n = m.hasEagerState ? m.eagerState : a(n, z);
        } else
          h = {
            lane: z,
            revertLane: m.revertLane,
            gesture: m.gesture,
            action: m.action,
            hasEagerState: m.hasEagerState,
            eagerState: m.eagerState,
            next: null
          }, i === null ? (c = i = h, f = n) : i = i.next = h, Y.lanes |= z, da |= z;
        m = m.next;
      } while (m !== null && m !== t);
      if (i === null ? f = n : i.next = c, !Pl(n, l.memoizedState) && (El = !0, S && (a = cu, a !== null)))
        throw a;
      l.memoizedState = n, l.baseState = f, l.baseQueue = i, u.lastRenderedState = n;
    }
    return e === null && (u.lanes = 0), [l.memoizedState, u.dispatch];
  }
  function kf(l) {
    var t = bl(), a = t.queue;
    if (a === null) throw Error(o(311));
    a.lastRenderedReducer = l;
    var u = a.dispatch, e = a.pending, n = t.memoizedState;
    if (e !== null) {
      a.pending = null;
      var f = e = e.next;
      do
        n = l(n, f.action), f = f.next;
      while (f !== e);
      Pl(n, t.memoizedState) || (El = !0), t.memoizedState = n, t.baseQueue === null && (t.baseState = n), a.lastRenderedState = n;
    }
    return [n, u];
  }
  function j0(l, t, a) {
    var u = Y, e = bl(), n = $;
    if (n) {
      if (a === void 0) throw Error(o(407));
      a = a();
    } else a = t();
    var f = !Pl(
      (el || e).memoizedState,
      a
    );
    if (f && (e.memoizedState = a, El = !0), e = e.queue, Pf(X0.bind(null, u, e, l), [
      l
    ]), e.getSnapshot !== t || f || zl !== null && zl.memoizedState.tag & 1) {
      if (u.flags |= 2048, mu(
        9,
        { destroy: void 0 },
        G0.bind(
          null,
          u,
          e,
          a,
          t
        ),
        null
      ), il === null) throw Error(o(349));
      n || (jt & 127) !== 0 || Y0(u, t, a);
    }
    return a;
  }
  function Y0(l, t, a) {
    l.flags |= 16384, l = { getSnapshot: t, value: a }, t = Y.updateQueue, t === null ? (t = ln(), Y.updateQueue = t, t.stores = [l]) : (a = t.stores, a === null ? t.stores = [l] : a.push(l));
  }
  function G0(l, t, a, u) {
    t.value = a, t.getSnapshot = u, Q0(t) && Z0(l);
  }
  function X0(l, t, a) {
    return a(function() {
      Q0(t) && Z0(l);
    });
  }
  function Q0(l) {
    var t = l.getSnapshot;
    l = l.value;
    try {
      var a = t();
      return !Pl(l, a);
    } catch {
      return !0;
    }
  }
  function Z0(l) {
    var t = Da(l, 2);
    t !== null && wl(t, l, 2);
  }
  function Ff(l) {
    var t = Bl();
    if (typeof l == "function") {
      var a = l;
      if (l = a(), ja) {
        kt(!0);
        try {
          a();
        } finally {
          kt(!1);
        }
      }
    }
    return t.memoizedState = t.baseState = l, t.queue = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: Yt,
      lastRenderedState: l
    }, t;
  }
  function V0(l, t, a, u) {
    return l.baseState = a, $f(
      l,
      el,
      typeof u == "function" ? u : Yt
    );
  }
  function Lv(l, t, a, u, e) {
    if (nn(l)) throw Error(o(485));
    if (l = t.action, l !== null) {
      var n = {
        payload: e,
        action: l,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function(f) {
          n.listeners.push(f);
        }
      };
      b.T !== null ? a(!0) : n.isTransition = !1, u(n), a = t.pending, a === null ? (n.next = t.pending = n, L0(t, n)) : (n.next = a.next, t.pending = a.next = n);
    }
  }
  function L0(l, t) {
    var a = t.action, u = t.payload, e = l.state;
    if (t.isTransition) {
      var n = b.T, f = {};
      b.T = f;
      try {
        var c = a(e, u), i = b.S;
        i !== null && i(f, c), K0(l, t, c);
      } catch (m) {
        If(l, t, m);
      } finally {
        n !== null && f.types !== null && (n.types = f.types), b.T = n;
      }
    } else
      try {
        n = a(e, u), K0(l, t, n);
      } catch (m) {
        If(l, t, m);
      }
  }
  function K0(l, t, a) {
    a !== null && typeof a == "object" && typeof a.then == "function" ? a.then(
      function(u) {
        J0(l, t, u);
      },
      function(u) {
        return If(l, t, u);
      }
    ) : J0(l, t, a);
  }
  function J0(l, t, a) {
    t.status = "fulfilled", t.value = a, w0(t), l.state = a, t = l.pending, t !== null && (a = t.next, a === t ? l.pending = null : (a = a.next, t.next = a, L0(l, a)));
  }
  function If(l, t, a) {
    var u = l.pending;
    if (l.pending = null, u !== null) {
      u = u.next;
      do
        t.status = "rejected", t.reason = a, w0(t), t = t.next;
      while (t !== u);
    }
    l.action = null;
  }
  function w0(l) {
    l = l.listeners;
    for (var t = 0; t < l.length; t++) (0, l[t])();
  }
  function W0(l, t) {
    return t;
  }
  function $0(l, t) {
    if ($) {
      var a = il.formState;
      if (a !== null) {
        l: {
          var u = Y;
          if ($) {
            if (sl) {
              t: {
                for (var e = sl, n = mt; e.nodeType !== 8; ) {
                  if (!n) {
                    e = null;
                    break t;
                  }
                  if (e = ot(
                    e.nextSibling
                  ), e === null) {
                    e = null;
                    break t;
                  }
                }
                n = e.data, e = n === "F!" || n === "F" ? e : null;
              }
              if (e) {
                sl = ot(
                  e.nextSibling
                ), u = e.data === "F!";
                break l;
              }
            }
            ta(u);
          }
          u = !1;
        }
        u && (t = a[0]);
      }
    }
    return a = Bl(), a.memoizedState = a.baseState = t, u = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: W0,
      lastRenderedState: t
    }, a.queue = u, a = hs.bind(
      null,
      Y,
      u
    ), u.dispatch = a, u = Ff(!1), n = ec.bind(
      null,
      Y,
      !1,
      u.queue
    ), u = Bl(), e = {
      state: t,
      dispatch: null,
      action: l,
      pending: null
    }, u.queue = e, a = Lv.bind(
      null,
      Y,
      e,
      n,
      a
    ), e.dispatch = a, u.memoizedState = l, [t, a, !1];
  }
  function k0(l) {
    var t = bl();
    return F0(t, el, l);
  }
  function F0(l, t, a) {
    if (t = $f(
      l,
      t,
      W0
    )[0], l = an(Yt)[0], typeof t == "object" && t !== null && typeof t.then == "function")
      try {
        var u = Fu(t);
      } catch (f) {
        throw f === iu ? Je : f;
      }
    else u = t;
    t = bl();
    var e = t.queue, n = e.dispatch;
    return a !== t.memoizedState && (Y.flags |= 2048, mu(
      9,
      { destroy: void 0 },
      Kv.bind(null, e, a),
      null
    )), [u, n, l];
  }
  function Kv(l, t) {
    l.action = t;
  }
  function I0(l) {
    var t = bl(), a = el;
    if (a !== null)
      return F0(t, a, l);
    bl(), t = t.memoizedState, a = bl();
    var u = a.queue.dispatch;
    return a.memoizedState = l, [t, u, !1];
  }
  function mu(l, t, a, u) {
    return l = { tag: l, create: a, deps: u, inst: t, next: null }, t = Y.updateQueue, t === null && (t = ln(), Y.updateQueue = t), a = t.lastEffect, a === null ? t.lastEffect = l.next = l : (u = a.next, a.next = l, l.next = u, t.lastEffect = l), l;
  }
  function P0() {
    return bl().memoizedState;
  }
  function un(l, t, a, u) {
    var e = Bl();
    Y.flags |= l, e.memoizedState = mu(
      1 | t,
      { destroy: void 0 },
      a,
      u === void 0 ? null : u
    );
  }
  function en(l, t, a, u) {
    var e = bl();
    u = u === void 0 ? null : u;
    var n = e.memoizedState.inst;
    el !== null && u !== null && Vf(u, el.memoizedState.deps) ? e.memoizedState = mu(t, n, a, u) : (Y.flags |= l, e.memoizedState = mu(
      1 | t,
      n,
      a,
      u
    ));
  }
  function ls(l, t) {
    un(8390656, 8, l, t);
  }
  function Pf(l, t) {
    en(2048, 8, l, t);
  }
  function Jv(l) {
    Y.flags |= 4;
    var t = Y.updateQueue;
    if (t === null)
      t = ln(), Y.updateQueue = t, t.events = [l];
    else {
      var a = t.events;
      a === null ? t.events = [l] : a.push(l);
    }
  }
  function ts(l) {
    var t = bl().memoizedState;
    return Jv({ ref: t, nextImpl: l }), function() {
      if ((P & 2) !== 0) throw Error(o(440));
      return t.impl.apply(void 0, arguments);
    };
  }
  function as(l, t) {
    return en(4, 2, l, t);
  }
  function us(l, t) {
    return en(4, 4, l, t);
  }
  function es(l, t) {
    if (typeof t == "function") {
      l = l();
      var a = t(l);
      return function() {
        typeof a == "function" ? a() : t(null);
      };
    }
    if (t != null)
      return l = l(), t.current = l, function() {
        t.current = null;
      };
  }
  function ns(l, t, a) {
    a = a != null ? a.concat([l]) : null, en(4, 4, es.bind(null, t, l), a);
  }
  function lc() {
  }
  function fs(l, t) {
    var a = bl();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    return t !== null && Vf(t, u[1]) ? u[0] : (a.memoizedState = [l, t], l);
  }
  function cs(l, t) {
    var a = bl();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    if (t !== null && Vf(t, u[1]))
      return u[0];
    if (u = l(), ja) {
      kt(!0);
      try {
        l();
      } finally {
        kt(!1);
      }
    }
    return a.memoizedState = [u, t], u;
  }
  function tc(l, t, a) {
    return a === void 0 || (jt & 1073741824) !== 0 && (J & 261930) === 0 ? l.memoizedState = t : (l.memoizedState = a, l = id(), Y.lanes |= l, da |= l, a);
  }
  function is(l, t, a, u) {
    return Pl(a, t) ? a : du.current !== null ? (l = tc(l, a, u), Pl(l, t) || (El = !0), l) : (jt & 42) === 0 || (jt & 1073741824) !== 0 && (J & 261930) === 0 ? (El = !0, l.memoizedState = a) : (l = id(), Y.lanes |= l, da |= l, t);
  }
  function ss(l, t, a, u, e) {
    var n = _.p;
    _.p = n !== 0 && 8 > n ? n : 8;
    var f = b.T, c = {};
    b.T = c, ec(l, !1, t, a);
    try {
      var i = e(), m = b.S;
      if (m !== null && m(c, i), i !== null && typeof i == "object" && typeof i.then == "function") {
        var S = Qv(
          i,
          u
        );
        Iu(
          l,
          t,
          S,
          nt(l)
        );
      } else
        Iu(
          l,
          t,
          u,
          nt(l)
        );
    } catch (z) {
      Iu(
        l,
        t,
        { then: function() {
        }, status: "rejected", reason: z },
        nt()
      );
    } finally {
      _.p = n, f !== null && c.types !== null && (f.types = c.types), b.T = f;
    }
  }
  function wv() {
  }
  function ac(l, t, a, u) {
    if (l.tag !== 5) throw Error(o(476));
    var e = ds(l).queue;
    ss(
      l,
      e,
      t,
      x,
      a === null ? wv : function() {
        return ys(l), a(u);
      }
    );
  }
  function ds(l) {
    var t = l.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: x,
      baseState: x,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Yt,
        lastRenderedState: x
      },
      next: null
    };
    var a = {};
    return t.next = {
      memoizedState: a,
      baseState: a,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Yt,
        lastRenderedState: a
      },
      next: null
    }, l.memoizedState = t, l = l.alternate, l !== null && (l.memoizedState = t), t;
  }
  function ys(l) {
    var t = ds(l);
    t.next === null && (t = l.alternate.memoizedState), Iu(
      l,
      t.next.queue,
      {},
      nt()
    );
  }
  function uc() {
    return Ul(oe);
  }
  function vs() {
    return bl().memoizedState;
  }
  function ms() {
    return bl().memoizedState;
  }
  function Wv(l) {
    for (var t = l.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var a = nt();
          l = ea(a);
          var u = na(t, l, a);
          u !== null && (wl(u, t, a), wu(u, t, a)), t = { cache: Rf() }, l.payload = t;
          return;
      }
      t = t.return;
    }
  }
  function $v(l, t, a) {
    var u = nt();
    a = {
      lane: u,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, nn(l) ? os(t, a) : (a = Ef(l, t, a, u), a !== null && (wl(a, l, u), gs(a, t, u)));
  }
  function hs(l, t, a) {
    var u = nt();
    Iu(l, t, a, u);
  }
  function Iu(l, t, a, u) {
    var e = {
      lane: u,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if (nn(l)) os(t, e);
    else {
      var n = l.alternate;
      if (l.lanes === 0 && (n === null || n.lanes === 0) && (n = t.lastRenderedReducer, n !== null))
        try {
          var f = t.lastRenderedState, c = n(f, a);
          if (e.hasEagerState = !0, e.eagerState = c, Pl(c, f))
            return Ge(l, t, e, 0), il === null && Ye(), !1;
        } catch {
        }
      if (a = Ef(l, t, e, u), a !== null)
        return wl(a, l, u), gs(a, t, u), !0;
    }
    return !1;
  }
  function ec(l, t, a, u) {
    if (u = {
      lane: 2,
      revertLane: Bc(),
      gesture: null,
      action: u,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, nn(l)) {
      if (t) throw Error(o(479));
    } else
      t = Ef(
        l,
        a,
        u,
        2
      ), t !== null && wl(t, l, 2);
  }
  function nn(l) {
    var t = l.alternate;
    return l === Y || t !== null && t === Y;
  }
  function os(l, t) {
    yu = Ie = !0;
    var a = l.pending;
    a === null ? t.next = t : (t.next = a.next, a.next = t), l.pending = t;
  }
  function gs(l, t, a) {
    if ((a & 4194048) !== 0) {
      var u = t.lanes;
      u &= l.pendingLanes, a |= u, t.lanes = a, Ei(l, a);
    }
  }
  var Pu = {
    readContext: Ul,
    use: tn,
    useCallback: ml,
    useContext: ml,
    useEffect: ml,
    useImperativeHandle: ml,
    useLayoutEffect: ml,
    useInsertionEffect: ml,
    useMemo: ml,
    useReducer: ml,
    useRef: ml,
    useState: ml,
    useDebugValue: ml,
    useDeferredValue: ml,
    useTransition: ml,
    useSyncExternalStore: ml,
    useId: ml,
    useHostTransitionStatus: ml,
    useFormState: ml,
    useActionState: ml,
    useOptimistic: ml,
    useMemoCache: ml,
    useCacheRefresh: ml
  };
  Pu.useEffectEvent = ml;
  var Ss = {
    readContext: Ul,
    use: tn,
    useCallback: function(l, t) {
      return Bl().memoizedState = [
        l,
        t === void 0 ? null : t
      ], l;
    },
    useContext: Ul,
    useEffect: ls,
    useImperativeHandle: function(l, t, a) {
      a = a != null ? a.concat([l]) : null, un(
        4194308,
        4,
        es.bind(null, t, l),
        a
      );
    },
    useLayoutEffect: function(l, t) {
      return un(4194308, 4, l, t);
    },
    useInsertionEffect: function(l, t) {
      un(4, 2, l, t);
    },
    useMemo: function(l, t) {
      var a = Bl();
      t = t === void 0 ? null : t;
      var u = l();
      if (ja) {
        kt(!0);
        try {
          l();
        } finally {
          kt(!1);
        }
      }
      return a.memoizedState = [u, t], u;
    },
    useReducer: function(l, t, a) {
      var u = Bl();
      if (a !== void 0) {
        var e = a(t);
        if (ja) {
          kt(!0);
          try {
            a(t);
          } finally {
            kt(!1);
          }
        }
      } else e = t;
      return u.memoizedState = u.baseState = e, l = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: l,
        lastRenderedState: e
      }, u.queue = l, l = l.dispatch = $v.bind(
        null,
        Y,
        l
      ), [u.memoizedState, l];
    },
    useRef: function(l) {
      var t = Bl();
      return l = { current: l }, t.memoizedState = l;
    },
    useState: function(l) {
      l = Ff(l);
      var t = l.queue, a = hs.bind(null, Y, t);
      return t.dispatch = a, [l.memoizedState, a];
    },
    useDebugValue: lc,
    useDeferredValue: function(l, t) {
      var a = Bl();
      return tc(a, l, t);
    },
    useTransition: function() {
      var l = Ff(!1);
      return l = ss.bind(
        null,
        Y,
        l.queue,
        !0,
        !1
      ), Bl().memoizedState = l, [!1, l];
    },
    useSyncExternalStore: function(l, t, a) {
      var u = Y, e = Bl();
      if ($) {
        if (a === void 0)
          throw Error(o(407));
        a = a();
      } else {
        if (a = t(), il === null)
          throw Error(o(349));
        (J & 127) !== 0 || Y0(u, t, a);
      }
      e.memoizedState = a;
      var n = { value: a, getSnapshot: t };
      return e.queue = n, ls(X0.bind(null, u, n, l), [
        l
      ]), u.flags |= 2048, mu(
        9,
        { destroy: void 0 },
        G0.bind(
          null,
          u,
          n,
          a,
          t
        ),
        null
      ), a;
    },
    useId: function() {
      var l = Bl(), t = il.identifierPrefix;
      if ($) {
        var a = Mt, u = _t;
        a = (u & ~(1 << 32 - Il(u) - 1)).toString(32) + a, t = "_" + t + "R_" + a, a = Pe++, 0 < a && (t += "H" + a.toString(32)), t += "_";
      } else
        a = Zv++, t = "_" + t + "r_" + a.toString(32) + "_";
      return l.memoizedState = t;
    },
    useHostTransitionStatus: uc,
    useFormState: $0,
    useActionState: $0,
    useOptimistic: function(l) {
      var t = Bl();
      t.memoizedState = t.baseState = l;
      var a = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return t.queue = a, t = ec.bind(
        null,
        Y,
        !0,
        a
      ), a.dispatch = t, [l, t];
    },
    useMemoCache: Wf,
    useCacheRefresh: function() {
      return Bl().memoizedState = Wv.bind(
        null,
        Y
      );
    },
    useEffectEvent: function(l) {
      var t = Bl(), a = { impl: l };
      return t.memoizedState = a, function() {
        if ((P & 2) !== 0)
          throw Error(o(440));
        return a.impl.apply(void 0, arguments);
      };
    }
  }, nc = {
    readContext: Ul,
    use: tn,
    useCallback: fs,
    useContext: Ul,
    useEffect: Pf,
    useImperativeHandle: ns,
    useInsertionEffect: as,
    useLayoutEffect: us,
    useMemo: cs,
    useReducer: an,
    useRef: P0,
    useState: function() {
      return an(Yt);
    },
    useDebugValue: lc,
    useDeferredValue: function(l, t) {
      var a = bl();
      return is(
        a,
        el.memoizedState,
        l,
        t
      );
    },
    useTransition: function() {
      var l = an(Yt)[0], t = bl().memoizedState;
      return [
        typeof l == "boolean" ? l : Fu(l),
        t
      ];
    },
    useSyncExternalStore: j0,
    useId: vs,
    useHostTransitionStatus: uc,
    useFormState: k0,
    useActionState: k0,
    useOptimistic: function(l, t) {
      var a = bl();
      return V0(a, el, l, t);
    },
    useMemoCache: Wf,
    useCacheRefresh: ms
  };
  nc.useEffectEvent = ts;
  var bs = {
    readContext: Ul,
    use: tn,
    useCallback: fs,
    useContext: Ul,
    useEffect: Pf,
    useImperativeHandle: ns,
    useInsertionEffect: as,
    useLayoutEffect: us,
    useMemo: cs,
    useReducer: kf,
    useRef: P0,
    useState: function() {
      return kf(Yt);
    },
    useDebugValue: lc,
    useDeferredValue: function(l, t) {
      var a = bl();
      return el === null ? tc(a, l, t) : is(
        a,
        el.memoizedState,
        l,
        t
      );
    },
    useTransition: function() {
      var l = kf(Yt)[0], t = bl().memoizedState;
      return [
        typeof l == "boolean" ? l : Fu(l),
        t
      ];
    },
    useSyncExternalStore: j0,
    useId: vs,
    useHostTransitionStatus: uc,
    useFormState: I0,
    useActionState: I0,
    useOptimistic: function(l, t) {
      var a = bl();
      return el !== null ? V0(a, el, l, t) : (a.baseState = l, [l, a.queue.dispatch]);
    },
    useMemoCache: Wf,
    useCacheRefresh: ms
  };
  bs.useEffectEvent = ts;
  function fc(l, t, a, u) {
    t = l.memoizedState, a = a(u, t), a = a == null ? t : R({}, t, a), l.memoizedState = a, l.lanes === 0 && (l.updateQueue.baseState = a);
  }
  var cc = {
    enqueueSetState: function(l, t, a) {
      l = l._reactInternals;
      var u = nt(), e = ea(u);
      e.payload = t, a != null && (e.callback = a), t = na(l, e, u), t !== null && (wl(t, l, u), wu(t, l, u));
    },
    enqueueReplaceState: function(l, t, a) {
      l = l._reactInternals;
      var u = nt(), e = ea(u);
      e.tag = 1, e.payload = t, a != null && (e.callback = a), t = na(l, e, u), t !== null && (wl(t, l, u), wu(t, l, u));
    },
    enqueueForceUpdate: function(l, t) {
      l = l._reactInternals;
      var a = nt(), u = ea(a);
      u.tag = 2, t != null && (u.callback = t), t = na(l, u, a), t !== null && (wl(t, l, a), wu(t, l, a));
    }
  };
  function rs(l, t, a, u, e, n, f) {
    return l = l.stateNode, typeof l.shouldComponentUpdate == "function" ? l.shouldComponentUpdate(u, n, f) : t.prototype && t.prototype.isPureReactComponent ? !Gu(a, u) || !Gu(e, n) : !0;
  }
  function zs(l, t, a, u) {
    l = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(a, u), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(a, u), t.state !== l && cc.enqueueReplaceState(t, t.state, null);
  }
  function Ya(l, t) {
    var a = t;
    if ("ref" in t) {
      a = {};
      for (var u in t)
        u !== "ref" && (a[u] = t[u]);
    }
    if (l = l.defaultProps) {
      a === t && (a = R({}, a));
      for (var e in l)
        a[e] === void 0 && (a[e] = l[e]);
    }
    return a;
  }
  function Es(l) {
    je(l);
  }
  function Ts(l) {
    console.error(l);
  }
  function As(l) {
    je(l);
  }
  function fn(l, t) {
    try {
      var a = l.onUncaughtError;
      a(t.value, { componentStack: t.stack });
    } catch (u) {
      setTimeout(function() {
        throw u;
      });
    }
  }
  function _s(l, t, a) {
    try {
      var u = l.onCaughtError;
      u(a.value, {
        componentStack: a.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null
      });
    } catch (e) {
      setTimeout(function() {
        throw e;
      });
    }
  }
  function ic(l, t, a) {
    return a = ea(a), a.tag = 3, a.payload = { element: null }, a.callback = function() {
      fn(l, t);
    }, a;
  }
  function Ms(l) {
    return l = ea(l), l.tag = 3, l;
  }
  function Os(l, t, a, u) {
    var e = a.type.getDerivedStateFromError;
    if (typeof e == "function") {
      var n = u.value;
      l.payload = function() {
        return e(n);
      }, l.callback = function() {
        _s(t, a, u);
      };
    }
    var f = a.stateNode;
    f !== null && typeof f.componentDidCatch == "function" && (l.callback = function() {
      _s(t, a, u), typeof e != "function" && (ya === null ? ya = /* @__PURE__ */ new Set([this]) : ya.add(this));
      var c = u.stack;
      this.componentDidCatch(u.value, {
        componentStack: c !== null ? c : ""
      });
    });
  }
  function kv(l, t, a, u, e) {
    if (a.flags |= 32768, u !== null && typeof u == "object" && typeof u.then == "function") {
      if (t = a.alternate, t !== null && nu(
        t,
        a,
        e,
        !0
      ), a = tt.current, a !== null) {
        switch (a.tag) {
          case 31:
          case 13:
            return ht === null ? rn() : a.alternate === null && hl === 0 && (hl = 3), a.flags &= -257, a.flags |= 65536, a.lanes = e, u === we ? a.flags |= 16384 : (t = a.updateQueue, t === null ? a.updateQueue = /* @__PURE__ */ new Set([u]) : t.add(u), xc(l, u, e)), !1;
          case 22:
            return a.flags |= 65536, u === we ? a.flags |= 16384 : (t = a.updateQueue, t === null ? (t = {
              transitions: null,
              markerInstances: null,
              retryQueue: /* @__PURE__ */ new Set([u])
            }, a.updateQueue = t) : (a = t.retryQueue, a === null ? t.retryQueue = /* @__PURE__ */ new Set([u]) : a.add(u)), xc(l, u, e)), !1;
        }
        throw Error(o(435, a.tag));
      }
      return xc(l, u, e), rn(), !1;
    }
    if ($)
      return t = tt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = e, u !== pf && (l = Error(o(422), { cause: u }), Zu(dt(l, a)))) : (u !== pf && (t = Error(o(423), {
        cause: u
      }), Zu(
        dt(t, a)
      )), l = l.current.alternate, l.flags |= 65536, e &= -e, l.lanes |= e, u = dt(u, a), e = ic(
        l.stateNode,
        u,
        e
      ), Yf(l, e), hl !== 4 && (hl = 2)), !1;
    var n = Error(o(520), { cause: u });
    if (n = dt(n, a), ce === null ? ce = [n] : ce.push(n), hl !== 4 && (hl = 2), t === null) return !0;
    u = dt(u, a), a = t;
    do {
      switch (a.tag) {
        case 3:
          return a.flags |= 65536, l = e & -e, a.lanes |= l, l = ic(a.stateNode, u, l), Yf(a, l), !1;
        case 1:
          if (t = a.type, n = a.stateNode, (a.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || n !== null && typeof n.componentDidCatch == "function" && (ya === null || !ya.has(n))))
            return a.flags |= 65536, e &= -e, a.lanes |= e, e = Ms(e), Os(
              e,
              l,
              a,
              u
            ), Yf(a, e), !1;
      }
      a = a.return;
    } while (a !== null);
    return !1;
  }
  var sc = Error(o(461)), El = !1;
  function Nl(l, t, a, u) {
    t.child = l === null ? N0(t, null, a, u) : Ba(
      t,
      l.child,
      a,
      u
    );
  }
  function ps(l, t, a, u, e) {
    a = a.render;
    var n = t.ref;
    if ("ref" in u) {
      var f = {};
      for (var c in u)
        c !== "ref" && (f[c] = u[c]);
    } else f = u;
    return Ra(t), u = Lf(
      l,
      t,
      a,
      f,
      n,
      e
    ), c = Kf(), l !== null && !El ? (Jf(l, t, e), Gt(l, t, e)) : ($ && c && Mf(t), t.flags |= 1, Nl(l, t, u, e), t.child);
  }
  function Ds(l, t, a, u, e) {
    if (l === null) {
      var n = a.type;
      return typeof n == "function" && !Tf(n) && n.defaultProps === void 0 && a.compare === null ? (t.tag = 15, t.type = n, Us(
        l,
        t,
        n,
        u,
        e
      )) : (l = Qe(
        a.type,
        null,
        u,
        t,
        t.mode,
        e
      ), l.ref = t.ref, l.return = t, t.child = l);
    }
    if (n = l.child, !Sc(l, e)) {
      var f = n.memoizedProps;
      if (a = a.compare, a = a !== null ? a : Gu, a(f, u) && l.ref === t.ref)
        return Gt(l, t, e);
    }
    return t.flags |= 1, l = xt(n, u), l.ref = t.ref, l.return = t, t.child = l;
  }
  function Us(l, t, a, u, e) {
    if (l !== null) {
      var n = l.memoizedProps;
      if (Gu(n, u) && l.ref === t.ref)
        if (El = !1, t.pendingProps = u = n, Sc(l, e))
          (l.flags & 131072) !== 0 && (El = !0);
        else
          return t.lanes = l.lanes, Gt(l, t, e);
    }
    return dc(
      l,
      t,
      a,
      u,
      e
    );
  }
  function Ns(l, t, a, u) {
    var e = u.children, n = l !== null ? l.memoizedState : null;
    if (l === null && t.stateNode === null && (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), u.mode === "hidden") {
      if ((t.flags & 128) !== 0) {
        if (n = n !== null ? n.baseLanes | a : a, l !== null) {
          for (u = t.child = l.child, e = 0; u !== null; )
            e = e | u.lanes | u.childLanes, u = u.sibling;
          u = e & ~n;
        } else u = 0, t.child = null;
        return Hs(
          l,
          t,
          n,
          a,
          u
        );
      }
      if ((a & 536870912) !== 0)
        t.memoizedState = { baseLanes: 0, cachePool: null }, l !== null && Ke(
          t,
          n !== null ? n.cachePool : null
        ), n !== null ? x0(t, n) : Xf(), C0(t);
      else
        return u = t.lanes = 536870912, Hs(
          l,
          t,
          n !== null ? n.baseLanes | a : a,
          a,
          u
        );
    } else
      n !== null ? (Ke(t, n.cachePool), x0(t, n), ca(), t.memoizedState = null) : (l !== null && Ke(t, null), Xf(), ca());
    return Nl(l, t, e, a), t.child;
  }
  function le(l, t) {
    return l !== null && l.tag === 22 || t.stateNode !== null || (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), t.sibling;
  }
  function Hs(l, t, a, u, e) {
    var n = Cf();
    return n = n === null ? null : { parent: rl._currentValue, pool: n }, t.memoizedState = {
      baseLanes: a,
      cachePool: n
    }, l !== null && Ke(t, null), Xf(), C0(t), l !== null && nu(l, t, u, !0), t.childLanes = e, null;
  }
  function cn(l, t) {
    return t = dn(
      { mode: t.mode, children: t.children },
      l.mode
    ), t.ref = l.ref, l.child = t, t.return = l, t;
  }
  function Rs(l, t, a) {
    return Ba(t, l.child, null, a), l = cn(t, t.pendingProps), l.flags |= 2, at(t), t.memoizedState = null, l;
  }
  function Fv(l, t, a) {
    var u = t.pendingProps, e = (t.flags & 128) !== 0;
    if (t.flags &= -129, l === null) {
      if ($) {
        if (u.mode === "hidden")
          return l = cn(t, u), t.lanes = 536870912, le(null, l);
        if (Zf(t), (l = sl) ? (l = Ld(
          l,
          mt
        ), l = l !== null && l.data === "&" ? l : null, l !== null && (t.memoizedState = {
          dehydrated: l,
          treeContext: Pt !== null ? { id: _t, overflow: Mt } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = o0(l), a.return = t, t.child = a, Dl = t, sl = null)) : l = null, l === null) throw ta(t);
        return t.lanes = 536870912, null;
      }
      return cn(t, u);
    }
    var n = l.memoizedState;
    if (n !== null) {
      var f = n.dehydrated;
      if (Zf(t), e)
        if (t.flags & 256)
          t.flags &= -257, t = Rs(
            l,
            t,
            a
          );
        else if (t.memoizedState !== null)
          t.child = l.child, t.flags |= 128, t = null;
        else throw Error(o(558));
      else if (El || nu(l, t, a, !1), e = (a & l.childLanes) !== 0, El || e) {
        if (u = il, u !== null && (f = Ti(u, a), f !== 0 && f !== n.retryLane))
          throw n.retryLane = f, Da(l, f), wl(u, l, f), sc;
        rn(), t = Rs(
          l,
          t,
          a
        );
      } else
        l = n.treeContext, sl = ot(f.nextSibling), Dl = t, $ = !0, la = null, mt = !1, l !== null && b0(t, l), t = cn(t, u), t.flags |= 4096;
      return t;
    }
    return l = xt(l.child, {
      mode: u.mode,
      children: u.children
    }), l.ref = t.ref, t.child = l, l.return = t, l;
  }
  function sn(l, t) {
    var a = t.ref;
    if (a === null)
      l !== null && l.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof a != "function" && typeof a != "object")
        throw Error(o(284));
      (l === null || l.ref !== a) && (t.flags |= 4194816);
    }
  }
  function dc(l, t, a, u, e) {
    return Ra(t), a = Lf(
      l,
      t,
      a,
      u,
      void 0,
      e
    ), u = Kf(), l !== null && !El ? (Jf(l, t, e), Gt(l, t, e)) : ($ && u && Mf(t), t.flags |= 1, Nl(l, t, a, e), t.child);
  }
  function xs(l, t, a, u, e, n) {
    return Ra(t), t.updateQueue = null, a = B0(
      t,
      u,
      a,
      e
    ), q0(l), u = Kf(), l !== null && !El ? (Jf(l, t, n), Gt(l, t, n)) : ($ && u && Mf(t), t.flags |= 1, Nl(l, t, a, n), t.child);
  }
  function Cs(l, t, a, u, e) {
    if (Ra(t), t.stateNode === null) {
      var n = tu, f = a.contextType;
      typeof f == "object" && f !== null && (n = Ul(f)), n = new a(u, n), t.memoizedState = n.state !== null && n.state !== void 0 ? n.state : null, n.updater = cc, t.stateNode = n, n._reactInternals = t, n = t.stateNode, n.props = u, n.state = t.memoizedState, n.refs = {}, Bf(t), f = a.contextType, n.context = typeof f == "object" && f !== null ? Ul(f) : tu, n.state = t.memoizedState, f = a.getDerivedStateFromProps, typeof f == "function" && (fc(
        t,
        a,
        f,
        u
      ), n.state = t.memoizedState), typeof a.getDerivedStateFromProps == "function" || typeof n.getSnapshotBeforeUpdate == "function" || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (f = n.state, typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount(), f !== n.state && cc.enqueueReplaceState(n, n.state, null), $u(t, u, n, e), Wu(), n.state = t.memoizedState), typeof n.componentDidMount == "function" && (t.flags |= 4194308), u = !0;
    } else if (l === null) {
      n = t.stateNode;
      var c = t.memoizedProps, i = Ya(a, c);
      n.props = i;
      var m = n.context, S = a.contextType;
      f = tu, typeof S == "object" && S !== null && (f = Ul(S));
      var z = a.getDerivedStateFromProps;
      S = typeof z == "function" || typeof n.getSnapshotBeforeUpdate == "function", c = t.pendingProps !== c, S || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (c || m !== f) && zs(
        t,
        n,
        u,
        f
      ), ua = !1;
      var h = t.memoizedState;
      n.state = h, $u(t, u, n, e), Wu(), m = t.memoizedState, c || h !== m || ua ? (typeof z == "function" && (fc(
        t,
        a,
        z,
        u
      ), m = t.memoizedState), (i = ua || rs(
        t,
        a,
        i,
        u,
        h,
        m,
        f
      )) ? (S || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount()), typeof n.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = u, t.memoizedState = m), n.props = u, n.state = m, n.context = f, u = i) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), u = !1);
    } else {
      n = t.stateNode, jf(l, t), f = t.memoizedProps, S = Ya(a, f), n.props = S, z = t.pendingProps, h = n.context, m = a.contextType, i = tu, typeof m == "object" && m !== null && (i = Ul(m)), c = a.getDerivedStateFromProps, (m = typeof c == "function" || typeof n.getSnapshotBeforeUpdate == "function") || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (f !== z || h !== i) && zs(
        t,
        n,
        u,
        i
      ), ua = !1, h = t.memoizedState, n.state = h, $u(t, u, n, e), Wu();
      var g = t.memoizedState;
      f !== z || h !== g || ua || l !== null && l.dependencies !== null && Ve(l.dependencies) ? (typeof c == "function" && (fc(
        t,
        a,
        c,
        u
      ), g = t.memoizedState), (S = ua || rs(
        t,
        a,
        S,
        u,
        h,
        g,
        i
      ) || l !== null && l.dependencies !== null && Ve(l.dependencies)) ? (m || typeof n.UNSAFE_componentWillUpdate != "function" && typeof n.componentWillUpdate != "function" || (typeof n.componentWillUpdate == "function" && n.componentWillUpdate(u, g, i), typeof n.UNSAFE_componentWillUpdate == "function" && n.UNSAFE_componentWillUpdate(
        u,
        g,
        i
      )), typeof n.componentDidUpdate == "function" && (t.flags |= 4), typeof n.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof n.componentDidUpdate != "function" || f === l.memoizedProps && h === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || f === l.memoizedProps && h === l.memoizedState || (t.flags |= 1024), t.memoizedProps = u, t.memoizedState = g), n.props = u, n.state = g, n.context = i, u = S) : (typeof n.componentDidUpdate != "function" || f === l.memoizedProps && h === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || f === l.memoizedProps && h === l.memoizedState || (t.flags |= 1024), u = !1);
    }
    return n = u, sn(l, t), u = (t.flags & 128) !== 0, n || u ? (n = t.stateNode, a = u && typeof a.getDerivedStateFromError != "function" ? null : n.render(), t.flags |= 1, l !== null && u ? (t.child = Ba(
      t,
      l.child,
      null,
      e
    ), t.child = Ba(
      t,
      null,
      a,
      e
    )) : Nl(l, t, a, e), t.memoizedState = n.state, l = t.child) : l = Gt(
      l,
      t,
      e
    ), l;
  }
  function qs(l, t, a, u) {
    return Na(), t.flags |= 256, Nl(l, t, a, u), t.child;
  }
  var yc = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null
  };
  function vc(l) {
    return { baseLanes: l, cachePool: _0() };
  }
  function mc(l, t, a) {
    return l = l !== null ? l.childLanes & ~a : 0, t && (l |= et), l;
  }
  function Bs(l, t, a) {
    var u = t.pendingProps, e = !1, n = (t.flags & 128) !== 0, f;
    if ((f = n) || (f = l !== null && l.memoizedState === null ? !1 : (Sl.current & 2) !== 0), f && (e = !0, t.flags &= -129), f = (t.flags & 32) !== 0, t.flags &= -33, l === null) {
      if ($) {
        if (e ? fa(t) : ca(), (l = sl) ? (l = Ld(
          l,
          mt
        ), l = l !== null && l.data !== "&" ? l : null, l !== null && (t.memoizedState = {
          dehydrated: l,
          treeContext: Pt !== null ? { id: _t, overflow: Mt } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = o0(l), a.return = t, t.child = a, Dl = t, sl = null)) : l = null, l === null) throw ta(t);
        return $c(l) ? t.lanes = 32 : t.lanes = 536870912, null;
      }
      var c = u.children;
      return u = u.fallback, e ? (ca(), e = t.mode, c = dn(
        { mode: "hidden", children: c },
        e
      ), u = Ua(
        u,
        e,
        a,
        null
      ), c.return = t, u.return = t, c.sibling = u, t.child = c, u = t.child, u.memoizedState = vc(a), u.childLanes = mc(
        l,
        f,
        a
      ), t.memoizedState = yc, le(null, u)) : (fa(t), hc(t, c));
    }
    var i = l.memoizedState;
    if (i !== null && (c = i.dehydrated, c !== null)) {
      if (n)
        t.flags & 256 ? (fa(t), t.flags &= -257, t = oc(
          l,
          t,
          a
        )) : t.memoizedState !== null ? (ca(), t.child = l.child, t.flags |= 128, t = null) : (ca(), c = u.fallback, e = t.mode, u = dn(
          { mode: "visible", children: u.children },
          e
        ), c = Ua(
          c,
          e,
          a,
          null
        ), c.flags |= 2, u.return = t, c.return = t, u.sibling = c, t.child = u, Ba(
          t,
          l.child,
          null,
          a
        ), u = t.child, u.memoizedState = vc(a), u.childLanes = mc(
          l,
          f,
          a
        ), t.memoizedState = yc, t = le(null, u));
      else if (fa(t), $c(c)) {
        if (f = c.nextSibling && c.nextSibling.dataset, f) var m = f.dgst;
        f = m, u = Error(o(419)), u.stack = "", u.digest = f, Zu({ value: u, source: null, stack: null }), t = oc(
          l,
          t,
          a
        );
      } else if (El || nu(l, t, a, !1), f = (a & l.childLanes) !== 0, El || f) {
        if (f = il, f !== null && (u = Ti(f, a), u !== 0 && u !== i.retryLane))
          throw i.retryLane = u, Da(l, u), wl(f, l, u), sc;
        Wc(c) || rn(), t = oc(
          l,
          t,
          a
        );
      } else
        Wc(c) ? (t.flags |= 192, t.child = l.child, t = null) : (l = i.treeContext, sl = ot(
          c.nextSibling
        ), Dl = t, $ = !0, la = null, mt = !1, l !== null && b0(t, l), t = hc(
          t,
          u.children
        ), t.flags |= 4096);
      return t;
    }
    return e ? (ca(), c = u.fallback, e = t.mode, i = l.child, m = i.sibling, u = xt(i, {
      mode: "hidden",
      children: u.children
    }), u.subtreeFlags = i.subtreeFlags & 65011712, m !== null ? c = xt(
      m,
      c
    ) : (c = Ua(
      c,
      e,
      a,
      null
    ), c.flags |= 2), c.return = t, u.return = t, u.sibling = c, t.child = u, le(null, u), u = t.child, c = l.child.memoizedState, c === null ? c = vc(a) : (e = c.cachePool, e !== null ? (i = rl._currentValue, e = e.parent !== i ? { parent: i, pool: i } : e) : e = _0(), c = {
      baseLanes: c.baseLanes | a,
      cachePool: e
    }), u.memoizedState = c, u.childLanes = mc(
      l,
      f,
      a
    ), t.memoizedState = yc, le(l.child, u)) : (fa(t), a = l.child, l = a.sibling, a = xt(a, {
      mode: "visible",
      children: u.children
    }), a.return = t, a.sibling = null, l !== null && (f = t.deletions, f === null ? (t.deletions = [l], t.flags |= 16) : f.push(l)), t.child = a, t.memoizedState = null, a);
  }
  function hc(l, t) {
    return t = dn(
      { mode: "visible", children: t },
      l.mode
    ), t.return = l, l.child = t;
  }
  function dn(l, t) {
    return l = lt(22, l, null, t), l.lanes = 0, l;
  }
  function oc(l, t, a) {
    return Ba(t, l.child, null, a), l = hc(
      t,
      t.pendingProps.children
    ), l.flags |= 2, t.memoizedState = null, l;
  }
  function js(l, t, a) {
    l.lanes |= t;
    var u = l.alternate;
    u !== null && (u.lanes |= t), Nf(l.return, t, a);
  }
  function gc(l, t, a, u, e, n) {
    var f = l.memoizedState;
    f === null ? l.memoizedState = {
      isBackwards: t,
      rendering: null,
      renderingStartTime: 0,
      last: u,
      tail: a,
      tailMode: e,
      treeForkCount: n
    } : (f.isBackwards = t, f.rendering = null, f.renderingStartTime = 0, f.last = u, f.tail = a, f.tailMode = e, f.treeForkCount = n);
  }
  function Ys(l, t, a) {
    var u = t.pendingProps, e = u.revealOrder, n = u.tail;
    u = u.children;
    var f = Sl.current, c = (f & 2) !== 0;
    if (c ? (f = f & 1 | 2, t.flags |= 128) : f &= 1, M(Sl, f), Nl(l, t, u, a), u = $ ? Qu : 0, !c && l !== null && (l.flags & 128) !== 0)
      l: for (l = t.child; l !== null; ) {
        if (l.tag === 13)
          l.memoizedState !== null && js(l, a, t);
        else if (l.tag === 19)
          js(l, a, t);
        else if (l.child !== null) {
          l.child.return = l, l = l.child;
          continue;
        }
        if (l === t) break l;
        for (; l.sibling === null; ) {
          if (l.return === null || l.return === t)
            break l;
          l = l.return;
        }
        l.sibling.return = l.return, l = l.sibling;
      }
    switch (e) {
      case "forwards":
        for (a = t.child, e = null; a !== null; )
          l = a.alternate, l !== null && Fe(l) === null && (e = a), a = a.sibling;
        a = e, a === null ? (e = t.child, t.child = null) : (e = a.sibling, a.sibling = null), gc(
          t,
          !1,
          e,
          a,
          n,
          u
        );
        break;
      case "backwards":
      case "unstable_legacy-backwards":
        for (a = null, e = t.child, t.child = null; e !== null; ) {
          if (l = e.alternate, l !== null && Fe(l) === null) {
            t.child = e;
            break;
          }
          l = e.sibling, e.sibling = a, a = e, e = l;
        }
        gc(
          t,
          !0,
          a,
          null,
          n,
          u
        );
        break;
      case "together":
        gc(
          t,
          !1,
          null,
          null,
          void 0,
          u
        );
        break;
      default:
        t.memoizedState = null;
    }
    return t.child;
  }
  function Gt(l, t, a) {
    if (l !== null && (t.dependencies = l.dependencies), da |= t.lanes, (a & t.childLanes) === 0)
      if (l !== null) {
        if (nu(
          l,
          t,
          a,
          !1
        ), (a & t.childLanes) === 0)
          return null;
      } else return null;
    if (l !== null && t.child !== l.child)
      throw Error(o(153));
    if (t.child !== null) {
      for (l = t.child, a = xt(l, l.pendingProps), t.child = a, a.return = t; l.sibling !== null; )
        l = l.sibling, a = a.sibling = xt(l, l.pendingProps), a.return = t;
      a.sibling = null;
    }
    return t.child;
  }
  function Sc(l, t) {
    return (l.lanes & t) !== 0 ? !0 : (l = l.dependencies, !!(l !== null && Ve(l)));
  }
  function Iv(l, t, a) {
    switch (t.tag) {
      case 3:
        ql(t, t.stateNode.containerInfo), aa(t, rl, l.memoizedState.cache), Na();
        break;
      case 27:
      case 5:
        Ou(t);
        break;
      case 4:
        ql(t, t.stateNode.containerInfo);
        break;
      case 10:
        aa(
          t,
          t.type,
          t.memoizedProps.value
        );
        break;
      case 31:
        if (t.memoizedState !== null)
          return t.flags |= 128, Zf(t), null;
        break;
      case 13:
        var u = t.memoizedState;
        if (u !== null)
          return u.dehydrated !== null ? (fa(t), t.flags |= 128, null) : (a & t.child.childLanes) !== 0 ? Bs(l, t, a) : (fa(t), l = Gt(
            l,
            t,
            a
          ), l !== null ? l.sibling : null);
        fa(t);
        break;
      case 19:
        var e = (l.flags & 128) !== 0;
        if (u = (a & t.childLanes) !== 0, u || (nu(
          l,
          t,
          a,
          !1
        ), u = (a & t.childLanes) !== 0), e) {
          if (u)
            return Ys(
              l,
              t,
              a
            );
          t.flags |= 128;
        }
        if (e = t.memoizedState, e !== null && (e.rendering = null, e.tail = null, e.lastEffect = null), M(Sl, Sl.current), u) break;
        return null;
      case 22:
        return t.lanes = 0, Ns(
          l,
          t,
          a,
          t.pendingProps
        );
      case 24:
        aa(t, rl, l.memoizedState.cache);
    }
    return Gt(l, t, a);
  }
  function Gs(l, t, a) {
    if (l !== null)
      if (l.memoizedProps !== t.pendingProps)
        El = !0;
      else {
        if (!Sc(l, a) && (t.flags & 128) === 0)
          return El = !1, Iv(
            l,
            t,
            a
          );
        El = (l.flags & 131072) !== 0;
      }
    else
      El = !1, $ && (t.flags & 1048576) !== 0 && S0(t, Qu, t.index);
    switch (t.lanes = 0, t.tag) {
      case 16:
        l: {
          var u = t.pendingProps;
          if (l = Ca(t.elementType), t.type = l, typeof l == "function")
            Tf(l) ? (u = Ya(l, u), t.tag = 1, t = Cs(
              null,
              t,
              l,
              u,
              a
            )) : (t.tag = 0, t = dc(
              null,
              t,
              l,
              u,
              a
            ));
          else {
            if (l != null) {
              var e = l.$$typeof;
              if (e === ft) {
                t.tag = 11, t = ps(
                  null,
                  t,
                  l,
                  u,
                  a
                );
                break l;
              } else if (e === W) {
                t.tag = 14, t = Ds(
                  null,
                  t,
                  l,
                  u,
                  a
                );
                break l;
              }
            }
            throw t = Ut(l) || l, Error(o(306, t, ""));
          }
        }
        return t;
      case 0:
        return dc(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 1:
        return u = t.type, e = Ya(
          u,
          t.pendingProps
        ), Cs(
          l,
          t,
          u,
          e,
          a
        );
      case 3:
        l: {
          if (ql(
            t,
            t.stateNode.containerInfo
          ), l === null) throw Error(o(387));
          u = t.pendingProps;
          var n = t.memoizedState;
          e = n.element, jf(l, t), $u(t, u, null, a);
          var f = t.memoizedState;
          if (u = f.cache, aa(t, rl, u), u !== n.cache && Hf(
            t,
            [rl],
            a,
            !0
          ), Wu(), u = f.element, n.isDehydrated)
            if (n = {
              element: u,
              isDehydrated: !1,
              cache: f.cache
            }, t.updateQueue.baseState = n, t.memoizedState = n, t.flags & 256) {
              t = qs(
                l,
                t,
                u,
                a
              );
              break l;
            } else if (u !== e) {
              e = dt(
                Error(o(424)),
                t
              ), Zu(e), t = qs(
                l,
                t,
                u,
                a
              );
              break l;
            } else
              for (l = t.stateNode.containerInfo, l.nodeType === 9 ? l = l.body : l = l.nodeName === "HTML" ? l.ownerDocument.body : l, sl = ot(l.firstChild), Dl = t, $ = !0, la = null, mt = !0, a = N0(
                t,
                null,
                u,
                a
              ), t.child = a; a; )
                a.flags = a.flags & -3 | 4096, a = a.sibling;
          else {
            if (Na(), u === e) {
              t = Gt(
                l,
                t,
                a
              );
              break l;
            }
            Nl(l, t, u, a);
          }
          t = t.child;
        }
        return t;
      case 26:
        return sn(l, t), l === null ? (a = kd(
          t.type,
          null,
          t.pendingProps,
          null
        )) ? t.memoizedState = a : $ || (a = t.type, l = t.pendingProps, u = On(
          V.current
        ).createElement(a), u[pl] = t, u[Ql] = l, Hl(u, a, l), Ml(u), t.stateNode = u) : t.memoizedState = kd(
          t.type,
          l.memoizedProps,
          t.pendingProps,
          l.memoizedState
        ), null;
      case 27:
        return Ou(t), l === null && $ && (u = t.stateNode = wd(
          t.type,
          t.pendingProps,
          V.current
        ), Dl = t, mt = !0, e = sl, oa(t.type) ? (kc = e, sl = ot(u.firstChild)) : sl = e), Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), sn(l, t), l === null && (t.flags |= 4194304), t.child;
      case 5:
        return l === null && $ && ((e = u = sl) && (u = D1(
          u,
          t.type,
          t.pendingProps,
          mt
        ), u !== null ? (t.stateNode = u, Dl = t, sl = ot(u.firstChild), mt = !1, e = !0) : e = !1), e || ta(t)), Ou(t), e = t.type, n = t.pendingProps, f = l !== null ? l.memoizedProps : null, u = n.children, Kc(e, n) ? u = null : f !== null && Kc(e, f) && (t.flags |= 32), t.memoizedState !== null && (e = Lf(
          l,
          t,
          Vv,
          null,
          null,
          a
        ), oe._currentValue = e), sn(l, t), Nl(l, t, u, a), t.child;
      case 6:
        return l === null && $ && ((l = a = sl) && (a = U1(
          a,
          t.pendingProps,
          mt
        ), a !== null ? (t.stateNode = a, Dl = t, sl = null, l = !0) : l = !1), l || ta(t)), null;
      case 13:
        return Bs(l, t, a);
      case 4:
        return ql(
          t,
          t.stateNode.containerInfo
        ), u = t.pendingProps, l === null ? t.child = Ba(
          t,
          null,
          u,
          a
        ) : Nl(l, t, u, a), t.child;
      case 11:
        return ps(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 7:
        return Nl(
          l,
          t,
          t.pendingProps,
          a
        ), t.child;
      case 8:
        return Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 12:
        return Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 10:
        return u = t.pendingProps, aa(t, t.type, u.value), Nl(l, t, u.children, a), t.child;
      case 9:
        return e = t.type._context, u = t.pendingProps.children, Ra(t), e = Ul(e), u = u(e), t.flags |= 1, Nl(l, t, u, a), t.child;
      case 14:
        return Ds(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 15:
        return Us(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 19:
        return Ys(l, t, a);
      case 31:
        return Fv(l, t, a);
      case 22:
        return Ns(
          l,
          t,
          a,
          t.pendingProps
        );
      case 24:
        return Ra(t), u = Ul(rl), l === null ? (e = Cf(), e === null && (e = il, n = Rf(), e.pooledCache = n, n.refCount++, n !== null && (e.pooledCacheLanes |= a), e = n), t.memoizedState = { parent: u, cache: e }, Bf(t), aa(t, rl, e)) : ((l.lanes & a) !== 0 && (jf(l, t), $u(t, null, null, a), Wu()), e = l.memoizedState, n = t.memoizedState, e.parent !== u ? (e = { parent: u, cache: u }, t.memoizedState = e, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = e), aa(t, rl, u)) : (u = n.cache, aa(t, rl, u), u !== e.cache && Hf(
          t,
          [rl],
          a,
          !0
        ))), Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 29:
        throw t.pendingProps;
    }
    throw Error(o(156, t.tag));
  }
  function Xt(l) {
    l.flags |= 4;
  }
  function bc(l, t, a, u, e) {
    if ((t = (l.mode & 32) !== 0) && (t = !1), t) {
      if (l.flags |= 16777216, (e & 335544128) === e)
        if (l.stateNode.complete) l.flags |= 8192;
        else if (vd()) l.flags |= 8192;
        else
          throw qa = we, qf;
    } else l.flags &= -16777217;
  }
  function Xs(l, t) {
    if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0)
      l.flags &= -16777217;
    else if (l.flags |= 16777216, !ty(t))
      if (vd()) l.flags |= 8192;
      else
        throw qa = we, qf;
  }
  function yn(l, t) {
    t !== null && (l.flags |= 4), l.flags & 16384 && (t = l.tag !== 22 ? ri() : 536870912, l.lanes |= t, Su |= t);
  }
  function te(l, t) {
    if (!$)
      switch (l.tailMode) {
        case "hidden":
          t = l.tail;
          for (var a = null; t !== null; )
            t.alternate !== null && (a = t), t = t.sibling;
          a === null ? l.tail = null : a.sibling = null;
          break;
        case "collapsed":
          a = l.tail;
          for (var u = null; a !== null; )
            a.alternate !== null && (u = a), a = a.sibling;
          u === null ? t || l.tail === null ? l.tail = null : l.tail.sibling = null : u.sibling = null;
      }
  }
  function dl(l) {
    var t = l.alternate !== null && l.alternate.child === l.child, a = 0, u = 0;
    if (t)
      for (var e = l.child; e !== null; )
        a |= e.lanes | e.childLanes, u |= e.subtreeFlags & 65011712, u |= e.flags & 65011712, e.return = l, e = e.sibling;
    else
      for (e = l.child; e !== null; )
        a |= e.lanes | e.childLanes, u |= e.subtreeFlags, u |= e.flags, e.return = l, e = e.sibling;
    return l.subtreeFlags |= u, l.childLanes = a, t;
  }
  function Pv(l, t, a) {
    var u = t.pendingProps;
    switch (Of(t), t.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return dl(t), null;
      case 1:
        return dl(t), null;
      case 3:
        return a = t.stateNode, u = null, l !== null && (u = l.memoizedState.cache), t.memoizedState.cache !== u && (t.flags |= 2048), Bt(rl), gl(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (l === null || l.child === null) && (eu(t) ? Xt(t) : l === null || l.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, Df())), dl(t), null;
      case 26:
        var e = t.type, n = t.memoizedState;
        return l === null ? (Xt(t), n !== null ? (dl(t), Xs(t, n)) : (dl(t), bc(
          t,
          e,
          null,
          u,
          a
        ))) : n ? n !== l.memoizedState ? (Xt(t), dl(t), Xs(t, n)) : (dl(t), t.flags &= -16777217) : (l = l.memoizedProps, l !== u && Xt(t), dl(t), bc(
          t,
          e,
          l,
          u,
          a
        )), null;
      case 27:
        if (Ee(t), a = V.current, e = t.type, l !== null && t.stateNode != null)
          l.memoizedProps !== u && Xt(t);
        else {
          if (!u) {
            if (t.stateNode === null)
              throw Error(o(166));
            return dl(t), null;
          }
          l = p.current, eu(t) ? r0(t) : (l = wd(e, u, a), t.stateNode = l, Xt(t));
        }
        return dl(t), null;
      case 5:
        if (Ee(t), e = t.type, l !== null && t.stateNode != null)
          l.memoizedProps !== u && Xt(t);
        else {
          if (!u) {
            if (t.stateNode === null)
              throw Error(o(166));
            return dl(t), null;
          }
          if (n = p.current, eu(t))
            r0(t);
          else {
            var f = On(
              V.current
            );
            switch (n) {
              case 1:
                n = f.createElementNS(
                  "http://www.w3.org/2000/svg",
                  e
                );
                break;
              case 2:
                n = f.createElementNS(
                  "http://www.w3.org/1998/Math/MathML",
                  e
                );
                break;
              default:
                switch (e) {
                  case "svg":
                    n = f.createElementNS(
                      "http://www.w3.org/2000/svg",
                      e
                    );
                    break;
                  case "math":
                    n = f.createElementNS(
                      "http://www.w3.org/1998/Math/MathML",
                      e
                    );
                    break;
                  case "script":
                    n = f.createElement("div"), n.innerHTML = "<script><\/script>", n = n.removeChild(
                      n.firstChild
                    );
                    break;
                  case "select":
                    n = typeof u.is == "string" ? f.createElement("select", {
                      is: u.is
                    }) : f.createElement("select"), u.multiple ? n.multiple = !0 : u.size && (n.size = u.size);
                    break;
                  default:
                    n = typeof u.is == "string" ? f.createElement(e, { is: u.is }) : f.createElement(e);
                }
            }
            n[pl] = t, n[Ql] = u;
            l: for (f = t.child; f !== null; ) {
              if (f.tag === 5 || f.tag === 6)
                n.appendChild(f.stateNode);
              else if (f.tag !== 4 && f.tag !== 27 && f.child !== null) {
                f.child.return = f, f = f.child;
                continue;
              }
              if (f === t) break l;
              for (; f.sibling === null; ) {
                if (f.return === null || f.return === t)
                  break l;
                f = f.return;
              }
              f.sibling.return = f.return, f = f.sibling;
            }
            t.stateNode = n;
            l: switch (Hl(n, e, u), e) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                u = !!u.autoFocus;
                break l;
              case "img":
                u = !0;
                break l;
              default:
                u = !1;
            }
            u && Xt(t);
          }
        }
        return dl(t), bc(
          t,
          t.type,
          l === null ? null : l.memoizedProps,
          t.pendingProps,
          a
        ), null;
      case 6:
        if (l && t.stateNode != null)
          l.memoizedProps !== u && Xt(t);
        else {
          if (typeof u != "string" && t.stateNode === null)
            throw Error(o(166));
          if (l = V.current, eu(t)) {
            if (l = t.stateNode, a = t.memoizedProps, u = null, e = Dl, e !== null)
              switch (e.tag) {
                case 27:
                case 5:
                  u = e.memoizedProps;
              }
            l[pl] = t, l = !!(l.nodeValue === a || u !== null && u.suppressHydrationWarning === !0 || Bd(l.nodeValue, a)), l || ta(t, !0);
          } else
            l = On(l).createTextNode(
              u
            ), l[pl] = t, t.stateNode = l;
        }
        return dl(t), null;
      case 31:
        if (a = t.memoizedState, l === null || l.memoizedState !== null) {
          if (u = eu(t), a !== null) {
            if (l === null) {
              if (!u) throw Error(o(318));
              if (l = t.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(o(557));
              l[pl] = t;
            } else
              Na(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            dl(t), l = !1;
          } else
            a = Df(), l !== null && l.memoizedState !== null && (l.memoizedState.hydrationErrors = a), l = !0;
          if (!l)
            return t.flags & 256 ? (at(t), t) : (at(t), null);
          if ((t.flags & 128) !== 0)
            throw Error(o(558));
        }
        return dl(t), null;
      case 13:
        if (u = t.memoizedState, l === null || l.memoizedState !== null && l.memoizedState.dehydrated !== null) {
          if (e = eu(t), u !== null && u.dehydrated !== null) {
            if (l === null) {
              if (!e) throw Error(o(318));
              if (e = t.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(o(317));
              e[pl] = t;
            } else
              Na(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            dl(t), e = !1;
          } else
            e = Df(), l !== null && l.memoizedState !== null && (l.memoizedState.hydrationErrors = e), e = !0;
          if (!e)
            return t.flags & 256 ? (at(t), t) : (at(t), null);
        }
        return at(t), (t.flags & 128) !== 0 ? (t.lanes = a, t) : (a = u !== null, l = l !== null && l.memoizedState !== null, a && (u = t.child, e = null, u.alternate !== null && u.alternate.memoizedState !== null && u.alternate.memoizedState.cachePool !== null && (e = u.alternate.memoizedState.cachePool.pool), n = null, u.memoizedState !== null && u.memoizedState.cachePool !== null && (n = u.memoizedState.cachePool.pool), n !== e && (u.flags |= 2048)), a !== l && a && (t.child.flags |= 8192), yn(t, t.updateQueue), dl(t), null);
      case 4:
        return gl(), l === null && Xc(t.stateNode.containerInfo), dl(t), null;
      case 10:
        return Bt(t.type), dl(t), null;
      case 19:
        if (E(Sl), u = t.memoizedState, u === null) return dl(t), null;
        if (e = (t.flags & 128) !== 0, n = u.rendering, n === null)
          if (e) te(u, !1);
          else {
            if (hl !== 0 || l !== null && (l.flags & 128) !== 0)
              for (l = t.child; l !== null; ) {
                if (n = Fe(l), n !== null) {
                  for (t.flags |= 128, te(u, !1), l = n.updateQueue, t.updateQueue = l, yn(t, l), t.subtreeFlags = 0, l = a, a = t.child; a !== null; )
                    h0(a, l), a = a.sibling;
                  return M(
                    Sl,
                    Sl.current & 1 | 2
                  ), $ && Ct(t, u.treeForkCount), t.child;
                }
                l = l.sibling;
              }
            u.tail !== null && kl() > gn && (t.flags |= 128, e = !0, te(u, !1), t.lanes = 4194304);
          }
        else {
          if (!e)
            if (l = Fe(n), l !== null) {
              if (t.flags |= 128, e = !0, l = l.updateQueue, t.updateQueue = l, yn(t, l), te(u, !0), u.tail === null && u.tailMode === "hidden" && !n.alternate && !$)
                return dl(t), null;
            } else
              2 * kl() - u.renderingStartTime > gn && a !== 536870912 && (t.flags |= 128, e = !0, te(u, !1), t.lanes = 4194304);
          u.isBackwards ? (n.sibling = t.child, t.child = n) : (l = u.last, l !== null ? l.sibling = n : t.child = n, u.last = n);
        }
        return u.tail !== null ? (l = u.tail, u.rendering = l, u.tail = l.sibling, u.renderingStartTime = kl(), l.sibling = null, a = Sl.current, M(
          Sl,
          e ? a & 1 | 2 : a & 1
        ), $ && Ct(t, u.treeForkCount), l) : (dl(t), null);
      case 22:
      case 23:
        return at(t), Qf(), u = t.memoizedState !== null, l !== null ? l.memoizedState !== null !== u && (t.flags |= 8192) : u && (t.flags |= 8192), u ? (a & 536870912) !== 0 && (t.flags & 128) === 0 && (dl(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : dl(t), a = t.updateQueue, a !== null && yn(t, a.retryQueue), a = null, l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), u = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (u = t.memoizedState.cachePool.pool), u !== a && (t.flags |= 2048), l !== null && E(xa), null;
      case 24:
        return a = null, l !== null && (a = l.memoizedState.cache), t.memoizedState.cache !== a && (t.flags |= 2048), Bt(rl), dl(t), null;
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(o(156, t.tag));
  }
  function l1(l, t) {
    switch (Of(t), t.tag) {
      case 1:
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 3:
        return Bt(rl), gl(), l = t.flags, (l & 65536) !== 0 && (l & 128) === 0 ? (t.flags = l & -65537 | 128, t) : null;
      case 26:
      case 27:
      case 5:
        return Ee(t), null;
      case 31:
        if (t.memoizedState !== null) {
          if (at(t), t.alternate === null)
            throw Error(o(340));
          Na();
        }
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 13:
        if (at(t), l = t.memoizedState, l !== null && l.dehydrated !== null) {
          if (t.alternate === null)
            throw Error(o(340));
          Na();
        }
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 19:
        return E(Sl), null;
      case 4:
        return gl(), null;
      case 10:
        return Bt(t.type), null;
      case 22:
      case 23:
        return at(t), Qf(), l !== null && E(xa), l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 24:
        return Bt(rl), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Qs(l, t) {
    switch (Of(t), t.tag) {
      case 3:
        Bt(rl), gl();
        break;
      case 26:
      case 27:
      case 5:
        Ee(t);
        break;
      case 4:
        gl();
        break;
      case 31:
        t.memoizedState !== null && at(t);
        break;
      case 13:
        at(t);
        break;
      case 19:
        E(Sl);
        break;
      case 10:
        Bt(t.type);
        break;
      case 22:
      case 23:
        at(t), Qf(), l !== null && E(xa);
        break;
      case 24:
        Bt(rl);
    }
  }
  function ae(l, t) {
    try {
      var a = t.updateQueue, u = a !== null ? a.lastEffect : null;
      if (u !== null) {
        var e = u.next;
        a = e;
        do {
          if ((a.tag & l) === l) {
            u = void 0;
            var n = a.create, f = a.inst;
            u = n(), f.destroy = u;
          }
          a = a.next;
        } while (a !== e);
      }
    } catch (c) {
      al(t, t.return, c);
    }
  }
  function ia(l, t, a) {
    try {
      var u = t.updateQueue, e = u !== null ? u.lastEffect : null;
      if (e !== null) {
        var n = e.next;
        u = n;
        do {
          if ((u.tag & l) === l) {
            var f = u.inst, c = f.destroy;
            if (c !== void 0) {
              f.destroy = void 0, e = t;
              var i = a, m = c;
              try {
                m();
              } catch (S) {
                al(
                  e,
                  i,
                  S
                );
              }
            }
          }
          u = u.next;
        } while (u !== n);
      }
    } catch (S) {
      al(t, t.return, S);
    }
  }
  function Zs(l) {
    var t = l.updateQueue;
    if (t !== null) {
      var a = l.stateNode;
      try {
        R0(t, a);
      } catch (u) {
        al(l, l.return, u);
      }
    }
  }
  function Vs(l, t, a) {
    a.props = Ya(
      l.type,
      l.memoizedProps
    ), a.state = l.memoizedState;
    try {
      a.componentWillUnmount();
    } catch (u) {
      al(l, t, u);
    }
  }
  function ue(l, t) {
    try {
      var a = l.ref;
      if (a !== null) {
        switch (l.tag) {
          case 26:
          case 27:
          case 5:
            var u = l.stateNode;
            break;
          case 30:
            u = l.stateNode;
            break;
          default:
            u = l.stateNode;
        }
        typeof a == "function" ? l.refCleanup = a(u) : a.current = u;
      }
    } catch (e) {
      al(l, t, e);
    }
  }
  function Ot(l, t) {
    var a = l.ref, u = l.refCleanup;
    if (a !== null)
      if (typeof u == "function")
        try {
          u();
        } catch (e) {
          al(l, t, e);
        } finally {
          l.refCleanup = null, l = l.alternate, l != null && (l.refCleanup = null);
        }
      else if (typeof a == "function")
        try {
          a(null);
        } catch (e) {
          al(l, t, e);
        }
      else a.current = null;
  }
  function Ls(l) {
    var t = l.type, a = l.memoizedProps, u = l.stateNode;
    try {
      l: switch (t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          a.autoFocus && u.focus();
          break l;
        case "img":
          a.src ? u.src = a.src : a.srcSet && (u.srcset = a.srcSet);
      }
    } catch (e) {
      al(l, l.return, e);
    }
  }
  function rc(l, t, a) {
    try {
      var u = l.stateNode;
      T1(u, l.type, a, t), u[Ql] = t;
    } catch (e) {
      al(l, l.return, e);
    }
  }
  function Ks(l) {
    return l.tag === 5 || l.tag === 3 || l.tag === 26 || l.tag === 27 && oa(l.type) || l.tag === 4;
  }
  function zc(l) {
    l: for (; ; ) {
      for (; l.sibling === null; ) {
        if (l.return === null || Ks(l.return)) return null;
        l = l.return;
      }
      for (l.sibling.return = l.return, l = l.sibling; l.tag !== 5 && l.tag !== 6 && l.tag !== 18; ) {
        if (l.tag === 27 && oa(l.type) || l.flags & 2 || l.child === null || l.tag === 4) continue l;
        l.child.return = l, l = l.child;
      }
      if (!(l.flags & 2)) return l.stateNode;
    }
  }
  function Ec(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      l = l.stateNode, t ? (a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a).insertBefore(l, t) : (t = a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a, t.appendChild(l), a = a._reactRootContainer, a != null || t.onclick !== null || (t.onclick = Ht));
    else if (u !== 4 && (u === 27 && oa(l.type) && (a = l.stateNode, t = null), l = l.child, l !== null))
      for (Ec(l, t, a), l = l.sibling; l !== null; )
        Ec(l, t, a), l = l.sibling;
  }
  function vn(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      l = l.stateNode, t ? a.insertBefore(l, t) : a.appendChild(l);
    else if (u !== 4 && (u === 27 && oa(l.type) && (a = l.stateNode), l = l.child, l !== null))
      for (vn(l, t, a), l = l.sibling; l !== null; )
        vn(l, t, a), l = l.sibling;
  }
  function Js(l) {
    var t = l.stateNode, a = l.memoizedProps;
    try {
      for (var u = l.type, e = t.attributes; e.length; )
        t.removeAttributeNode(e[0]);
      Hl(t, u, a), t[pl] = l, t[Ql] = a;
    } catch (n) {
      al(l, l.return, n);
    }
  }
  var Qt = !1, Tl = !1, Tc = !1, ws = typeof WeakSet == "function" ? WeakSet : Set, Ol = null;
  function t1(l, t) {
    if (l = l.containerInfo, Vc = xn, l = n0(l), of(l)) {
      if ("selectionStart" in l)
        var a = {
          start: l.selectionStart,
          end: l.selectionEnd
        };
      else
        l: {
          a = (a = l.ownerDocument) && a.defaultView || window;
          var u = a.getSelection && a.getSelection();
          if (u && u.rangeCount !== 0) {
            a = u.anchorNode;
            var e = u.anchorOffset, n = u.focusNode;
            u = u.focusOffset;
            try {
              a.nodeType, n.nodeType;
            } catch {
              a = null;
              break l;
            }
            var f = 0, c = -1, i = -1, m = 0, S = 0, z = l, h = null;
            t: for (; ; ) {
              for (var g; z !== a || e !== 0 && z.nodeType !== 3 || (c = f + e), z !== n || u !== 0 && z.nodeType !== 3 || (i = f + u), z.nodeType === 3 && (f += z.nodeValue.length), (g = z.firstChild) !== null; )
                h = z, z = g;
              for (; ; ) {
                if (z === l) break t;
                if (h === a && ++m === e && (c = f), h === n && ++S === u && (i = f), (g = z.nextSibling) !== null) break;
                z = h, h = z.parentNode;
              }
              z = g;
            }
            a = c === -1 || i === -1 ? null : { start: c, end: i };
          } else a = null;
        }
      a = a || { start: 0, end: 0 };
    } else a = null;
    for (Lc = { focusedElem: l, selectionRange: a }, xn = !1, Ol = t; Ol !== null; )
      if (t = Ol, l = t.child, (t.subtreeFlags & 1028) !== 0 && l !== null)
        l.return = t, Ol = l;
      else
        for (; Ol !== null; ) {
          switch (t = Ol, n = t.alternate, l = t.flags, t.tag) {
            case 0:
              if ((l & 4) !== 0 && (l = t.updateQueue, l = l !== null ? l.events : null, l !== null))
                for (a = 0; a < l.length; a++)
                  e = l[a], e.ref.impl = e.nextImpl;
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((l & 1024) !== 0 && n !== null) {
                l = void 0, a = t, e = n.memoizedProps, n = n.memoizedState, u = a.stateNode;
                try {
                  var O = Ya(
                    a.type,
                    e
                  );
                  l = u.getSnapshotBeforeUpdate(
                    O,
                    n
                  ), u.__reactInternalSnapshotBeforeUpdate = l;
                } catch (H) {
                  al(
                    a,
                    a.return,
                    H
                  );
                }
              }
              break;
            case 3:
              if ((l & 1024) !== 0) {
                if (l = t.stateNode.containerInfo, a = l.nodeType, a === 9)
                  wc(l);
                else if (a === 1)
                  switch (l.nodeName) {
                    case "HEAD":
                    case "HTML":
                    case "BODY":
                      wc(l);
                      break;
                    default:
                      l.textContent = "";
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((l & 1024) !== 0) throw Error(o(163));
          }
          if (l = t.sibling, l !== null) {
            l.return = t.return, Ol = l;
            break;
          }
          Ol = t.return;
        }
  }
  function Ws(l, t, a) {
    var u = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 15:
        Vt(l, a), u & 4 && ae(5, a);
        break;
      case 1:
        if (Vt(l, a), u & 4)
          if (l = a.stateNode, t === null)
            try {
              l.componentDidMount();
            } catch (f) {
              al(a, a.return, f);
            }
          else {
            var e = Ya(
              a.type,
              t.memoizedProps
            );
            t = t.memoizedState;
            try {
              l.componentDidUpdate(
                e,
                t,
                l.__reactInternalSnapshotBeforeUpdate
              );
            } catch (f) {
              al(
                a,
                a.return,
                f
              );
            }
          }
        u & 64 && Zs(a), u & 512 && ue(a, a.return);
        break;
      case 3:
        if (Vt(l, a), u & 64 && (l = a.updateQueue, l !== null)) {
          if (t = null, a.child !== null)
            switch (a.child.tag) {
              case 27:
              case 5:
                t = a.child.stateNode;
                break;
              case 1:
                t = a.child.stateNode;
            }
          try {
            R0(l, t);
          } catch (f) {
            al(a, a.return, f);
          }
        }
        break;
      case 27:
        t === null && u & 4 && Js(a);
      case 26:
      case 5:
        Vt(l, a), t === null && u & 4 && Ls(a), u & 512 && ue(a, a.return);
        break;
      case 12:
        Vt(l, a);
        break;
      case 31:
        Vt(l, a), u & 4 && Fs(l, a);
        break;
      case 13:
        Vt(l, a), u & 4 && Is(l, a), u & 64 && (l = a.memoizedState, l !== null && (l = l.dehydrated, l !== null && (a = d1.bind(
          null,
          a
        ), N1(l, a))));
        break;
      case 22:
        if (u = a.memoizedState !== null || Qt, !u) {
          t = t !== null && t.memoizedState !== null || Tl, e = Qt;
          var n = Tl;
          Qt = u, (Tl = t) && !n ? Lt(
            l,
            a,
            (a.subtreeFlags & 8772) !== 0
          ) : Vt(l, a), Qt = e, Tl = n;
        }
        break;
      case 30:
        break;
      default:
        Vt(l, a);
    }
  }
  function $s(l) {
    var t = l.alternate;
    t !== null && (l.alternate = null, $s(t)), l.child = null, l.deletions = null, l.sibling = null, l.tag === 5 && (t = l.stateNode, t !== null && Fn(t)), l.stateNode = null, l.return = null, l.dependencies = null, l.memoizedProps = null, l.memoizedState = null, l.pendingProps = null, l.stateNode = null, l.updateQueue = null;
  }
  var vl = null, Vl = !1;
  function Zt(l, t, a) {
    for (a = a.child; a !== null; )
      ks(l, t, a), a = a.sibling;
  }
  function ks(l, t, a) {
    if (Fl && typeof Fl.onCommitFiberUnmount == "function")
      try {
        Fl.onCommitFiberUnmount(pu, a);
      } catch {
      }
    switch (a.tag) {
      case 26:
        Tl || Ot(a, t), Zt(
          l,
          t,
          a
        ), a.memoizedState ? a.memoizedState.count-- : a.stateNode && (a = a.stateNode, a.parentNode.removeChild(a));
        break;
      case 27:
        Tl || Ot(a, t);
        var u = vl, e = Vl;
        oa(a.type) && (vl = a.stateNode, Vl = !1), Zt(
          l,
          t,
          a
        ), ve(a.stateNode), vl = u, Vl = e;
        break;
      case 5:
        Tl || Ot(a, t);
      case 6:
        if (u = vl, e = Vl, vl = null, Zt(
          l,
          t,
          a
        ), vl = u, Vl = e, vl !== null)
          if (Vl)
            try {
              (vl.nodeType === 9 ? vl.body : vl.nodeName === "HTML" ? vl.ownerDocument.body : vl).removeChild(a.stateNode);
            } catch (n) {
              al(
                a,
                t,
                n
              );
            }
          else
            try {
              vl.removeChild(a.stateNode);
            } catch (n) {
              al(
                a,
                t,
                n
              );
            }
        break;
      case 18:
        vl !== null && (Vl ? (l = vl, Zd(
          l.nodeType === 9 ? l.body : l.nodeName === "HTML" ? l.ownerDocument.body : l,
          a.stateNode
        ), Mu(l)) : Zd(vl, a.stateNode));
        break;
      case 4:
        u = vl, e = Vl, vl = a.stateNode.containerInfo, Vl = !0, Zt(
          l,
          t,
          a
        ), vl = u, Vl = e;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        ia(2, a, t), Tl || ia(4, a, t), Zt(
          l,
          t,
          a
        );
        break;
      case 1:
        Tl || (Ot(a, t), u = a.stateNode, typeof u.componentWillUnmount == "function" && Vs(
          a,
          t,
          u
        )), Zt(
          l,
          t,
          a
        );
        break;
      case 21:
        Zt(
          l,
          t,
          a
        );
        break;
      case 22:
        Tl = (u = Tl) || a.memoizedState !== null, Zt(
          l,
          t,
          a
        ), Tl = u;
        break;
      default:
        Zt(
          l,
          t,
          a
        );
    }
  }
  function Fs(l, t) {
    if (t.memoizedState === null && (l = t.alternate, l !== null && (l = l.memoizedState, l !== null))) {
      l = l.dehydrated;
      try {
        Mu(l);
      } catch (a) {
        al(t, t.return, a);
      }
    }
  }
  function Is(l, t) {
    if (t.memoizedState === null && (l = t.alternate, l !== null && (l = l.memoizedState, l !== null && (l = l.dehydrated, l !== null))))
      try {
        Mu(l);
      } catch (a) {
        al(t, t.return, a);
      }
  }
  function a1(l) {
    switch (l.tag) {
      case 31:
      case 13:
      case 19:
        var t = l.stateNode;
        return t === null && (t = l.stateNode = new ws()), t;
      case 22:
        return l = l.stateNode, t = l._retryCache, t === null && (t = l._retryCache = new ws()), t;
      default:
        throw Error(o(435, l.tag));
    }
  }
  function mn(l, t) {
    var a = a1(l);
    t.forEach(function(u) {
      if (!a.has(u)) {
        a.add(u);
        var e = y1.bind(null, l, u);
        u.then(e, e);
      }
    });
  }
  function Ll(l, t) {
    var a = t.deletions;
    if (a !== null)
      for (var u = 0; u < a.length; u++) {
        var e = a[u], n = l, f = t, c = f;
        l: for (; c !== null; ) {
          switch (c.tag) {
            case 27:
              if (oa(c.type)) {
                vl = c.stateNode, Vl = !1;
                break l;
              }
              break;
            case 5:
              vl = c.stateNode, Vl = !1;
              break l;
            case 3:
            case 4:
              vl = c.stateNode.containerInfo, Vl = !0;
              break l;
          }
          c = c.return;
        }
        if (vl === null) throw Error(o(160));
        ks(n, f, e), vl = null, Vl = !1, n = e.alternate, n !== null && (n.return = null), e.return = null;
      }
    if (t.subtreeFlags & 13886)
      for (t = t.child; t !== null; )
        Ps(t, l), t = t.sibling;
  }
  var rt = null;
  function Ps(l, t) {
    var a = l.alternate, u = l.flags;
    switch (l.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        Ll(t, l), Kl(l), u & 4 && (ia(3, l, l.return), ae(3, l), ia(5, l, l.return));
        break;
      case 1:
        Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Ot(a, a.return)), u & 64 && Qt && (l = l.updateQueue, l !== null && (u = l.callbacks, u !== null && (a = l.shared.hiddenCallbacks, l.shared.hiddenCallbacks = a === null ? u : a.concat(u))));
        break;
      case 26:
        var e = rt;
        if (Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Ot(a, a.return)), u & 4) {
          var n = a !== null ? a.memoizedState : null;
          if (u = l.memoizedState, a === null)
            if (u === null)
              if (l.stateNode === null) {
                l: {
                  u = l.type, a = l.memoizedProps, e = e.ownerDocument || e;
                  t: switch (u) {
                    case "title":
                      n = e.getElementsByTagName("title")[0], (!n || n[Nu] || n[pl] || n.namespaceURI === "http://www.w3.org/2000/svg" || n.hasAttribute("itemprop")) && (n = e.createElement(u), e.head.insertBefore(
                        n,
                        e.querySelector("head > title")
                      )), Hl(n, u, a), n[pl] = l, Ml(n), u = n;
                      break l;
                    case "link":
                      var f = Pd(
                        "link",
                        "href",
                        e
                      ).get(u + (a.href || ""));
                      if (f) {
                        for (var c = 0; c < f.length; c++)
                          if (n = f[c], n.getAttribute("href") === (a.href == null || a.href === "" ? null : a.href) && n.getAttribute("rel") === (a.rel == null ? null : a.rel) && n.getAttribute("title") === (a.title == null ? null : a.title) && n.getAttribute("crossorigin") === (a.crossOrigin == null ? null : a.crossOrigin)) {
                            f.splice(c, 1);
                            break t;
                          }
                      }
                      n = e.createElement(u), Hl(n, u, a), e.head.appendChild(n);
                      break;
                    case "meta":
                      if (f = Pd(
                        "meta",
                        "content",
                        e
                      ).get(u + (a.content || ""))) {
                        for (c = 0; c < f.length; c++)
                          if (n = f[c], n.getAttribute("content") === (a.content == null ? null : "" + a.content) && n.getAttribute("name") === (a.name == null ? null : a.name) && n.getAttribute("property") === (a.property == null ? null : a.property) && n.getAttribute("http-equiv") === (a.httpEquiv == null ? null : a.httpEquiv) && n.getAttribute("charset") === (a.charSet == null ? null : a.charSet)) {
                            f.splice(c, 1);
                            break t;
                          }
                      }
                      n = e.createElement(u), Hl(n, u, a), e.head.appendChild(n);
                      break;
                    default:
                      throw Error(o(468, u));
                  }
                  n[pl] = l, Ml(n), u = n;
                }
                l.stateNode = u;
              } else
                ly(
                  e,
                  l.type,
                  l.stateNode
                );
            else
              l.stateNode = Id(
                e,
                u,
                l.memoizedProps
              );
          else
            n !== u ? (n === null ? a.stateNode !== null && (a = a.stateNode, a.parentNode.removeChild(a)) : n.count--, u === null ? ly(
              e,
              l.type,
              l.stateNode
            ) : Id(
              e,
              u,
              l.memoizedProps
            )) : u === null && l.stateNode !== null && rc(
              l,
              l.memoizedProps,
              a.memoizedProps
            );
        }
        break;
      case 27:
        Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Ot(a, a.return)), a !== null && u & 4 && rc(
          l,
          l.memoizedProps,
          a.memoizedProps
        );
        break;
      case 5:
        if (Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Ot(a, a.return)), l.flags & 32) {
          e = l.stateNode;
          try {
            Wa(e, "");
          } catch (O) {
            al(l, l.return, O);
          }
        }
        u & 4 && l.stateNode != null && (e = l.memoizedProps, rc(
          l,
          e,
          a !== null ? a.memoizedProps : e
        )), u & 1024 && (Tc = !0);
        break;
      case 6:
        if (Ll(t, l), Kl(l), u & 4) {
          if (l.stateNode === null)
            throw Error(o(162));
          u = l.memoizedProps, a = l.stateNode;
          try {
            a.nodeValue = u;
          } catch (O) {
            al(l, l.return, O);
          }
        }
        break;
      case 3:
        if (Un = null, e = rt, rt = pn(t.containerInfo), Ll(t, l), rt = e, Kl(l), u & 4 && a !== null && a.memoizedState.isDehydrated)
          try {
            Mu(t.containerInfo);
          } catch (O) {
            al(l, l.return, O);
          }
        Tc && (Tc = !1, ld(l));
        break;
      case 4:
        u = rt, rt = pn(
          l.stateNode.containerInfo
        ), Ll(t, l), Kl(l), rt = u;
        break;
      case 12:
        Ll(t, l), Kl(l);
        break;
      case 31:
        Ll(t, l), Kl(l), u & 4 && (u = l.updateQueue, u !== null && (l.updateQueue = null, mn(l, u)));
        break;
      case 13:
        Ll(t, l), Kl(l), l.child.flags & 8192 && l.memoizedState !== null != (a !== null && a.memoizedState !== null) && (on = kl()), u & 4 && (u = l.updateQueue, u !== null && (l.updateQueue = null, mn(l, u)));
        break;
      case 22:
        e = l.memoizedState !== null;
        var i = a !== null && a.memoizedState !== null, m = Qt, S = Tl;
        if (Qt = m || e, Tl = S || i, Ll(t, l), Tl = S, Qt = m, Kl(l), u & 8192)
          l: for (t = l.stateNode, t._visibility = e ? t._visibility & -2 : t._visibility | 1, e && (a === null || i || Qt || Tl || Ga(l)), a = null, t = l; ; ) {
            if (t.tag === 5 || t.tag === 26) {
              if (a === null) {
                i = a = t;
                try {
                  if (n = i.stateNode, e)
                    f = n.style, typeof f.setProperty == "function" ? f.setProperty("display", "none", "important") : f.display = "none";
                  else {
                    c = i.stateNode;
                    var z = i.memoizedProps.style, h = z != null && z.hasOwnProperty("display") ? z.display : null;
                    c.style.display = h == null || typeof h == "boolean" ? "" : ("" + h).trim();
                  }
                } catch (O) {
                  al(i, i.return, O);
                }
              }
            } else if (t.tag === 6) {
              if (a === null) {
                i = t;
                try {
                  i.stateNode.nodeValue = e ? "" : i.memoizedProps;
                } catch (O) {
                  al(i, i.return, O);
                }
              }
            } else if (t.tag === 18) {
              if (a === null) {
                i = t;
                try {
                  var g = i.stateNode;
                  e ? Vd(g, !0) : Vd(i.stateNode, !1);
                } catch (O) {
                  al(i, i.return, O);
                }
              }
            } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === l) && t.child !== null) {
              t.child.return = t, t = t.child;
              continue;
            }
            if (t === l) break l;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === l) break l;
              a === t && (a = null), t = t.return;
            }
            a === t && (a = null), t.sibling.return = t.return, t = t.sibling;
          }
        u & 4 && (u = l.updateQueue, u !== null && (a = u.retryQueue, a !== null && (u.retryQueue = null, mn(l, a))));
        break;
      case 19:
        Ll(t, l), Kl(l), u & 4 && (u = l.updateQueue, u !== null && (l.updateQueue = null, mn(l, u)));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        Ll(t, l), Kl(l);
    }
  }
  function Kl(l) {
    var t = l.flags;
    if (t & 2) {
      try {
        for (var a, u = l.return; u !== null; ) {
          if (Ks(u)) {
            a = u;
            break;
          }
          u = u.return;
        }
        if (a == null) throw Error(o(160));
        switch (a.tag) {
          case 27:
            var e = a.stateNode, n = zc(l);
            vn(l, n, e);
            break;
          case 5:
            var f = a.stateNode;
            a.flags & 32 && (Wa(f, ""), a.flags &= -33);
            var c = zc(l);
            vn(l, c, f);
            break;
          case 3:
          case 4:
            var i = a.stateNode.containerInfo, m = zc(l);
            Ec(
              l,
              m,
              i
            );
            break;
          default:
            throw Error(o(161));
        }
      } catch (S) {
        al(l, l.return, S);
      }
      l.flags &= -3;
    }
    t & 4096 && (l.flags &= -4097);
  }
  function ld(l) {
    if (l.subtreeFlags & 1024)
      for (l = l.child; l !== null; ) {
        var t = l;
        ld(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), l = l.sibling;
      }
  }
  function Vt(l, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; )
        Ws(l, t.alternate, t), t = t.sibling;
  }
  function Ga(l) {
    for (l = l.child; l !== null; ) {
      var t = l;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          ia(4, t, t.return), Ga(t);
          break;
        case 1:
          Ot(t, t.return);
          var a = t.stateNode;
          typeof a.componentWillUnmount == "function" && Vs(
            t,
            t.return,
            a
          ), Ga(t);
          break;
        case 27:
          ve(t.stateNode);
        case 26:
        case 5:
          Ot(t, t.return), Ga(t);
          break;
        case 22:
          t.memoizedState === null && Ga(t);
          break;
        case 30:
          Ga(t);
          break;
        default:
          Ga(t);
      }
      l = l.sibling;
    }
  }
  function Lt(l, t, a) {
    for (a = a && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
      var u = t.alternate, e = l, n = t, f = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          Lt(
            e,
            n,
            a
          ), ae(4, n);
          break;
        case 1:
          if (Lt(
            e,
            n,
            a
          ), u = n, e = u.stateNode, typeof e.componentDidMount == "function")
            try {
              e.componentDidMount();
            } catch (m) {
              al(u, u.return, m);
            }
          if (u = n, e = u.updateQueue, e !== null) {
            var c = u.stateNode;
            try {
              var i = e.shared.hiddenCallbacks;
              if (i !== null)
                for (e.shared.hiddenCallbacks = null, e = 0; e < i.length; e++)
                  H0(i[e], c);
            } catch (m) {
              al(u, u.return, m);
            }
          }
          a && f & 64 && Zs(n), ue(n, n.return);
          break;
        case 27:
          Js(n);
        case 26:
        case 5:
          Lt(
            e,
            n,
            a
          ), a && u === null && f & 4 && Ls(n), ue(n, n.return);
          break;
        case 12:
          Lt(
            e,
            n,
            a
          );
          break;
        case 31:
          Lt(
            e,
            n,
            a
          ), a && f & 4 && Fs(e, n);
          break;
        case 13:
          Lt(
            e,
            n,
            a
          ), a && f & 4 && Is(e, n);
          break;
        case 22:
          n.memoizedState === null && Lt(
            e,
            n,
            a
          ), ue(n, n.return);
          break;
        case 30:
          break;
        default:
          Lt(
            e,
            n,
            a
          );
      }
      t = t.sibling;
    }
  }
  function Ac(l, t) {
    var a = null;
    l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), l = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (l = t.memoizedState.cachePool.pool), l !== a && (l != null && l.refCount++, a != null && Vu(a));
  }
  function _c(l, t) {
    l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && Vu(l));
  }
  function zt(l, t, a, u) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; )
        td(
          l,
          t,
          a,
          u
        ), t = t.sibling;
  }
  function td(l, t, a, u) {
    var e = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        zt(
          l,
          t,
          a,
          u
        ), e & 2048 && ae(9, t);
        break;
      case 1:
        zt(
          l,
          t,
          a,
          u
        );
        break;
      case 3:
        zt(
          l,
          t,
          a,
          u
        ), e & 2048 && (l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && Vu(l)));
        break;
      case 12:
        if (e & 2048) {
          zt(
            l,
            t,
            a,
            u
          ), l = t.stateNode;
          try {
            var n = t.memoizedProps, f = n.id, c = n.onPostCommit;
            typeof c == "function" && c(
              f,
              t.alternate === null ? "mount" : "update",
              l.passiveEffectDuration,
              -0
            );
          } catch (i) {
            al(t, t.return, i);
          }
        } else
          zt(
            l,
            t,
            a,
            u
          );
        break;
      case 31:
        zt(
          l,
          t,
          a,
          u
        );
        break;
      case 13:
        zt(
          l,
          t,
          a,
          u
        );
        break;
      case 23:
        break;
      case 22:
        n = t.stateNode, f = t.alternate, t.memoizedState !== null ? n._visibility & 2 ? zt(
          l,
          t,
          a,
          u
        ) : ee(l, t) : n._visibility & 2 ? zt(
          l,
          t,
          a,
          u
        ) : (n._visibility |= 2, hu(
          l,
          t,
          a,
          u,
          (t.subtreeFlags & 10256) !== 0 || !1
        )), e & 2048 && Ac(f, t);
        break;
      case 24:
        zt(
          l,
          t,
          a,
          u
        ), e & 2048 && _c(t.alternate, t);
        break;
      default:
        zt(
          l,
          t,
          a,
          u
        );
    }
  }
  function hu(l, t, a, u, e) {
    for (e = e && ((t.subtreeFlags & 10256) !== 0 || !1), t = t.child; t !== null; ) {
      var n = l, f = t, c = a, i = u, m = f.flags;
      switch (f.tag) {
        case 0:
        case 11:
        case 15:
          hu(
            n,
            f,
            c,
            i,
            e
          ), ae(8, f);
          break;
        case 23:
          break;
        case 22:
          var S = f.stateNode;
          f.memoizedState !== null ? S._visibility & 2 ? hu(
            n,
            f,
            c,
            i,
            e
          ) : ee(
            n,
            f
          ) : (S._visibility |= 2, hu(
            n,
            f,
            c,
            i,
            e
          )), e && m & 2048 && Ac(
            f.alternate,
            f
          );
          break;
        case 24:
          hu(
            n,
            f,
            c,
            i,
            e
          ), e && m & 2048 && _c(f.alternate, f);
          break;
        default:
          hu(
            n,
            f,
            c,
            i,
            e
          );
      }
      t = t.sibling;
    }
  }
  function ee(l, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var a = l, u = t, e = u.flags;
        switch (u.tag) {
          case 22:
            ee(a, u), e & 2048 && Ac(
              u.alternate,
              u
            );
            break;
          case 24:
            ee(a, u), e & 2048 && _c(u.alternate, u);
            break;
          default:
            ee(a, u);
        }
        t = t.sibling;
      }
  }
  var ne = 8192;
  function ou(l, t, a) {
    if (l.subtreeFlags & ne)
      for (l = l.child; l !== null; )
        ad(
          l,
          t,
          a
        ), l = l.sibling;
  }
  function ad(l, t, a) {
    switch (l.tag) {
      case 26:
        ou(
          l,
          t,
          a
        ), l.flags & ne && l.memoizedState !== null && Z1(
          a,
          rt,
          l.memoizedState,
          l.memoizedProps
        );
        break;
      case 5:
        ou(
          l,
          t,
          a
        );
        break;
      case 3:
      case 4:
        var u = rt;
        rt = pn(l.stateNode.containerInfo), ou(
          l,
          t,
          a
        ), rt = u;
        break;
      case 22:
        l.memoizedState === null && (u = l.alternate, u !== null && u.memoizedState !== null ? (u = ne, ne = 16777216, ou(
          l,
          t,
          a
        ), ne = u) : ou(
          l,
          t,
          a
        ));
        break;
      default:
        ou(
          l,
          t,
          a
        );
    }
  }
  function ud(l) {
    var t = l.alternate;
    if (t !== null && (l = t.child, l !== null)) {
      t.child = null;
      do
        t = l.sibling, l.sibling = null, l = t;
      while (l !== null);
    }
  }
  function fe(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          Ol = u, nd(
            u,
            l
          );
        }
      ud(l);
    }
    if (l.subtreeFlags & 10256)
      for (l = l.child; l !== null; )
        ed(l), l = l.sibling;
  }
  function ed(l) {
    switch (l.tag) {
      case 0:
      case 11:
      case 15:
        fe(l), l.flags & 2048 && ia(9, l, l.return);
        break;
      case 3:
        fe(l);
        break;
      case 12:
        fe(l);
        break;
      case 22:
        var t = l.stateNode;
        l.memoizedState !== null && t._visibility & 2 && (l.return === null || l.return.tag !== 13) ? (t._visibility &= -3, hn(l)) : fe(l);
        break;
      default:
        fe(l);
    }
  }
  function hn(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          Ol = u, nd(
            u,
            l
          );
        }
      ud(l);
    }
    for (l = l.child; l !== null; ) {
      switch (t = l, t.tag) {
        case 0:
        case 11:
        case 15:
          ia(8, t, t.return), hn(t);
          break;
        case 22:
          a = t.stateNode, a._visibility & 2 && (a._visibility &= -3, hn(t));
          break;
        default:
          hn(t);
      }
      l = l.sibling;
    }
  }
  function nd(l, t) {
    for (; Ol !== null; ) {
      var a = Ol;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          ia(8, a, t);
          break;
        case 23:
        case 22:
          if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
            var u = a.memoizedState.cachePool.pool;
            u != null && u.refCount++;
          }
          break;
        case 24:
          Vu(a.memoizedState.cache);
      }
      if (u = a.child, u !== null) u.return = a, Ol = u;
      else
        l: for (a = l; Ol !== null; ) {
          u = Ol;
          var e = u.sibling, n = u.return;
          if ($s(u), u === a) {
            Ol = null;
            break l;
          }
          if (e !== null) {
            e.return = n, Ol = e;
            break l;
          }
          Ol = n;
        }
    }
  }
  var u1 = {
    getCacheForType: function(l) {
      var t = Ul(rl), a = t.data.get(l);
      return a === void 0 && (a = l(), t.data.set(l, a)), a;
    },
    cacheSignal: function() {
      return Ul(rl).controller.signal;
    }
  }, e1 = typeof WeakMap == "function" ? WeakMap : Map, P = 0, il = null, L = null, J = 0, tl = 0, ut = null, sa = !1, gu = !1, Mc = !1, Kt = 0, hl = 0, da = 0, Xa = 0, Oc = 0, et = 0, Su = 0, ce = null, Jl = null, pc = !1, on = 0, fd = 0, gn = 1 / 0, Sn = null, ya = null, Al = 0, va = null, bu = null, Jt = 0, Dc = 0, Uc = null, cd = null, ie = 0, Nc = null;
  function nt() {
    return (P & 2) !== 0 && J !== 0 ? J & -J : b.T !== null ? Bc() : Ai();
  }
  function id() {
    if (et === 0)
      if ((J & 536870912) === 0 || $) {
        var l = _e;
        _e <<= 1, (_e & 3932160) === 0 && (_e = 262144), et = l;
      } else et = 536870912;
    return l = tt.current, l !== null && (l.flags |= 32), et;
  }
  function wl(l, t, a) {
    (l === il && (tl === 2 || tl === 9) || l.cancelPendingCommit !== null) && (ru(l, 0), ma(
      l,
      J,
      et,
      !1
    )), Uu(l, a), ((P & 2) === 0 || l !== il) && (l === il && ((P & 2) === 0 && (Xa |= a), hl === 4 && ma(
      l,
      J,
      et,
      !1
    )), pt(l));
  }
  function sd(l, t, a) {
    if ((P & 6) !== 0) throw Error(o(327));
    var u = !a && (t & 127) === 0 && (t & l.expiredLanes) === 0 || Du(l, t), e = u ? c1(l, t) : Rc(l, t, !0), n = u;
    do {
      if (e === 0) {
        gu && !u && ma(l, t, 0, !1);
        break;
      } else {
        if (a = l.current.alternate, n && !n1(a)) {
          e = Rc(l, t, !1), n = !1;
          continue;
        }
        if (e === 2) {
          if (n = t, l.errorRecoveryDisabledLanes & n)
            var f = 0;
          else
            f = l.pendingLanes & -536870913, f = f !== 0 ? f : f & 536870912 ? 536870912 : 0;
          if (f !== 0) {
            t = f;
            l: {
              var c = l;
              e = ce;
              var i = c.current.memoizedState.isDehydrated;
              if (i && (ru(c, f).flags |= 256), f = Rc(
                c,
                f,
                !1
              ), f !== 2) {
                if (Mc && !i) {
                  c.errorRecoveryDisabledLanes |= n, Xa |= n, e = 4;
                  break l;
                }
                n = Jl, Jl = e, n !== null && (Jl === null ? Jl = n : Jl.push.apply(
                  Jl,
                  n
                ));
              }
              e = f;
            }
            if (n = !1, e !== 2) continue;
          }
        }
        if (e === 1) {
          ru(l, 0), ma(l, t, 0, !0);
          break;
        }
        l: {
          switch (u = l, n = e, n) {
            case 0:
            case 1:
              throw Error(o(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              ma(
                u,
                t,
                et,
                !sa
              );
              break l;
            case 2:
              Jl = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(o(329));
          }
          if ((t & 62914560) === t && (e = on + 300 - kl(), 10 < e)) {
            if (ma(
              u,
              t,
              et,
              !sa
            ), Oe(u, 0, !0) !== 0) break l;
            Jt = t, u.timeoutHandle = Xd(
              dd.bind(
                null,
                u,
                a,
                Jl,
                Sn,
                pc,
                t,
                et,
                Xa,
                Su,
                sa,
                n,
                "Throttled",
                -0,
                0
              ),
              e
            );
            break l;
          }
          dd(
            u,
            a,
            Jl,
            Sn,
            pc,
            t,
            et,
            Xa,
            Su,
            sa,
            n,
            null,
            -0,
            0
          );
        }
      }
      break;
    } while (!0);
    pt(l);
  }
  function dd(l, t, a, u, e, n, f, c, i, m, S, z, h, g) {
    if (l.timeoutHandle = -1, z = t.subtreeFlags, z & 8192 || (z & 16785408) === 16785408) {
      z = {
        stylesheets: null,
        count: 0,
        imgCount: 0,
        imgBytes: 0,
        suspenseyImages: [],
        waitingForImages: !0,
        waitingForViewTransition: !1,
        unsuspend: Ht
      }, ad(
        t,
        n,
        z
      );
      var O = (n & 62914560) === n ? on - kl() : (n & 4194048) === n ? fd - kl() : 0;
      if (O = V1(
        z,
        O
      ), O !== null) {
        Jt = n, l.cancelPendingCommit = O(
          bd.bind(
            null,
            l,
            t,
            n,
            a,
            u,
            e,
            f,
            c,
            i,
            S,
            z,
            null,
            h,
            g
          )
        ), ma(l, n, f, !m);
        return;
      }
    }
    bd(
      l,
      t,
      n,
      a,
      u,
      e,
      f,
      c,
      i
    );
  }
  function n1(l) {
    for (var t = l; ; ) {
      var a = t.tag;
      if ((a === 0 || a === 11 || a === 15) && t.flags & 16384 && (a = t.updateQueue, a !== null && (a = a.stores, a !== null)))
        for (var u = 0; u < a.length; u++) {
          var e = a[u], n = e.getSnapshot;
          e = e.value;
          try {
            if (!Pl(n(), e)) return !1;
          } catch {
            return !1;
          }
        }
      if (a = t.child, t.subtreeFlags & 16384 && a !== null)
        a.return = t, t = a;
      else {
        if (t === l) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === l) return !0;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
    }
    return !0;
  }
  function ma(l, t, a, u) {
    t &= ~Oc, t &= ~Xa, l.suspendedLanes |= t, l.pingedLanes &= ~t, u && (l.warmLanes |= t), u = l.expirationTimes;
    for (var e = t; 0 < e; ) {
      var n = 31 - Il(e), f = 1 << n;
      u[n] = -1, e &= ~f;
    }
    a !== 0 && zi(l, a, t);
  }
  function bn() {
    return (P & 6) === 0 ? (se(0), !1) : !0;
  }
  function Hc() {
    if (L !== null) {
      if (tl === 0)
        var l = L.return;
      else
        l = L, qt = Ha = null, wf(l), su = null, Ku = 0, l = L;
      for (; l !== null; )
        Qs(l.alternate, l), l = l.return;
      L = null;
    }
  }
  function ru(l, t) {
    var a = l.timeoutHandle;
    a !== -1 && (l.timeoutHandle = -1, M1(a)), a = l.cancelPendingCommit, a !== null && (l.cancelPendingCommit = null, a()), Jt = 0, Hc(), il = l, L = a = xt(l.current, null), J = t, tl = 0, ut = null, sa = !1, gu = Du(l, t), Mc = !1, Su = et = Oc = Xa = da = hl = 0, Jl = ce = null, pc = !1, (t & 8) !== 0 && (t |= t & 32);
    var u = l.entangledLanes;
    if (u !== 0)
      for (l = l.entanglements, u &= t; 0 < u; ) {
        var e = 31 - Il(u), n = 1 << e;
        t |= l[e], u &= ~n;
      }
    return Kt = t, Ye(), a;
  }
  function yd(l, t) {
    Y = null, b.H = Pu, t === iu || t === Je ? (t = p0(), tl = 3) : t === qf ? (t = p0(), tl = 4) : tl = t === sc ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, ut = t, L === null && (hl = 1, fn(
      l,
      dt(t, l.current)
    ));
  }
  function vd() {
    var l = tt.current;
    return l === null ? !0 : (J & 4194048) === J ? ht === null : (J & 62914560) === J || (J & 536870912) !== 0 ? l === ht : !1;
  }
  function md() {
    var l = b.H;
    return b.H = Pu, l === null ? Pu : l;
  }
  function hd() {
    var l = b.A;
    return b.A = u1, l;
  }
  function rn() {
    hl = 4, sa || (J & 4194048) !== J && tt.current !== null || (gu = !0), (da & 134217727) === 0 && (Xa & 134217727) === 0 || il === null || ma(
      il,
      J,
      et,
      !1
    );
  }
  function Rc(l, t, a) {
    var u = P;
    P |= 2;
    var e = md(), n = hd();
    (il !== l || J !== t) && (Sn = null, ru(l, t)), t = !1;
    var f = hl;
    l: do
      try {
        if (tl !== 0 && L !== null) {
          var c = L, i = ut;
          switch (tl) {
            case 8:
              Hc(), f = 6;
              break l;
            case 3:
            case 2:
            case 9:
            case 6:
              tt.current === null && (t = !0);
              var m = tl;
              if (tl = 0, ut = null, zu(l, c, i, m), a && gu) {
                f = 0;
                break l;
              }
              break;
            default:
              m = tl, tl = 0, ut = null, zu(l, c, i, m);
          }
        }
        f1(), f = hl;
        break;
      } catch (S) {
        yd(l, S);
      }
    while (!0);
    return t && l.shellSuspendCounter++, qt = Ha = null, P = u, b.H = e, b.A = n, L === null && (il = null, J = 0, Ye()), f;
  }
  function f1() {
    for (; L !== null; ) od(L);
  }
  function c1(l, t) {
    var a = P;
    P |= 2;
    var u = md(), e = hd();
    il !== l || J !== t ? (Sn = null, gn = kl() + 500, ru(l, t)) : gu = Du(
      l,
      t
    );
    l: do
      try {
        if (tl !== 0 && L !== null) {
          t = L;
          var n = ut;
          t: switch (tl) {
            case 1:
              tl = 0, ut = null, zu(l, t, n, 1);
              break;
            case 2:
            case 9:
              if (M0(n)) {
                tl = 0, ut = null, gd(t);
                break;
              }
              t = function() {
                tl !== 2 && tl !== 9 || il !== l || (tl = 7), pt(l);
              }, n.then(t, t);
              break l;
            case 3:
              tl = 7;
              break l;
            case 4:
              tl = 5;
              break l;
            case 7:
              M0(n) ? (tl = 0, ut = null, gd(t)) : (tl = 0, ut = null, zu(l, t, n, 7));
              break;
            case 5:
              var f = null;
              switch (L.tag) {
                case 26:
                  f = L.memoizedState;
                case 5:
                case 27:
                  var c = L;
                  if (f ? ty(f) : c.stateNode.complete) {
                    tl = 0, ut = null;
                    var i = c.sibling;
                    if (i !== null) L = i;
                    else {
                      var m = c.return;
                      m !== null ? (L = m, zn(m)) : L = null;
                    }
                    break t;
                  }
              }
              tl = 0, ut = null, zu(l, t, n, 5);
              break;
            case 6:
              tl = 0, ut = null, zu(l, t, n, 6);
              break;
            case 8:
              Hc(), hl = 6;
              break l;
            default:
              throw Error(o(462));
          }
        }
        i1();
        break;
      } catch (S) {
        yd(l, S);
      }
    while (!0);
    return qt = Ha = null, b.H = u, b.A = e, P = a, L !== null ? 0 : (il = null, J = 0, Ye(), hl);
  }
  function i1() {
    for (; L !== null && !Hy(); )
      od(L);
  }
  function od(l) {
    var t = Gs(l.alternate, l, Kt);
    l.memoizedProps = l.pendingProps, t === null ? zn(l) : L = t;
  }
  function gd(l) {
    var t = l, a = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = xs(
          a,
          t,
          t.pendingProps,
          t.type,
          void 0,
          J
        );
        break;
      case 11:
        t = xs(
          a,
          t,
          t.pendingProps,
          t.type.render,
          t.ref,
          J
        );
        break;
      case 5:
        wf(t);
      default:
        Qs(a, t), t = L = h0(t, Kt), t = Gs(a, t, Kt);
    }
    l.memoizedProps = l.pendingProps, t === null ? zn(l) : L = t;
  }
  function zu(l, t, a, u) {
    qt = Ha = null, wf(t), su = null, Ku = 0;
    var e = t.return;
    try {
      if (kv(
        l,
        e,
        t,
        a,
        J
      )) {
        hl = 1, fn(
          l,
          dt(a, l.current)
        ), L = null;
        return;
      }
    } catch (n) {
      if (e !== null) throw L = e, n;
      hl = 1, fn(
        l,
        dt(a, l.current)
      ), L = null;
      return;
    }
    t.flags & 32768 ? ($ || u === 1 ? l = !0 : gu || (J & 536870912) !== 0 ? l = !1 : (sa = l = !0, (u === 2 || u === 9 || u === 3 || u === 6) && (u = tt.current, u !== null && u.tag === 13 && (u.flags |= 16384))), Sd(t, l)) : zn(t);
  }
  function zn(l) {
    var t = l;
    do {
      if ((t.flags & 32768) !== 0) {
        Sd(
          t,
          sa
        );
        return;
      }
      l = t.return;
      var a = Pv(
        t.alternate,
        t,
        Kt
      );
      if (a !== null) {
        L = a;
        return;
      }
      if (t = t.sibling, t !== null) {
        L = t;
        return;
      }
      L = t = l;
    } while (t !== null);
    hl === 0 && (hl = 5);
  }
  function Sd(l, t) {
    do {
      var a = l1(l.alternate, l);
      if (a !== null) {
        a.flags &= 32767, L = a;
        return;
      }
      if (a = l.return, a !== null && (a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null), !t && (l = l.sibling, l !== null)) {
        L = l;
        return;
      }
      L = l = a;
    } while (l !== null);
    hl = 6, L = null;
  }
  function bd(l, t, a, u, e, n, f, c, i) {
    l.cancelPendingCommit = null;
    do
      En();
    while (Al !== 0);
    if ((P & 6) !== 0) throw Error(o(327));
    if (t !== null) {
      if (t === l.current) throw Error(o(177));
      if (n = t.lanes | t.childLanes, n |= zf, Qy(
        l,
        a,
        n,
        f,
        c,
        i
      ), l === il && (L = il = null, J = 0), bu = t, va = l, Jt = a, Dc = n, Uc = e, cd = u, (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? (l.callbackNode = null, l.callbackPriority = 0, v1(Te, function() {
        return Ad(), null;
      })) : (l.callbackNode = null, l.callbackPriority = 0), u = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || u) {
        u = b.T, b.T = null, e = _.p, _.p = 2, f = P, P |= 4;
        try {
          t1(l, t, a);
        } finally {
          P = f, _.p = e, b.T = u;
        }
      }
      Al = 1, rd(), zd(), Ed();
    }
  }
  function rd() {
    if (Al === 1) {
      Al = 0;
      var l = va, t = bu, a = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || a) {
        a = b.T, b.T = null;
        var u = _.p;
        _.p = 2;
        var e = P;
        P |= 4;
        try {
          Ps(t, l);
          var n = Lc, f = n0(l.containerInfo), c = n.focusedElem, i = n.selectionRange;
          if (f !== c && c && c.ownerDocument && e0(
            c.ownerDocument.documentElement,
            c
          )) {
            if (i !== null && of(c)) {
              var m = i.start, S = i.end;
              if (S === void 0 && (S = m), "selectionStart" in c)
                c.selectionStart = m, c.selectionEnd = Math.min(
                  S,
                  c.value.length
                );
              else {
                var z = c.ownerDocument || document, h = z && z.defaultView || window;
                if (h.getSelection) {
                  var g = h.getSelection(), O = c.textContent.length, H = Math.min(i.start, O), fl = i.end === void 0 ? H : Math.min(i.end, O);
                  !g.extend && H > fl && (f = fl, fl = H, H = f);
                  var y = u0(
                    c,
                    H
                  ), s = u0(
                    c,
                    fl
                  );
                  if (y && s && (g.rangeCount !== 1 || g.anchorNode !== y.node || g.anchorOffset !== y.offset || g.focusNode !== s.node || g.focusOffset !== s.offset)) {
                    var v = z.createRange();
                    v.setStart(y.node, y.offset), g.removeAllRanges(), H > fl ? (g.addRange(v), g.extend(s.node, s.offset)) : (v.setEnd(s.node, s.offset), g.addRange(v));
                  }
                }
              }
            }
            for (z = [], g = c; g = g.parentNode; )
              g.nodeType === 1 && z.push({
                element: g,
                left: g.scrollLeft,
                top: g.scrollTop
              });
            for (typeof c.focus == "function" && c.focus(), c = 0; c < z.length; c++) {
              var r = z[c];
              r.element.scrollLeft = r.left, r.element.scrollTop = r.top;
            }
          }
          xn = !!Vc, Lc = Vc = null;
        } finally {
          P = e, _.p = u, b.T = a;
        }
      }
      l.current = t, Al = 2;
    }
  }
  function zd() {
    if (Al === 2) {
      Al = 0;
      var l = va, t = bu, a = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || a) {
        a = b.T, b.T = null;
        var u = _.p;
        _.p = 2;
        var e = P;
        P |= 4;
        try {
          Ws(l, t.alternate, t);
        } finally {
          P = e, _.p = u, b.T = a;
        }
      }
      Al = 3;
    }
  }
  function Ed() {
    if (Al === 4 || Al === 3) {
      Al = 0, Ry();
      var l = va, t = bu, a = Jt, u = cd;
      (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? Al = 5 : (Al = 0, bu = va = null, Td(l, l.pendingLanes));
      var e = l.pendingLanes;
      if (e === 0 && (ya = null), $n(a), t = t.stateNode, Fl && typeof Fl.onCommitFiberRoot == "function")
        try {
          Fl.onCommitFiberRoot(
            pu,
            t,
            void 0,
            (t.current.flags & 128) === 128
          );
        } catch {
        }
      if (u !== null) {
        t = b.T, e = _.p, _.p = 2, b.T = null;
        try {
          for (var n = l.onRecoverableError, f = 0; f < u.length; f++) {
            var c = u[f];
            n(c.value, {
              componentStack: c.stack
            });
          }
        } finally {
          b.T = t, _.p = e;
        }
      }
      (Jt & 3) !== 0 && En(), pt(l), e = l.pendingLanes, (a & 261930) !== 0 && (e & 42) !== 0 ? l === Nc ? ie++ : (ie = 0, Nc = l) : ie = 0, se(0);
    }
  }
  function Td(l, t) {
    (l.pooledCacheLanes &= t) === 0 && (t = l.pooledCache, t != null && (l.pooledCache = null, Vu(t)));
  }
  function En() {
    return rd(), zd(), Ed(), Ad();
  }
  function Ad() {
    if (Al !== 5) return !1;
    var l = va, t = Dc;
    Dc = 0;
    var a = $n(Jt), u = b.T, e = _.p;
    try {
      _.p = 32 > a ? 32 : a, b.T = null, a = Uc, Uc = null;
      var n = va, f = Jt;
      if (Al = 0, bu = va = null, Jt = 0, (P & 6) !== 0) throw Error(o(331));
      var c = P;
      if (P |= 4, ed(n.current), td(
        n,
        n.current,
        f,
        a
      ), P = c, se(0, !1), Fl && typeof Fl.onPostCommitFiberRoot == "function")
        try {
          Fl.onPostCommitFiberRoot(pu, n);
        } catch {
        }
      return !0;
    } finally {
      _.p = e, b.T = u, Td(l, t);
    }
  }
  function _d(l, t, a) {
    t = dt(a, t), t = ic(l.stateNode, t, 2), l = na(l, t, 2), l !== null && (Uu(l, 2), pt(l));
  }
  function al(l, t, a) {
    if (l.tag === 3)
      _d(l, l, a);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          _d(
            t,
            l,
            a
          );
          break;
        } else if (t.tag === 1) {
          var u = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof u.componentDidCatch == "function" && (ya === null || !ya.has(u))) {
            l = dt(a, l), a = Ms(2), u = na(t, a, 2), u !== null && (Os(
              a,
              u,
              t,
              l
            ), Uu(u, 2), pt(u));
            break;
          }
        }
        t = t.return;
      }
  }
  function xc(l, t, a) {
    var u = l.pingCache;
    if (u === null) {
      u = l.pingCache = new e1();
      var e = /* @__PURE__ */ new Set();
      u.set(t, e);
    } else
      e = u.get(t), e === void 0 && (e = /* @__PURE__ */ new Set(), u.set(t, e));
    e.has(a) || (Mc = !0, e.add(a), l = s1.bind(null, l, t, a), t.then(l, l));
  }
  function s1(l, t, a) {
    var u = l.pingCache;
    u !== null && u.delete(t), l.pingedLanes |= l.suspendedLanes & a, l.warmLanes &= ~a, il === l && (J & a) === a && (hl === 4 || hl === 3 && (J & 62914560) === J && 300 > kl() - on ? (P & 2) === 0 && ru(l, 0) : Oc |= a, Su === J && (Su = 0)), pt(l);
  }
  function Md(l, t) {
    t === 0 && (t = ri()), l = Da(l, t), l !== null && (Uu(l, t), pt(l));
  }
  function d1(l) {
    var t = l.memoizedState, a = 0;
    t !== null && (a = t.retryLane), Md(l, a);
  }
  function y1(l, t) {
    var a = 0;
    switch (l.tag) {
      case 31:
      case 13:
        var u = l.stateNode, e = l.memoizedState;
        e !== null && (a = e.retryLane);
        break;
      case 19:
        u = l.stateNode;
        break;
      case 22:
        u = l.stateNode._retryCache;
        break;
      default:
        throw Error(o(314));
    }
    u !== null && u.delete(t), Md(l, a);
  }
  function v1(l, t) {
    return Kn(l, t);
  }
  var Tn = null, Eu = null, Cc = !1, An = !1, qc = !1, ha = 0;
  function pt(l) {
    l !== Eu && l.next === null && (Eu === null ? Tn = Eu = l : Eu = Eu.next = l), An = !0, Cc || (Cc = !0, h1());
  }
  function se(l, t) {
    if (!qc && An) {
      qc = !0;
      do
        for (var a = !1, u = Tn; u !== null; ) {
          if (l !== 0) {
            var e = u.pendingLanes;
            if (e === 0) var n = 0;
            else {
              var f = u.suspendedLanes, c = u.pingedLanes;
              n = (1 << 31 - Il(42 | l) + 1) - 1, n &= e & ~(f & ~c), n = n & 201326741 ? n & 201326741 | 1 : n ? n | 2 : 0;
            }
            n !== 0 && (a = !0, Ud(u, n));
          } else
            n = J, n = Oe(
              u,
              u === il ? n : 0,
              u.cancelPendingCommit !== null || u.timeoutHandle !== -1
            ), (n & 3) === 0 || Du(u, n) || (a = !0, Ud(u, n));
          u = u.next;
        }
      while (a);
      qc = !1;
    }
  }
  function m1() {
    Od();
  }
  function Od() {
    An = Cc = !1;
    var l = 0;
    ha !== 0 && _1() && (l = ha);
    for (var t = kl(), a = null, u = Tn; u !== null; ) {
      var e = u.next, n = pd(u, t);
      n === 0 ? (u.next = null, a === null ? Tn = e : a.next = e, e === null && (Eu = a)) : (a = u, (l !== 0 || (n & 3) !== 0) && (An = !0)), u = e;
    }
    Al !== 0 && Al !== 5 || se(l), ha !== 0 && (ha = 0);
  }
  function pd(l, t) {
    for (var a = l.suspendedLanes, u = l.pingedLanes, e = l.expirationTimes, n = l.pendingLanes & -62914561; 0 < n; ) {
      var f = 31 - Il(n), c = 1 << f, i = e[f];
      i === -1 ? ((c & a) === 0 || (c & u) !== 0) && (e[f] = Xy(c, t)) : i <= t && (l.expiredLanes |= c), n &= ~c;
    }
    if (t = il, a = J, a = Oe(
      l,
      l === t ? a : 0,
      l.cancelPendingCommit !== null || l.timeoutHandle !== -1
    ), u = l.callbackNode, a === 0 || l === t && (tl === 2 || tl === 9) || l.cancelPendingCommit !== null)
      return u !== null && u !== null && Jn(u), l.callbackNode = null, l.callbackPriority = 0;
    if ((a & 3) === 0 || Du(l, a)) {
      if (t = a & -a, t === l.callbackPriority) return t;
      switch (u !== null && Jn(u), $n(a)) {
        case 2:
        case 8:
          a = Si;
          break;
        case 32:
          a = Te;
          break;
        case 268435456:
          a = bi;
          break;
        default:
          a = Te;
      }
      return u = Dd.bind(null, l), a = Kn(a, u), l.callbackPriority = t, l.callbackNode = a, t;
    }
    return u !== null && u !== null && Jn(u), l.callbackPriority = 2, l.callbackNode = null, 2;
  }
  function Dd(l, t) {
    if (Al !== 0 && Al !== 5)
      return l.callbackNode = null, l.callbackPriority = 0, null;
    var a = l.callbackNode;
    if (En() && l.callbackNode !== a)
      return null;
    var u = J;
    return u = Oe(
      l,
      l === il ? u : 0,
      l.cancelPendingCommit !== null || l.timeoutHandle !== -1
    ), u === 0 ? null : (sd(l, u, t), pd(l, kl()), l.callbackNode != null && l.callbackNode === a ? Dd.bind(null, l) : null);
  }
  function Ud(l, t) {
    if (En()) return null;
    sd(l, t, !0);
  }
  function h1() {
    O1(function() {
      (P & 6) !== 0 ? Kn(
        gi,
        m1
      ) : Od();
    });
  }
  function Bc() {
    if (ha === 0) {
      var l = fu;
      l === 0 && (l = Ae, Ae <<= 1, (Ae & 261888) === 0 && (Ae = 256)), ha = l;
    }
    return ha;
  }
  function Nd(l) {
    return l == null || typeof l == "symbol" || typeof l == "boolean" ? null : typeof l == "function" ? l : Ne("" + l);
  }
  function Hd(l, t) {
    var a = t.ownerDocument.createElement("input");
    return a.name = t.name, a.value = t.value, l.id && a.setAttribute("form", l.id), t.parentNode.insertBefore(a, t), l = new FormData(l), a.parentNode.removeChild(a), l;
  }
  function o1(l, t, a, u, e) {
    if (t === "submit" && a && a.stateNode === e) {
      var n = Nd(
        (e[Ql] || null).action
      ), f = u.submitter;
      f && (t = (t = f[Ql] || null) ? Nd(t.formAction) : f.getAttribute("formAction"), t !== null && (n = t, f = null));
      var c = new Ce(
        "action",
        "action",
        null,
        u,
        e
      );
      l.push({
        event: c,
        listeners: [
          {
            instance: null,
            listener: function() {
              if (u.defaultPrevented) {
                if (ha !== 0) {
                  var i = f ? Hd(e, f) : new FormData(e);
                  ac(
                    a,
                    {
                      pending: !0,
                      data: i,
                      method: e.method,
                      action: n
                    },
                    null,
                    i
                  );
                }
              } else
                typeof n == "function" && (c.preventDefault(), i = f ? Hd(e, f) : new FormData(e), ac(
                  a,
                  {
                    pending: !0,
                    data: i,
                    method: e.method,
                    action: n
                  },
                  n,
                  i
                ));
            },
            currentTarget: e
          }
        ]
      });
    }
  }
  for (var jc = 0; jc < rf.length; jc++) {
    var Yc = rf[jc], g1 = Yc.toLowerCase(), S1 = Yc[0].toUpperCase() + Yc.slice(1);
    bt(
      g1,
      "on" + S1
    );
  }
  bt(i0, "onAnimationEnd"), bt(s0, "onAnimationIteration"), bt(d0, "onAnimationStart"), bt("dblclick", "onDoubleClick"), bt("focusin", "onFocus"), bt("focusout", "onBlur"), bt(xv, "onTransitionRun"), bt(Cv, "onTransitionStart"), bt(qv, "onTransitionCancel"), bt(y0, "onTransitionEnd"), Ja("onMouseEnter", ["mouseout", "mouseover"]), Ja("onMouseLeave", ["mouseout", "mouseover"]), Ja("onPointerEnter", ["pointerout", "pointerover"]), Ja("onPointerLeave", ["pointerout", "pointerover"]), _a(
    "onChange",
    "change click focusin focusout input keydown keyup selectionchange".split(" ")
  ), _a(
    "onSelect",
    "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
      " "
    )
  ), _a("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]), _a(
    "onCompositionEnd",
    "compositionend focusout keydown keypress keyup mousedown".split(" ")
  ), _a(
    "onCompositionStart",
    "compositionstart focusout keydown keypress keyup mousedown".split(" ")
  ), _a(
    "onCompositionUpdate",
    "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
  );
  var de = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
    " "
  ), b1 = new Set(
    "beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(de)
  );
  function Rd(l, t) {
    t = (t & 4) !== 0;
    for (var a = 0; a < l.length; a++) {
      var u = l[a], e = u.event;
      u = u.listeners;
      l: {
        var n = void 0;
        if (t)
          for (var f = u.length - 1; 0 <= f; f--) {
            var c = u[f], i = c.instance, m = c.currentTarget;
            if (c = c.listener, i !== n && e.isPropagationStopped())
              break l;
            n = c, e.currentTarget = m;
            try {
              n(e);
            } catch (S) {
              je(S);
            }
            e.currentTarget = null, n = i;
          }
        else
          for (f = 0; f < u.length; f++) {
            if (c = u[f], i = c.instance, m = c.currentTarget, c = c.listener, i !== n && e.isPropagationStopped())
              break l;
            n = c, e.currentTarget = m;
            try {
              n(e);
            } catch (S) {
              je(S);
            }
            e.currentTarget = null, n = i;
          }
      }
    }
  }
  function K(l, t) {
    var a = t[kn];
    a === void 0 && (a = t[kn] = /* @__PURE__ */ new Set());
    var u = l + "__bubble";
    a.has(u) || (xd(t, l, 2, !1), a.add(u));
  }
  function Gc(l, t, a) {
    var u = 0;
    t && (u |= 4), xd(
      a,
      l,
      u,
      t
    );
  }
  var _n = "_reactListening" + Math.random().toString(36).slice(2);
  function Xc(l) {
    if (!l[_n]) {
      l[_n] = !0, Oi.forEach(function(a) {
        a !== "selectionchange" && (b1.has(a) || Gc(a, !1, l), Gc(a, !0, l));
      });
      var t = l.nodeType === 9 ? l : l.ownerDocument;
      t === null || t[_n] || (t[_n] = !0, Gc("selectionchange", !1, t));
    }
  }
  function xd(l, t, a, u) {
    switch (iy(t)) {
      case 2:
        var e = J1;
        break;
      case 8:
        e = w1;
        break;
      default:
        e = ti;
    }
    a = e.bind(
      null,
      t,
      a,
      l
    ), e = void 0, !nf || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (e = !0), u ? e !== void 0 ? l.addEventListener(t, a, {
      capture: !0,
      passive: e
    }) : l.addEventListener(t, a, !0) : e !== void 0 ? l.addEventListener(t, a, {
      passive: e
    }) : l.addEventListener(t, a, !1);
  }
  function Qc(l, t, a, u, e) {
    var n = u;
    if ((t & 1) === 0 && (t & 2) === 0 && u !== null)
      l: for (; ; ) {
        if (u === null) return;
        var f = u.tag;
        if (f === 3 || f === 4) {
          var c = u.stateNode.containerInfo;
          if (c === e) break;
          if (f === 4)
            for (f = u.return; f !== null; ) {
              var i = f.tag;
              if ((i === 3 || i === 4) && f.stateNode.containerInfo === e)
                return;
              f = f.return;
            }
          for (; c !== null; ) {
            if (f = Va(c), f === null) return;
            if (i = f.tag, i === 5 || i === 6 || i === 26 || i === 27) {
              u = n = f;
              continue l;
            }
            c = c.parentNode;
          }
        }
        u = u.return;
      }
    Yi(function() {
      var m = n, S = uf(a), z = [];
      l: {
        var h = v0.get(l);
        if (h !== void 0) {
          var g = Ce, O = l;
          switch (l) {
            case "keypress":
              if (Re(a) === 0) break l;
            case "keydown":
            case "keyup":
              g = yv;
              break;
            case "focusin":
              O = "focus", g = df;
              break;
            case "focusout":
              O = "blur", g = df;
              break;
            case "beforeblur":
            case "afterblur":
              g = df;
              break;
            case "click":
              if (a.button === 2) break l;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              g = Qi;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              g = Py;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              g = hv;
              break;
            case i0:
            case s0:
            case d0:
              g = av;
              break;
            case y0:
              g = gv;
              break;
            case "scroll":
            case "scrollend":
              g = Fy;
              break;
            case "wheel":
              g = bv;
              break;
            case "copy":
            case "cut":
            case "paste":
              g = ev;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              g = Vi;
              break;
            case "toggle":
            case "beforetoggle":
              g = zv;
          }
          var H = (t & 4) !== 0, fl = !H && (l === "scroll" || l === "scrollend"), y = H ? h !== null ? h + "Capture" : null : h;
          H = [];
          for (var s = m, v; s !== null; ) {
            var r = s;
            if (v = r.stateNode, r = r.tag, r !== 5 && r !== 26 && r !== 27 || v === null || y === null || (r = Ru(s, y), r != null && H.push(
              ye(s, r, v)
            )), fl) break;
            s = s.return;
          }
          0 < H.length && (h = new g(
            h,
            O,
            null,
            a,
            S
          ), z.push({ event: h, listeners: H }));
        }
      }
      if ((t & 7) === 0) {
        l: {
          if (h = l === "mouseover" || l === "pointerover", g = l === "mouseout" || l === "pointerout", h && a !== af && (O = a.relatedTarget || a.fromElement) && (Va(O) || O[Za]))
            break l;
          if ((g || h) && (h = S.window === S ? S : (h = S.ownerDocument) ? h.defaultView || h.parentWindow : window, g ? (O = a.relatedTarget || a.toElement, g = m, O = O ? Va(O) : null, O !== null && (fl = Z(O), H = O.tag, O !== fl || H !== 5 && H !== 27 && H !== 6) && (O = null)) : (g = null, O = m), g !== O)) {
            if (H = Qi, r = "onMouseLeave", y = "onMouseEnter", s = "mouse", (l === "pointerout" || l === "pointerover") && (H = Vi, r = "onPointerLeave", y = "onPointerEnter", s = "pointer"), fl = g == null ? h : Hu(g), v = O == null ? h : Hu(O), h = new H(
              r,
              s + "leave",
              g,
              a,
              S
            ), h.target = fl, h.relatedTarget = v, r = null, Va(S) === m && (H = new H(
              y,
              s + "enter",
              O,
              a,
              S
            ), H.target = v, H.relatedTarget = fl, r = H), fl = r, g && O)
              t: {
                for (H = r1, y = g, s = O, v = 0, r = y; r; r = H(r))
                  v++;
                r = 0;
                for (var N = s; N; N = H(N))
                  r++;
                for (; 0 < v - r; )
                  y = H(y), v--;
                for (; 0 < r - v; )
                  s = H(s), r--;
                for (; v--; ) {
                  if (y === s || s !== null && y === s.alternate) {
                    H = y;
                    break t;
                  }
                  y = H(y), s = H(s);
                }
                H = null;
              }
            else H = null;
            g !== null && Cd(
              z,
              h,
              g,
              H,
              !1
            ), O !== null && fl !== null && Cd(
              z,
              fl,
              O,
              H,
              !0
            );
          }
        }
        l: {
          if (h = m ? Hu(m) : window, g = h.nodeName && h.nodeName.toLowerCase(), g === "select" || g === "input" && h.type === "file")
            var F = Fi;
          else if ($i(h))
            if (Ii)
              F = Nv;
            else {
              F = Dv;
              var D = pv;
            }
          else
            g = h.nodeName, !g || g.toLowerCase() !== "input" || h.type !== "checkbox" && h.type !== "radio" ? m && tf(m.elementType) && (F = Fi) : F = Uv;
          if (F && (F = F(l, m))) {
            ki(
              z,
              F,
              a,
              S
            );
            break l;
          }
          D && D(l, h, m), l === "focusout" && m && h.type === "number" && m.memoizedProps.value != null && lf(h, "number", h.value);
        }
        switch (D = m ? Hu(m) : window, l) {
          case "focusin":
            ($i(D) || D.contentEditable === "true") && (Ia = D, gf = m, Xu = null);
            break;
          case "focusout":
            Xu = gf = Ia = null;
            break;
          case "mousedown":
            Sf = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Sf = !1, f0(z, a, S);
            break;
          case "selectionchange":
            if (Rv) break;
          case "keydown":
          case "keyup":
            f0(z, a, S);
        }
        var X;
        if (vf)
          l: {
            switch (l) {
              case "compositionstart":
                var w = "onCompositionStart";
                break l;
              case "compositionend":
                w = "onCompositionEnd";
                break l;
              case "compositionupdate":
                w = "onCompositionUpdate";
                break l;
            }
            w = void 0;
          }
        else
          Fa ? wi(l, a) && (w = "onCompositionEnd") : l === "keydown" && a.keyCode === 229 && (w = "onCompositionStart");
        w && (Li && a.locale !== "ko" && (Fa || w !== "onCompositionStart" ? w === "onCompositionEnd" && Fa && (X = Gi()) : (It = S, ff = "value" in It ? It.value : It.textContent, Fa = !0)), D = Mn(m, w), 0 < D.length && (w = new Zi(
          w,
          l,
          null,
          a,
          S
        ), z.push({ event: w, listeners: D }), X ? w.data = X : (X = Wi(a), X !== null && (w.data = X)))), (X = Tv ? Av(l, a) : _v(l, a)) && (w = Mn(m, "onBeforeInput"), 0 < w.length && (D = new Zi(
          "onBeforeInput",
          "beforeinput",
          null,
          a,
          S
        ), z.push({
          event: D,
          listeners: w
        }), D.data = X)), o1(
          z,
          l,
          m,
          a,
          S
        );
      }
      Rd(z, t);
    });
  }
  function ye(l, t, a) {
    return {
      instance: l,
      listener: t,
      currentTarget: a
    };
  }
  function Mn(l, t) {
    for (var a = t + "Capture", u = []; l !== null; ) {
      var e = l, n = e.stateNode;
      if (e = e.tag, e !== 5 && e !== 26 && e !== 27 || n === null || (e = Ru(l, a), e != null && u.unshift(
        ye(l, e, n)
      ), e = Ru(l, t), e != null && u.push(
        ye(l, e, n)
      )), l.tag === 3) return u;
      l = l.return;
    }
    return [];
  }
  function r1(l) {
    if (l === null) return null;
    do
      l = l.return;
    while (l && l.tag !== 5 && l.tag !== 27);
    return l || null;
  }
  function Cd(l, t, a, u, e) {
    for (var n = t._reactName, f = []; a !== null && a !== u; ) {
      var c = a, i = c.alternate, m = c.stateNode;
      if (c = c.tag, i !== null && i === u) break;
      c !== 5 && c !== 26 && c !== 27 || m === null || (i = m, e ? (m = Ru(a, n), m != null && f.unshift(
        ye(a, m, i)
      )) : e || (m = Ru(a, n), m != null && f.push(
        ye(a, m, i)
      ))), a = a.return;
    }
    f.length !== 0 && l.push({ event: t, listeners: f });
  }
  var z1 = /\r\n?/g, E1 = /\u0000|\uFFFD/g;
  function qd(l) {
    return (typeof l == "string" ? l : "" + l).replace(z1, `
`).replace(E1, "");
  }
  function Bd(l, t) {
    return t = qd(t), qd(l) === t;
  }
  function nl(l, t, a, u, e, n) {
    switch (a) {
      case "children":
        typeof u == "string" ? t === "body" || t === "textarea" && u === "" || Wa(l, u) : (typeof u == "number" || typeof u == "bigint") && t !== "body" && Wa(l, "" + u);
        break;
      case "className":
        De(l, "class", u);
        break;
      case "tabIndex":
        De(l, "tabindex", u);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        De(l, a, u);
        break;
      case "style":
        Bi(l, u, n);
        break;
      case "data":
        if (t !== "object") {
          De(l, "data", u);
          break;
        }
      case "src":
      case "href":
        if (u === "" && (t !== "a" || a !== "href")) {
          l.removeAttribute(a);
          break;
        }
        if (u == null || typeof u == "function" || typeof u == "symbol" || typeof u == "boolean") {
          l.removeAttribute(a);
          break;
        }
        u = Ne("" + u), l.setAttribute(a, u);
        break;
      case "action":
      case "formAction":
        if (typeof u == "function") {
          l.setAttribute(
            a,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')"
          );
          break;
        } else
          typeof n == "function" && (a === "formAction" ? (t !== "input" && nl(l, t, "name", e.name, e, null), nl(
            l,
            t,
            "formEncType",
            e.formEncType,
            e,
            null
          ), nl(
            l,
            t,
            "formMethod",
            e.formMethod,
            e,
            null
          ), nl(
            l,
            t,
            "formTarget",
            e.formTarget,
            e,
            null
          )) : (nl(l, t, "encType", e.encType, e, null), nl(l, t, "method", e.method, e, null), nl(l, t, "target", e.target, e, null)));
        if (u == null || typeof u == "symbol" || typeof u == "boolean") {
          l.removeAttribute(a);
          break;
        }
        u = Ne("" + u), l.setAttribute(a, u);
        break;
      case "onClick":
        u != null && (l.onclick = Ht);
        break;
      case "onScroll":
        u != null && K("scroll", l);
        break;
      case "onScrollEnd":
        u != null && K("scrollend", l);
        break;
      case "dangerouslySetInnerHTML":
        if (u != null) {
          if (typeof u != "object" || !("__html" in u))
            throw Error(o(61));
          if (a = u.__html, a != null) {
            if (e.children != null) throw Error(o(60));
            l.innerHTML = a;
          }
        }
        break;
      case "multiple":
        l.multiple = u && typeof u != "function" && typeof u != "symbol";
        break;
      case "muted":
        l.muted = u && typeof u != "function" && typeof u != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (u == null || typeof u == "function" || typeof u == "boolean" || typeof u == "symbol") {
          l.removeAttribute("xlink:href");
          break;
        }
        a = Ne("" + u), l.setAttributeNS(
          "http://www.w3.org/1999/xlink",
          "xlink:href",
          a
        );
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        u != null && typeof u != "function" && typeof u != "symbol" ? l.setAttribute(a, "" + u) : l.removeAttribute(a);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        u && typeof u != "function" && typeof u != "symbol" ? l.setAttribute(a, "") : l.removeAttribute(a);
        break;
      case "capture":
      case "download":
        u === !0 ? l.setAttribute(a, "") : u !== !1 && u != null && typeof u != "function" && typeof u != "symbol" ? l.setAttribute(a, u) : l.removeAttribute(a);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        u != null && typeof u != "function" && typeof u != "symbol" && !isNaN(u) && 1 <= u ? l.setAttribute(a, u) : l.removeAttribute(a);
        break;
      case "rowSpan":
      case "start":
        u == null || typeof u == "function" || typeof u == "symbol" || isNaN(u) ? l.removeAttribute(a) : l.setAttribute(a, u);
        break;
      case "popover":
        K("beforetoggle", l), K("toggle", l), pe(l, "popover", u);
        break;
      case "xlinkActuate":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:actuate",
          u
        );
        break;
      case "xlinkArcrole":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:arcrole",
          u
        );
        break;
      case "xlinkRole":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:role",
          u
        );
        break;
      case "xlinkShow":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:show",
          u
        );
        break;
      case "xlinkTitle":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:title",
          u
        );
        break;
      case "xlinkType":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:type",
          u
        );
        break;
      case "xmlBase":
        Nt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:base",
          u
        );
        break;
      case "xmlLang":
        Nt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:lang",
          u
        );
        break;
      case "xmlSpace":
        Nt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:space",
          u
        );
        break;
      case "is":
        pe(l, "is", u);
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        (!(2 < a.length) || a[0] !== "o" && a[0] !== "O" || a[1] !== "n" && a[1] !== "N") && (a = $y.get(a) || a, pe(l, a, u));
    }
  }
  function Zc(l, t, a, u, e, n) {
    switch (a) {
      case "style":
        Bi(l, u, n);
        break;
      case "dangerouslySetInnerHTML":
        if (u != null) {
          if (typeof u != "object" || !("__html" in u))
            throw Error(o(61));
          if (a = u.__html, a != null) {
            if (e.children != null) throw Error(o(60));
            l.innerHTML = a;
          }
        }
        break;
      case "children":
        typeof u == "string" ? Wa(l, u) : (typeof u == "number" || typeof u == "bigint") && Wa(l, "" + u);
        break;
      case "onScroll":
        u != null && K("scroll", l);
        break;
      case "onScrollEnd":
        u != null && K("scrollend", l);
        break;
      case "onClick":
        u != null && (l.onclick = Ht);
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        if (!pi.hasOwnProperty(a))
          l: {
            if (a[0] === "o" && a[1] === "n" && (e = a.endsWith("Capture"), t = a.slice(2, e ? a.length - 7 : void 0), n = l[Ql] || null, n = n != null ? n[a] : null, typeof n == "function" && l.removeEventListener(t, n, e), typeof u == "function")) {
              typeof n != "function" && n !== null && (a in l ? l[a] = null : l.hasAttribute(a) && l.removeAttribute(a)), l.addEventListener(t, u, e);
              break l;
            }
            a in l ? l[a] = u : u === !0 ? l.setAttribute(a, "") : pe(l, a, u);
          }
    }
  }
  function Hl(l, t, a) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        K("error", l), K("load", l);
        var u = !1, e = !1, n;
        for (n in a)
          if (a.hasOwnProperty(n)) {
            var f = a[n];
            if (f != null)
              switch (n) {
                case "src":
                  u = !0;
                  break;
                case "srcSet":
                  e = !0;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  throw Error(o(137, t));
                default:
                  nl(l, t, n, f, a, null);
              }
          }
        e && nl(l, t, "srcSet", a.srcSet, a, null), u && nl(l, t, "src", a.src, a, null);
        return;
      case "input":
        K("invalid", l);
        var c = n = f = e = null, i = null, m = null;
        for (u in a)
          if (a.hasOwnProperty(u)) {
            var S = a[u];
            if (S != null)
              switch (u) {
                case "name":
                  e = S;
                  break;
                case "type":
                  f = S;
                  break;
                case "checked":
                  i = S;
                  break;
                case "defaultChecked":
                  m = S;
                  break;
                case "value":
                  n = S;
                  break;
                case "defaultValue":
                  c = S;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  if (S != null)
                    throw Error(o(137, t));
                  break;
                default:
                  nl(l, t, u, S, a, null);
              }
          }
        Ri(
          l,
          n,
          c,
          i,
          m,
          f,
          e,
          !1
        );
        return;
      case "select":
        K("invalid", l), u = f = n = null;
        for (e in a)
          if (a.hasOwnProperty(e) && (c = a[e], c != null))
            switch (e) {
              case "value":
                n = c;
                break;
              case "defaultValue":
                f = c;
                break;
              case "multiple":
                u = c;
              default:
                nl(l, t, e, c, a, null);
            }
        t = n, a = f, l.multiple = !!u, t != null ? wa(l, !!u, t, !1) : a != null && wa(l, !!u, a, !0);
        return;
      case "textarea":
        K("invalid", l), n = e = u = null;
        for (f in a)
          if (a.hasOwnProperty(f) && (c = a[f], c != null))
            switch (f) {
              case "value":
                u = c;
                break;
              case "defaultValue":
                e = c;
                break;
              case "children":
                n = c;
                break;
              case "dangerouslySetInnerHTML":
                if (c != null) throw Error(o(91));
                break;
              default:
                nl(l, t, f, c, a, null);
            }
        Ci(l, u, e, n);
        return;
      case "option":
        for (i in a)
          a.hasOwnProperty(i) && (u = a[i], u != null) && (i === "selected" ? l.selected = u && typeof u != "function" && typeof u != "symbol" : nl(l, t, i, u, a, null));
        return;
      case "dialog":
        K("beforetoggle", l), K("toggle", l), K("cancel", l), K("close", l);
        break;
      case "iframe":
      case "object":
        K("load", l);
        break;
      case "video":
      case "audio":
        for (u = 0; u < de.length; u++)
          K(de[u], l);
        break;
      case "image":
        K("error", l), K("load", l);
        break;
      case "details":
        K("toggle", l);
        break;
      case "embed":
      case "source":
      case "link":
        K("error", l), K("load", l);
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (m in a)
          if (a.hasOwnProperty(m) && (u = a[m], u != null))
            switch (m) {
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(o(137, t));
              default:
                nl(l, t, m, u, a, null);
            }
        return;
      default:
        if (tf(t)) {
          for (S in a)
            a.hasOwnProperty(S) && (u = a[S], u !== void 0 && Zc(
              l,
              t,
              S,
              u,
              a,
              void 0
            ));
          return;
        }
    }
    for (c in a)
      a.hasOwnProperty(c) && (u = a[c], u != null && nl(l, t, c, u, a, null));
  }
  function T1(l, t, a, u) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var e = null, n = null, f = null, c = null, i = null, m = null, S = null;
        for (g in a) {
          var z = a[g];
          if (a.hasOwnProperty(g) && z != null)
            switch (g) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                i = z;
              default:
                u.hasOwnProperty(g) || nl(l, t, g, null, u, z);
            }
        }
        for (var h in u) {
          var g = u[h];
          if (z = a[h], u.hasOwnProperty(h) && (g != null || z != null))
            switch (h) {
              case "type":
                n = g;
                break;
              case "name":
                e = g;
                break;
              case "checked":
                m = g;
                break;
              case "defaultChecked":
                S = g;
                break;
              case "value":
                f = g;
                break;
              case "defaultValue":
                c = g;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (g != null)
                  throw Error(o(137, t));
                break;
              default:
                g !== z && nl(
                  l,
                  t,
                  h,
                  g,
                  u,
                  z
                );
            }
        }
        Pn(
          l,
          f,
          c,
          i,
          m,
          S,
          n,
          e
        );
        return;
      case "select":
        g = f = c = h = null;
        for (n in a)
          if (i = a[n], a.hasOwnProperty(n) && i != null)
            switch (n) {
              case "value":
                break;
              case "multiple":
                g = i;
              default:
                u.hasOwnProperty(n) || nl(
                  l,
                  t,
                  n,
                  null,
                  u,
                  i
                );
            }
        for (e in u)
          if (n = u[e], i = a[e], u.hasOwnProperty(e) && (n != null || i != null))
            switch (e) {
              case "value":
                h = n;
                break;
              case "defaultValue":
                c = n;
                break;
              case "multiple":
                f = n;
              default:
                n !== i && nl(
                  l,
                  t,
                  e,
                  n,
                  u,
                  i
                );
            }
        t = c, a = f, u = g, h != null ? wa(l, !!a, h, !1) : !!u != !!a && (t != null ? wa(l, !!a, t, !0) : wa(l, !!a, a ? [] : "", !1));
        return;
      case "textarea":
        g = h = null;
        for (c in a)
          if (e = a[c], a.hasOwnProperty(c) && e != null && !u.hasOwnProperty(c))
            switch (c) {
              case "value":
                break;
              case "children":
                break;
              default:
                nl(l, t, c, null, u, e);
            }
        for (f in u)
          if (e = u[f], n = a[f], u.hasOwnProperty(f) && (e != null || n != null))
            switch (f) {
              case "value":
                h = e;
                break;
              case "defaultValue":
                g = e;
                break;
              case "children":
                break;
              case "dangerouslySetInnerHTML":
                if (e != null) throw Error(o(91));
                break;
              default:
                e !== n && nl(l, t, f, e, u, n);
            }
        xi(l, h, g);
        return;
      case "option":
        for (var O in a)
          h = a[O], a.hasOwnProperty(O) && h != null && !u.hasOwnProperty(O) && (O === "selected" ? l.selected = !1 : nl(
            l,
            t,
            O,
            null,
            u,
            h
          ));
        for (i in u)
          h = u[i], g = a[i], u.hasOwnProperty(i) && h !== g && (h != null || g != null) && (i === "selected" ? l.selected = h && typeof h != "function" && typeof h != "symbol" : nl(
            l,
            t,
            i,
            h,
            u,
            g
          ));
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var H in a)
          h = a[H], a.hasOwnProperty(H) && h != null && !u.hasOwnProperty(H) && nl(l, t, H, null, u, h);
        for (m in u)
          if (h = u[m], g = a[m], u.hasOwnProperty(m) && h !== g && (h != null || g != null))
            switch (m) {
              case "children":
              case "dangerouslySetInnerHTML":
                if (h != null)
                  throw Error(o(137, t));
                break;
              default:
                nl(
                  l,
                  t,
                  m,
                  h,
                  u,
                  g
                );
            }
        return;
      default:
        if (tf(t)) {
          for (var fl in a)
            h = a[fl], a.hasOwnProperty(fl) && h !== void 0 && !u.hasOwnProperty(fl) && Zc(
              l,
              t,
              fl,
              void 0,
              u,
              h
            );
          for (S in u)
            h = u[S], g = a[S], !u.hasOwnProperty(S) || h === g || h === void 0 && g === void 0 || Zc(
              l,
              t,
              S,
              h,
              u,
              g
            );
          return;
        }
    }
    for (var y in a)
      h = a[y], a.hasOwnProperty(y) && h != null && !u.hasOwnProperty(y) && nl(l, t, y, null, u, h);
    for (z in u)
      h = u[z], g = a[z], !u.hasOwnProperty(z) || h === g || h == null && g == null || nl(l, t, z, h, u, g);
  }
  function jd(l) {
    switch (l) {
      case "css":
      case "script":
      case "font":
      case "img":
      case "image":
      case "input":
      case "link":
        return !0;
      default:
        return !1;
    }
  }
  function A1() {
    if (typeof performance.getEntriesByType == "function") {
      for (var l = 0, t = 0, a = performance.getEntriesByType("resource"), u = 0; u < a.length; u++) {
        var e = a[u], n = e.transferSize, f = e.initiatorType, c = e.duration;
        if (n && c && jd(f)) {
          for (f = 0, c = e.responseEnd, u += 1; u < a.length; u++) {
            var i = a[u], m = i.startTime;
            if (m > c) break;
            var S = i.transferSize, z = i.initiatorType;
            S && jd(z) && (i = i.responseEnd, f += S * (i < c ? 1 : (c - m) / (i - m)));
          }
          if (--u, t += 8 * (n + f) / (e.duration / 1e3), l++, 10 < l) break;
        }
      }
      if (0 < l) return t / l / 1e6;
    }
    return navigator.connection && (l = navigator.connection.downlink, typeof l == "number") ? l : 5;
  }
  var Vc = null, Lc = null;
  function On(l) {
    return l.nodeType === 9 ? l : l.ownerDocument;
  }
  function Yd(l) {
    switch (l) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function Gd(l, t) {
    if (l === 0)
      switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
    return l === 1 && t === "foreignObject" ? 0 : l;
  }
  function Kc(l, t) {
    return l === "textarea" || l === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
  }
  var Jc = null;
  function _1() {
    var l = window.event;
    return l && l.type === "popstate" ? l === Jc ? !1 : (Jc = l, !0) : (Jc = null, !1);
  }
  var Xd = typeof setTimeout == "function" ? setTimeout : void 0, M1 = typeof clearTimeout == "function" ? clearTimeout : void 0, Qd = typeof Promise == "function" ? Promise : void 0, O1 = typeof queueMicrotask == "function" ? queueMicrotask : typeof Qd < "u" ? function(l) {
    return Qd.resolve(null).then(l).catch(p1);
  } : Xd;
  function p1(l) {
    setTimeout(function() {
      throw l;
    });
  }
  function oa(l) {
    return l === "head";
  }
  function Zd(l, t) {
    var a = t, u = 0;
    do {
      var e = a.nextSibling;
      if (l.removeChild(a), e && e.nodeType === 8)
        if (a = e.data, a === "/$" || a === "/&") {
          if (u === 0) {
            l.removeChild(e), Mu(t);
            return;
          }
          u--;
        } else if (a === "$" || a === "$?" || a === "$~" || a === "$!" || a === "&")
          u++;
        else if (a === "html")
          ve(l.ownerDocument.documentElement);
        else if (a === "head") {
          a = l.ownerDocument.head, ve(a);
          for (var n = a.firstChild; n; ) {
            var f = n.nextSibling, c = n.nodeName;
            n[Nu] || c === "SCRIPT" || c === "STYLE" || c === "LINK" && n.rel.toLowerCase() === "stylesheet" || a.removeChild(n), n = f;
          }
        } else
          a === "body" && ve(l.ownerDocument.body);
      a = e;
    } while (a);
    Mu(t);
  }
  function Vd(l, t) {
    var a = l;
    l = 0;
    do {
      var u = a.nextSibling;
      if (a.nodeType === 1 ? t ? (a._stashedDisplay = a.style.display, a.style.display = "none") : (a.style.display = a._stashedDisplay || "", a.getAttribute("style") === "" && a.removeAttribute("style")) : a.nodeType === 3 && (t ? (a._stashedText = a.nodeValue, a.nodeValue = "") : a.nodeValue = a._stashedText || ""), u && u.nodeType === 8)
        if (a = u.data, a === "/$") {
          if (l === 0) break;
          l--;
        } else
          a !== "$" && a !== "$?" && a !== "$~" && a !== "$!" || l++;
      a = u;
    } while (a);
  }
  function wc(l) {
    var t = l.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var a = t;
      switch (t = t.nextSibling, a.nodeName) {
        case "HTML":
        case "HEAD":
        case "BODY":
          wc(a), Fn(a);
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (a.rel.toLowerCase() === "stylesheet") continue;
      }
      l.removeChild(a);
    }
  }
  function D1(l, t, a, u) {
    for (; l.nodeType === 1; ) {
      var e = a;
      if (l.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!u && (l.nodeName !== "INPUT" || l.type !== "hidden"))
          break;
      } else if (u) {
        if (!l[Nu])
          switch (t) {
            case "meta":
              if (!l.hasAttribute("itemprop")) break;
              return l;
            case "link":
              if (n = l.getAttribute("rel"), n === "stylesheet" && l.hasAttribute("data-precedence"))
                break;
              if (n !== e.rel || l.getAttribute("href") !== (e.href == null || e.href === "" ? null : e.href) || l.getAttribute("crossorigin") !== (e.crossOrigin == null ? null : e.crossOrigin) || l.getAttribute("title") !== (e.title == null ? null : e.title))
                break;
              return l;
            case "style":
              if (l.hasAttribute("data-precedence")) break;
              return l;
            case "script":
              if (n = l.getAttribute("src"), (n !== (e.src == null ? null : e.src) || l.getAttribute("type") !== (e.type == null ? null : e.type) || l.getAttribute("crossorigin") !== (e.crossOrigin == null ? null : e.crossOrigin)) && n && l.hasAttribute("async") && !l.hasAttribute("itemprop"))
                break;
              return l;
            default:
              return l;
          }
      } else if (t === "input" && l.type === "hidden") {
        var n = e.name == null ? null : "" + e.name;
        if (e.type === "hidden" && l.getAttribute("name") === n)
          return l;
      } else return l;
      if (l = ot(l.nextSibling), l === null) break;
    }
    return null;
  }
  function U1(l, t, a) {
    if (t === "") return null;
    for (; l.nodeType !== 3; )
      if ((l.nodeType !== 1 || l.nodeName !== "INPUT" || l.type !== "hidden") && !a || (l = ot(l.nextSibling), l === null)) return null;
    return l;
  }
  function Ld(l, t) {
    for (; l.nodeType !== 8; )
      if ((l.nodeType !== 1 || l.nodeName !== "INPUT" || l.type !== "hidden") && !t || (l = ot(l.nextSibling), l === null)) return null;
    return l;
  }
  function Wc(l) {
    return l.data === "$?" || l.data === "$~";
  }
  function $c(l) {
    return l.data === "$!" || l.data === "$?" && l.ownerDocument.readyState !== "loading";
  }
  function N1(l, t) {
    var a = l.ownerDocument;
    if (l.data === "$~") l._reactRetry = t;
    else if (l.data !== "$?" || a.readyState !== "loading")
      t();
    else {
      var u = function() {
        t(), a.removeEventListener("DOMContentLoaded", u);
      };
      a.addEventListener("DOMContentLoaded", u), l._reactRetry = u;
    }
  }
  function ot(l) {
    for (; l != null; l = l.nextSibling) {
      var t = l.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (t = l.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F")
          break;
        if (t === "/$" || t === "/&") return null;
      }
    }
    return l;
  }
  var kc = null;
  function Kd(l) {
    l = l.nextSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === "/$" || a === "/&") {
          if (t === 0)
            return ot(l.nextSibling);
          t--;
        } else
          a !== "$" && a !== "$!" && a !== "$?" && a !== "$~" && a !== "&" || t++;
      }
      l = l.nextSibling;
    }
    return null;
  }
  function Jd(l) {
    l = l.previousSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === "$" || a === "$!" || a === "$?" || a === "$~" || a === "&") {
          if (t === 0) return l;
          t--;
        } else a !== "/$" && a !== "/&" || t++;
      }
      l = l.previousSibling;
    }
    return null;
  }
  function wd(l, t, a) {
    switch (t = On(a), l) {
      case "html":
        if (l = t.documentElement, !l) throw Error(o(452));
        return l;
      case "head":
        if (l = t.head, !l) throw Error(o(453));
        return l;
      case "body":
        if (l = t.body, !l) throw Error(o(454));
        return l;
      default:
        throw Error(o(451));
    }
  }
  function ve(l) {
    for (var t = l.attributes; t.length; )
      l.removeAttributeNode(t[0]);
    Fn(l);
  }
  var gt = /* @__PURE__ */ new Map(), Wd = /* @__PURE__ */ new Set();
  function pn(l) {
    return typeof l.getRootNode == "function" ? l.getRootNode() : l.nodeType === 9 ? l : l.ownerDocument;
  }
  var wt = _.d;
  _.d = {
    f: H1,
    r: R1,
    D: x1,
    C: C1,
    L: q1,
    m: B1,
    X: Y1,
    S: j1,
    M: G1
  };
  function H1() {
    var l = wt.f(), t = bn();
    return l || t;
  }
  function R1(l) {
    var t = La(l);
    t !== null && t.tag === 5 && t.type === "form" ? ys(t) : wt.r(l);
  }
  var Tu = typeof document > "u" ? null : document;
  function $d(l, t, a) {
    var u = Tu;
    if (u && typeof t == "string" && t) {
      var e = it(t);
      e = 'link[rel="' + l + '"][href="' + e + '"]', typeof a == "string" && (e += '[crossorigin="' + a + '"]'), Wd.has(e) || (Wd.add(e), l = { rel: l, crossOrigin: a, href: t }, u.querySelector(e) === null && (t = u.createElement("link"), Hl(t, "link", l), Ml(t), u.head.appendChild(t)));
    }
  }
  function x1(l) {
    wt.D(l), $d("dns-prefetch", l, null);
  }
  function C1(l, t) {
    wt.C(l, t), $d("preconnect", l, t);
  }
  function q1(l, t, a) {
    wt.L(l, t, a);
    var u = Tu;
    if (u && l && t) {
      var e = 'link[rel="preload"][as="' + it(t) + '"]';
      t === "image" && a && a.imageSrcSet ? (e += '[imagesrcset="' + it(
        a.imageSrcSet
      ) + '"]', typeof a.imageSizes == "string" && (e += '[imagesizes="' + it(
        a.imageSizes
      ) + '"]')) : e += '[href="' + it(l) + '"]';
      var n = e;
      switch (t) {
        case "style":
          n = Au(l);
          break;
        case "script":
          n = _u(l);
      }
      gt.has(n) || (l = R(
        {
          rel: "preload",
          href: t === "image" && a && a.imageSrcSet ? void 0 : l,
          as: t
        },
        a
      ), gt.set(n, l), u.querySelector(e) !== null || t === "style" && u.querySelector(me(n)) || t === "script" && u.querySelector(he(n)) || (t = u.createElement("link"), Hl(t, "link", l), Ml(t), u.head.appendChild(t)));
    }
  }
  function B1(l, t) {
    wt.m(l, t);
    var a = Tu;
    if (a && l) {
      var u = t && typeof t.as == "string" ? t.as : "script", e = 'link[rel="modulepreload"][as="' + it(u) + '"][href="' + it(l) + '"]', n = e;
      switch (u) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          n = _u(l);
      }
      if (!gt.has(n) && (l = R({ rel: "modulepreload", href: l }, t), gt.set(n, l), a.querySelector(e) === null)) {
        switch (u) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (a.querySelector(he(n)))
              return;
        }
        u = a.createElement("link"), Hl(u, "link", l), Ml(u), a.head.appendChild(u);
      }
    }
  }
  function j1(l, t, a) {
    wt.S(l, t, a);
    var u = Tu;
    if (u && l) {
      var e = Ka(u).hoistableStyles, n = Au(l);
      t = t || "default";
      var f = e.get(n);
      if (!f) {
        var c = { loading: 0, preload: null };
        if (f = u.querySelector(
          me(n)
        ))
          c.loading = 5;
        else {
          l = R(
            { rel: "stylesheet", href: l, "data-precedence": t },
            a
          ), (a = gt.get(n)) && Fc(l, a);
          var i = f = u.createElement("link");
          Ml(i), Hl(i, "link", l), i._p = new Promise(function(m, S) {
            i.onload = m, i.onerror = S;
          }), i.addEventListener("load", function() {
            c.loading |= 1;
          }), i.addEventListener("error", function() {
            c.loading |= 2;
          }), c.loading |= 4, Dn(f, t, u);
        }
        f = {
          type: "stylesheet",
          instance: f,
          count: 1,
          state: c
        }, e.set(n, f);
      }
    }
  }
  function Y1(l, t) {
    wt.X(l, t);
    var a = Tu;
    if (a && l) {
      var u = Ka(a).hoistableScripts, e = _u(l), n = u.get(e);
      n || (n = a.querySelector(he(e)), n || (l = R({ src: l, async: !0 }, t), (t = gt.get(e)) && Ic(l, t), n = a.createElement("script"), Ml(n), Hl(n, "link", l), a.head.appendChild(n)), n = {
        type: "script",
        instance: n,
        count: 1,
        state: null
      }, u.set(e, n));
    }
  }
  function G1(l, t) {
    wt.M(l, t);
    var a = Tu;
    if (a && l) {
      var u = Ka(a).hoistableScripts, e = _u(l), n = u.get(e);
      n || (n = a.querySelector(he(e)), n || (l = R({ src: l, async: !0, type: "module" }, t), (t = gt.get(e)) && Ic(l, t), n = a.createElement("script"), Ml(n), Hl(n, "link", l), a.head.appendChild(n)), n = {
        type: "script",
        instance: n,
        count: 1,
        state: null
      }, u.set(e, n));
    }
  }
  function kd(l, t, a, u) {
    var e = (e = V.current) ? pn(e) : null;
    if (!e) throw Error(o(446));
    switch (l) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof a.precedence == "string" && typeof a.href == "string" ? (t = Au(a.href), a = Ka(
          e
        ).hoistableStyles, u = a.get(t), u || (u = {
          type: "style",
          instance: null,
          count: 0,
          state: null
        }, a.set(t, u)), u) : { type: "void", instance: null, count: 0, state: null };
      case "link":
        if (a.rel === "stylesheet" && typeof a.href == "string" && typeof a.precedence == "string") {
          l = Au(a.href);
          var n = Ka(
            e
          ).hoistableStyles, f = n.get(l);
          if (f || (e = e.ownerDocument || e, f = {
            type: "stylesheet",
            instance: null,
            count: 0,
            state: { loading: 0, preload: null }
          }, n.set(l, f), (n = e.querySelector(
            me(l)
          )) && !n._p && (f.instance = n, f.state.loading = 5), gt.has(l) || (a = {
            rel: "preload",
            as: "style",
            href: a.href,
            crossOrigin: a.crossOrigin,
            integrity: a.integrity,
            media: a.media,
            hrefLang: a.hrefLang,
            referrerPolicy: a.referrerPolicy
          }, gt.set(l, a), n || X1(
            e,
            l,
            a,
            f.state
          ))), t && u === null)
            throw Error(o(528, ""));
          return f;
        }
        if (t && u !== null)
          throw Error(o(529, ""));
        return null;
      case "script":
        return t = a.async, a = a.src, typeof a == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = _u(a), a = Ka(
          e
        ).hoistableScripts, u = a.get(t), u || (u = {
          type: "script",
          instance: null,
          count: 0,
          state: null
        }, a.set(t, u)), u) : { type: "void", instance: null, count: 0, state: null };
      default:
        throw Error(o(444, l));
    }
  }
  function Au(l) {
    return 'href="' + it(l) + '"';
  }
  function me(l) {
    return 'link[rel="stylesheet"][' + l + "]";
  }
  function Fd(l) {
    return R({}, l, {
      "data-precedence": l.precedence,
      precedence: null
    });
  }
  function X1(l, t, a, u) {
    l.querySelector('link[rel="preload"][as="style"][' + t + "]") ? u.loading = 1 : (t = l.createElement("link"), u.preload = t, t.addEventListener("load", function() {
      return u.loading |= 1;
    }), t.addEventListener("error", function() {
      return u.loading |= 2;
    }), Hl(t, "link", a), Ml(t), l.head.appendChild(t));
  }
  function _u(l) {
    return '[src="' + it(l) + '"]';
  }
  function he(l) {
    return "script[async]" + l;
  }
  function Id(l, t, a) {
    if (t.count++, t.instance === null)
      switch (t.type) {
        case "style":
          var u = l.querySelector(
            'style[data-href~="' + it(a.href) + '"]'
          );
          if (u)
            return t.instance = u, Ml(u), u;
          var e = R({}, a, {
            "data-href": a.href,
            "data-precedence": a.precedence,
            href: null,
            precedence: null
          });
          return u = (l.ownerDocument || l).createElement(
            "style"
          ), Ml(u), Hl(u, "style", e), Dn(u, a.precedence, l), t.instance = u;
        case "stylesheet":
          e = Au(a.href);
          var n = l.querySelector(
            me(e)
          );
          if (n)
            return t.state.loading |= 4, t.instance = n, Ml(n), n;
          u = Fd(a), (e = gt.get(e)) && Fc(u, e), n = (l.ownerDocument || l).createElement("link"), Ml(n);
          var f = n;
          return f._p = new Promise(function(c, i) {
            f.onload = c, f.onerror = i;
          }), Hl(n, "link", u), t.state.loading |= 4, Dn(n, a.precedence, l), t.instance = n;
        case "script":
          return n = _u(a.src), (e = l.querySelector(
            he(n)
          )) ? (t.instance = e, Ml(e), e) : (u = a, (e = gt.get(n)) && (u = R({}, a), Ic(u, e)), l = l.ownerDocument || l, e = l.createElement("script"), Ml(e), Hl(e, "link", u), l.head.appendChild(e), t.instance = e);
        case "void":
          return null;
        default:
          throw Error(o(443, t.type));
      }
    else
      t.type === "stylesheet" && (t.state.loading & 4) === 0 && (u = t.instance, t.state.loading |= 4, Dn(u, a.precedence, l));
    return t.instance;
  }
  function Dn(l, t, a) {
    for (var u = a.querySelectorAll(
      'link[rel="stylesheet"][data-precedence],style[data-precedence]'
    ), e = u.length ? u[u.length - 1] : null, n = e, f = 0; f < u.length; f++) {
      var c = u[f];
      if (c.dataset.precedence === t) n = c;
      else if (n !== e) break;
    }
    n ? n.parentNode.insertBefore(l, n.nextSibling) : (t = a.nodeType === 9 ? a.head : a, t.insertBefore(l, t.firstChild));
  }
  function Fc(l, t) {
    l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.title == null && (l.title = t.title);
  }
  function Ic(l, t) {
    l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.integrity == null && (l.integrity = t.integrity);
  }
  var Un = null;
  function Pd(l, t, a) {
    if (Un === null) {
      var u = /* @__PURE__ */ new Map(), e = Un = /* @__PURE__ */ new Map();
      e.set(a, u);
    } else
      e = Un, u = e.get(a), u || (u = /* @__PURE__ */ new Map(), e.set(a, u));
    if (u.has(l)) return u;
    for (u.set(l, null), a = a.getElementsByTagName(l), e = 0; e < a.length; e++) {
      var n = a[e];
      if (!(n[Nu] || n[pl] || l === "link" && n.getAttribute("rel") === "stylesheet") && n.namespaceURI !== "http://www.w3.org/2000/svg") {
        var f = n.getAttribute(t) || "";
        f = l + f;
        var c = u.get(f);
        c ? c.push(n) : u.set(f, [n]);
      }
    }
    return u;
  }
  function ly(l, t, a) {
    l = l.ownerDocument || l, l.head.insertBefore(
      a,
      t === "title" ? l.querySelector("head > title") : null
    );
  }
  function Q1(l, t, a) {
    if (a === 1 || t.itemProp != null) return !1;
    switch (l) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "")
          break;
        return !0;
      case "link":
        if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError)
          break;
        return t.rel === "stylesheet" ? (l = t.disabled, typeof t.precedence == "string" && l == null) : !0;
      case "script":
        if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string")
          return !0;
    }
    return !1;
  }
  function ty(l) {
    return !(l.type === "stylesheet" && (l.state.loading & 3) === 0);
  }
  function Z1(l, t, a, u) {
    if (a.type === "stylesheet" && (typeof u.media != "string" || matchMedia(u.media).matches !== !1) && (a.state.loading & 4) === 0) {
      if (a.instance === null) {
        var e = Au(u.href), n = t.querySelector(
          me(e)
        );
        if (n) {
          t = n._p, t !== null && typeof t == "object" && typeof t.then == "function" && (l.count++, l = Nn.bind(l), t.then(l, l)), a.state.loading |= 4, a.instance = n, Ml(n);
          return;
        }
        n = t.ownerDocument || t, u = Fd(u), (e = gt.get(e)) && Fc(u, e), n = n.createElement("link"), Ml(n);
        var f = n;
        f._p = new Promise(function(c, i) {
          f.onload = c, f.onerror = i;
        }), Hl(n, "link", u), a.instance = n;
      }
      l.stylesheets === null && (l.stylesheets = /* @__PURE__ */ new Map()), l.stylesheets.set(a, t), (t = a.state.preload) && (a.state.loading & 3) === 0 && (l.count++, a = Nn.bind(l), t.addEventListener("load", a), t.addEventListener("error", a));
    }
  }
  var Pc = 0;
  function V1(l, t) {
    return l.stylesheets && l.count === 0 && Rn(l, l.stylesheets), 0 < l.count || 0 < l.imgCount ? function(a) {
      var u = setTimeout(function() {
        if (l.stylesheets && Rn(l, l.stylesheets), l.unsuspend) {
          var n = l.unsuspend;
          l.unsuspend = null, n();
        }
      }, 6e4 + t);
      0 < l.imgBytes && Pc === 0 && (Pc = 62500 * A1());
      var e = setTimeout(
        function() {
          if (l.waitingForImages = !1, l.count === 0 && (l.stylesheets && Rn(l, l.stylesheets), l.unsuspend)) {
            var n = l.unsuspend;
            l.unsuspend = null, n();
          }
        },
        (l.imgBytes > Pc ? 50 : 800) + t
      );
      return l.unsuspend = a, function() {
        l.unsuspend = null, clearTimeout(u), clearTimeout(e);
      };
    } : null;
  }
  function Nn() {
    if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
      if (this.stylesheets) Rn(this, this.stylesheets);
      else if (this.unsuspend) {
        var l = this.unsuspend;
        this.unsuspend = null, l();
      }
    }
  }
  var Hn = null;
  function Rn(l, t) {
    l.stylesheets = null, l.unsuspend !== null && (l.count++, Hn = /* @__PURE__ */ new Map(), t.forEach(L1, l), Hn = null, Nn.call(l));
  }
  function L1(l, t) {
    if (!(t.state.loading & 4)) {
      var a = Hn.get(l);
      if (a) var u = a.get(null);
      else {
        a = /* @__PURE__ */ new Map(), Hn.set(l, a);
        for (var e = l.querySelectorAll(
          "link[data-precedence],style[data-precedence]"
        ), n = 0; n < e.length; n++) {
          var f = e[n];
          (f.nodeName === "LINK" || f.getAttribute("media") !== "not all") && (a.set(f.dataset.precedence, f), u = f);
        }
        u && a.set(null, u);
      }
      e = t.instance, f = e.getAttribute("data-precedence"), n = a.get(f) || u, n === u && a.set(null, e), a.set(f, e), this.count++, u = Nn.bind(this), e.addEventListener("load", u), e.addEventListener("error", u), n ? n.parentNode.insertBefore(e, n.nextSibling) : (l = l.nodeType === 9 ? l.head : l, l.insertBefore(e, l.firstChild)), t.state.loading |= 4;
    }
  }
  var oe = {
    $$typeof: Rl,
    Provider: null,
    Consumer: null,
    _currentValue: x,
    _currentValue2: x,
    _threadCount: 0
  };
  function K1(l, t, a, u, e, n, f, c, i) {
    this.tag = 1, this.containerInfo = l, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = wn(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = wn(0), this.hiddenUpdates = wn(null), this.identifierPrefix = u, this.onUncaughtError = e, this.onCaughtError = n, this.onRecoverableError = f, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = i, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function ay(l, t, a, u, e, n, f, c, i, m, S, z) {
    return l = new K1(
      l,
      t,
      a,
      f,
      i,
      m,
      S,
      z,
      c
    ), t = 1, n === !0 && (t |= 24), n = lt(3, null, null, t), l.current = n, n.stateNode = l, t = Rf(), t.refCount++, l.pooledCache = t, t.refCount++, n.memoizedState = {
      element: u,
      isDehydrated: a,
      cache: t
    }, Bf(n), l;
  }
  function uy(l) {
    return l ? (l = tu, l) : tu;
  }
  function ey(l, t, a, u, e, n) {
    e = uy(e), u.context === null ? u.context = e : u.pendingContext = e, u = ea(t), u.payload = { element: a }, n = n === void 0 ? null : n, n !== null && (u.callback = n), a = na(l, u, t), a !== null && (wl(a, l, t), wu(a, l, t));
  }
  function ny(l, t) {
    if (l = l.memoizedState, l !== null && l.dehydrated !== null) {
      var a = l.retryLane;
      l.retryLane = a !== 0 && a < t ? a : t;
    }
  }
  function li(l, t) {
    ny(l, t), (l = l.alternate) && ny(l, t);
  }
  function fy(l) {
    if (l.tag === 13 || l.tag === 31) {
      var t = Da(l, 67108864);
      t !== null && wl(t, l, 67108864), li(l, 67108864);
    }
  }
  function cy(l) {
    if (l.tag === 13 || l.tag === 31) {
      var t = nt();
      t = Wn(t);
      var a = Da(l, t);
      a !== null && wl(a, l, t), li(l, t);
    }
  }
  var xn = !0;
  function J1(l, t, a, u) {
    var e = b.T;
    b.T = null;
    var n = _.p;
    try {
      _.p = 2, ti(l, t, a, u);
    } finally {
      _.p = n, b.T = e;
    }
  }
  function w1(l, t, a, u) {
    var e = b.T;
    b.T = null;
    var n = _.p;
    try {
      _.p = 8, ti(l, t, a, u);
    } finally {
      _.p = n, b.T = e;
    }
  }
  function ti(l, t, a, u) {
    if (xn) {
      var e = ai(u);
      if (e === null)
        Qc(
          l,
          t,
          u,
          Cn,
          a
        ), sy(l, u);
      else if ($1(
        e,
        l,
        t,
        a,
        u
      ))
        u.stopPropagation();
      else if (sy(l, u), t & 4 && -1 < W1.indexOf(l)) {
        for (; e !== null; ) {
          var n = La(e);
          if (n !== null)
            switch (n.tag) {
              case 3:
                if (n = n.stateNode, n.current.memoizedState.isDehydrated) {
                  var f = Aa(n.pendingLanes);
                  if (f !== 0) {
                    var c = n;
                    for (c.pendingLanes |= 2, c.entangledLanes |= 2; f; ) {
                      var i = 1 << 31 - Il(f);
                      c.entanglements[1] |= i, f &= ~i;
                    }
                    pt(n), (P & 6) === 0 && (gn = kl() + 500, se(0));
                  }
                }
                break;
              case 31:
              case 13:
                c = Da(n, 2), c !== null && wl(c, n, 2), bn(), li(n, 2);
            }
          if (n = ai(u), n === null && Qc(
            l,
            t,
            u,
            Cn,
            a
          ), n === e) break;
          e = n;
        }
        e !== null && u.stopPropagation();
      } else
        Qc(
          l,
          t,
          u,
          null,
          a
        );
    }
  }
  function ai(l) {
    return l = uf(l), ui(l);
  }
  var Cn = null;
  function ui(l) {
    if (Cn = null, l = Va(l), l !== null) {
      var t = Z(l);
      if (t === null) l = null;
      else {
        var a = t.tag;
        if (a === 13) {
          if (l = ol(t), l !== null) return l;
          l = null;
        } else if (a === 31) {
          if (l = _l(t), l !== null) return l;
          l = null;
        } else if (a === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          l = null;
        } else t !== l && (l = null);
      }
    }
    return Cn = l, null;
  }
  function iy(l) {
    switch (l) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (xy()) {
          case gi:
            return 2;
          case Si:
            return 8;
          case Te:
          case Cy:
            return 32;
          case bi:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var ei = !1, ga = null, Sa = null, ba = null, ge = /* @__PURE__ */ new Map(), Se = /* @__PURE__ */ new Map(), ra = [], W1 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(
    " "
  );
  function sy(l, t) {
    switch (l) {
      case "focusin":
      case "focusout":
        ga = null;
        break;
      case "dragenter":
      case "dragleave":
        Sa = null;
        break;
      case "mouseover":
      case "mouseout":
        ba = null;
        break;
      case "pointerover":
      case "pointerout":
        ge.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Se.delete(t.pointerId);
    }
  }
  function be(l, t, a, u, e, n) {
    return l === null || l.nativeEvent !== n ? (l = {
      blockedOn: t,
      domEventName: a,
      eventSystemFlags: u,
      nativeEvent: n,
      targetContainers: [e]
    }, t !== null && (t = La(t), t !== null && fy(t)), l) : (l.eventSystemFlags |= u, t = l.targetContainers, e !== null && t.indexOf(e) === -1 && t.push(e), l);
  }
  function $1(l, t, a, u, e) {
    switch (t) {
      case "focusin":
        return ga = be(
          ga,
          l,
          t,
          a,
          u,
          e
        ), !0;
      case "dragenter":
        return Sa = be(
          Sa,
          l,
          t,
          a,
          u,
          e
        ), !0;
      case "mouseover":
        return ba = be(
          ba,
          l,
          t,
          a,
          u,
          e
        ), !0;
      case "pointerover":
        var n = e.pointerId;
        return ge.set(
          n,
          be(
            ge.get(n) || null,
            l,
            t,
            a,
            u,
            e
          )
        ), !0;
      case "gotpointercapture":
        return n = e.pointerId, Se.set(
          n,
          be(
            Se.get(n) || null,
            l,
            t,
            a,
            u,
            e
          )
        ), !0;
    }
    return !1;
  }
  function dy(l) {
    var t = Va(l.target);
    if (t !== null) {
      var a = Z(t);
      if (a !== null) {
        if (t = a.tag, t === 13) {
          if (t = ol(a), t !== null) {
            l.blockedOn = t, _i(l.priority, function() {
              cy(a);
            });
            return;
          }
        } else if (t === 31) {
          if (t = _l(a), t !== null) {
            l.blockedOn = t, _i(l.priority, function() {
              cy(a);
            });
            return;
          }
        } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
          l.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
          return;
        }
      }
    }
    l.blockedOn = null;
  }
  function qn(l) {
    if (l.blockedOn !== null) return !1;
    for (var t = l.targetContainers; 0 < t.length; ) {
      var a = ai(l.nativeEvent);
      if (a === null) {
        a = l.nativeEvent;
        var u = new a.constructor(
          a.type,
          a
        );
        af = u, a.target.dispatchEvent(u), af = null;
      } else
        return t = La(a), t !== null && fy(t), l.blockedOn = a, !1;
      t.shift();
    }
    return !0;
  }
  function yy(l, t, a) {
    qn(l) && a.delete(t);
  }
  function k1() {
    ei = !1, ga !== null && qn(ga) && (ga = null), Sa !== null && qn(Sa) && (Sa = null), ba !== null && qn(ba) && (ba = null), ge.forEach(yy), Se.forEach(yy);
  }
  function Bn(l, t) {
    l.blockedOn === t && (l.blockedOn = null, ei || (ei = !0, A.unstable_scheduleCallback(
      A.unstable_NormalPriority,
      k1
    )));
  }
  var jn = null;
  function vy(l) {
    jn !== l && (jn = l, A.unstable_scheduleCallback(
      A.unstable_NormalPriority,
      function() {
        jn === l && (jn = null);
        for (var t = 0; t < l.length; t += 3) {
          var a = l[t], u = l[t + 1], e = l[t + 2];
          if (typeof u != "function") {
            if (ui(u || a) === null)
              continue;
            break;
          }
          var n = La(a);
          n !== null && (l.splice(t, 3), t -= 3, ac(
            n,
            {
              pending: !0,
              data: e,
              method: a.method,
              action: u
            },
            u,
            e
          ));
        }
      }
    ));
  }
  function Mu(l) {
    function t(i) {
      return Bn(i, l);
    }
    ga !== null && Bn(ga, l), Sa !== null && Bn(Sa, l), ba !== null && Bn(ba, l), ge.forEach(t), Se.forEach(t);
    for (var a = 0; a < ra.length; a++) {
      var u = ra[a];
      u.blockedOn === l && (u.blockedOn = null);
    }
    for (; 0 < ra.length && (a = ra[0], a.blockedOn === null); )
      dy(a), a.blockedOn === null && ra.shift();
    if (a = (l.ownerDocument || l).$$reactFormReplay, a != null)
      for (u = 0; u < a.length; u += 3) {
        var e = a[u], n = a[u + 1], f = e[Ql] || null;
        if (typeof n == "function")
          f || vy(a);
        else if (f) {
          var c = null;
          if (n && n.hasAttribute("formAction")) {
            if (e = n, f = n[Ql] || null)
              c = f.formAction;
            else if (ui(e) !== null) continue;
          } else c = f.action;
          typeof c == "function" ? a[u + 1] = c : (a.splice(u, 3), u -= 3), vy(a);
        }
      }
  }
  function my() {
    function l(n) {
      n.canIntercept && n.info === "react-transition" && n.intercept({
        handler: function() {
          return new Promise(function(f) {
            return e = f;
          });
        },
        focusReset: "manual",
        scroll: "manual"
      });
    }
    function t() {
      e !== null && (e(), e = null), u || setTimeout(a, 20);
    }
    function a() {
      if (!u && !navigation.transition) {
        var n = navigation.currentEntry;
        n && n.url != null && navigation.navigate(n.url, {
          state: n.getState(),
          info: "react-transition",
          history: "replace"
        });
      }
    }
    if (typeof navigation == "object") {
      var u = !1, e = null;
      return navigation.addEventListener("navigate", l), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(a, 100), function() {
        u = !0, navigation.removeEventListener("navigate", l), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), e !== null && (e(), e = null);
      };
    }
  }
  function ni(l) {
    this._internalRoot = l;
  }
  Yn.prototype.render = ni.prototype.render = function(l) {
    var t = this._internalRoot;
    if (t === null) throw Error(o(409));
    var a = t.current, u = nt();
    ey(a, u, l, t, null, null);
  }, Yn.prototype.unmount = ni.prototype.unmount = function() {
    var l = this._internalRoot;
    if (l !== null) {
      this._internalRoot = null;
      var t = l.containerInfo;
      ey(l.current, 2, null, l, null, null), bn(), t[Za] = null;
    }
  };
  function Yn(l) {
    this._internalRoot = l;
  }
  Yn.prototype.unstable_scheduleHydration = function(l) {
    if (l) {
      var t = Ai();
      l = { blockedOn: null, target: l, priority: t };
      for (var a = 0; a < ra.length && t !== 0 && t < ra[a].priority; a++) ;
      ra.splice(a, 0, l), a === 0 && dy(l);
    }
  };
  var hy = G.version;
  if (hy !== "19.2.5")
    throw Error(
      o(
        527,
        hy,
        "19.2.5"
      )
    );
  _.findDOMNode = function(l) {
    var t = l._reactInternals;
    if (t === void 0)
      throw typeof l.render == "function" ? Error(o(188)) : (l = Object.keys(l).join(","), Error(o(268, l)));
    return l = T(t), l = l !== null ? k(l) : null, l = l === null ? null : l.stateNode, l;
  };
  var F1 = {
    bundleType: 0,
    version: "19.2.5",
    rendererPackageName: "react-dom",
    currentDispatcherRef: b,
    reconcilerVersion: "19.2.5"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Gn = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Gn.isDisabled && Gn.supportsFiber)
      try {
        pu = Gn.inject(
          F1
        ), Fl = Gn;
      } catch {
      }
  }
  return ze.createRoot = function(l, t) {
    if (!C(l)) throw Error(o(299));
    var a = !1, u = "", e = Es, n = Ts, f = As;
    return t != null && (t.unstable_strictMode === !0 && (a = !0), t.identifierPrefix !== void 0 && (u = t.identifierPrefix), t.onUncaughtError !== void 0 && (e = t.onUncaughtError), t.onCaughtError !== void 0 && (n = t.onCaughtError), t.onRecoverableError !== void 0 && (f = t.onRecoverableError)), t = ay(
      l,
      1,
      !1,
      null,
      null,
      a,
      u,
      null,
      e,
      n,
      f,
      my
    ), l[Za] = t.current, Xc(l), new ni(t);
  }, ze.hydrateRoot = function(l, t, a) {
    if (!C(l)) throw Error(o(299));
    var u = !1, e = "", n = Es, f = Ts, c = As, i = null;
    return a != null && (a.unstable_strictMode === !0 && (u = !0), a.identifierPrefix !== void 0 && (e = a.identifierPrefix), a.onUncaughtError !== void 0 && (n = a.onUncaughtError), a.onCaughtError !== void 0 && (f = a.onCaughtError), a.onRecoverableError !== void 0 && (c = a.onRecoverableError), a.formState !== void 0 && (i = a.formState)), t = ay(
      l,
      1,
      !0,
      t,
      a ?? null,
      u,
      e,
      i,
      n,
      f,
      c,
      my
    ), t.context = uy(null), a = t.current, u = nt(), u = Wn(u), e = ea(u), e.callback = null, na(a, e, u), a = u, t.current.lanes = a, Uu(t, a), pt(t), l[Za] = t.current, Xc(l), new Yn(t);
  }, ze.version = "19.2.5", ze;
}
var _y;
function im() {
  if (_y) return ii.exports;
  _y = 1;
  function A() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A);
      } catch (G) {
        console.error(G);
      }
  }
  return A(), ii.exports = cm(), ii.exports;
}
var sm = im();
const dm = (A) => A.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), ym = (A) => A.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (G, Q, o) => o ? o.toUpperCase() : Q.toLowerCase()
), My = (A) => {
  const G = ym(A);
  return G.charAt(0).toUpperCase() + G.slice(1);
}, Uy = (...A) => A.filter((G, Q, o) => !!G && G.trim() !== "" && o.indexOf(G) === Q).join(" ").trim(), vm = (A) => {
  for (const G in A)
    if (G.startsWith("aria-") || G === "role" || G === "title")
      return !0;
};
var mm = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const hm = Wt.forwardRef(
  ({
    color: A = "currentColor",
    size: G = 24,
    strokeWidth: Q = 2,
    absoluteStrokeWidth: o,
    className: C = "",
    children: Z,
    iconNode: ol,
    ..._l
  }, U) => Wt.createElement(
    "svg",
    {
      ref: U,
      ...mm,
      width: G,
      height: G,
      stroke: A,
      strokeWidth: o ? Number(Q) * 24 / Number(G) : Q,
      className: Uy("lucide", C),
      ...!Z && !vm(_l) && { "aria-hidden": "true" },
      ..._l
    },
    [
      ...ol.map(([T, k]) => Wt.createElement(T, k)),
      ...Array.isArray(Z) ? Z : [Z]
    ]
  )
);
const Xn = (A, G) => {
  const Q = Wt.forwardRef(
    ({ className: o, ...C }, Z) => Wt.createElement(hm, {
      ref: Z,
      iconNode: G,
      className: Uy(
        `lucide-${dm(My(A))}`,
        `lucide-${A}`,
        o
      ),
      ...C
    })
  );
  return Q.displayName = My(A), Q;
};
const om = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]], Oy = Xn("check", om);
const gm = [
  ["path", { d: "M21.54 15H17a2 2 0 0 0-2 2v4.54", key: "1djwo0" }],
  [
    "path",
    {
      d: "M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",
      key: "1tzkfa"
    }
  ],
  ["path", { d: "M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05", key: "14pb5j" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
], Sm = Xn("earth", gm);
const bm = [
  ["path", { d: "M10 8h.01", key: "1r9ogq" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M14 8h.01", key: "1primd" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }],
  ["path", { d: "M18 8h.01", key: "emo2bl" }],
  ["path", { d: "M6 8h.01", key: "x9i8wu" }],
  ["path", { d: "M7 16h10", key: "wp8him" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }]
], rm = Xn("keyboard", bm);
const zm = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ],
  ["path", { d: "M20 2v4", key: "1rf3ol" }],
  ["path", { d: "M22 4h-4", key: "gwowj6" }],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
], Em = Xn("sparkles", zm), vi = P1(
  void 0,
  void 0,
  "",
  ""
), py = [
  {
    value: "alt_option",
    label: "Alt / Option",
    description: "Windows: Alt | Mac: Option",
    keyHint: "⌥"
  },
  {
    value: "cmd_ctrl",
    label: "Cmd / Ctrl",
    description: "Windows: Ctrl | Mac: Cmd",
    keyHint: "⌘"
  }
];
function Tm() {
  const [A, G] = Wt.useState({
    modifier: "alt_option",
    apiBaseUrl: vi,
    saved: !1
  }), Q = Wt.useMemo(
    () => py.find((C) => C.value === A.modifier),
    [A.modifier]
  );
  Wt.useEffect(() => {
    chrome.storage.sync.get(["flow_reader_modifier", "flow_reader_api_base_url"]).then((C) => {
      G((Z) => ({
        ...Z,
        modifier: C.flow_reader_modifier || "alt_option",
        apiBaseUrl: C.flow_reader_api_base_url || vi
      }));
    });
  }, []), Wt.useEffect(() => {
    if (!A.saved)
      return;
    const C = window.setTimeout(() => {
      G((Z) => ({ ...Z, saved: !1 }));
    }, 1800);
    return () => window.clearTimeout(C);
  }, [A.saved]);
  const o = async () => {
    await chrome.storage.sync.set({
      flow_reader_modifier: A.modifier,
      flow_reader_api_base_url: A.apiBaseUrl.trim()
    }), G((C) => ({ ...C, saved: !0 }));
  };
  return /* @__PURE__ */ B.jsx("div", { className: "min-h-screen bg-transparent px-4 py-10 text-slate-900", children: /* @__PURE__ */ B.jsxs("div", { className: "mx-auto max-w-3xl", children: [
    /* @__PURE__ */ B.jsxs("header", { className: "mb-6 rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)] backdrop-blur", children: [
      /* @__PURE__ */ B.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ B.jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-950 text-white shadow-lg shadow-slate-950/15", children: /* @__PURE__ */ B.jsx(Em, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ B.jsxs("div", { children: [
          /* @__PURE__ */ B.jsx("p", { className: "text-xs font-bold uppercase tracking-[0.28em] text-indigo-600", children: "AI English Study" }),
          /* @__PURE__ */ B.jsx("h1", { className: "text-2xl font-black tracking-tight", children: "설정" })
        ] })
      ] }),
      /* @__PURE__ */ B.jsx("p", { className: "mt-3 max-w-2xl text-sm leading-6 text-slate-600", children: "단축키와 서버 주소를 저장하면 확장앱이 바로 동작합니다. 저장 후 열려 있는 탭에도 설정이 자동 반영됩니다." })
    ] }),
    /* @__PURE__ */ B.jsxs("section", { className: "space-y-4 rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)] backdrop-blur", children: [
      /* @__PURE__ */ B.jsxs("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ B.jsx("div", { className: "flex h-10 w-10 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100", children: /* @__PURE__ */ B.jsx(rm, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ B.jsxs("div", { children: [
          /* @__PURE__ */ B.jsx("h2", { className: "text-lg font-bold text-slate-950", children: "단어 조회 단축키" }),
          /* @__PURE__ */ B.jsx("p", { className: "text-sm text-slate-600", children: "이 키를 누른 상태에서 단어 위에 마우스를 올리면 뜻이 표시됩니다." })
        ] })
      ] }),
      /* @__PURE__ */ B.jsx("div", { className: "grid gap-3 sm:grid-cols-2", children: py.map((C) => {
        const Z = A.modifier === C.value;
        return /* @__PURE__ */ B.jsxs(
          "label",
          {
            className: `flex cursor-pointer items-center gap-4 rounded-3xl border p-4 transition ${Z ? "border-indigo-300 bg-indigo-50/80 shadow-sm" : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"}`,
            children: [
              /* @__PURE__ */ B.jsx(
                "input",
                {
                  type: "radio",
                  name: "modifier",
                  value: C.value,
                  checked: Z,
                  onChange: () => G((ol) => ({ ...ol, modifier: C.value })),
                  className: "sr-only"
                }
              ),
              /* @__PURE__ */ B.jsx(
                "div",
                {
                  className: `flex h-11 w-11 items-center justify-center rounded-2xl text-lg font-black ${Z ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600"}`,
                  children: C.keyHint
                }
              ),
              /* @__PURE__ */ B.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ B.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ B.jsx("span", { className: "font-bold text-slate-950", children: C.label }),
                  Z ? /* @__PURE__ */ B.jsx(Oy, { className: "h-4 w-4 text-indigo-600" }) : null
                ] }),
                /* @__PURE__ */ B.jsx("p", { className: "text-sm text-slate-500", children: C.description })
              ] })
            ]
          },
          C.value
        );
      }) })
    ] }),
    /* @__PURE__ */ B.jsxs("section", { className: "mt-4 rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)] backdrop-blur", children: [
      /* @__PURE__ */ B.jsxs("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ B.jsx("div", { className: "flex h-10 w-10 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100", children: /* @__PURE__ */ B.jsx(Sm, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ B.jsxs("div", { children: [
          /* @__PURE__ */ B.jsx("h2", { className: "text-lg font-bold text-slate-950", children: "서버 주소" }),
          /* @__PURE__ */ B.jsx("p", { className: "text-sm text-slate-600", children: "AI English Study 서버의 주소를 입력하세요." })
        ] })
      ] }),
      /* @__PURE__ */ B.jsxs("div", { className: "mt-4", children: [
        /* @__PURE__ */ B.jsxs("label", { className: "space-y-2", children: [
          /* @__PURE__ */ B.jsx("span", { className: "text-xs font-bold uppercase tracking-[0.24em] text-slate-400", children: "API Base URL" }),
          /* @__PURE__ */ B.jsx(
            "input",
            {
              type: "url",
              value: A.apiBaseUrl,
              onChange: (C) => G((Z) => ({ ...Z, apiBaseUrl: C.target.value })),
              placeholder: "http://localhost:3000",
              className: "h-12 w-full rounded-2xl border border-slate-200 bg-white px-4 font-mono text-sm outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:ring-4 focus:ring-indigo-100"
            }
          )
        ] }),
        /* @__PURE__ */ B.jsxs("p", { className: "mt-2 text-xs text-slate-500", children: [
          "기본값: ",
          vi
        ] })
      ] })
    ] }),
    /* @__PURE__ */ B.jsxs(
      "button",
      {
        onClick: o,
        className: `mt-6 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full px-5 text-sm font-bold text-white shadow-lg transition ${A.saved ? "bg-emerald-500 shadow-emerald-500/30" : "bg-gradient-to-r from-indigo-600 via-violet-600 to-sky-600 shadow-indigo-500/25 hover:brightness-105"}`,
        children: [
          A.saved ? /* @__PURE__ */ B.jsx(Oy, { className: "h-4 w-4" }) : null,
          A.saved ? "저장되었습니다" : "설정 저장"
        ]
      }
    ),
    /* @__PURE__ */ B.jsxs("div", { className: "mt-4 rounded-3xl border border-indigo-100 bg-indigo-50/70 p-4 text-sm text-indigo-900", children: [
      /* @__PURE__ */ B.jsx("strong", { children: "사용법:" }),
      " 영어 웹페이지에서 선택한 키를 누른 채로 모르는 단어 위에 마우스를 0.2초 올려두면 뜻이 팝업으로 표시됩니다.",
      Q ? /* @__PURE__ */ B.jsxs("div", { className: "mt-2 text-xs text-indigo-700", children: [
        "현재 선택: ",
        Q.label
      ] }) : null
    ] })
  ] }) });
}
const Dy = document.getElementById("root");
Dy && sm.createRoot(Dy).render(/* @__PURE__ */ B.jsx(Tm, {}));
export {
  Tm as default
};
