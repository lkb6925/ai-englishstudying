import { a as et } from "./app-config-DuchQk2N.js";
var ye = { exports: {} }, le = {};
var Ue;
function tt() {
  if (Ue) return le;
  Ue = 1;
  var d = /* @__PURE__ */ Symbol.for("react.transitional.element"), s = /* @__PURE__ */ Symbol.for("react.fragment");
  function k(j, m, y) {
    var C = null;
    if (y !== void 0 && (C = "" + y), m.key !== void 0 && (C = "" + m.key), "key" in m) {
      y = {};
      for (var x in m)
        x !== "key" && (y[x] = m[x]);
    } else y = m;
    return m = y.ref, {
      $$typeof: d,
      type: j,
      key: C,
      ref: m !== void 0 ? m : null,
      props: y
    };
  }
  return le.Fragment = s, le.jsx = k, le.jsxs = k, le;
}
var fe = {}, ve = { exports: {} }, f = {};
var De;
function rt() {
  if (De) return f;
  De = 1;
  var d = /* @__PURE__ */ Symbol.for("react.transitional.element"), s = /* @__PURE__ */ Symbol.for("react.portal"), k = /* @__PURE__ */ Symbol.for("react.fragment"), j = /* @__PURE__ */ Symbol.for("react.strict_mode"), m = /* @__PURE__ */ Symbol.for("react.profiler"), y = /* @__PURE__ */ Symbol.for("react.consumer"), C = /* @__PURE__ */ Symbol.for("react.context"), x = /* @__PURE__ */ Symbol.for("react.forward_ref"), H = /* @__PURE__ */ Symbol.for("react.suspense"), G = /* @__PURE__ */ Symbol.for("react.memo"), P = /* @__PURE__ */ Symbol.for("react.lazy"), W = /* @__PURE__ */ Symbol.for("react.activity"), F = Symbol.iterator;
  function q(t) {
    return t === null || typeof t != "object" ? null : (t = F && t[F] || t["@@iterator"], typeof t == "function" ? t : null);
  }
  var Q = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, re = Object.assign, K = {};
  function U(t, n, u) {
    this.props = t, this.context = n, this.refs = K, this.updater = u || Q;
  }
  U.prototype.isReactComponent = {}, U.prototype.setState = function(t, n) {
    if (typeof t != "object" && typeof t != "function" && t != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, t, n, "setState");
  }, U.prototype.forceUpdate = function(t) {
    this.updater.enqueueForceUpdate(this, t, "forceUpdate");
  };
  function X() {
  }
  X.prototype = U.prototype;
  function ne(t, n, u) {
    this.props = t, this.context = n, this.refs = K, this.updater = u || Q;
  }
  var V = ne.prototype = new X();
  V.constructor = ne, re(V, U.prototype), V.isPureReactComponent = !0;
  var L = Array.isArray;
  function oe() {
  }
  var b = { H: null, A: null, T: null, S: null }, ue = Object.prototype.hasOwnProperty;
  function S(t, n, u) {
    var i = u.ref;
    return {
      $$typeof: d,
      type: t,
      key: n,
      ref: i !== void 0 ? i : null,
      props: u
    };
  }
  function Z(t, n) {
    return S(t.type, n, t.props);
  }
  function se(t) {
    return typeof t == "object" && t !== null && t.$$typeof === d;
  }
  function R(t) {
    var n = { "=": "=0", ":": "=2" };
    return "$" + t.replace(/[=:]/g, function(u) {
      return n[u];
    });
  }
  var J = /\/+/g;
  function D(t, n) {
    return typeof t == "object" && t !== null && t.key != null ? R("" + t.key) : n.toString(36);
  }
  function Y(t) {
    switch (t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw t.reason;
      default:
        switch (typeof t.status == "string" ? t.then(oe, oe) : (t.status = "pending", t.then(
          function(n) {
            t.status === "pending" && (t.status = "fulfilled", t.value = n);
          },
          function(n) {
            t.status === "pending" && (t.status = "rejected", t.reason = n);
          }
        )), t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw t.reason;
        }
    }
    throw t;
  }
  function N(t, n, u, i, _) {
    var w = typeof t;
    (w === "undefined" || w === "boolean") && (t = null);
    var l = !1;
    if (t === null) l = !0;
    else
      switch (w) {
        case "bigint":
        case "string":
        case "number":
          l = !0;
          break;
        case "object":
          switch (t.$$typeof) {
            case d:
            case s:
              l = !0;
              break;
            case P:
              return l = t._init, N(
                l(t._payload),
                n,
                u,
                i,
                _
              );
          }
      }
    if (l)
      return _ = _(t), l = i === "" ? "." + D(t, 0) : i, L(_) ? (u = "", l != null && (u = l.replace(J, "$&/") + "/"), N(_, n, u, "", function(z) {
        return z;
      })) : _ != null && (se(_) && (_ = Z(
        _,
        u + (_.key == null || t && t.key === _.key ? "" : ("" + _.key).replace(
          J,
          "$&/"
        ) + "/") + l
      )), n.push(_)), 1;
    l = 0;
    var A = i === "" ? "." : i + ":";
    if (L(t))
      for (var O = 0; O < t.length; O++)
        i = t[O], w = A + D(i, O), l += N(
          i,
          n,
          u,
          w,
          _
        );
    else if (O = q(t), typeof O == "function")
      for (t = O.call(t), O = 0; !(i = t.next()).done; )
        i = i.value, w = A + D(i, O++), l += N(
          i,
          n,
          u,
          w,
          _
        );
    else if (w === "object") {
      if (typeof t.then == "function")
        return N(
          Y(t),
          n,
          u,
          i,
          _
        );
      throw n = String(t), Error(
        "Objects are not valid as a React child (found: " + (n === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : n) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return l;
  }
  function I(t, n, u) {
    if (t == null) return t;
    var i = [], _ = 0;
    return N(t, i, "", "", function(w) {
      return n.call(u, w, _++);
    }), i;
  }
  function ee(t) {
    if (t._status === -1) {
      var n = t._result;
      n = n(), n.then(
        function(u) {
          (t._status === 0 || t._status === -1) && (t._status = 1, t._result = u);
        },
        function(u) {
          (t._status === 0 || t._status === -1) && (t._status = 2, t._result = u);
        }
      ), t._status === -1 && (t._status = 0, t._result = n);
    }
    if (t._status === 1) return t._result.default;
    throw t._result;
  }
  var $ = typeof reportError == "function" ? reportError : function(t) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var n = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
        error: t
      });
      if (!window.dispatchEvent(n)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", t);
      return;
    }
    console.error(t);
  }, ae = {
    map: I,
    forEach: function(t, n, u) {
      I(
        t,
        function() {
          n.apply(this, arguments);
        },
        u
      );
    },
    count: function(t) {
      var n = 0;
      return I(t, function() {
        n++;
      }), n;
    },
    toArray: function(t) {
      return I(t, function(n) {
        return n;
      }) || [];
    },
    only: function(t) {
      if (!se(t))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return t;
    }
  };
  return f.Activity = W, f.Children = ae, f.Component = U, f.Fragment = k, f.Profiler = m, f.PureComponent = ne, f.StrictMode = j, f.Suspense = H, f.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = b, f.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(t) {
      return b.H.useMemoCache(t);
    }
  }, f.cache = function(t) {
    return function() {
      return t.apply(null, arguments);
    };
  }, f.cacheSignal = function() {
    return null;
  }, f.cloneElement = function(t, n, u) {
    if (t == null)
      throw Error(
        "The argument must be a React element, but you passed " + t + "."
      );
    var i = re({}, t.props), _ = t.key;
    if (n != null)
      for (w in n.key !== void 0 && (_ = "" + n.key), n)
        !ue.call(n, w) || w === "key" || w === "__self" || w === "__source" || w === "ref" && n.ref === void 0 || (i[w] = n[w]);
    var w = arguments.length - 2;
    if (w === 1) i.children = u;
    else if (1 < w) {
      for (var l = Array(w), A = 0; A < w; A++)
        l[A] = arguments[A + 2];
      i.children = l;
    }
    return S(t.type, _, i);
  }, f.createContext = function(t) {
    return t = {
      $$typeof: C,
      _currentValue: t,
      _currentValue2: t,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, t.Provider = t, t.Consumer = {
      $$typeof: y,
      _context: t
    }, t;
  }, f.createElement = function(t, n, u) {
    var i, _ = {}, w = null;
    if (n != null)
      for (i in n.key !== void 0 && (w = "" + n.key), n)
        ue.call(n, i) && i !== "key" && i !== "__self" && i !== "__source" && (_[i] = n[i]);
    var l = arguments.length - 2;
    if (l === 1) _.children = u;
    else if (1 < l) {
      for (var A = Array(l), O = 0; O < l; O++)
        A[O] = arguments[O + 2];
      _.children = A;
    }
    if (t && t.defaultProps)
      for (i in l = t.defaultProps, l)
        _[i] === void 0 && (_[i] = l[i]);
    return S(t, w, _);
  }, f.createRef = function() {
    return { current: null };
  }, f.forwardRef = function(t) {
    return { $$typeof: x, render: t };
  }, f.isValidElement = se, f.lazy = function(t) {
    return {
      $$typeof: P,
      _payload: { _status: -1, _result: t },
      _init: ee
    };
  }, f.memo = function(t, n) {
    return {
      $$typeof: G,
      type: t,
      compare: n === void 0 ? null : n
    };
  }, f.startTransition = function(t) {
    var n = b.T, u = {};
    b.T = u;
    try {
      var i = t(), _ = b.S;
      _ !== null && _(u, i), typeof i == "object" && i !== null && typeof i.then == "function" && i.then(oe, $);
    } catch (w) {
      $(w);
    } finally {
      n !== null && u.types !== null && (n.types = u.types), b.T = n;
    }
  }, f.unstable_useCacheRefresh = function() {
    return b.H.useCacheRefresh();
  }, f.use = function(t) {
    return b.H.use(t);
  }, f.useActionState = function(t, n, u) {
    return b.H.useActionState(t, n, u);
  }, f.useCallback = function(t, n) {
    return b.H.useCallback(t, n);
  }, f.useContext = function(t) {
    return b.H.useContext(t);
  }, f.useDebugValue = function() {
  }, f.useDeferredValue = function(t, n) {
    return b.H.useDeferredValue(t, n);
  }, f.useEffect = function(t, n) {
    return b.H.useEffect(t, n);
  }, f.useEffectEvent = function(t) {
    return b.H.useEffectEvent(t);
  }, f.useId = function() {
    return b.H.useId();
  }, f.useImperativeHandle = function(t, n, u) {
    return b.H.useImperativeHandle(t, n, u);
  }, f.useInsertionEffect = function(t, n) {
    return b.H.useInsertionEffect(t, n);
  }, f.useLayoutEffect = function(t, n) {
    return b.H.useLayoutEffect(t, n);
  }, f.useMemo = function(t, n) {
    return b.H.useMemo(t, n);
  }, f.useOptimistic = function(t, n) {
    return b.H.useOptimistic(t, n);
  }, f.useReducer = function(t, n, u) {
    return b.H.useReducer(t, n, u);
  }, f.useRef = function(t) {
    return b.H.useRef(t);
  }, f.useState = function(t) {
    return b.H.useState(t);
  }, f.useSyncExternalStore = function(t, n, u) {
    return b.H.useSyncExternalStore(
      t,
      n,
      u
    );
  }, f.useTransition = function() {
    return b.H.useTransition();
  }, f.version = "19.2.5", f;
}
var de = { exports: {} };
de.exports;
var He;
function nt() {
  return He || (He = 1, (function(d, s) {
    process.env.NODE_ENV !== "production" && (function() {
      function k(e, r) {
        Object.defineProperty(y.prototype, e, {
          get: function() {
            console.warn(
              "%s(...) is deprecated in plain JavaScript React classes. %s",
              r[0],
              r[1]
            );
          }
        });
      }
      function j(e) {
        return e === null || typeof e != "object" ? null : (e = Te && e[Te] || e["@@iterator"], typeof e == "function" ? e : null);
      }
      function m(e, r) {
        e = (e = e.constructor) && (e.displayName || e.name) || "ReactClass";
        var o = e + "." + r;
        ke[o] || (console.error(
          "Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.",
          r,
          e
        ), ke[o] = !0);
      }
      function y(e, r, o) {
        this.props = e, this.context = r, this.refs = Ee, this.updater = o || Oe;
      }
      function C() {
      }
      function x(e, r, o) {
        this.props = e, this.context = r, this.refs = Ee, this.updater = o || Oe;
      }
      function H() {
      }
      function G(e) {
        return "" + e;
      }
      function P(e) {
        try {
          G(e);
          var r = !1;
        } catch {
          r = !0;
        }
        if (r) {
          r = console;
          var o = r.error, a = typeof Symbol == "function" && Symbol.toStringTag && e[Symbol.toStringTag] || e.constructor.name || "Object";
          return o.call(
            r,
            "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",
            a
          ), G(e);
        }
      }
      function W(e) {
        if (e == null) return null;
        if (typeof e == "function")
          return e.$$typeof === Ke ? null : e.displayName || e.name || null;
        if (typeof e == "string") return e;
        switch (e) {
          case t:
            return "Fragment";
          case u:
            return "Profiler";
          case n:
            return "StrictMode";
          case l:
            return "Suspense";
          case A:
            return "SuspenseList";
          case Re:
            return "Activity";
        }
        if (typeof e == "object")
          switch (typeof e.tag == "number" && console.error(
            "Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."
          ), e.$$typeof) {
            case ae:
              return "Portal";
            case _:
              return e.displayName || "Context";
            case i:
              return (e._context.displayName || "Context") + ".Consumer";
            case w:
              var r = e.render;
              return e = e.displayName, e || (e = r.displayName || r.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
            case O:
              return r = e.displayName || null, r !== null ? r : W(e.type) || "Memo";
            case z:
              r = e._payload, e = e._init;
              try {
                return W(e(r));
              } catch {
              }
          }
        return null;
      }
      function F(e) {
        if (e === t) return "<>";
        if (typeof e == "object" && e !== null && e.$$typeof === z)
          return "<...>";
        try {
          var r = W(e);
          return r ? "<" + r + ">" : "<...>";
        } catch {
          return "<...>";
        }
      }
      function q() {
        var e = v.A;
        return e === null ? null : e.getOwner();
      }
      function Q() {
        return Error("react-stack-top-frame");
      }
      function re(e) {
        if (pe.call(e, "key")) {
          var r = Object.getOwnPropertyDescriptor(e, "key").get;
          if (r && r.isReactWarning) return !1;
        }
        return e.key !== void 0;
      }
      function K(e, r) {
        function o() {
          xe || (xe = !0, console.error(
            "%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",
            r
          ));
        }
        o.isReactWarning = !0, Object.defineProperty(e, "key", {
          get: o,
          configurable: !0
        });
      }
      function U() {
        var e = W(this.type);
        return Ne[e] || (Ne[e] = !0, console.error(
          "Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."
        )), e = this.props.ref, e !== void 0 ? e : null;
      }
      function X(e, r, o, a, c, g) {
        var h = o.ref;
        return e = {
          $$typeof: $,
          type: e,
          key: r,
          props: o,
          _owner: a
        }, (h !== void 0 ? h : null) !== null ? Object.defineProperty(e, "ref", {
          enumerable: !1,
          get: U
        }) : Object.defineProperty(e, "ref", { enumerable: !1, value: null }), e._store = {}, Object.defineProperty(e._store, "validated", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: 0
        }), Object.defineProperty(e, "_debugInfo", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: null
        }), Object.defineProperty(e, "_debugStack", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: c
        }), Object.defineProperty(e, "_debugTask", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: g
        }), Object.freeze && (Object.freeze(e.props), Object.freeze(e)), e;
      }
      function ne(e, r) {
        return r = X(
          e.type,
          r,
          e.props,
          e._owner,
          e._debugStack,
          e._debugTask
        ), e._store && (r._store.validated = e._store.validated), r;
      }
      function V(e) {
        L(e) ? e._store && (e._store.validated = 1) : typeof e == "object" && e !== null && e.$$typeof === z && (e._payload.status === "fulfilled" ? L(e._payload.value) && e._payload.value._store && (e._payload.value._store.validated = 1) : e._store && (e._store.validated = 1));
      }
      function L(e) {
        return typeof e == "object" && e !== null && e.$$typeof === $;
      }
      function oe(e) {
        var r = { "=": "=0", ":": "=2" };
        return "$" + e.replace(/[=:]/g, function(o) {
          return r[o];
        });
      }
      function b(e, r) {
        return typeof e == "object" && e !== null && e.key != null ? (P(e.key), oe("" + e.key)) : r.toString(36);
      }
      function ue(e) {
        switch (e.status) {
          case "fulfilled":
            return e.value;
          case "rejected":
            throw e.reason;
          default:
            switch (typeof e.status == "string" ? e.then(H, H) : (e.status = "pending", e.then(
              function(r) {
                e.status === "pending" && (e.status = "fulfilled", e.value = r);
              },
              function(r) {
                e.status === "pending" && (e.status = "rejected", e.reason = r);
              }
            )), e.status) {
              case "fulfilled":
                return e.value;
              case "rejected":
                throw e.reason;
            }
        }
        throw e;
      }
      function S(e, r, o, a, c) {
        var g = typeof e;
        (g === "undefined" || g === "boolean") && (e = null);
        var h = !1;
        if (e === null) h = !0;
        else
          switch (g) {
            case "bigint":
            case "string":
            case "number":
              h = !0;
              break;
            case "object":
              switch (e.$$typeof) {
                case $:
                case ae:
                  h = !0;
                  break;
                case z:
                  return h = e._init, S(
                    h(e._payload),
                    r,
                    o,
                    a,
                    c
                  );
              }
          }
        if (h) {
          h = e, c = c(h);
          var T = a === "" ? "." + b(h, 0) : a;
          return Ae(c) ? (o = "", T != null && (o = T.replace(Me, "$&/") + "/"), S(c, r, o, "", function(te) {
            return te;
          })) : c != null && (L(c) && (c.key != null && (h && h.key === c.key || P(c.key)), o = ne(
            c,
            o + (c.key == null || h && h.key === c.key ? "" : ("" + c.key).replace(
              Me,
              "$&/"
            ) + "/") + T
          ), a !== "" && h != null && L(h) && h.key == null && h._store && !h._store.validated && (o._store.validated = 2), c = o), r.push(c)), 1;
        }
        if (h = 0, T = a === "" ? "." : a + ":", Ae(e))
          for (var E = 0; E < e.length; E++)
            a = e[E], g = T + b(a, E), h += S(
              a,
              r,
              o,
              g,
              c
            );
        else if (E = j(e), typeof E == "function")
          for (E === e.entries && (Pe || console.warn(
            "Using Maps as children is not supported. Use an array of keyed ReactElements instead."
          ), Pe = !0), e = E.call(e), E = 0; !(a = e.next()).done; )
            a = a.value, g = T + b(a, E++), h += S(
              a,
              r,
              o,
              g,
              c
            );
        else if (g === "object") {
          if (typeof e.then == "function")
            return S(
              ue(e),
              r,
              o,
              a,
              c
            );
          throw r = String(e), Error(
            "Objects are not valid as a React child (found: " + (r === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead."
          );
        }
        return h;
      }
      function Z(e, r, o) {
        if (e == null) return e;
        var a = [], c = 0;
        return S(e, a, "", "", function(g) {
          return r.call(o, g, c++);
        }), a;
      }
      function se(e) {
        if (e._status === -1) {
          var r = e._ioInfo;
          r != null && (r.start = r.end = performance.now()), r = e._result;
          var o = r();
          if (o.then(
            function(c) {
              if (e._status === 0 || e._status === -1) {
                e._status = 1, e._result = c;
                var g = e._ioInfo;
                g != null && (g.end = performance.now()), o.status === void 0 && (o.status = "fulfilled", o.value = c);
              }
            },
            function(c) {
              if (e._status === 0 || e._status === -1) {
                e._status = 2, e._result = c;
                var g = e._ioInfo;
                g != null && (g.end = performance.now()), o.status === void 0 && (o.status = "rejected", o.reason = c);
              }
            }
          ), r = e._ioInfo, r != null) {
            r.value = o;
            var a = o.displayName;
            typeof a == "string" && (r.name = a);
          }
          e._status === -1 && (e._status = 0, e._result = o);
        }
        if (e._status === 1)
          return r = e._result, r === void 0 && console.error(
            `lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`,
            r
          ), "default" in r || console.error(
            `lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`,
            r
          ), r.default;
        throw e._result;
      }
      function R() {
        var e = v.H;
        return e === null && console.error(
          `Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.`
        ), e;
      }
      function J() {
        v.asyncTransitions--;
      }
      function D(e) {
        if (me === null)
          try {
            var r = ("require" + Math.random()).slice(0, 7);
            me = (d && d[r]).call(
              d,
              "timers"
            ).setImmediate;
          } catch {
            me = function(a) {
              Ye === !1 && (Ye = !0, typeof MessageChannel > "u" && console.error(
                "This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."
              ));
              var c = new MessageChannel();
              c.port1.onmessage = a, c.port2.postMessage(void 0);
            };
          }
        return me(e);
      }
      function Y(e) {
        return 1 < e.length && typeof AggregateError == "function" ? new AggregateError(e) : e[0];
      }
      function N(e, r) {
        r !== he - 1 && console.error(
          "You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "
        ), he = r;
      }
      function I(e, r, o) {
        var a = v.actQueue;
        if (a !== null)
          if (a.length !== 0)
            try {
              ee(a), D(function() {
                return I(e, r, o);
              });
              return;
            } catch (c) {
              v.thrownErrors.push(c);
            }
          else v.actQueue = null;
        0 < v.thrownErrors.length ? (a = Y(v.thrownErrors), v.thrownErrors.length = 0, o(a)) : r(e);
      }
      function ee(e) {
        if (!we) {
          we = !0;
          var r = 0;
          try {
            for (; r < e.length; r++) {
              var o = e[r];
              do {
                v.didUsePromise = !1;
                var a = o(!1);
                if (a !== null) {
                  if (v.didUsePromise) {
                    e[r] = o, e.splice(0, r);
                    return;
                  }
                  o = a;
                } else break;
              } while (!0);
            }
            e.length = 0;
          } catch (c) {
            e.splice(0, r + 1), v.thrownErrors.push(c);
          } finally {
            we = !1;
          }
        }
      }
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var $ = /* @__PURE__ */ Symbol.for("react.transitional.element"), ae = /* @__PURE__ */ Symbol.for("react.portal"), t = /* @__PURE__ */ Symbol.for("react.fragment"), n = /* @__PURE__ */ Symbol.for("react.strict_mode"), u = /* @__PURE__ */ Symbol.for("react.profiler"), i = /* @__PURE__ */ Symbol.for("react.consumer"), _ = /* @__PURE__ */ Symbol.for("react.context"), w = /* @__PURE__ */ Symbol.for("react.forward_ref"), l = /* @__PURE__ */ Symbol.for("react.suspense"), A = /* @__PURE__ */ Symbol.for("react.suspense_list"), O = /* @__PURE__ */ Symbol.for("react.memo"), z = /* @__PURE__ */ Symbol.for("react.lazy"), Re = /* @__PURE__ */ Symbol.for("react.activity"), Te = Symbol.iterator, ke = {}, Oe = {
        isMounted: function() {
          return !1;
        },
        enqueueForceUpdate: function(e) {
          m(e, "forceUpdate");
        },
        enqueueReplaceState: function(e) {
          m(e, "replaceState");
        },
        enqueueSetState: function(e) {
          m(e, "setState");
        }
      }, je = Object.assign, Ee = {};
      Object.freeze(Ee), y.prototype.isReactComponent = {}, y.prototype.setState = function(e, r) {
        if (typeof e != "object" && typeof e != "function" && e != null)
          throw Error(
            "takes an object of state variables to update or a function which returns an object of state variables."
          );
        this.updater.enqueueSetState(this, e, r, "setState");
      }, y.prototype.forceUpdate = function(e) {
        this.updater.enqueueForceUpdate(this, e, "forceUpdate");
      };
      var M = {
        isMounted: [
          "isMounted",
          "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."
        ],
        replaceState: [
          "replaceState",
          "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."
        ]
      };
      for (ce in M)
        M.hasOwnProperty(ce) && k(ce, M[ce]);
      C.prototype = y.prototype, M = x.prototype = new C(), M.constructor = x, je(M, y.prototype), M.isPureReactComponent = !0;
      var Ae = Array.isArray, Ke = /* @__PURE__ */ Symbol.for("react.client.reference"), v = {
        H: null,
        A: null,
        T: null,
        S: null,
        actQueue: null,
        asyncTransitions: 0,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      }, pe = Object.prototype.hasOwnProperty, Ce = console.createTask ? console.createTask : function() {
        return null;
      };
      M = {
        react_stack_bottom_frame: function(e) {
          return e();
        }
      };
      var xe, Se, Ne = {}, Xe = M.react_stack_bottom_frame.bind(
        M,
        Q
      )(), Ve = Ce(F(Q)), Pe = !1, Me = /\/+/g, Le = typeof reportError == "function" ? reportError : function(e) {
        if (typeof window == "object" && typeof window.ErrorEvent == "function") {
          var r = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
            error: e
          });
          if (!window.dispatchEvent(r)) return;
        } else if (typeof process == "object" && typeof process.emit == "function") {
          process.emit("uncaughtException", e);
          return;
        }
        console.error(e);
      }, Ye = !1, me = null, he = 0, _e = !1, we = !1, Ie = typeof queueMicrotask == "function" ? function(e) {
        queueMicrotask(function() {
          return queueMicrotask(e);
        });
      } : D;
      M = Object.freeze({
        __proto__: null,
        c: function(e) {
          return R().useMemoCache(e);
        }
      });
      var ce = {
        map: Z,
        forEach: function(e, r, o) {
          Z(
            e,
            function() {
              r.apply(this, arguments);
            },
            o
          );
        },
        count: function(e) {
          var r = 0;
          return Z(e, function() {
            r++;
          }), r;
        },
        toArray: function(e) {
          return Z(e, function(r) {
            return r;
          }) || [];
        },
        only: function(e) {
          if (!L(e))
            throw Error(
              "React.Children.only expected to receive a single React element child."
            );
          return e;
        }
      };
      s.Activity = Re, s.Children = ce, s.Component = y, s.Fragment = t, s.Profiler = u, s.PureComponent = x, s.StrictMode = n, s.Suspense = l, s.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = v, s.__COMPILER_RUNTIME = M, s.act = function(e) {
        var r = v.actQueue, o = he;
        he++;
        var a = v.actQueue = r !== null ? r : [], c = !1;
        try {
          var g = e();
        } catch (E) {
          v.thrownErrors.push(E);
        }
        if (0 < v.thrownErrors.length)
          throw N(r, o), e = Y(v.thrownErrors), v.thrownErrors.length = 0, e;
        if (g !== null && typeof g == "object" && typeof g.then == "function") {
          var h = g;
          return Ie(function() {
            c || _e || (_e = !0, console.error(
              "You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"
            ));
          }), {
            then: function(E, te) {
              c = !0, h.then(
                function(ie) {
                  if (N(r, o), o === 0) {
                    try {
                      ee(a), D(function() {
                        return I(
                          ie,
                          E,
                          te
                        );
                      });
                    } catch (Je) {
                      v.thrownErrors.push(Je);
                    }
                    if (0 < v.thrownErrors.length) {
                      var Ze = Y(
                        v.thrownErrors
                      );
                      v.thrownErrors.length = 0, te(Ze);
                    }
                  } else E(ie);
                },
                function(ie) {
                  N(r, o), 0 < v.thrownErrors.length && (ie = Y(
                    v.thrownErrors
                  ), v.thrownErrors.length = 0), te(ie);
                }
              );
            }
          };
        }
        var T = g;
        if (N(r, o), o === 0 && (ee(a), a.length !== 0 && Ie(function() {
          c || _e || (_e = !0, console.error(
            "A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"
          ));
        }), v.actQueue = null), 0 < v.thrownErrors.length)
          throw e = Y(v.thrownErrors), v.thrownErrors.length = 0, e;
        return {
          then: function(E, te) {
            c = !0, o === 0 ? (v.actQueue = a, D(function() {
              return I(
                T,
                E,
                te
              );
            })) : E(T);
          }
        };
      }, s.cache = function(e) {
        return function() {
          return e.apply(null, arguments);
        };
      }, s.cacheSignal = function() {
        return null;
      }, s.captureOwnerStack = function() {
        var e = v.getCurrentStack;
        return e === null ? null : e();
      }, s.cloneElement = function(e, r, o) {
        if (e == null)
          throw Error(
            "The argument must be a React element, but you passed " + e + "."
          );
        var a = je({}, e.props), c = e.key, g = e._owner;
        if (r != null) {
          var h;
          e: {
            if (pe.call(r, "ref") && (h = Object.getOwnPropertyDescriptor(
              r,
              "ref"
            ).get) && h.isReactWarning) {
              h = !1;
              break e;
            }
            h = r.ref !== void 0;
          }
          h && (g = q()), re(r) && (P(r.key), c = "" + r.key);
          for (T in r)
            !pe.call(r, T) || T === "key" || T === "__self" || T === "__source" || T === "ref" && r.ref === void 0 || (a[T] = r[T]);
        }
        var T = arguments.length - 2;
        if (T === 1) a.children = o;
        else if (1 < T) {
          h = Array(T);
          for (var E = 0; E < T; E++)
            h[E] = arguments[E + 2];
          a.children = h;
        }
        for (a = X(
          e.type,
          c,
          a,
          g,
          e._debugStack,
          e._debugTask
        ), c = 2; c < arguments.length; c++)
          V(arguments[c]);
        return a;
      }, s.createContext = function(e) {
        return e = {
          $$typeof: _,
          _currentValue: e,
          _currentValue2: e,
          _threadCount: 0,
          Provider: null,
          Consumer: null
        }, e.Provider = e, e.Consumer = {
          $$typeof: i,
          _context: e
        }, e._currentRenderer = null, e._currentRenderer2 = null, e;
      }, s.createElement = function(e, r, o) {
        for (var a = 2; a < arguments.length; a++)
          V(arguments[a]);
        a = {};
        var c = null;
        if (r != null)
          for (E in Se || !("__self" in r) || "key" in r || (Se = !0, console.warn(
            "Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform"
          )), re(r) && (P(r.key), c = "" + r.key), r)
            pe.call(r, E) && E !== "key" && E !== "__self" && E !== "__source" && (a[E] = r[E]);
        var g = arguments.length - 2;
        if (g === 1) a.children = o;
        else if (1 < g) {
          for (var h = Array(g), T = 0; T < g; T++)
            h[T] = arguments[T + 2];
          Object.freeze && Object.freeze(h), a.children = h;
        }
        if (e && e.defaultProps)
          for (E in g = e.defaultProps, g)
            a[E] === void 0 && (a[E] = g[E]);
        c && K(
          a,
          typeof e == "function" ? e.displayName || e.name || "Unknown" : e
        );
        var E = 1e4 > v.recentlyCreatedOwnerStacks++;
        return X(
          e,
          c,
          a,
          q(),
          E ? Error("react-stack-top-frame") : Xe,
          E ? Ce(F(e)) : Ve
        );
      }, s.createRef = function() {
        var e = { current: null };
        return Object.seal(e), e;
      }, s.forwardRef = function(e) {
        e != null && e.$$typeof === O ? console.error(
          "forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...))."
        ) : typeof e != "function" ? console.error(
          "forwardRef requires a render function but was given %s.",
          e === null ? "null" : typeof e
        ) : e.length !== 0 && e.length !== 2 && console.error(
          "forwardRef render functions accept exactly two parameters: props and ref. %s",
          e.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."
        ), e != null && e.defaultProps != null && console.error(
          "forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?"
        );
        var r = { $$typeof: w, render: e }, o;
        return Object.defineProperty(r, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return o;
          },
          set: function(a) {
            o = a, e.name || e.displayName || (Object.defineProperty(e, "name", { value: a }), e.displayName = a);
          }
        }), r;
      }, s.isValidElement = L, s.lazy = function(e) {
        e = { _status: -1, _result: e };
        var r = {
          $$typeof: z,
          _payload: e,
          _init: se
        }, o = {
          name: "lazy",
          start: -1,
          end: -1,
          value: null,
          owner: null,
          debugStack: Error("react-stack-top-frame"),
          debugTask: console.createTask ? console.createTask("lazy()") : null
        };
        return e._ioInfo = o, r._debugInfo = [{ awaited: o }], r;
      }, s.memo = function(e, r) {
        e == null && console.error(
          "memo: The first argument must be a component. Instead received: %s",
          e === null ? "null" : typeof e
        ), r = {
          $$typeof: O,
          type: e,
          compare: r === void 0 ? null : r
        };
        var o;
        return Object.defineProperty(r, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return o;
          },
          set: function(a) {
            o = a, e.name || e.displayName || (Object.defineProperty(e, "name", { value: a }), e.displayName = a);
          }
        }), r;
      }, s.startTransition = function(e) {
        var r = v.T, o = {};
        o._updatedFibers = /* @__PURE__ */ new Set(), v.T = o;
        try {
          var a = e(), c = v.S;
          c !== null && c(o, a), typeof a == "object" && a !== null && typeof a.then == "function" && (v.asyncTransitions++, a.then(J, J), a.then(H, Le));
        } catch (g) {
          Le(g);
        } finally {
          r === null && o._updatedFibers && (e = o._updatedFibers.size, o._updatedFibers.clear(), 10 < e && console.warn(
            "Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."
          )), r !== null && o.types !== null && (r.types !== null && r.types !== o.types && console.error(
            "We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."
          ), r.types = o.types), v.T = r;
        }
      }, s.unstable_useCacheRefresh = function() {
        return R().useCacheRefresh();
      }, s.use = function(e) {
        return R().use(e);
      }, s.useActionState = function(e, r, o) {
        return R().useActionState(
          e,
          r,
          o
        );
      }, s.useCallback = function(e, r) {
        return R().useCallback(e, r);
      }, s.useContext = function(e) {
        var r = R();
        return e.$$typeof === i && console.error(
          "Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?"
        ), r.useContext(e);
      }, s.useDebugValue = function(e, r) {
        return R().useDebugValue(e, r);
      }, s.useDeferredValue = function(e, r) {
        return R().useDeferredValue(e, r);
      }, s.useEffect = function(e, r) {
        return e == null && console.warn(
          "React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), R().useEffect(e, r);
      }, s.useEffectEvent = function(e) {
        return R().useEffectEvent(e);
      }, s.useId = function() {
        return R().useId();
      }, s.useImperativeHandle = function(e, r, o) {
        return R().useImperativeHandle(e, r, o);
      }, s.useInsertionEffect = function(e, r) {
        return e == null && console.warn(
          "React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), R().useInsertionEffect(e, r);
      }, s.useLayoutEffect = function(e, r) {
        return e == null && console.warn(
          "React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?"
        ), R().useLayoutEffect(e, r);
      }, s.useMemo = function(e, r) {
        return R().useMemo(e, r);
      }, s.useOptimistic = function(e, r) {
        return R().useOptimistic(e, r);
      }, s.useReducer = function(e, r, o) {
        return R().useReducer(e, r, o);
      }, s.useRef = function(e) {
        return R().useRef(e);
      }, s.useState = function(e) {
        return R().useState(e);
      }, s.useSyncExternalStore = function(e, r, o) {
        return R().useSyncExternalStore(
          e,
          r,
          o
        );
      }, s.useTransition = function() {
        return R().useTransition();
      }, s.version = "19.2.5", typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    })();
  })(de, de.exports)), de.exports;
}
var We;
function Fe() {
  return We || (We = 1, process.env.NODE_ENV === "production" ? ve.exports = rt() : ve.exports = nt()), ve.exports;
}
var qe;
function ot() {
  return qe || (qe = 1, process.env.NODE_ENV !== "production" && (function() {
    function d(t) {
      if (t == null) return null;
      if (typeof t == "function")
        return t.$$typeof === se ? null : t.displayName || t.name || null;
      if (typeof t == "string") return t;
      switch (t) {
        case K:
          return "Fragment";
        case X:
          return "Profiler";
        case U:
          return "StrictMode";
        case oe:
          return "Suspense";
        case b:
          return "SuspenseList";
        case Z:
          return "Activity";
      }
      if (typeof t == "object")
        switch (typeof t.tag == "number" && console.error(
          "Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."
        ), t.$$typeof) {
          case re:
            return "Portal";
          case V:
            return t.displayName || "Context";
          case ne:
            return (t._context.displayName || "Context") + ".Consumer";
          case L:
            var n = t.render;
            return t = t.displayName, t || (t = n.displayName || n.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
          case ue:
            return n = t.displayName || null, n !== null ? n : d(t.type) || "Memo";
          case S:
            n = t._payload, t = t._init;
            try {
              return d(t(n));
            } catch {
            }
        }
      return null;
    }
    function s(t) {
      return "" + t;
    }
    function k(t) {
      try {
        s(t);
        var n = !1;
      } catch {
        n = !0;
      }
      if (n) {
        n = console;
        var u = n.error, i = typeof Symbol == "function" && Symbol.toStringTag && t[Symbol.toStringTag] || t.constructor.name || "Object";
        return u.call(
          n,
          "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.",
          i
        ), s(t);
      }
    }
    function j(t) {
      if (t === K) return "<>";
      if (typeof t == "object" && t !== null && t.$$typeof === S)
        return "<...>";
      try {
        var n = d(t);
        return n ? "<" + n + ">" : "<...>";
      } catch {
        return "<...>";
      }
    }
    function m() {
      var t = R.A;
      return t === null ? null : t.getOwner();
    }
    function y() {
      return Error("react-stack-top-frame");
    }
    function C(t) {
      if (J.call(t, "key")) {
        var n = Object.getOwnPropertyDescriptor(t, "key").get;
        if (n && n.isReactWarning) return !1;
      }
      return t.key !== void 0;
    }
    function x(t, n) {
      function u() {
        N || (N = !0, console.error(
          "%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)",
          n
        ));
      }
      u.isReactWarning = !0, Object.defineProperty(t, "key", {
        get: u,
        configurable: !0
      });
    }
    function H() {
      var t = d(this.type);
      return I[t] || (I[t] = !0, console.error(
        "Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."
      )), t = this.props.ref, t !== void 0 ? t : null;
    }
    function G(t, n, u, i, _, w) {
      var l = u.ref;
      return t = {
        $$typeof: Q,
        type: t,
        key: n,
        props: u,
        _owner: i
      }, (l !== void 0 ? l : null) !== null ? Object.defineProperty(t, "ref", {
        enumerable: !1,
        get: H
      }) : Object.defineProperty(t, "ref", { enumerable: !1, value: null }), t._store = {}, Object.defineProperty(t._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      }), Object.defineProperty(t, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      }), Object.defineProperty(t, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: _
      }), Object.defineProperty(t, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: w
      }), Object.freeze && (Object.freeze(t.props), Object.freeze(t)), t;
    }
    function P(t, n, u, i, _, w) {
      var l = n.children;
      if (l !== void 0)
        if (i)
          if (D(l)) {
            for (i = 0; i < l.length; i++)
              W(l[i]);
            Object.freeze && Object.freeze(l);
          } else
            console.error(
              "React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead."
            );
        else W(l);
      if (J.call(n, "key")) {
        l = d(t);
        var A = Object.keys(n).filter(function(z) {
          return z !== "key";
        });
        i = 0 < A.length ? "{key: someKey, " + A.join(": ..., ") + ": ...}" : "{key: someKey}", ae[l + i] || (A = 0 < A.length ? "{" + A.join(": ..., ") + ": ...}" : "{}", console.error(
          `A props object containing a "key" prop is being spread into JSX:
  let props = %s;
  <%s {...props} />
React keys must be passed directly to JSX without using spread:
  let props = %s;
  <%s key={someKey} {...props} />`,
          i,
          l,
          A,
          l
        ), ae[l + i] = !0);
      }
      if (l = null, u !== void 0 && (k(u), l = "" + u), C(n) && (k(n.key), l = "" + n.key), "key" in n) {
        u = {};
        for (var O in n)
          O !== "key" && (u[O] = n[O]);
      } else u = n;
      return l && x(
        u,
        typeof t == "function" ? t.displayName || t.name || "Unknown" : t
      ), G(
        t,
        l,
        u,
        m(),
        _,
        w
      );
    }
    function W(t) {
      F(t) ? t._store && (t._store.validated = 1) : typeof t == "object" && t !== null && t.$$typeof === S && (t._payload.status === "fulfilled" ? F(t._payload.value) && t._payload.value._store && (t._payload.value._store.validated = 1) : t._store && (t._store.validated = 1));
    }
    function F(t) {
      return typeof t == "object" && t !== null && t.$$typeof === Q;
    }
    var q = Fe(), Q = /* @__PURE__ */ Symbol.for("react.transitional.element"), re = /* @__PURE__ */ Symbol.for("react.portal"), K = /* @__PURE__ */ Symbol.for("react.fragment"), U = /* @__PURE__ */ Symbol.for("react.strict_mode"), X = /* @__PURE__ */ Symbol.for("react.profiler"), ne = /* @__PURE__ */ Symbol.for("react.consumer"), V = /* @__PURE__ */ Symbol.for("react.context"), L = /* @__PURE__ */ Symbol.for("react.forward_ref"), oe = /* @__PURE__ */ Symbol.for("react.suspense"), b = /* @__PURE__ */ Symbol.for("react.suspense_list"), ue = /* @__PURE__ */ Symbol.for("react.memo"), S = /* @__PURE__ */ Symbol.for("react.lazy"), Z = /* @__PURE__ */ Symbol.for("react.activity"), se = /* @__PURE__ */ Symbol.for("react.client.reference"), R = q.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, J = Object.prototype.hasOwnProperty, D = Array.isArray, Y = console.createTask ? console.createTask : function() {
      return null;
    };
    q = {
      react_stack_bottom_frame: function(t) {
        return t();
      }
    };
    var N, I = {}, ee = q.react_stack_bottom_frame.bind(
      q,
      y
    )(), $ = Y(j(y)), ae = {};
    fe.Fragment = K, fe.jsx = function(t, n, u) {
      var i = 1e4 > R.recentlyCreatedOwnerStacks++;
      return P(
        t,
        n,
        u,
        !1,
        i ? Error("react-stack-top-frame") : ee,
        i ? Y(j(t)) : $
      );
    }, fe.jsxs = function(t, n, u) {
      var i = 1e4 > R.recentlyCreatedOwnerStacks++;
      return P(
        t,
        n,
        u,
        !0,
        i ? Error("react-stack-top-frame") : ee,
        i ? Y(j(t)) : $
      );
    };
  })()), fe;
}
var $e;
function st() {
  return $e || ($e = 1, process.env.NODE_ENV === "production" ? ye.exports = tt() : ye.exports = ot()), ye.exports;
}
var p = st(), B = Fe();
const at = (d) => d.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), ut = (d) => d.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (s, k, j) => j ? j.toUpperCase() : k.toLowerCase()
), ze = (d) => {
  const s = ut(d);
  return s.charAt(0).toUpperCase() + s.slice(1);
}, Qe = (...d) => d.filter((s, k, j) => !!s && s.trim() !== "" && j.indexOf(s) === k).join(" ").trim(), it = (d) => {
  for (const s in d)
    if (s.startsWith("aria-") || s === "role" || s === "title")
      return !0;
};
var ct = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const lt = B.forwardRef(
  ({
    color: d = "currentColor",
    size: s = 24,
    strokeWidth: k = 2,
    absoluteStrokeWidth: j,
    className: m = "",
    children: y,
    iconNode: C,
    ...x
  }, H) => B.createElement(
    "svg",
    {
      ref: H,
      ...ct,
      width: s,
      height: s,
      stroke: d,
      strokeWidth: j ? Number(k) * 24 / Number(s) : k,
      className: Qe("lucide", m),
      ...!y && !it(x) && { "aria-hidden": "true" },
      ...x
    },
    [
      ...C.map(([G, P]) => B.createElement(G, P)),
      ...Array.isArray(y) ? y : [y]
    ]
  )
);
const ge = (d, s) => {
  const k = B.forwardRef(
    ({ className: j, ...m }, y) => B.createElement(lt, {
      ref: y,
      iconNode: s,
      className: Qe(
        `lucide-${at(ze(d))}`,
        `lucide-${d}`,
        j
      ),
      ...m
    })
  );
  return k.displayName = ze(d), k;
};
const ft = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]], Be = ge("check", ft);
const dt = [
  ["path", { d: "M21.54 15H17a2 2 0 0 0-2 2v4.54", key: "1djwo0" }],
  [
    "path",
    {
      d: "M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",
      key: "1tzkfa"
    }
  ],
  ["path", { d: "M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05", key: "14pb5j" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
], pt = ge("earth", dt);
const mt = [
  ["path", { d: "M10 8h.01", key: "1r9ogq" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M14 8h.01", key: "1primd" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }],
  ["path", { d: "M18 8h.01", key: "emo2bl" }],
  ["path", { d: "M6 8h.01", key: "x9i8wu" }],
  ["path", { d: "M7 16h10", key: "wp8him" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }]
], ht = ge("keyboard", mt);
const _t = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ],
  ["path", { d: "M20 2v4", key: "1rf3ol" }],
  ["path", { d: "M22 4h-4", key: "gwowj6" }],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
], yt = ge("sparkles", _t), be = et(
  void 0,
  void 0,
  "",
  ""
), Ge = [
  {
    value: "alt_option",
    label: "Alt / Option",
    description: "Windows: Alt | Mac: Option",
    keyHint: "⌥"
  },
  {
    value: "cmd_ctrl",
    label: "Cmd / Ctrl",
    description: "Windows: Ctrl | Mac: Cmd",
    keyHint: "⌘"
  }
];
function gt() {
  const [d, s] = B.useState({
    modifier: "alt_option",
    apiBaseUrl: be,
    saved: !1
  }), k = B.useMemo(
    () => Ge.find((m) => m.value === d.modifier),
    [d.modifier]
  );
  B.useEffect(() => {
    chrome.storage.sync.get(["flow_reader_modifier", "flow_reader_api_base_url"]).then((m) => {
      s((y) => ({
        ...y,
        modifier: m.flow_reader_modifier || "alt_option",
        apiBaseUrl: m.flow_reader_api_base_url || be
      }));
    });
  }, []), B.useEffect(() => {
    if (!d.saved)
      return;
    const m = window.setTimeout(() => {
      s((y) => ({ ...y, saved: !1 }));
    }, 1800);
    return () => window.clearTimeout(m);
  }, [d.saved]);
  const j = async () => {
    await chrome.storage.sync.set({
      flow_reader_modifier: d.modifier,
      flow_reader_api_base_url: d.apiBaseUrl.trim()
    }), s((m) => ({ ...m, saved: !0 }));
  };
  return /* @__PURE__ */ p.jsx("div", { className: "min-h-screen bg-transparent px-4 py-10 text-slate-900", children: /* @__PURE__ */ p.jsxs("div", { className: "mx-auto max-w-3xl", children: [
    /* @__PURE__ */ p.jsxs("header", { className: "mb-6 rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)] backdrop-blur", children: [
      /* @__PURE__ */ p.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ p.jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-950 text-white shadow-lg shadow-slate-950/15", children: /* @__PURE__ */ p.jsx(yt, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ p.jsxs("div", { children: [
          /* @__PURE__ */ p.jsx("p", { className: "text-xs font-bold uppercase tracking-[0.28em] text-indigo-600", children: "AI English Study" }),
          /* @__PURE__ */ p.jsx("h1", { className: "text-2xl font-black tracking-tight", children: "설정" })
        ] })
      ] }),
      /* @__PURE__ */ p.jsx("p", { className: "mt-3 max-w-2xl text-sm leading-6 text-slate-600", children: "단축키와 서버 주소를 저장하면 확장앱이 바로 동작합니다. 저장 후 열려 있는 탭에도 설정이 자동 반영됩니다." })
    ] }),
    /* @__PURE__ */ p.jsxs("section", { className: "space-y-4 rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)] backdrop-blur", children: [
      /* @__PURE__ */ p.jsxs("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ p.jsx("div", { className: "flex h-10 w-10 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700 ring-1 ring-indigo-100", children: /* @__PURE__ */ p.jsx(ht, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ p.jsxs("div", { children: [
          /* @__PURE__ */ p.jsx("h2", { className: "text-lg font-bold text-slate-950", children: "단어 조회 단축키" }),
          /* @__PURE__ */ p.jsx("p", { className: "text-sm text-slate-600", children: "이 키를 누른 상태에서 단어 위에 마우스를 올리면 뜻이 표시됩니다." })
        ] })
      ] }),
      /* @__PURE__ */ p.jsx("div", { className: "grid gap-3 sm:grid-cols-2", children: Ge.map((m) => {
        const y = d.modifier === m.value;
        return /* @__PURE__ */ p.jsxs(
          "label",
          {
            className: `flex cursor-pointer items-center gap-4 rounded-3xl border p-4 transition ${y ? "border-indigo-300 bg-indigo-50/80 shadow-sm" : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"}`,
            children: [
              /* @__PURE__ */ p.jsx(
                "input",
                {
                  type: "radio",
                  name: "modifier",
                  value: m.value,
                  checked: y,
                  onChange: () => s((C) => ({ ...C, modifier: m.value })),
                  className: "sr-only"
                }
              ),
              /* @__PURE__ */ p.jsx(
                "div",
                {
                  className: `flex h-11 w-11 items-center justify-center rounded-2xl text-lg font-black ${y ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600"}`,
                  children: m.keyHint
                }
              ),
              /* @__PURE__ */ p.jsxs("div", { className: "min-w-0", children: [
                /* @__PURE__ */ p.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ p.jsx("span", { className: "font-bold text-slate-950", children: m.label }),
                  y ? /* @__PURE__ */ p.jsx(Be, { className: "h-4 w-4 text-indigo-600" }) : null
                ] }),
                /* @__PURE__ */ p.jsx("p", { className: "text-sm text-slate-500", children: m.description })
              ] })
            ]
          },
          m.value
        );
      }) })
    ] }),
    /* @__PURE__ */ p.jsxs("section", { className: "mt-4 rounded-[2rem] border border-white/70 bg-white/85 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)] backdrop-blur", children: [
      /* @__PURE__ */ p.jsxs("div", { className: "flex items-start gap-3", children: [
        /* @__PURE__ */ p.jsx("div", { className: "flex h-10 w-10 items-center justify-center rounded-2xl bg-sky-50 text-sky-700 ring-1 ring-sky-100", children: /* @__PURE__ */ p.jsx(pt, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ p.jsxs("div", { children: [
          /* @__PURE__ */ p.jsx("h2", { className: "text-lg font-bold text-slate-950", children: "서버 주소" }),
          /* @__PURE__ */ p.jsx("p", { className: "text-sm text-slate-600", children: "AI English Study 서버의 주소를 입력하세요." })
        ] })
      ] }),
      /* @__PURE__ */ p.jsxs("div", { className: "mt-4", children: [
        /* @__PURE__ */ p.jsxs("label", { className: "space-y-2", children: [
          /* @__PURE__ */ p.jsx("span", { className: "text-xs font-bold uppercase tracking-[0.24em] text-slate-400", children: "API Base URL" }),
          /* @__PURE__ */ p.jsx(
            "input",
            {
              type: "url",
              value: d.apiBaseUrl,
              onChange: (m) => s((y) => ({ ...y, apiBaseUrl: m.target.value })),
              placeholder: "http://localhost:3000",
              className: "h-12 w-full rounded-2xl border border-slate-200 bg-white px-4 font-mono text-sm outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:ring-4 focus:ring-indigo-100"
            }
          )
        ] }),
        /* @__PURE__ */ p.jsxs("p", { className: "mt-2 text-xs text-slate-500", children: [
          "기본값: ",
          be
        ] })
      ] })
    ] }),
    /* @__PURE__ */ p.jsxs(
      "button",
      {
        onClick: j,
        className: `mt-6 inline-flex h-12 w-full items-center justify-center gap-2 rounded-full px-5 text-sm font-bold text-white shadow-lg transition ${d.saved ? "bg-emerald-500 shadow-emerald-500/30" : "bg-gradient-to-r from-indigo-600 via-violet-600 to-sky-600 shadow-indigo-500/25 hover:brightness-105"}`,
        children: [
          d.saved ? /* @__PURE__ */ p.jsx(Be, { className: "h-4 w-4" }) : null,
          d.saved ? "저장되었습니다" : "설정 저장"
        ]
      }
    ),
    /* @__PURE__ */ p.jsxs("div", { className: "mt-4 rounded-3xl border border-indigo-100 bg-indigo-50/70 p-4 text-sm text-indigo-900", children: [
      /* @__PURE__ */ p.jsx("strong", { children: "사용법:" }),
      " 영어 웹페이지에서 선택한 키를 누른 채로 모르는 단어 위에 마우스를 0.2초 올려두면 뜻이 팝업으로 표시됩니다.",
      k ? /* @__PURE__ */ p.jsxs("div", { className: "mt-2 text-xs text-indigo-700", children: [
        "현재 선택: ",
        k.label
      ] }) : null
    ] })
  ] }) });
}
export {
  gt as default
};
