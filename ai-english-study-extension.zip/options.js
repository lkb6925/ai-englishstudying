import { r as am, a as um } from "./app-config-DuchQk2N.js";
var fi = { exports: {} }, be = {};
var gv;
function em() {
  if (gv) return be;
  gv = 1;
  var A = /* @__PURE__ */ Symbol.for("react.transitional.element"), j = /* @__PURE__ */ Symbol.for("react.fragment");
  function X(h, q, Z) {
    var ol = null;
    if (Z !== void 0 && (ol = "" + Z), q.key !== void 0 && (ol = "" + q.key), "key" in q) {
      Z = {};
      for (var _l in q)
        _l !== "key" && (Z[_l] = q[_l]);
    } else Z = q;
    return q = Z.ref, {
      $$typeof: A,
      type: h,
      key: ol,
      ref: q !== void 0 ? q : null,
      props: Z
    };
  }
  return be.Fragment = j, be.jsx = X, be.jsxs = X, be;
}
var Sv;
function nm() {
  return Sv || (Sv = 1, fi.exports = em()), fi.exports;
}
var x = nm(), ci = { exports: {} }, B = {};
var rv;
function fm() {
  if (rv) return B;
  rv = 1;
  var A = /* @__PURE__ */ Symbol.for("react.transitional.element"), j = /* @__PURE__ */ Symbol.for("react.portal"), X = /* @__PURE__ */ Symbol.for("react.fragment"), h = /* @__PURE__ */ Symbol.for("react.strict_mode"), q = /* @__PURE__ */ Symbol.for("react.profiler"), Z = /* @__PURE__ */ Symbol.for("react.consumer"), ol = /* @__PURE__ */ Symbol.for("react.context"), _l = /* @__PURE__ */ Symbol.for("react.forward_ref"), D = /* @__PURE__ */ Symbol.for("react.suspense"), T = /* @__PURE__ */ Symbol.for("react.memo"), k = /* @__PURE__ */ Symbol.for("react.lazy"), R = /* @__PURE__ */ Symbol.for("react.activity"), vl = Symbol.iterator;
  function Wl(d) {
    return d === null || typeof d != "object" ? null : (d = vl && d[vl] || d["@@iterator"], typeof d == "function" ? d : null);
  }
  var Bl = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, Cl = Object.assign, Ut = {};
  function $l(d, E, p) {
    this.props = d, this.context = E, this.refs = Ut, this.updater = p || Bl;
  }
  $l.prototype.isReactComponent = {}, $l.prototype.setState = function(d, E) {
    if (typeof d != "object" && typeof d != "function" && d != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, d, E, "setState");
  }, $l.prototype.forceUpdate = function(d) {
    this.updater.enqueueForceUpdate(this, d, "forceUpdate");
  };
  function $t() {
  }
  $t.prototype = $l.prototype;
  function xl(d, E, p) {
    this.props = d, this.context = E, this.refs = Ut, this.updater = p || Bl;
  }
  var ft = xl.prototype = new $t();
  ft.constructor = xl, Cl(ft, $l.prototype), ft.isPureReactComponent = !0;
  var Et = Array.isArray;
  function Yl() {
  }
  var W = { H: null, A: null, T: null, S: null }, Gl = Object.prototype.hasOwnProperty;
  function Tt(d, E, p) {
    var O = p.ref;
    return {
      $$typeof: A,
      type: d,
      key: E,
      ref: O !== void 0 ? O : null,
      props: p
    };
  }
  function Qa(d, E) {
    return Tt(d.type, E, d.props);
  }
  function At(d) {
    return typeof d == "object" && d !== null && d.$$typeof === A;
  }
  function Xl(d) {
    var E = { "=": "=0", ":": "=2" };
    return "$" + d.replace(/[=:]/g, function(p) {
      return E[p];
    });
  }
  var Ea = /\/+/g;
  function Dt(d, E) {
    return typeof d == "object" && d !== null && d.key != null ? Xl("" + d.key) : E.toString(36);
  }
  function St(d) {
    switch (d.status) {
      case "fulfilled":
        return d.value;
      case "rejected":
        throw d.reason;
      default:
        switch (typeof d.status == "string" ? d.then(Yl, Yl) : (d.status = "pending", d.then(
          function(E) {
            d.status === "pending" && (d.status = "fulfilled", d.value = E);
          },
          function(E) {
            d.status === "pending" && (d.status = "rejected", d.reason = E);
          }
        )), d.status) {
          case "fulfilled":
            return d.value;
          case "rejected":
            throw d.reason;
        }
    }
    throw d;
  }
  function r(d, E, p, O, Y) {
    var V = typeof d;
    (V === "undefined" || V === "boolean") && (d = null);
    var ll = !1;
    if (d === null) ll = !0;
    else
      switch (V) {
        case "bigint":
        case "string":
        case "number":
          ll = !0;
          break;
        case "object":
          switch (d.$$typeof) {
            case A:
            case j:
              ll = !0;
              break;
            case k:
              return ll = d._init, r(
                ll(d._payload),
                E,
                p,
                O,
                Y
              );
          }
      }
    if (ll)
      return Y = Y(d), ll = O === "" ? "." + Dt(d, 0) : O, Et(Y) ? (p = "", ll != null && (p = ll.replace(Ea, "$&/") + "/"), r(Y, E, p, "", function(Mu) {
        return Mu;
      })) : Y != null && (At(Y) && (Y = Qa(
        Y,
        p + (Y.key == null || d && d.key === Y.key ? "" : ("" + Y.key).replace(
          Ea,
          "$&/"
        ) + "/") + ll
      )), E.push(Y)), 1;
    ll = 0;
    var ql = O === "" ? "." : O + ":";
    if (Et(d))
      for (var gl = 0; gl < d.length; gl++)
        O = d[gl], V = ql + Dt(O, gl), ll += r(
          O,
          E,
          p,
          V,
          Y
        );
    else if (gl = Wl(d), typeof gl == "function")
      for (d = gl.call(d), gl = 0; !(O = d.next()).done; )
        O = O.value, V = ql + Dt(O, gl++), ll += r(
          O,
          E,
          p,
          V,
          Y
        );
    else if (V === "object") {
      if (typeof d.then == "function")
        return r(
          St(d),
          E,
          p,
          O,
          Y
        );
      throw E = String(d), Error(
        "Objects are not valid as a React child (found: " + (E === "[object Object]" ? "object with keys {" + Object.keys(d).join(", ") + "}" : E) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return ll;
  }
  function _(d, E, p) {
    if (d == null) return d;
    var O = [], Y = 0;
    return r(d, O, "", "", function(V) {
      return E.call(p, V, Y++);
    }), O;
  }
  function C(d) {
    if (d._status === -1) {
      var E = d._result;
      E = E(), E.then(
        function(p) {
          (d._status === 0 || d._status === -1) && (d._status = 1, d._result = p);
        },
        function(p) {
          (d._status === 0 || d._status === -1) && (d._status = 2, d._result = p);
        }
      ), d._status === -1 && (d._status = 0, d._result = E);
    }
    if (d._status === 1) return d._result.default;
    throw d._result;
  }
  var ul = typeof reportError == "function" ? reportError : function(d) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var E = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof d == "object" && d !== null && typeof d.message == "string" ? String(d.message) : String(d),
        error: d
      });
      if (!window.dispatchEvent(E)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", d);
      return;
    }
    console.error(d);
  }, cl = {
    map: _,
    forEach: function(d, E, p) {
      _(
        d,
        function() {
          E.apply(this, arguments);
        },
        p
      );
    },
    count: function(d) {
      var E = 0;
      return _(d, function() {
        E++;
      }), E;
    },
    toArray: function(d) {
      return _(d, function(E) {
        return E;
      }) || [];
    },
    only: function(d) {
      if (!At(d))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return d;
    }
  };
  return B.Activity = R, B.Children = cl, B.Component = $l, B.Fragment = X, B.Profiler = q, B.PureComponent = xl, B.StrictMode = h, B.Suspense = D, B.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = W, B.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(d) {
      return W.H.useMemoCache(d);
    }
  }, B.cache = function(d) {
    return function() {
      return d.apply(null, arguments);
    };
  }, B.cacheSignal = function() {
    return null;
  }, B.cloneElement = function(d, E, p) {
    if (d == null)
      throw Error(
        "The argument must be a React element, but you passed " + d + "."
      );
    var O = Cl({}, d.props), Y = d.key;
    if (E != null)
      for (V in E.key !== void 0 && (Y = "" + E.key), E)
        !Gl.call(E, V) || V === "key" || V === "__self" || V === "__source" || V === "ref" && E.ref === void 0 || (O[V] = E[V]);
    var V = arguments.length - 2;
    if (V === 1) O.children = p;
    else if (1 < V) {
      for (var ll = Array(V), ql = 0; ql < V; ql++)
        ll[ql] = arguments[ql + 2];
      O.children = ll;
    }
    return Tt(d.type, Y, O);
  }, B.createContext = function(d) {
    return d = {
      $$typeof: ol,
      _currentValue: d,
      _currentValue2: d,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, d.Provider = d, d.Consumer = {
      $$typeof: Z,
      _context: d
    }, d;
  }, B.createElement = function(d, E, p) {
    var O, Y = {}, V = null;
    if (E != null)
      for (O in E.key !== void 0 && (V = "" + E.key), E)
        Gl.call(E, O) && O !== "key" && O !== "__self" && O !== "__source" && (Y[O] = E[O]);
    var ll = arguments.length - 2;
    if (ll === 1) Y.children = p;
    else if (1 < ll) {
      for (var ql = Array(ll), gl = 0; gl < ll; gl++)
        ql[gl] = arguments[gl + 2];
      Y.children = ql;
    }
    if (d && d.defaultProps)
      for (O in ll = d.defaultProps, ll)
        Y[O] === void 0 && (Y[O] = ll[O]);
    return Tt(d, V, Y);
  }, B.createRef = function() {
    return { current: null };
  }, B.forwardRef = function(d) {
    return { $$typeof: _l, render: d };
  }, B.isValidElement = At, B.lazy = function(d) {
    return {
      $$typeof: k,
      _payload: { _status: -1, _result: d },
      _init: C
    };
  }, B.memo = function(d, E) {
    return {
      $$typeof: T,
      type: d,
      compare: E === void 0 ? null : E
    };
  }, B.startTransition = function(d) {
    var E = W.T, p = {};
    W.T = p;
    try {
      var O = d(), Y = W.S;
      Y !== null && Y(p, O), typeof O == "object" && O !== null && typeof O.then == "function" && O.then(Yl, ul);
    } catch (V) {
      ul(V);
    } finally {
      E !== null && p.types !== null && (E.types = p.types), W.T = E;
    }
  }, B.unstable_useCacheRefresh = function() {
    return W.H.useCacheRefresh();
  }, B.use = function(d) {
    return W.H.use(d);
  }, B.useActionState = function(d, E, p) {
    return W.H.useActionState(d, E, p);
  }, B.useCallback = function(d, E) {
    return W.H.useCallback(d, E);
  }, B.useContext = function(d) {
    return W.H.useContext(d);
  }, B.useDebugValue = function() {
  }, B.useDeferredValue = function(d, E) {
    return W.H.useDeferredValue(d, E);
  }, B.useEffect = function(d, E) {
    return W.H.useEffect(d, E);
  }, B.useEffectEvent = function(d) {
    return W.H.useEffectEvent(d);
  }, B.useId = function() {
    return W.H.useId();
  }, B.useImperativeHandle = function(d, E, p) {
    return W.H.useImperativeHandle(d, E, p);
  }, B.useInsertionEffect = function(d, E) {
    return W.H.useInsertionEffect(d, E);
  }, B.useLayoutEffect = function(d, E) {
    return W.H.useLayoutEffect(d, E);
  }, B.useMemo = function(d, E) {
    return W.H.useMemo(d, E);
  }, B.useOptimistic = function(d, E) {
    return W.H.useOptimistic(d, E);
  }, B.useReducer = function(d, E, p) {
    return W.H.useReducer(d, E, p);
  }, B.useRef = function(d) {
    return W.H.useRef(d);
  }, B.useState = function(d) {
    return W.H.useState(d);
  }, B.useSyncExternalStore = function(d, E, p) {
    return W.H.useSyncExternalStore(
      d,
      E,
      p
    );
  }, B.useTransition = function() {
    return W.H.useTransition();
  }, B.version = "19.2.5", B;
}
var bv;
function hi() {
  return bv || (bv = 1, ci.exports = fm()), ci.exports;
}
var Wt = hi(), ii = { exports: {} }, ze = {}, si = { exports: {} }, di = {};
var zv;
function cm() {
  return zv || (zv = 1, (function(A) {
    function j(r, _) {
      var C = r.length;
      r.push(_);
      l: for (; 0 < C; ) {
        var ul = C - 1 >>> 1, cl = r[ul];
        if (0 < q(cl, _))
          r[ul] = _, r[C] = cl, C = ul;
        else break l;
      }
    }
    function X(r) {
      return r.length === 0 ? null : r[0];
    }
    function h(r) {
      if (r.length === 0) return null;
      var _ = r[0], C = r.pop();
      if (C !== _) {
        r[0] = C;
        l: for (var ul = 0, cl = r.length, d = cl >>> 1; ul < d; ) {
          var E = 2 * (ul + 1) - 1, p = r[E], O = E + 1, Y = r[O];
          if (0 > q(p, C))
            O < cl && 0 > q(Y, p) ? (r[ul] = Y, r[O] = C, ul = O) : (r[ul] = p, r[E] = C, ul = E);
          else if (O < cl && 0 > q(Y, C))
            r[ul] = Y, r[O] = C, ul = O;
          else break l;
        }
      }
      return _;
    }
    function q(r, _) {
      var C = r.sortIndex - _.sortIndex;
      return C !== 0 ? C : r.id - _.id;
    }
    if (A.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
      var Z = performance;
      A.unstable_now = function() {
        return Z.now();
      };
    } else {
      var ol = Date, _l = ol.now();
      A.unstable_now = function() {
        return ol.now() - _l;
      };
    }
    var D = [], T = [], k = 1, R = null, vl = 3, Wl = !1, Bl = !1, Cl = !1, Ut = !1, $l = typeof setTimeout == "function" ? setTimeout : null, $t = typeof clearTimeout == "function" ? clearTimeout : null, xl = typeof setImmediate < "u" ? setImmediate : null;
    function ft(r) {
      for (var _ = X(T); _ !== null; ) {
        if (_.callback === null) h(T);
        else if (_.startTime <= r)
          h(T), _.sortIndex = _.expirationTime, j(D, _);
        else break;
        _ = X(T);
      }
    }
    function Et(r) {
      if (Cl = !1, ft(r), !Bl)
        if (X(D) !== null)
          Bl = !0, Yl || (Yl = !0, Xl());
        else {
          var _ = X(T);
          _ !== null && St(Et, _.startTime - r);
        }
    }
    var Yl = !1, W = -1, Gl = 5, Tt = -1;
    function Qa() {
      return Ut ? !0 : !(A.unstable_now() - Tt < Gl);
    }
    function At() {
      if (Ut = !1, Yl) {
        var r = A.unstable_now();
        Tt = r;
        var _ = !0;
        try {
          l: {
            Bl = !1, Cl && (Cl = !1, $t(W), W = -1), Wl = !0;
            var C = vl;
            try {
              t: {
                for (ft(r), R = X(D); R !== null && !(R.expirationTime > r && Qa()); ) {
                  var ul = R.callback;
                  if (typeof ul == "function") {
                    R.callback = null, vl = R.priorityLevel;
                    var cl = ul(
                      R.expirationTime <= r
                    );
                    if (r = A.unstable_now(), typeof cl == "function") {
                      R.callback = cl, ft(r), _ = !0;
                      break t;
                    }
                    R === X(D) && h(D), ft(r);
                  } else h(D);
                  R = X(D);
                }
                if (R !== null) _ = !0;
                else {
                  var d = X(T);
                  d !== null && St(
                    Et,
                    d.startTime - r
                  ), _ = !1;
                }
              }
              break l;
            } finally {
              R = null, vl = C, Wl = !1;
            }
            _ = void 0;
          }
        } finally {
          _ ? Xl() : Yl = !1;
        }
      }
    }
    var Xl;
    if (typeof xl == "function")
      Xl = function() {
        xl(At);
      };
    else if (typeof MessageChannel < "u") {
      var Ea = new MessageChannel(), Dt = Ea.port2;
      Ea.port1.onmessage = At, Xl = function() {
        Dt.postMessage(null);
      };
    } else
      Xl = function() {
        $l(At, 0);
      };
    function St(r, _) {
      W = $l(function() {
        r(A.unstable_now());
      }, _);
    }
    A.unstable_IdlePriority = 5, A.unstable_ImmediatePriority = 1, A.unstable_LowPriority = 4, A.unstable_NormalPriority = 3, A.unstable_Profiling = null, A.unstable_UserBlockingPriority = 2, A.unstable_cancelCallback = function(r) {
      r.callback = null;
    }, A.unstable_forceFrameRate = function(r) {
      0 > r || 125 < r ? console.error(
        "forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"
      ) : Gl = 0 < r ? Math.floor(1e3 / r) : 5;
    }, A.unstable_getCurrentPriorityLevel = function() {
      return vl;
    }, A.unstable_next = function(r) {
      switch (vl) {
        case 1:
        case 2:
        case 3:
          var _ = 3;
          break;
        default:
          _ = vl;
      }
      var C = vl;
      vl = _;
      try {
        return r();
      } finally {
        vl = C;
      }
    }, A.unstable_requestPaint = function() {
      Ut = !0;
    }, A.unstable_runWithPriority = function(r, _) {
      switch (r) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          r = 3;
      }
      var C = vl;
      vl = r;
      try {
        return _();
      } finally {
        vl = C;
      }
    }, A.unstable_scheduleCallback = function(r, _, C) {
      var ul = A.unstable_now();
      switch (typeof C == "object" && C !== null ? (C = C.delay, C = typeof C == "number" && 0 < C ? ul + C : ul) : C = ul, r) {
        case 1:
          var cl = -1;
          break;
        case 2:
          cl = 250;
          break;
        case 5:
          cl = 1073741823;
          break;
        case 4:
          cl = 1e4;
          break;
        default:
          cl = 5e3;
      }
      return cl = C + cl, r = {
        id: k++,
        callback: _,
        priorityLevel: r,
        startTime: C,
        expirationTime: cl,
        sortIndex: -1
      }, C > ul ? (r.sortIndex = C, j(T, r), X(D) === null && r === X(T) && (Cl ? ($t(W), W = -1) : Cl = !0, St(Et, C - ul))) : (r.sortIndex = cl, j(D, r), Bl || Wl || (Bl = !0, Yl || (Yl = !0, Xl()))), r;
    }, A.unstable_shouldYield = Qa, A.unstable_wrapCallback = function(r) {
      var _ = vl;
      return function() {
        var C = vl;
        vl = _;
        try {
          return r.apply(this, arguments);
        } finally {
          vl = C;
        }
      };
    };
  })(di)), di;
}
var Ev;
function im() {
  return Ev || (Ev = 1, si.exports = cm()), si.exports;
}
var vi = { exports: {} }, Rl = {};
var Tv;
function sm() {
  if (Tv) return Rl;
  Tv = 1;
  var A = hi();
  function j(D) {
    var T = "https://react.dev/errors/" + D;
    if (1 < arguments.length) {
      T += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var k = 2; k < arguments.length; k++)
        T += "&args[]=" + encodeURIComponent(arguments[k]);
    }
    return "Minified React error #" + D + "; visit " + T + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function X() {
  }
  var h = {
    d: {
      f: X,
      r: function() {
        throw Error(j(522));
      },
      D: X,
      C: X,
      L: X,
      m: X,
      X,
      S: X,
      M: X
    },
    p: 0,
    findDOMNode: null
  }, q = /* @__PURE__ */ Symbol.for("react.portal");
  function Z(D, T, k) {
    var R = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
      $$typeof: q,
      key: R == null ? null : "" + R,
      children: D,
      containerInfo: T,
      implementation: k
    };
  }
  var ol = A.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
  function _l(D, T) {
    if (D === "font") return "";
    if (typeof T == "string")
      return T === "use-credentials" ? T : "";
  }
  return Rl.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = h, Rl.createPortal = function(D, T) {
    var k = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!T || T.nodeType !== 1 && T.nodeType !== 9 && T.nodeType !== 11)
      throw Error(j(299));
    return Z(D, T, null, k);
  }, Rl.flushSync = function(D) {
    var T = ol.T, k = h.p;
    try {
      if (ol.T = null, h.p = 2, D) return D();
    } finally {
      ol.T = T, h.p = k, h.d.f();
    }
  }, Rl.preconnect = function(D, T) {
    typeof D == "string" && (T ? (T = T.crossOrigin, T = typeof T == "string" ? T === "use-credentials" ? T : "" : void 0) : T = null, h.d.C(D, T));
  }, Rl.prefetchDNS = function(D) {
    typeof D == "string" && h.d.D(D);
  }, Rl.preinit = function(D, T) {
    if (typeof D == "string" && T && typeof T.as == "string") {
      var k = T.as, R = _l(k, T.crossOrigin), vl = typeof T.integrity == "string" ? T.integrity : void 0, Wl = typeof T.fetchPriority == "string" ? T.fetchPriority : void 0;
      k === "style" ? h.d.S(
        D,
        typeof T.precedence == "string" ? T.precedence : void 0,
        {
          crossOrigin: R,
          integrity: vl,
          fetchPriority: Wl
        }
      ) : k === "script" && h.d.X(D, {
        crossOrigin: R,
        integrity: vl,
        fetchPriority: Wl,
        nonce: typeof T.nonce == "string" ? T.nonce : void 0
      });
    }
  }, Rl.preinitModule = function(D, T) {
    if (typeof D == "string")
      if (typeof T == "object" && T !== null) {
        if (T.as == null || T.as === "script") {
          var k = _l(
            T.as,
            T.crossOrigin
          );
          h.d.M(D, {
            crossOrigin: k,
            integrity: typeof T.integrity == "string" ? T.integrity : void 0,
            nonce: typeof T.nonce == "string" ? T.nonce : void 0
          });
        }
      } else T == null && h.d.M(D);
  }, Rl.preload = function(D, T) {
    if (typeof D == "string" && typeof T == "object" && T !== null && typeof T.as == "string") {
      var k = T.as, R = _l(k, T.crossOrigin);
      h.d.L(D, k, {
        crossOrigin: R,
        integrity: typeof T.integrity == "string" ? T.integrity : void 0,
        nonce: typeof T.nonce == "string" ? T.nonce : void 0,
        type: typeof T.type == "string" ? T.type : void 0,
        fetchPriority: typeof T.fetchPriority == "string" ? T.fetchPriority : void 0,
        referrerPolicy: typeof T.referrerPolicy == "string" ? T.referrerPolicy : void 0,
        imageSrcSet: typeof T.imageSrcSet == "string" ? T.imageSrcSet : void 0,
        imageSizes: typeof T.imageSizes == "string" ? T.imageSizes : void 0,
        media: typeof T.media == "string" ? T.media : void 0
      });
    }
  }, Rl.preloadModule = function(D, T) {
    if (typeof D == "string")
      if (T) {
        var k = _l(T.as, T.crossOrigin);
        h.d.m(D, {
          as: typeof T.as == "string" && T.as !== "script" ? T.as : void 0,
          crossOrigin: k,
          integrity: typeof T.integrity == "string" ? T.integrity : void 0
        });
      } else h.d.m(D);
  }, Rl.requestFormReset = function(D) {
    h.d.r(D);
  }, Rl.unstable_batchedUpdates = function(D, T) {
    return D(T);
  }, Rl.useFormState = function(D, T, k) {
    return ol.H.useFormState(D, T, k);
  }, Rl.useFormStatus = function() {
    return ol.H.useHostTransitionStatus();
  }, Rl.version = "19.2.5", Rl;
}
var Av;
function dm() {
  if (Av) return vi.exports;
  Av = 1;
  function A() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A);
      } catch (j) {
        console.error(j);
      }
  }
  return A(), vi.exports = sm(), vi.exports;
}
var _v;
function vm() {
  if (_v) return ze;
  _v = 1;
  var A = im(), j = hi(), X = dm();
  function h(l) {
    var t = "https://react.dev/errors/" + l;
    if (1 < arguments.length) {
      t += "?args[]=" + encodeURIComponent(arguments[1]);
      for (var a = 2; a < arguments.length; a++)
        t += "&args[]=" + encodeURIComponent(arguments[a]);
    }
    return "Minified React error #" + l + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
  }
  function q(l) {
    return !(!l || l.nodeType !== 1 && l.nodeType !== 9 && l.nodeType !== 11);
  }
  function Z(l) {
    var t = l, a = l;
    if (l.alternate) for (; t.return; ) t = t.return;
    else {
      l = t;
      do
        t = l, (t.flags & 4098) !== 0 && (a = t.return), l = t.return;
      while (l);
    }
    return t.tag === 3 ? a : null;
  }
  function ol(l) {
    if (l.tag === 13) {
      var t = l.memoizedState;
      if (t === null && (l = l.alternate, l !== null && (t = l.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function _l(l) {
    if (l.tag === 31) {
      var t = l.memoizedState;
      if (t === null && (l = l.alternate, l !== null && (t = l.memoizedState)), t !== null) return t.dehydrated;
    }
    return null;
  }
  function D(l) {
    if (Z(l) !== l)
      throw Error(h(188));
  }
  function T(l) {
    var t = l.alternate;
    if (!t) {
      if (t = Z(l), t === null) throw Error(h(188));
      return t !== l ? null : l;
    }
    for (var a = l, u = t; ; ) {
      var e = a.return;
      if (e === null) break;
      var n = e.alternate;
      if (n === null) {
        if (u = e.return, u !== null) {
          a = u;
          continue;
        }
        break;
      }
      if (e.child === n.child) {
        for (n = e.child; n; ) {
          if (n === a) return D(e), l;
          if (n === u) return D(e), t;
          n = n.sibling;
        }
        throw Error(h(188));
      }
      if (a.return !== u.return) a = e, u = n;
      else {
        for (var f = !1, c = e.child; c; ) {
          if (c === a) {
            f = !0, a = e, u = n;
            break;
          }
          if (c === u) {
            f = !0, u = e, a = n;
            break;
          }
          c = c.sibling;
        }
        if (!f) {
          for (c = n.child; c; ) {
            if (c === a) {
              f = !0, a = n, u = e;
              break;
            }
            if (c === u) {
              f = !0, u = n, a = e;
              break;
            }
            c = c.sibling;
          }
          if (!f) throw Error(h(189));
        }
      }
      if (a.alternate !== u) throw Error(h(190));
    }
    if (a.tag !== 3) throw Error(h(188));
    return a.stateNode.current === a ? l : t;
  }
  function k(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l;
    for (l = l.child; l !== null; ) {
      if (t = k(l), t !== null) return t;
      l = l.sibling;
    }
    return null;
  }
  var R = Object.assign, vl = /* @__PURE__ */ Symbol.for("react.element"), Wl = /* @__PURE__ */ Symbol.for("react.transitional.element"), Bl = /* @__PURE__ */ Symbol.for("react.portal"), Cl = /* @__PURE__ */ Symbol.for("react.fragment"), Ut = /* @__PURE__ */ Symbol.for("react.strict_mode"), $l = /* @__PURE__ */ Symbol.for("react.profiler"), $t = /* @__PURE__ */ Symbol.for("react.consumer"), xl = /* @__PURE__ */ Symbol.for("react.context"), ft = /* @__PURE__ */ Symbol.for("react.forward_ref"), Et = /* @__PURE__ */ Symbol.for("react.suspense"), Yl = /* @__PURE__ */ Symbol.for("react.suspense_list"), W = /* @__PURE__ */ Symbol.for("react.memo"), Gl = /* @__PURE__ */ Symbol.for("react.lazy"), Tt = /* @__PURE__ */ Symbol.for("react.activity"), Qa = /* @__PURE__ */ Symbol.for("react.memo_cache_sentinel"), At = Symbol.iterator;
  function Xl(l) {
    return l === null || typeof l != "object" ? null : (l = At && l[At] || l["@@iterator"], typeof l == "function" ? l : null);
  }
  var Ea = /* @__PURE__ */ Symbol.for("react.client.reference");
  function Dt(l) {
    if (l == null) return null;
    if (typeof l == "function")
      return l.$$typeof === Ea ? null : l.displayName || l.name || null;
    if (typeof l == "string") return l;
    switch (l) {
      case Cl:
        return "Fragment";
      case $l:
        return "Profiler";
      case Ut:
        return "StrictMode";
      case Et:
        return "Suspense";
      case Yl:
        return "SuspenseList";
      case Tt:
        return "Activity";
    }
    if (typeof l == "object")
      switch (l.$$typeof) {
        case Bl:
          return "Portal";
        case xl:
          return l.displayName || "Context";
        case $t:
          return (l._context.displayName || "Context") + ".Consumer";
        case ft:
          var t = l.render;
          return l = l.displayName, l || (l = t.displayName || t.name || "", l = l !== "" ? "ForwardRef(" + l + ")" : "ForwardRef"), l;
        case W:
          return t = l.displayName || null, t !== null ? t : Dt(l.type) || "Memo";
        case Gl:
          t = l._payload, l = l._init;
          try {
            return Dt(l(t));
          } catch {
          }
      }
    return null;
  }
  var St = Array.isArray, r = j.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, _ = X.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, C = {
    pending: !1,
    data: null,
    method: null,
    action: null
  }, ul = [], cl = -1;
  function d(l) {
    return { current: l };
  }
  function E(l) {
    0 > cl || (l.current = ul[cl], ul[cl] = null, cl--);
  }
  function p(l, t) {
    cl++, ul[cl] = l.current, l.current = t;
  }
  var O = d(null), Y = d(null), V = d(null), ll = d(null);
  function ql(l, t) {
    switch (p(V, t), p(Y, l), p(O, null), t.nodeType) {
      case 9:
      case 11:
        l = (l = t.documentElement) && (l = l.namespaceURI) ? Gd(l) : 0;
        break;
      default:
        if (l = t.tagName, t = t.namespaceURI)
          t = Gd(t), l = Xd(t, l);
        else
          switch (l) {
            case "svg":
              l = 1;
              break;
            case "math":
              l = 2;
              break;
            default:
              l = 0;
          }
    }
    E(O), p(O, l);
  }
  function gl() {
    E(O), E(Y), E(V);
  }
  function Mu(l) {
    l.memoizedState !== null && p(ll, l);
    var t = O.current, a = Xd(t, l.type);
    t !== a && (p(Y, l), p(O, a));
  }
  function Ee(l) {
    Y.current === l && (E(O), E(Y)), ll.current === l && (E(ll), oe._currentValue = C);
  }
  var Qn, oi;
  function Ta(l) {
    if (Qn === void 0)
      try {
        throw Error();
      } catch (a) {
        var t = a.stack.trim().match(/\n( *(at )?)/);
        Qn = t && t[1] || "", oi = -1 < a.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < a.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
    return `
` + Qn + l + oi;
  }
  var Zn = !1;
  function Vn(l, t) {
    if (!l || Zn) return "";
    Zn = !0;
    var a = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
      var u = {
        DetermineComponentFrameRoot: function() {
          try {
            if (t) {
              var z = function() {
                throw Error();
              };
              if (Object.defineProperty(z.prototype, "props", {
                set: function() {
                  throw Error();
                }
              }), typeof Reflect == "object" && Reflect.construct) {
                try {
                  Reflect.construct(z, []);
                } catch (g) {
                  var o = g;
                }
                Reflect.construct(l, [], z);
              } else {
                try {
                  z.call();
                } catch (g) {
                  o = g;
                }
                l.call(z.prototype);
              }
            } else {
              try {
                throw Error();
              } catch (g) {
                o = g;
              }
              (z = l()) && typeof z.catch == "function" && z.catch(function() {
              });
            }
          } catch (g) {
            if (g && o && typeof g.stack == "string")
              return [g.stack, o.stack];
          }
          return [null, null];
        }
      };
      u.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
      var e = Object.getOwnPropertyDescriptor(
        u.DetermineComponentFrameRoot,
        "name"
      );
      e && e.configurable && Object.defineProperty(
        u.DetermineComponentFrameRoot,
        "name",
        { value: "DetermineComponentFrameRoot" }
      );
      var n = u.DetermineComponentFrameRoot(), f = n[0], c = n[1];
      if (f && c) {
        var i = f.split(`
`), m = c.split(`
`);
        for (e = u = 0; u < i.length && !i[u].includes("DetermineComponentFrameRoot"); )
          u++;
        for (; e < m.length && !m[e].includes(
          "DetermineComponentFrameRoot"
        ); )
          e++;
        if (u === i.length || e === m.length)
          for (u = i.length - 1, e = m.length - 1; 1 <= u && 0 <= e && i[u] !== m[e]; )
            e--;
        for (; 1 <= u && 0 <= e; u--, e--)
          if (i[u] !== m[e]) {
            if (u !== 1 || e !== 1)
              do
                if (u--, e--, 0 > e || i[u] !== m[e]) {
                  var S = `
` + i[u].replace(" at new ", " at ");
                  return l.displayName && S.includes("<anonymous>") && (S = S.replace("<anonymous>", l.displayName)), S;
                }
              while (1 <= u && 0 <= e);
            break;
          }
      }
    } finally {
      Zn = !1, Error.prepareStackTrace = a;
    }
    return (a = l ? l.displayName || l.name : "") ? Ta(a) : "";
  }
  function Rv(l, t) {
    switch (l.tag) {
      case 26:
      case 27:
      case 5:
        return Ta(l.type);
      case 16:
        return Ta("Lazy");
      case 13:
        return l.child !== t && t !== null ? Ta("Suspense Fallback") : Ta("Suspense");
      case 19:
        return Ta("SuspenseList");
      case 0:
      case 15:
        return Vn(l.type, !1);
      case 11:
        return Vn(l.type.render, !1);
      case 1:
        return Vn(l.type, !0);
      case 31:
        return Ta("Activity");
      default:
        return "";
    }
  }
  function gi(l) {
    try {
      var t = "", a = null;
      do
        t += Rv(l, a), a = l, l = l.return;
      while (l);
      return t;
    } catch (u) {
      return `
Error generating stack: ` + u.message + `
` + u.stack;
    }
  }
  var Ln = Object.prototype.hasOwnProperty, Kn = A.unstable_scheduleCallback, Jn = A.unstable_cancelCallback, Cv = A.unstable_shouldYield, qv = A.unstable_requestPaint, kl = A.unstable_now, jv = A.unstable_getCurrentPriorityLevel, Si = A.unstable_ImmediatePriority, ri = A.unstable_UserBlockingPriority, Te = A.unstable_NormalPriority, Bv = A.unstable_LowPriority, bi = A.unstable_IdlePriority, Yv = A.log, Gv = A.unstable_setDisableYieldValue, Ou = null, Fl = null;
  function kt(l) {
    if (typeof Yv == "function" && Gv(l), Fl && typeof Fl.setStrictMode == "function")
      try {
        Fl.setStrictMode(Ou, l);
      } catch {
      }
  }
  var Il = Math.clz32 ? Math.clz32 : Zv, Xv = Math.log, Qv = Math.LN2;
  function Zv(l) {
    return l >>>= 0, l === 0 ? 32 : 31 - (Xv(l) / Qv | 0) | 0;
  }
  var Ae = 256, _e = 262144, pe = 4194304;
  function Aa(l) {
    var t = l & 42;
    if (t !== 0) return t;
    switch (l & -l) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 4;
      case 8:
        return 8;
      case 16:
        return 16;
      case 32:
        return 32;
      case 64:
        return 64;
      case 128:
        return 128;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
        return l & 261888;
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return l & 3932160;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return l & 62914560;
      case 67108864:
        return 67108864;
      case 134217728:
        return 134217728;
      case 268435456:
        return 268435456;
      case 536870912:
        return 536870912;
      case 1073741824:
        return 0;
      default:
        return l;
    }
  }
  function Me(l, t, a) {
    var u = l.pendingLanes;
    if (u === 0) return 0;
    var e = 0, n = l.suspendedLanes, f = l.pingedLanes;
    l = l.warmLanes;
    var c = u & 134217727;
    return c !== 0 ? (u = c & ~n, u !== 0 ? e = Aa(u) : (f &= c, f !== 0 ? e = Aa(f) : a || (a = c & ~l, a !== 0 && (e = Aa(a))))) : (c = u & ~n, c !== 0 ? e = Aa(c) : f !== 0 ? e = Aa(f) : a || (a = u & ~l, a !== 0 && (e = Aa(a)))), e === 0 ? 0 : t !== 0 && t !== e && (t & n) === 0 && (n = e & -e, a = t & -t, n >= a || n === 32 && (a & 4194048) !== 0) ? t : e;
  }
  function Uu(l, t) {
    return (l.pendingLanes & ~(l.suspendedLanes & ~l.pingedLanes) & t) === 0;
  }
  function Vv(l, t) {
    switch (l) {
      case 1:
      case 2:
      case 4:
      case 8:
      case 64:
        return t + 250;
      case 16:
      case 32:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
        return t + 5e3;
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        return -1;
      case 67108864:
      case 134217728:
      case 268435456:
      case 536870912:
      case 1073741824:
        return -1;
      default:
        return -1;
    }
  }
  function zi() {
    var l = pe;
    return pe <<= 1, (pe & 62914560) === 0 && (pe = 4194304), l;
  }
  function wn(l) {
    for (var t = [], a = 0; 31 > a; a++) t.push(l);
    return t;
  }
  function Du(l, t) {
    l.pendingLanes |= t, t !== 268435456 && (l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0);
  }
  function Lv(l, t, a, u, e, n) {
    var f = l.pendingLanes;
    l.pendingLanes = a, l.suspendedLanes = 0, l.pingedLanes = 0, l.warmLanes = 0, l.expiredLanes &= a, l.entangledLanes &= a, l.errorRecoveryDisabledLanes &= a, l.shellSuspendCounter = 0;
    var c = l.entanglements, i = l.expirationTimes, m = l.hiddenUpdates;
    for (a = f & ~a; 0 < a; ) {
      var S = 31 - Il(a), z = 1 << S;
      c[S] = 0, i[S] = -1;
      var o = m[S];
      if (o !== null)
        for (m[S] = null, S = 0; S < o.length; S++) {
          var g = o[S];
          g !== null && (g.lane &= -536870913);
        }
      a &= ~z;
    }
    u !== 0 && Ei(l, u, 0), n !== 0 && e === 0 && l.tag !== 0 && (l.suspendedLanes |= n & ~(f & ~t));
  }
  function Ei(l, t, a) {
    l.pendingLanes |= t, l.suspendedLanes &= ~t;
    var u = 31 - Il(t);
    l.entangledLanes |= t, l.entanglements[u] = l.entanglements[u] | 1073741824 | a & 261930;
  }
  function Ti(l, t) {
    var a = l.entangledLanes |= t;
    for (l = l.entanglements; a; ) {
      var u = 31 - Il(a), e = 1 << u;
      e & t | l[u] & t && (l[u] |= t), a &= ~e;
    }
  }
  function Ai(l, t) {
    var a = t & -t;
    return a = (a & 42) !== 0 ? 1 : Wn(a), (a & (l.suspendedLanes | t)) !== 0 ? 0 : a;
  }
  function Wn(l) {
    switch (l) {
      case 2:
        l = 1;
        break;
      case 8:
        l = 4;
        break;
      case 32:
        l = 16;
        break;
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 16384:
      case 32768:
      case 65536:
      case 131072:
      case 262144:
      case 524288:
      case 1048576:
      case 2097152:
      case 4194304:
      case 8388608:
      case 16777216:
      case 33554432:
        l = 128;
        break;
      case 268435456:
        l = 134217728;
        break;
      default:
        l = 0;
    }
    return l;
  }
  function $n(l) {
    return l &= -l, 2 < l ? 8 < l ? (l & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
  }
  function _i() {
    var l = _.p;
    return l !== 0 ? l : (l = window.event, l === void 0 ? 32 : sv(l.type));
  }
  function pi(l, t) {
    var a = _.p;
    try {
      return _.p = l, t();
    } finally {
      _.p = a;
    }
  }
  var Ft = Math.random().toString(36).slice(2), Ol = "__reactFiber$" + Ft, Ql = "__reactProps$" + Ft, Za = "__reactContainer$" + Ft, kn = "__reactEvents$" + Ft, Kv = "__reactListeners$" + Ft, Jv = "__reactHandles$" + Ft, Mi = "__reactResources$" + Ft, Nu = "__reactMarker$" + Ft;
  function Fn(l) {
    delete l[Ol], delete l[Ql], delete l[kn], delete l[Kv], delete l[Jv];
  }
  function Va(l) {
    var t = l[Ol];
    if (t) return t;
    for (var a = l.parentNode; a; ) {
      if (t = a[Za] || a[Ol]) {
        if (a = t.alternate, t.child !== null || a !== null && a.child !== null)
          for (l = wd(l); l !== null; ) {
            if (a = l[Ol]) return a;
            l = wd(l);
          }
        return t;
      }
      l = a, a = l.parentNode;
    }
    return null;
  }
  function La(l) {
    if (l = l[Ol] || l[Za]) {
      var t = l.tag;
      if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3)
        return l;
    }
    return null;
  }
  function Hu(l) {
    var t = l.tag;
    if (t === 5 || t === 26 || t === 27 || t === 6) return l.stateNode;
    throw Error(h(33));
  }
  function Ka(l) {
    var t = l[Mi];
    return t || (t = l[Mi] = { hoistableStyles: /* @__PURE__ */ new Map(), hoistableScripts: /* @__PURE__ */ new Map() }), t;
  }
  function pl(l) {
    l[Nu] = !0;
  }
  var Oi = /* @__PURE__ */ new Set(), Ui = {};
  function _a(l, t) {
    Ja(l, t), Ja(l + "Capture", t);
  }
  function Ja(l, t) {
    for (Ui[l] = t, l = 0; l < t.length; l++)
      Oi.add(t[l]);
  }
  var wv = RegExp(
    "^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"
  ), Di = {}, Ni = {};
  function Wv(l) {
    return Ln.call(Ni, l) ? !0 : Ln.call(Di, l) ? !1 : wv.test(l) ? Ni[l] = !0 : (Di[l] = !0, !1);
  }
  function Oe(l, t, a) {
    if (Wv(t))
      if (a === null) l.removeAttribute(t);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
            l.removeAttribute(t);
            return;
          case "boolean":
            var u = t.toLowerCase().slice(0, 5);
            if (u !== "data-" && u !== "aria-") {
              l.removeAttribute(t);
              return;
            }
        }
        l.setAttribute(t, "" + a);
      }
  }
  function Ue(l, t, a) {
    if (a === null) l.removeAttribute(t);
    else {
      switch (typeof a) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          l.removeAttribute(t);
          return;
      }
      l.setAttribute(t, "" + a);
    }
  }
  function Nt(l, t, a, u) {
    if (u === null) l.removeAttribute(a);
    else {
      switch (typeof u) {
        case "undefined":
        case "function":
        case "symbol":
        case "boolean":
          l.removeAttribute(a);
          return;
      }
      l.setAttributeNS(t, a, "" + u);
    }
  }
  function ct(l) {
    switch (typeof l) {
      case "bigint":
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return l;
      case "object":
        return l;
      default:
        return "";
    }
  }
  function Hi(l) {
    var t = l.type;
    return (l = l.nodeName) && l.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
  }
  function $v(l, t, a) {
    var u = Object.getOwnPropertyDescriptor(
      l.constructor.prototype,
      t
    );
    if (!l.hasOwnProperty(t) && typeof u < "u" && typeof u.get == "function" && typeof u.set == "function") {
      var e = u.get, n = u.set;
      return Object.defineProperty(l, t, {
        configurable: !0,
        get: function() {
          return e.call(this);
        },
        set: function(f) {
          a = "" + f, n.call(this, f);
        }
      }), Object.defineProperty(l, t, {
        enumerable: u.enumerable
      }), {
        getValue: function() {
          return a;
        },
        setValue: function(f) {
          a = "" + f;
        },
        stopTracking: function() {
          l._valueTracker = null, delete l[t];
        }
      };
    }
  }
  function In(l) {
    if (!l._valueTracker) {
      var t = Hi(l) ? "checked" : "value";
      l._valueTracker = $v(
        l,
        t,
        "" + l[t]
      );
    }
  }
  function xi(l) {
    if (!l) return !1;
    var t = l._valueTracker;
    if (!t) return !0;
    var a = t.getValue(), u = "";
    return l && (u = Hi(l) ? l.checked ? "true" : "false" : l.value), l = u, l !== a ? (t.setValue(l), !0) : !1;
  }
  function De(l) {
    if (l = l || (typeof document < "u" ? document : void 0), typeof l > "u") return null;
    try {
      return l.activeElement || l.body;
    } catch {
      return l.body;
    }
  }
  var kv = /[\n"\\]/g;
  function it(l) {
    return l.replace(
      kv,
      function(t) {
        return "\\" + t.charCodeAt(0).toString(16) + " ";
      }
    );
  }
  function Pn(l, t, a, u, e, n, f, c) {
    l.name = "", f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" ? l.type = f : l.removeAttribute("type"), t != null ? f === "number" ? (t === 0 && l.value === "" || l.value != t) && (l.value = "" + ct(t)) : l.value !== "" + ct(t) && (l.value = "" + ct(t)) : f !== "submit" && f !== "reset" || l.removeAttribute("value"), t != null ? lf(l, f, ct(t)) : a != null ? lf(l, f, ct(a)) : u != null && l.removeAttribute("value"), e == null && n != null && (l.defaultChecked = !!n), e != null && (l.checked = e && typeof e != "function" && typeof e != "symbol"), c != null && typeof c != "function" && typeof c != "symbol" && typeof c != "boolean" ? l.name = "" + ct(c) : l.removeAttribute("name");
  }
  function Ri(l, t, a, u, e, n, f, c) {
    if (n != null && typeof n != "function" && typeof n != "symbol" && typeof n != "boolean" && (l.type = n), t != null || a != null) {
      if (!(n !== "submit" && n !== "reset" || t != null)) {
        In(l);
        return;
      }
      a = a != null ? "" + ct(a) : "", t = t != null ? "" + ct(t) : a, c || t === l.value || (l.value = t), l.defaultValue = t;
    }
    u = u ?? e, u = typeof u != "function" && typeof u != "symbol" && !!u, l.checked = c ? l.checked : !!u, l.defaultChecked = !!u, f != null && typeof f != "function" && typeof f != "symbol" && typeof f != "boolean" && (l.name = f), In(l);
  }
  function lf(l, t, a) {
    t === "number" && De(l.ownerDocument) === l || l.defaultValue === "" + a || (l.defaultValue = "" + a);
  }
  function wa(l, t, a, u) {
    if (l = l.options, t) {
      t = {};
      for (var e = 0; e < a.length; e++)
        t["$" + a[e]] = !0;
      for (a = 0; a < l.length; a++)
        e = t.hasOwnProperty("$" + l[a].value), l[a].selected !== e && (l[a].selected = e), e && u && (l[a].defaultSelected = !0);
    } else {
      for (a = "" + ct(a), t = null, e = 0; e < l.length; e++) {
        if (l[e].value === a) {
          l[e].selected = !0, u && (l[e].defaultSelected = !0);
          return;
        }
        t !== null || l[e].disabled || (t = l[e]);
      }
      t !== null && (t.selected = !0);
    }
  }
  function Ci(l, t, a) {
    if (t != null && (t = "" + ct(t), t !== l.value && (l.value = t), a == null)) {
      l.defaultValue !== t && (l.defaultValue = t);
      return;
    }
    l.defaultValue = a != null ? "" + ct(a) : "";
  }
  function qi(l, t, a, u) {
    if (t == null) {
      if (u != null) {
        if (a != null) throw Error(h(92));
        if (St(u)) {
          if (1 < u.length) throw Error(h(93));
          u = u[0];
        }
        a = u;
      }
      a == null && (a = ""), t = a;
    }
    a = ct(t), l.defaultValue = a, u = l.textContent, u === a && u !== "" && u !== null && (l.value = u), In(l);
  }
  function Wa(l, t) {
    if (t) {
      var a = l.firstChild;
      if (a && a === l.lastChild && a.nodeType === 3) {
        a.nodeValue = t;
        return;
      }
    }
    l.textContent = t;
  }
  var Fv = new Set(
    "animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(
      " "
    )
  );
  function ji(l, t, a) {
    var u = t.indexOf("--") === 0;
    a == null || typeof a == "boolean" || a === "" ? u ? l.setProperty(t, "") : t === "float" ? l.cssFloat = "" : l[t] = "" : u ? l.setProperty(t, a) : typeof a != "number" || a === 0 || Fv.has(t) ? t === "float" ? l.cssFloat = a : l[t] = ("" + a).trim() : l[t] = a + "px";
  }
  function Bi(l, t, a) {
    if (t != null && typeof t != "object")
      throw Error(h(62));
    if (l = l.style, a != null) {
      for (var u in a)
        !a.hasOwnProperty(u) || t != null && t.hasOwnProperty(u) || (u.indexOf("--") === 0 ? l.setProperty(u, "") : u === "float" ? l.cssFloat = "" : l[u] = "");
      for (var e in t)
        u = t[e], t.hasOwnProperty(e) && a[e] !== u && ji(l, e, u);
    } else
      for (var n in t)
        t.hasOwnProperty(n) && ji(l, n, t[n]);
  }
  function tf(l) {
    if (l.indexOf("-") === -1) return !1;
    switch (l) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var Iv = /* @__PURE__ */ new Map([
    ["acceptCharset", "accept-charset"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"],
    ["crossOrigin", "crossorigin"],
    ["accentHeight", "accent-height"],
    ["alignmentBaseline", "alignment-baseline"],
    ["arabicForm", "arabic-form"],
    ["baselineShift", "baseline-shift"],
    ["capHeight", "cap-height"],
    ["clipPath", "clip-path"],
    ["clipRule", "clip-rule"],
    ["colorInterpolation", "color-interpolation"],
    ["colorInterpolationFilters", "color-interpolation-filters"],
    ["colorProfile", "color-profile"],
    ["colorRendering", "color-rendering"],
    ["dominantBaseline", "dominant-baseline"],
    ["enableBackground", "enable-background"],
    ["fillOpacity", "fill-opacity"],
    ["fillRule", "fill-rule"],
    ["floodColor", "flood-color"],
    ["floodOpacity", "flood-opacity"],
    ["fontFamily", "font-family"],
    ["fontSize", "font-size"],
    ["fontSizeAdjust", "font-size-adjust"],
    ["fontStretch", "font-stretch"],
    ["fontStyle", "font-style"],
    ["fontVariant", "font-variant"],
    ["fontWeight", "font-weight"],
    ["glyphName", "glyph-name"],
    ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
    ["glyphOrientationVertical", "glyph-orientation-vertical"],
    ["horizAdvX", "horiz-adv-x"],
    ["horizOriginX", "horiz-origin-x"],
    ["imageRendering", "image-rendering"],
    ["letterSpacing", "letter-spacing"],
    ["lightingColor", "lighting-color"],
    ["markerEnd", "marker-end"],
    ["markerMid", "marker-mid"],
    ["markerStart", "marker-start"],
    ["overlinePosition", "overline-position"],
    ["overlineThickness", "overline-thickness"],
    ["paintOrder", "paint-order"],
    ["panose-1", "panose-1"],
    ["pointerEvents", "pointer-events"],
    ["renderingIntent", "rendering-intent"],
    ["shapeRendering", "shape-rendering"],
    ["stopColor", "stop-color"],
    ["stopOpacity", "stop-opacity"],
    ["strikethroughPosition", "strikethrough-position"],
    ["strikethroughThickness", "strikethrough-thickness"],
    ["strokeDasharray", "stroke-dasharray"],
    ["strokeDashoffset", "stroke-dashoffset"],
    ["strokeLinecap", "stroke-linecap"],
    ["strokeLinejoin", "stroke-linejoin"],
    ["strokeMiterlimit", "stroke-miterlimit"],
    ["strokeOpacity", "stroke-opacity"],
    ["strokeWidth", "stroke-width"],
    ["textAnchor", "text-anchor"],
    ["textDecoration", "text-decoration"],
    ["textRendering", "text-rendering"],
    ["transformOrigin", "transform-origin"],
    ["underlinePosition", "underline-position"],
    ["underlineThickness", "underline-thickness"],
    ["unicodeBidi", "unicode-bidi"],
    ["unicodeRange", "unicode-range"],
    ["unitsPerEm", "units-per-em"],
    ["vAlphabetic", "v-alphabetic"],
    ["vHanging", "v-hanging"],
    ["vIdeographic", "v-ideographic"],
    ["vMathematical", "v-mathematical"],
    ["vectorEffect", "vector-effect"],
    ["vertAdvY", "vert-adv-y"],
    ["vertOriginX", "vert-origin-x"],
    ["vertOriginY", "vert-origin-y"],
    ["wordSpacing", "word-spacing"],
    ["writingMode", "writing-mode"],
    ["xmlnsXlink", "xmlns:xlink"],
    ["xHeight", "x-height"]
  ]), Pv = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
  function Ne(l) {
    return Pv.test("" + l) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : l;
  }
  function Ht() {
  }
  var af = null;
  function uf(l) {
    return l = l.target || l.srcElement || window, l.correspondingUseElement && (l = l.correspondingUseElement), l.nodeType === 3 ? l.parentNode : l;
  }
  var $a = null, ka = null;
  function Yi(l) {
    var t = La(l);
    if (t && (l = t.stateNode)) {
      var a = l[Ql] || null;
      l: switch (l = t.stateNode, t.type) {
        case "input":
          if (Pn(
            l,
            a.value,
            a.defaultValue,
            a.defaultValue,
            a.checked,
            a.defaultChecked,
            a.type,
            a.name
          ), t = a.name, a.type === "radio" && t != null) {
            for (a = l; a.parentNode; ) a = a.parentNode;
            for (a = a.querySelectorAll(
              'input[name="' + it(
                "" + t
              ) + '"][type="radio"]'
            ), t = 0; t < a.length; t++) {
              var u = a[t];
              if (u !== l && u.form === l.form) {
                var e = u[Ql] || null;
                if (!e) throw Error(h(90));
                Pn(
                  u,
                  e.value,
                  e.defaultValue,
                  e.defaultValue,
                  e.checked,
                  e.defaultChecked,
                  e.type,
                  e.name
                );
              }
            }
            for (t = 0; t < a.length; t++)
              u = a[t], u.form === l.form && xi(u);
          }
          break l;
        case "textarea":
          Ci(l, a.value, a.defaultValue);
          break l;
        case "select":
          t = a.value, t != null && wa(l, !!a.multiple, t, !1);
      }
    }
  }
  var ef = !1;
  function Gi(l, t, a) {
    if (ef) return l(t, a);
    ef = !0;
    try {
      var u = l(t);
      return u;
    } finally {
      if (ef = !1, ($a !== null || ka !== null) && (rn(), $a && (t = $a, l = ka, ka = $a = null, Yi(t), l)))
        for (t = 0; t < l.length; t++) Yi(l[t]);
    }
  }
  function xu(l, t) {
    var a = l.stateNode;
    if (a === null) return null;
    var u = a[Ql] || null;
    if (u === null) return null;
    a = u[t];
    l: switch (t) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        (u = !u.disabled) || (l = l.type, u = !(l === "button" || l === "input" || l === "select" || l === "textarea")), l = !u;
        break l;
      default:
        l = !1;
    }
    if (l) return null;
    if (a && typeof a != "function")
      throw Error(
        h(231, t, typeof a)
      );
    return a;
  }
  var xt = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), nf = !1;
  if (xt)
    try {
      var Ru = {};
      Object.defineProperty(Ru, "passive", {
        get: function() {
          nf = !0;
        }
      }), window.addEventListener("test", Ru, Ru), window.removeEventListener("test", Ru, Ru);
    } catch {
      nf = !1;
    }
  var It = null, ff = null, He = null;
  function Xi() {
    if (He) return He;
    var l, t = ff, a = t.length, u, e = "value" in It ? It.value : It.textContent, n = e.length;
    for (l = 0; l < a && t[l] === e[l]; l++) ;
    var f = a - l;
    for (u = 1; u <= f && t[a - u] === e[n - u]; u++) ;
    return He = e.slice(l, 1 < u ? 1 - u : void 0);
  }
  function xe(l) {
    var t = l.keyCode;
    return "charCode" in l ? (l = l.charCode, l === 0 && t === 13 && (l = 13)) : l = t, l === 10 && (l = 13), 32 <= l || l === 13 ? l : 0;
  }
  function Re() {
    return !0;
  }
  function Qi() {
    return !1;
  }
  function Zl(l) {
    function t(a, u, e, n, f) {
      this._reactName = a, this._targetInst = e, this.type = u, this.nativeEvent = n, this.target = f, this.currentTarget = null;
      for (var c in l)
        l.hasOwnProperty(c) && (a = l[c], this[c] = a ? a(n) : n[c]);
      return this.isDefaultPrevented = (n.defaultPrevented != null ? n.defaultPrevented : n.returnValue === !1) ? Re : Qi, this.isPropagationStopped = Qi, this;
    }
    return R(t.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var a = this.nativeEvent;
        a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = !1), this.isDefaultPrevented = Re);
      },
      stopPropagation: function() {
        var a = this.nativeEvent;
        a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = !0), this.isPropagationStopped = Re);
      },
      persist: function() {
      },
      isPersistent: Re
    }), t;
  }
  var pa = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(l) {
      return l.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, Ce = Zl(pa), Cu = R({}, pa, { view: 0, detail: 0 }), ly = Zl(Cu), cf, sf, qu, qe = R({}, Cu, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: vf,
    button: 0,
    buttons: 0,
    relatedTarget: function(l) {
      return l.relatedTarget === void 0 ? l.fromElement === l.srcElement ? l.toElement : l.fromElement : l.relatedTarget;
    },
    movementX: function(l) {
      return "movementX" in l ? l.movementX : (l !== qu && (qu && l.type === "mousemove" ? (cf = l.screenX - qu.screenX, sf = l.screenY - qu.screenY) : sf = cf = 0, qu = l), cf);
    },
    movementY: function(l) {
      return "movementY" in l ? l.movementY : sf;
    }
  }), Zi = Zl(qe), ty = R({}, qe, { dataTransfer: 0 }), ay = Zl(ty), uy = R({}, Cu, { relatedTarget: 0 }), df = Zl(uy), ey = R({}, pa, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), ny = Zl(ey), fy = R({}, pa, {
    clipboardData: function(l) {
      return "clipboardData" in l ? l.clipboardData : window.clipboardData;
    }
  }), cy = Zl(fy), iy = R({}, pa, { data: 0 }), Vi = Zl(iy), sy = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, dy = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  }, vy = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function yy(l) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(l) : (l = vy[l]) ? !!t[l] : !1;
  }
  function vf() {
    return yy;
  }
  var my = R({}, Cu, {
    key: function(l) {
      if (l.key) {
        var t = sy[l.key] || l.key;
        if (t !== "Unidentified") return t;
      }
      return l.type === "keypress" ? (l = xe(l), l === 13 ? "Enter" : String.fromCharCode(l)) : l.type === "keydown" || l.type === "keyup" ? dy[l.keyCode] || "Unidentified" : "";
    },
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: vf,
    charCode: function(l) {
      return l.type === "keypress" ? xe(l) : 0;
    },
    keyCode: function(l) {
      return l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0;
    },
    which: function(l) {
      return l.type === "keypress" ? xe(l) : l.type === "keydown" || l.type === "keyup" ? l.keyCode : 0;
    }
  }), hy = Zl(my), oy = R({}, qe, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), Li = Zl(oy), gy = R({}, Cu, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: vf
  }), Sy = Zl(gy), ry = R({}, pa, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), by = Zl(ry), zy = R({}, qe, {
    deltaX: function(l) {
      return "deltaX" in l ? l.deltaX : "wheelDeltaX" in l ? -l.wheelDeltaX : 0;
    },
    deltaY: function(l) {
      return "deltaY" in l ? l.deltaY : "wheelDeltaY" in l ? -l.wheelDeltaY : "wheelDelta" in l ? -l.wheelDelta : 0;
    },
    deltaZ: 0,
    deltaMode: 0
  }), Ey = Zl(zy), Ty = R({}, pa, {
    newState: 0,
    oldState: 0
  }), Ay = Zl(Ty), _y = [9, 13, 27, 32], yf = xt && "CompositionEvent" in window, ju = null;
  xt && "documentMode" in document && (ju = document.documentMode);
  var py = xt && "TextEvent" in window && !ju, Ki = xt && (!yf || ju && 8 < ju && 11 >= ju), Ji = " ", wi = !1;
  function Wi(l, t) {
    switch (l) {
      case "keyup":
        return _y.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== 229;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function $i(l) {
    return l = l.detail, typeof l == "object" && "data" in l ? l.data : null;
  }
  var Fa = !1;
  function My(l, t) {
    switch (l) {
      case "compositionend":
        return $i(t);
      case "keypress":
        return t.which !== 32 ? null : (wi = !0, Ji);
      case "textInput":
        return l = t.data, l === Ji && wi ? null : l;
      default:
        return null;
    }
  }
  function Oy(l, t) {
    if (Fa)
      return l === "compositionend" || !yf && Wi(l, t) ? (l = Xi(), He = ff = It = null, Fa = !1, l) : null;
    switch (l) {
      case "paste":
        return null;
      case "keypress":
        if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
          if (t.char && 1 < t.char.length)
            return t.char;
          if (t.which) return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Ki && t.locale !== "ko" ? null : t.data;
      default:
        return null;
    }
  }
  var Uy = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function ki(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t === "input" ? !!Uy[l.type] : t === "textarea";
  }
  function Fi(l, t, a, u) {
    $a ? ka ? ka.push(u) : ka = [u] : $a = u, t = pn(t, "onChange"), 0 < t.length && (a = new Ce(
      "onChange",
      "change",
      null,
      a,
      u
    ), l.push({ event: a, listeners: t }));
  }
  var Bu = null, Yu = null;
  function Dy(l) {
    Rd(l, 0);
  }
  function je(l) {
    var t = Hu(l);
    if (xi(t)) return l;
  }
  function Ii(l, t) {
    if (l === "change") return t;
  }
  var Pi = !1;
  if (xt) {
    var mf;
    if (xt) {
      var hf = "oninput" in document;
      if (!hf) {
        var l0 = document.createElement("div");
        l0.setAttribute("oninput", "return;"), hf = typeof l0.oninput == "function";
      }
      mf = hf;
    } else mf = !1;
    Pi = mf && (!document.documentMode || 9 < document.documentMode);
  }
  function t0() {
    Bu && (Bu.detachEvent("onpropertychange", a0), Yu = Bu = null);
  }
  function a0(l) {
    if (l.propertyName === "value" && je(Yu)) {
      var t = [];
      Fi(
        t,
        Yu,
        l,
        uf(l)
      ), Gi(Dy, t);
    }
  }
  function Ny(l, t, a) {
    l === "focusin" ? (t0(), Bu = t, Yu = a, Bu.attachEvent("onpropertychange", a0)) : l === "focusout" && t0();
  }
  function Hy(l) {
    if (l === "selectionchange" || l === "keyup" || l === "keydown")
      return je(Yu);
  }
  function xy(l, t) {
    if (l === "click") return je(t);
  }
  function Ry(l, t) {
    if (l === "input" || l === "change")
      return je(t);
  }
  function Cy(l, t) {
    return l === t && (l !== 0 || 1 / l === 1 / t) || l !== l && t !== t;
  }
  var Pl = typeof Object.is == "function" ? Object.is : Cy;
  function Gu(l, t) {
    if (Pl(l, t)) return !0;
    if (typeof l != "object" || l === null || typeof t != "object" || t === null)
      return !1;
    var a = Object.keys(l), u = Object.keys(t);
    if (a.length !== u.length) return !1;
    for (u = 0; u < a.length; u++) {
      var e = a[u];
      if (!Ln.call(t, e) || !Pl(l[e], t[e]))
        return !1;
    }
    return !0;
  }
  function u0(l) {
    for (; l && l.firstChild; ) l = l.firstChild;
    return l;
  }
  function e0(l, t) {
    var a = u0(l);
    l = 0;
    for (var u; a; ) {
      if (a.nodeType === 3) {
        if (u = l + a.textContent.length, l <= t && u >= t)
          return { node: a, offset: t - l };
        l = u;
      }
      l: {
        for (; a; ) {
          if (a.nextSibling) {
            a = a.nextSibling;
            break l;
          }
          a = a.parentNode;
        }
        a = void 0;
      }
      a = u0(a);
    }
  }
  function n0(l, t) {
    return l && t ? l === t ? !0 : l && l.nodeType === 3 ? !1 : t && t.nodeType === 3 ? n0(l, t.parentNode) : "contains" in l ? l.contains(t) : l.compareDocumentPosition ? !!(l.compareDocumentPosition(t) & 16) : !1 : !1;
  }
  function f0(l) {
    l = l != null && l.ownerDocument != null && l.ownerDocument.defaultView != null ? l.ownerDocument.defaultView : window;
    for (var t = De(l.document); t instanceof l.HTMLIFrameElement; ) {
      try {
        var a = typeof t.contentWindow.location.href == "string";
      } catch {
        a = !1;
      }
      if (a) l = t.contentWindow;
      else break;
      t = De(l.document);
    }
    return t;
  }
  function of(l) {
    var t = l && l.nodeName && l.nodeName.toLowerCase();
    return t && (t === "input" && (l.type === "text" || l.type === "search" || l.type === "tel" || l.type === "url" || l.type === "password") || t === "textarea" || l.contentEditable === "true");
  }
  var qy = xt && "documentMode" in document && 11 >= document.documentMode, Ia = null, gf = null, Xu = null, Sf = !1;
  function c0(l, t, a) {
    var u = a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
    Sf || Ia == null || Ia !== De(u) || (u = Ia, "selectionStart" in u && of(u) ? u = { start: u.selectionStart, end: u.selectionEnd } : (u = (u.ownerDocument && u.ownerDocument.defaultView || window).getSelection(), u = {
      anchorNode: u.anchorNode,
      anchorOffset: u.anchorOffset,
      focusNode: u.focusNode,
      focusOffset: u.focusOffset
    }), Xu && Gu(Xu, u) || (Xu = u, u = pn(gf, "onSelect"), 0 < u.length && (t = new Ce(
      "onSelect",
      "select",
      null,
      t,
      a
    ), l.push({ event: t, listeners: u }), t.target = Ia)));
  }
  function Ma(l, t) {
    var a = {};
    return a[l.toLowerCase()] = t.toLowerCase(), a["Webkit" + l] = "webkit" + t, a["Moz" + l] = "moz" + t, a;
  }
  var Pa = {
    animationend: Ma("Animation", "AnimationEnd"),
    animationiteration: Ma("Animation", "AnimationIteration"),
    animationstart: Ma("Animation", "AnimationStart"),
    transitionrun: Ma("Transition", "TransitionRun"),
    transitionstart: Ma("Transition", "TransitionStart"),
    transitioncancel: Ma("Transition", "TransitionCancel"),
    transitionend: Ma("Transition", "TransitionEnd")
  }, rf = {}, i0 = {};
  xt && (i0 = document.createElement("div").style, "AnimationEvent" in window || (delete Pa.animationend.animation, delete Pa.animationiteration.animation, delete Pa.animationstart.animation), "TransitionEvent" in window || delete Pa.transitionend.transition);
  function Oa(l) {
    if (rf[l]) return rf[l];
    if (!Pa[l]) return l;
    var t = Pa[l], a;
    for (a in t)
      if (t.hasOwnProperty(a) && a in i0)
        return rf[l] = t[a];
    return l;
  }
  var s0 = Oa("animationend"), d0 = Oa("animationiteration"), v0 = Oa("animationstart"), jy = Oa("transitionrun"), By = Oa("transitionstart"), Yy = Oa("transitioncancel"), y0 = Oa("transitionend"), m0 = /* @__PURE__ */ new Map(), bf = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(
    " "
  );
  bf.push("scrollEnd");
  function rt(l, t) {
    m0.set(l, t), _a(t, [l]);
  }
  var Be = typeof reportError == "function" ? reportError : function(l) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var t = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof l == "object" && l !== null && typeof l.message == "string" ? String(l.message) : String(l),
        error: l
      });
      if (!window.dispatchEvent(t)) return;
    } else if (typeof process == "object" && typeof process.emit == "function") {
      process.emit("uncaughtException", l);
      return;
    }
    console.error(l);
  }, st = [], lu = 0, zf = 0;
  function Ye() {
    for (var l = lu, t = zf = lu = 0; t < l; ) {
      var a = st[t];
      st[t++] = null;
      var u = st[t];
      st[t++] = null;
      var e = st[t];
      st[t++] = null;
      var n = st[t];
      if (st[t++] = null, u !== null && e !== null) {
        var f = u.pending;
        f === null ? e.next = e : (e.next = f.next, f.next = e), u.pending = e;
      }
      n !== 0 && h0(a, e, n);
    }
  }
  function Ge(l, t, a, u) {
    st[lu++] = l, st[lu++] = t, st[lu++] = a, st[lu++] = u, zf |= u, l.lanes |= u, l = l.alternate, l !== null && (l.lanes |= u);
  }
  function Ef(l, t, a, u) {
    return Ge(l, t, a, u), Xe(l);
  }
  function Ua(l, t) {
    return Ge(l, null, null, t), Xe(l);
  }
  function h0(l, t, a) {
    l.lanes |= a;
    var u = l.alternate;
    u !== null && (u.lanes |= a);
    for (var e = !1, n = l.return; n !== null; )
      n.childLanes |= a, u = n.alternate, u !== null && (u.childLanes |= a), n.tag === 22 && (l = n.stateNode, l === null || l._visibility & 1 || (e = !0)), l = n, n = n.return;
    return l.tag === 3 ? (n = l.stateNode, e && t !== null && (e = 31 - Il(a), l = n.hiddenUpdates, u = l[e], u === null ? l[e] = [t] : u.push(t), t.lane = a | 536870912), n) : null;
  }
  function Xe(l) {
    if (50 < ie)
      throw ie = 0, Nc = null, Error(h(185));
    for (var t = l.return; t !== null; )
      l = t, t = l.return;
    return l.tag === 3 ? l.stateNode : null;
  }
  var tu = {};
  function Gy(l, t, a, u) {
    this.tag = l, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = u, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
  }
  function lt(l, t, a, u) {
    return new Gy(l, t, a, u);
  }
  function Tf(l) {
    return l = l.prototype, !(!l || !l.isReactComponent);
  }
  function Rt(l, t) {
    var a = l.alternate;
    return a === null ? (a = lt(
      l.tag,
      t,
      l.key,
      l.mode
    ), a.elementType = l.elementType, a.type = l.type, a.stateNode = l.stateNode, a.alternate = l, l.alternate = a) : (a.pendingProps = t, a.type = l.type, a.flags = 0, a.subtreeFlags = 0, a.deletions = null), a.flags = l.flags & 65011712, a.childLanes = l.childLanes, a.lanes = l.lanes, a.child = l.child, a.memoizedProps = l.memoizedProps, a.memoizedState = l.memoizedState, a.updateQueue = l.updateQueue, t = l.dependencies, a.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }, a.sibling = l.sibling, a.index = l.index, a.ref = l.ref, a.refCleanup = l.refCleanup, a;
  }
  function o0(l, t) {
    l.flags &= 65011714;
    var a = l.alternate;
    return a === null ? (l.childLanes = 0, l.lanes = t, l.child = null, l.subtreeFlags = 0, l.memoizedProps = null, l.memoizedState = null, l.updateQueue = null, l.dependencies = null, l.stateNode = null) : (l.childLanes = a.childLanes, l.lanes = a.lanes, l.child = a.child, l.subtreeFlags = 0, l.deletions = null, l.memoizedProps = a.memoizedProps, l.memoizedState = a.memoizedState, l.updateQueue = a.updateQueue, l.type = a.type, t = a.dependencies, l.dependencies = t === null ? null : {
      lanes: t.lanes,
      firstContext: t.firstContext
    }), l;
  }
  function Qe(l, t, a, u, e, n) {
    var f = 0;
    if (u = l, typeof l == "function") Tf(l) && (f = 1);
    else if (typeof l == "string")
      f = L1(
        l,
        a,
        O.current
      ) ? 26 : l === "html" || l === "head" || l === "body" ? 27 : 5;
    else
      l: switch (l) {
        case Tt:
          return l = lt(31, a, t, e), l.elementType = Tt, l.lanes = n, l;
        case Cl:
          return Da(a.children, e, n, t);
        case Ut:
          f = 8, e |= 24;
          break;
        case $l:
          return l = lt(12, a, t, e | 2), l.elementType = $l, l.lanes = n, l;
        case Et:
          return l = lt(13, a, t, e), l.elementType = Et, l.lanes = n, l;
        case Yl:
          return l = lt(19, a, t, e), l.elementType = Yl, l.lanes = n, l;
        default:
          if (typeof l == "object" && l !== null)
            switch (l.$$typeof) {
              case xl:
                f = 10;
                break l;
              case $t:
                f = 9;
                break l;
              case ft:
                f = 11;
                break l;
              case W:
                f = 14;
                break l;
              case Gl:
                f = 16, u = null;
                break l;
            }
          f = 29, a = Error(
            h(130, l === null ? "null" : typeof l, "")
          ), u = null;
      }
    return t = lt(f, a, t, e), t.elementType = l, t.type = u, t.lanes = n, t;
  }
  function Da(l, t, a, u) {
    return l = lt(7, l, u, t), l.lanes = a, l;
  }
  function Af(l, t, a) {
    return l = lt(6, l, null, t), l.lanes = a, l;
  }
  function g0(l) {
    var t = lt(18, null, null, 0);
    return t.stateNode = l, t;
  }
  function _f(l, t, a) {
    return t = lt(
      4,
      l.children !== null ? l.children : [],
      l.key,
      t
    ), t.lanes = a, t.stateNode = {
      containerInfo: l.containerInfo,
      pendingChildren: null,
      implementation: l.implementation
    }, t;
  }
  var S0 = /* @__PURE__ */ new WeakMap();
  function dt(l, t) {
    if (typeof l == "object" && l !== null) {
      var a = S0.get(l);
      return a !== void 0 ? a : (t = {
        value: l,
        source: t,
        stack: gi(t)
      }, S0.set(l, t), t);
    }
    return {
      value: l,
      source: t,
      stack: gi(t)
    };
  }
  var au = [], uu = 0, Ze = null, Qu = 0, vt = [], yt = 0, Pt = null, _t = 1, pt = "";
  function Ct(l, t) {
    au[uu++] = Qu, au[uu++] = Ze, Ze = l, Qu = t;
  }
  function r0(l, t, a) {
    vt[yt++] = _t, vt[yt++] = pt, vt[yt++] = Pt, Pt = l;
    var u = _t;
    l = pt;
    var e = 32 - Il(u) - 1;
    u &= ~(1 << e), a += 1;
    var n = 32 - Il(t) + e;
    if (30 < n) {
      var f = e - e % 5;
      n = (u & (1 << f) - 1).toString(32), u >>= f, e -= f, _t = 1 << 32 - Il(t) + e | a << e | u, pt = n + l;
    } else
      _t = 1 << n | a << e | u, pt = l;
  }
  function pf(l) {
    l.return !== null && (Ct(l, 1), r0(l, 1, 0));
  }
  function Mf(l) {
    for (; l === Ze; )
      Ze = au[--uu], au[uu] = null, Qu = au[--uu], au[uu] = null;
    for (; l === Pt; )
      Pt = vt[--yt], vt[yt] = null, pt = vt[--yt], vt[yt] = null, _t = vt[--yt], vt[yt] = null;
  }
  function b0(l, t) {
    vt[yt++] = _t, vt[yt++] = pt, vt[yt++] = Pt, _t = t.id, pt = t.overflow, Pt = l;
  }
  var Ul = null, sl = null, $ = !1, la = null, mt = !1, Of = Error(h(519));
  function ta(l) {
    var t = Error(
      h(
        418,
        1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML",
        ""
      )
    );
    throw Zu(dt(t, l)), Of;
  }
  function z0(l) {
    var t = l.stateNode, a = l.type, u = l.memoizedProps;
    switch (t[Ol] = l, t[Ql] = u, a) {
      case "dialog":
        K("cancel", t), K("close", t);
        break;
      case "iframe":
      case "object":
      case "embed":
        K("load", t);
        break;
      case "video":
      case "audio":
        for (a = 0; a < de.length; a++)
          K(de[a], t);
        break;
      case "source":
        K("error", t);
        break;
      case "img":
      case "image":
      case "link":
        K("error", t), K("load", t);
        break;
      case "details":
        K("toggle", t);
        break;
      case "input":
        K("invalid", t), Ri(
          t,
          u.value,
          u.defaultValue,
          u.checked,
          u.defaultChecked,
          u.type,
          u.name,
          !0
        );
        break;
      case "select":
        K("invalid", t);
        break;
      case "textarea":
        K("invalid", t), qi(t, u.value, u.defaultValue, u.children);
    }
    a = u.children, typeof a != "string" && typeof a != "number" && typeof a != "bigint" || t.textContent === "" + a || u.suppressHydrationWarning === !0 || Bd(t.textContent, a) ? (u.popover != null && (K("beforetoggle", t), K("toggle", t)), u.onScroll != null && K("scroll", t), u.onScrollEnd != null && K("scrollend", t), u.onClick != null && (t.onclick = Ht), t = !0) : t = !1, t || ta(l, !0);
  }
  function E0(l) {
    for (Ul = l.return; Ul; )
      switch (Ul.tag) {
        case 5:
        case 31:
        case 13:
          mt = !1;
          return;
        case 27:
        case 3:
          mt = !0;
          return;
        default:
          Ul = Ul.return;
      }
  }
  function eu(l) {
    if (l !== Ul) return !1;
    if (!$) return E0(l), $ = !0, !1;
    var t = l.tag, a;
    if ((a = t !== 3 && t !== 27) && ((a = t === 5) && (a = l.type, a = !(a !== "form" && a !== "button") || Kc(l.type, l.memoizedProps)), a = !a), a && sl && ta(l), E0(l), t === 13) {
      if (l = l.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(h(317));
      sl = Jd(l);
    } else if (t === 31) {
      if (l = l.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(h(317));
      sl = Jd(l);
    } else
      t === 27 ? (t = sl, oa(l.type) ? (l = kc, kc = null, sl = l) : sl = t) : sl = Ul ? ot(l.stateNode.nextSibling) : null;
    return !0;
  }
  function Na() {
    sl = Ul = null, $ = !1;
  }
  function Uf() {
    var l = la;
    return l !== null && (Jl === null ? Jl = l : Jl.push.apply(
      Jl,
      l
    ), la = null), l;
  }
  function Zu(l) {
    la === null ? la = [l] : la.push(l);
  }
  var Df = d(null), Ha = null, qt = null;
  function aa(l, t, a) {
    p(Df, t._currentValue), t._currentValue = a;
  }
  function jt(l) {
    l._currentValue = Df.current, E(Df);
  }
  function Nf(l, t, a) {
    for (; l !== null; ) {
      var u = l.alternate;
      if ((l.childLanes & t) !== t ? (l.childLanes |= t, u !== null && (u.childLanes |= t)) : u !== null && (u.childLanes & t) !== t && (u.childLanes |= t), l === a) break;
      l = l.return;
    }
  }
  function Hf(l, t, a, u) {
    var e = l.child;
    for (e !== null && (e.return = l); e !== null; ) {
      var n = e.dependencies;
      if (n !== null) {
        var f = e.child;
        n = n.firstContext;
        l: for (; n !== null; ) {
          var c = n;
          n = e;
          for (var i = 0; i < t.length; i++)
            if (c.context === t[i]) {
              n.lanes |= a, c = n.alternate, c !== null && (c.lanes |= a), Nf(
                n.return,
                a,
                l
              ), u || (f = null);
              break l;
            }
          n = c.next;
        }
      } else if (e.tag === 18) {
        if (f = e.return, f === null) throw Error(h(341));
        f.lanes |= a, n = f.alternate, n !== null && (n.lanes |= a), Nf(f, a, l), f = null;
      } else f = e.child;
      if (f !== null) f.return = e;
      else
        for (f = e; f !== null; ) {
          if (f === l) {
            f = null;
            break;
          }
          if (e = f.sibling, e !== null) {
            e.return = f.return, f = e;
            break;
          }
          f = f.return;
        }
      e = f;
    }
  }
  function nu(l, t, a, u) {
    l = null;
    for (var e = t, n = !1; e !== null; ) {
      if (!n) {
        if ((e.flags & 524288) !== 0) n = !0;
        else if ((e.flags & 262144) !== 0) break;
      }
      if (e.tag === 10) {
        var f = e.alternate;
        if (f === null) throw Error(h(387));
        if (f = f.memoizedProps, f !== null) {
          var c = e.type;
          Pl(e.pendingProps.value, f.value) || (l !== null ? l.push(c) : l = [c]);
        }
      } else if (e === ll.current) {
        if (f = e.alternate, f === null) throw Error(h(387));
        f.memoizedState.memoizedState !== e.memoizedState.memoizedState && (l !== null ? l.push(oe) : l = [oe]);
      }
      e = e.return;
    }
    l !== null && Hf(
      t,
      l,
      a,
      u
    ), t.flags |= 262144;
  }
  function Ve(l) {
    for (l = l.firstContext; l !== null; ) {
      if (!Pl(
        l.context._currentValue,
        l.memoizedValue
      ))
        return !0;
      l = l.next;
    }
    return !1;
  }
  function xa(l) {
    Ha = l, qt = null, l = l.dependencies, l !== null && (l.firstContext = null);
  }
  function Dl(l) {
    return T0(Ha, l);
  }
  function Le(l, t) {
    return Ha === null && xa(l), T0(l, t);
  }
  function T0(l, t) {
    var a = t._currentValue;
    if (t = { context: t, memoizedValue: a, next: null }, qt === null) {
      if (l === null) throw Error(h(308));
      qt = t, l.dependencies = { lanes: 0, firstContext: t }, l.flags |= 524288;
    } else qt = qt.next = t;
    return a;
  }
  var Xy = typeof AbortController < "u" ? AbortController : function() {
    var l = [], t = this.signal = {
      aborted: !1,
      addEventListener: function(a, u) {
        l.push(u);
      }
    };
    this.abort = function() {
      t.aborted = !0, l.forEach(function(a) {
        return a();
      });
    };
  }, Qy = A.unstable_scheduleCallback, Zy = A.unstable_NormalPriority, bl = {
    $$typeof: xl,
    Consumer: null,
    Provider: null,
    _currentValue: null,
    _currentValue2: null,
    _threadCount: 0
  };
  function xf() {
    return {
      controller: new Xy(),
      data: /* @__PURE__ */ new Map(),
      refCount: 0
    };
  }
  function Vu(l) {
    l.refCount--, l.refCount === 0 && Qy(Zy, function() {
      l.controller.abort();
    });
  }
  var Lu = null, Rf = 0, fu = 0, cu = null;
  function Vy(l, t) {
    if (Lu === null) {
      var a = Lu = [];
      Rf = 0, fu = jc(), cu = {
        status: "pending",
        value: void 0,
        then: function(u) {
          a.push(u);
        }
      };
    }
    return Rf++, t.then(A0, A0), t;
  }
  function A0() {
    if (--Rf === 0 && Lu !== null) {
      cu !== null && (cu.status = "fulfilled");
      var l = Lu;
      Lu = null, fu = 0, cu = null;
      for (var t = 0; t < l.length; t++) (0, l[t])();
    }
  }
  function Ly(l, t) {
    var a = [], u = {
      status: "pending",
      value: null,
      reason: null,
      then: function(e) {
        a.push(e);
      }
    };
    return l.then(
      function() {
        u.status = "fulfilled", u.value = t;
        for (var e = 0; e < a.length; e++) (0, a[e])(t);
      },
      function(e) {
        for (u.status = "rejected", u.reason = e, e = 0; e < a.length; e++)
          (0, a[e])(void 0);
      }
    ), u;
  }
  var _0 = r.S;
  r.S = function(l, t) {
    cd = kl(), typeof t == "object" && t !== null && typeof t.then == "function" && Vy(l, t), _0 !== null && _0(l, t);
  };
  var Ra = d(null);
  function Cf() {
    var l = Ra.current;
    return l !== null ? l : il.pooledCache;
  }
  function Ke(l, t) {
    t === null ? p(Ra, Ra.current) : p(Ra, t.pool);
  }
  function p0() {
    var l = Cf();
    return l === null ? null : { parent: bl._currentValue, pool: l };
  }
  var iu = Error(h(460)), qf = Error(h(474)), Je = Error(h(542)), we = { then: function() {
  } };
  function M0(l) {
    return l = l.status, l === "fulfilled" || l === "rejected";
  }
  function O0(l, t, a) {
    switch (a = l[a], a === void 0 ? l.push(t) : a !== t && (t.then(Ht, Ht), t = a), t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw l = t.reason, D0(l), l;
      default:
        if (typeof t.status == "string") t.then(Ht, Ht);
        else {
          if (l = il, l !== null && 100 < l.shellSuspendCounter)
            throw Error(h(482));
          l = t, l.status = "pending", l.then(
            function(u) {
              if (t.status === "pending") {
                var e = t;
                e.status = "fulfilled", e.value = u;
              }
            },
            function(u) {
              if (t.status === "pending") {
                var e = t;
                e.status = "rejected", e.reason = u;
              }
            }
          );
        }
        switch (t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw l = t.reason, D0(l), l;
        }
        throw qa = t, iu;
    }
  }
  function Ca(l) {
    try {
      var t = l._init;
      return t(l._payload);
    } catch (a) {
      throw a !== null && typeof a == "object" && typeof a.then == "function" ? (qa = a, iu) : a;
    }
  }
  var qa = null;
  function U0() {
    if (qa === null) throw Error(h(459));
    var l = qa;
    return qa = null, l;
  }
  function D0(l) {
    if (l === iu || l === Je)
      throw Error(h(483));
  }
  var su = null, Ku = 0;
  function We(l) {
    var t = Ku;
    return Ku += 1, su === null && (su = []), O0(su, l, t);
  }
  function Ju(l, t) {
    t = t.props.ref, l.ref = t !== void 0 ? t : null;
  }
  function $e(l, t) {
    throw t.$$typeof === vl ? Error(h(525)) : (l = Object.prototype.toString.call(t), Error(
      h(
        31,
        l === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : l
      )
    ));
  }
  function N0(l) {
    function t(v, s) {
      if (l) {
        var y = v.deletions;
        y === null ? (v.deletions = [s], v.flags |= 16) : y.push(s);
      }
    }
    function a(v, s) {
      if (!l) return null;
      for (; s !== null; )
        t(v, s), s = s.sibling;
      return null;
    }
    function u(v) {
      for (var s = /* @__PURE__ */ new Map(); v !== null; )
        v.key !== null ? s.set(v.key, v) : s.set(v.index, v), v = v.sibling;
      return s;
    }
    function e(v, s) {
      return v = Rt(v, s), v.index = 0, v.sibling = null, v;
    }
    function n(v, s, y) {
      return v.index = y, l ? (y = v.alternate, y !== null ? (y = y.index, y < s ? (v.flags |= 67108866, s) : y) : (v.flags |= 67108866, s)) : (v.flags |= 1048576, s);
    }
    function f(v) {
      return l && v.alternate === null && (v.flags |= 67108866), v;
    }
    function c(v, s, y, b) {
      return s === null || s.tag !== 6 ? (s = Af(y, v.mode, b), s.return = v, s) : (s = e(s, y), s.return = v, s);
    }
    function i(v, s, y, b) {
      var N = y.type;
      return N === Cl ? S(
        v,
        s,
        y.props.children,
        b,
        y.key
      ) : s !== null && (s.elementType === N || typeof N == "object" && N !== null && N.$$typeof === Gl && Ca(N) === s.type) ? (s = e(s, y.props), Ju(s, y), s.return = v, s) : (s = Qe(
        y.type,
        y.key,
        y.props,
        null,
        v.mode,
        b
      ), Ju(s, y), s.return = v, s);
    }
    function m(v, s, y, b) {
      return s === null || s.tag !== 4 || s.stateNode.containerInfo !== y.containerInfo || s.stateNode.implementation !== y.implementation ? (s = _f(y, v.mode, b), s.return = v, s) : (s = e(s, y.children || []), s.return = v, s);
    }
    function S(v, s, y, b, N) {
      return s === null || s.tag !== 7 ? (s = Da(
        y,
        v.mode,
        b,
        N
      ), s.return = v, s) : (s = e(s, y), s.return = v, s);
    }
    function z(v, s, y) {
      if (typeof s == "string" && s !== "" || typeof s == "number" || typeof s == "bigint")
        return s = Af(
          "" + s,
          v.mode,
          y
        ), s.return = v, s;
      if (typeof s == "object" && s !== null) {
        switch (s.$$typeof) {
          case Wl:
            return y = Qe(
              s.type,
              s.key,
              s.props,
              null,
              v.mode,
              y
            ), Ju(y, s), y.return = v, y;
          case Bl:
            return s = _f(
              s,
              v.mode,
              y
            ), s.return = v, s;
          case Gl:
            return s = Ca(s), z(v, s, y);
        }
        if (St(s) || Xl(s))
          return s = Da(
            s,
            v.mode,
            y,
            null
          ), s.return = v, s;
        if (typeof s.then == "function")
          return z(v, We(s), y);
        if (s.$$typeof === xl)
          return z(
            v,
            Le(v, s),
            y
          );
        $e(v, s);
      }
      return null;
    }
    function o(v, s, y, b) {
      var N = s !== null ? s.key : null;
      if (typeof y == "string" && y !== "" || typeof y == "number" || typeof y == "bigint")
        return N !== null ? null : c(v, s, "" + y, b);
      if (typeof y == "object" && y !== null) {
        switch (y.$$typeof) {
          case Wl:
            return y.key === N ? i(v, s, y, b) : null;
          case Bl:
            return y.key === N ? m(v, s, y, b) : null;
          case Gl:
            return y = Ca(y), o(v, s, y, b);
        }
        if (St(y) || Xl(y))
          return N !== null ? null : S(v, s, y, b, null);
        if (typeof y.then == "function")
          return o(
            v,
            s,
            We(y),
            b
          );
        if (y.$$typeof === xl)
          return o(
            v,
            s,
            Le(v, y),
            b
          );
        $e(v, y);
      }
      return null;
    }
    function g(v, s, y, b, N) {
      if (typeof b == "string" && b !== "" || typeof b == "number" || typeof b == "bigint")
        return v = v.get(y) || null, c(s, v, "" + b, N);
      if (typeof b == "object" && b !== null) {
        switch (b.$$typeof) {
          case Wl:
            return v = v.get(
              b.key === null ? y : b.key
            ) || null, i(s, v, b, N);
          case Bl:
            return v = v.get(
              b.key === null ? y : b.key
            ) || null, m(s, v, b, N);
          case Gl:
            return b = Ca(b), g(
              v,
              s,
              y,
              b,
              N
            );
        }
        if (St(b) || Xl(b))
          return v = v.get(y) || null, S(s, v, b, N, null);
        if (typeof b.then == "function")
          return g(
            v,
            s,
            y,
            We(b),
            N
          );
        if (b.$$typeof === xl)
          return g(
            v,
            s,
            y,
            Le(s, b),
            N
          );
        $e(s, b);
      }
      return null;
    }
    function M(v, s, y, b) {
      for (var N = null, F = null, U = s, Q = s = 0, w = null; U !== null && Q < y.length; Q++) {
        U.index > Q ? (w = U, U = null) : w = U.sibling;
        var I = o(
          v,
          U,
          y[Q],
          b
        );
        if (I === null) {
          U === null && (U = w);
          break;
        }
        l && U && I.alternate === null && t(v, U), s = n(I, s, Q), F === null ? N = I : F.sibling = I, F = I, U = w;
      }
      if (Q === y.length)
        return a(v, U), $ && Ct(v, Q), N;
      if (U === null) {
        for (; Q < y.length; Q++)
          U = z(v, y[Q], b), U !== null && (s = n(
            U,
            s,
            Q
          ), F === null ? N = U : F.sibling = U, F = U);
        return $ && Ct(v, Q), N;
      }
      for (U = u(U); Q < y.length; Q++)
        w = g(
          U,
          v,
          Q,
          y[Q],
          b
        ), w !== null && (l && w.alternate !== null && U.delete(
          w.key === null ? Q : w.key
        ), s = n(
          w,
          s,
          Q
        ), F === null ? N = w : F.sibling = w, F = w);
      return l && U.forEach(function(za) {
        return t(v, za);
      }), $ && Ct(v, Q), N;
    }
    function H(v, s, y, b) {
      if (y == null) throw Error(h(151));
      for (var N = null, F = null, U = s, Q = s = 0, w = null, I = y.next(); U !== null && !I.done; Q++, I = y.next()) {
        U.index > Q ? (w = U, U = null) : w = U.sibling;
        var za = o(v, U, I.value, b);
        if (za === null) {
          U === null && (U = w);
          break;
        }
        l && U && za.alternate === null && t(v, U), s = n(za, s, Q), F === null ? N = za : F.sibling = za, F = za, U = w;
      }
      if (I.done)
        return a(v, U), $ && Ct(v, Q), N;
      if (U === null) {
        for (; !I.done; Q++, I = y.next())
          I = z(v, I.value, b), I !== null && (s = n(I, s, Q), F === null ? N = I : F.sibling = I, F = I);
        return $ && Ct(v, Q), N;
      }
      for (U = u(U); !I.done; Q++, I = y.next())
        I = g(U, v, Q, I.value, b), I !== null && (l && I.alternate !== null && U.delete(I.key === null ? Q : I.key), s = n(I, s, Q), F === null ? N = I : F.sibling = I, F = I);
      return l && U.forEach(function(tm) {
        return t(v, tm);
      }), $ && Ct(v, Q), N;
    }
    function fl(v, s, y, b) {
      if (typeof y == "object" && y !== null && y.type === Cl && y.key === null && (y = y.props.children), typeof y == "object" && y !== null) {
        switch (y.$$typeof) {
          case Wl:
            l: {
              for (var N = y.key; s !== null; ) {
                if (s.key === N) {
                  if (N = y.type, N === Cl) {
                    if (s.tag === 7) {
                      a(
                        v,
                        s.sibling
                      ), b = e(
                        s,
                        y.props.children
                      ), b.return = v, v = b;
                      break l;
                    }
                  } else if (s.elementType === N || typeof N == "object" && N !== null && N.$$typeof === Gl && Ca(N) === s.type) {
                    a(
                      v,
                      s.sibling
                    ), b = e(s, y.props), Ju(b, y), b.return = v, v = b;
                    break l;
                  }
                  a(v, s);
                  break;
                } else t(v, s);
                s = s.sibling;
              }
              y.type === Cl ? (b = Da(
                y.props.children,
                v.mode,
                b,
                y.key
              ), b.return = v, v = b) : (b = Qe(
                y.type,
                y.key,
                y.props,
                null,
                v.mode,
                b
              ), Ju(b, y), b.return = v, v = b);
            }
            return f(v);
          case Bl:
            l: {
              for (N = y.key; s !== null; ) {
                if (s.key === N)
                  if (s.tag === 4 && s.stateNode.containerInfo === y.containerInfo && s.stateNode.implementation === y.implementation) {
                    a(
                      v,
                      s.sibling
                    ), b = e(s, y.children || []), b.return = v, v = b;
                    break l;
                  } else {
                    a(v, s);
                    break;
                  }
                else t(v, s);
                s = s.sibling;
              }
              b = _f(y, v.mode, b), b.return = v, v = b;
            }
            return f(v);
          case Gl:
            return y = Ca(y), fl(
              v,
              s,
              y,
              b
            );
        }
        if (St(y))
          return M(
            v,
            s,
            y,
            b
          );
        if (Xl(y)) {
          if (N = Xl(y), typeof N != "function") throw Error(h(150));
          return y = N.call(y), H(
            v,
            s,
            y,
            b
          );
        }
        if (typeof y.then == "function")
          return fl(
            v,
            s,
            We(y),
            b
          );
        if (y.$$typeof === xl)
          return fl(
            v,
            s,
            Le(v, y),
            b
          );
        $e(v, y);
      }
      return typeof y == "string" && y !== "" || typeof y == "number" || typeof y == "bigint" ? (y = "" + y, s !== null && s.tag === 6 ? (a(v, s.sibling), b = e(s, y), b.return = v, v = b) : (a(v, s), b = Af(y, v.mode, b), b.return = v, v = b), f(v)) : a(v, s);
    }
    return function(v, s, y, b) {
      try {
        Ku = 0;
        var N = fl(
          v,
          s,
          y,
          b
        );
        return su = null, N;
      } catch (U) {
        if (U === iu || U === Je) throw U;
        var F = lt(29, U, null, v.mode);
        return F.lanes = b, F.return = v, F;
      }
    };
  }
  var ja = N0(!0), H0 = N0(!1), ua = !1;
  function jf(l) {
    l.updateQueue = {
      baseState: l.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: { pending: null, lanes: 0, hiddenCallbacks: null },
      callbacks: null
    };
  }
  function Bf(l, t) {
    l = l.updateQueue, t.updateQueue === l && (t.updateQueue = {
      baseState: l.baseState,
      firstBaseUpdate: l.firstBaseUpdate,
      lastBaseUpdate: l.lastBaseUpdate,
      shared: l.shared,
      callbacks: null
    });
  }
  function ea(l) {
    return { lane: l, tag: 0, payload: null, callback: null, next: null };
  }
  function na(l, t, a) {
    var u = l.updateQueue;
    if (u === null) return null;
    if (u = u.shared, (P & 2) !== 0) {
      var e = u.pending;
      return e === null ? t.next = t : (t.next = e.next, e.next = t), u.pending = t, t = Xe(l), h0(l, null, a), t;
    }
    return Ge(l, u, t, a), Xe(l);
  }
  function wu(l, t, a) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (a & 4194048) !== 0)) {
      var u = t.lanes;
      u &= l.pendingLanes, a |= u, t.lanes = a, Ti(l, a);
    }
  }
  function Yf(l, t) {
    var a = l.updateQueue, u = l.alternate;
    if (u !== null && (u = u.updateQueue, a === u)) {
      var e = null, n = null;
      if (a = a.firstBaseUpdate, a !== null) {
        do {
          var f = {
            lane: a.lane,
            tag: a.tag,
            payload: a.payload,
            callback: null,
            next: null
          };
          n === null ? e = n = f : n = n.next = f, a = a.next;
        } while (a !== null);
        n === null ? e = n = t : n = n.next = t;
      } else e = n = t;
      a = {
        baseState: u.baseState,
        firstBaseUpdate: e,
        lastBaseUpdate: n,
        shared: u.shared,
        callbacks: u.callbacks
      }, l.updateQueue = a;
      return;
    }
    l = a.lastBaseUpdate, l === null ? a.firstBaseUpdate = t : l.next = t, a.lastBaseUpdate = t;
  }
  var Gf = !1;
  function Wu() {
    if (Gf) {
      var l = cu;
      if (l !== null) throw l;
    }
  }
  function $u(l, t, a, u) {
    Gf = !1;
    var e = l.updateQueue;
    ua = !1;
    var n = e.firstBaseUpdate, f = e.lastBaseUpdate, c = e.shared.pending;
    if (c !== null) {
      e.shared.pending = null;
      var i = c, m = i.next;
      i.next = null, f === null ? n = m : f.next = m, f = i;
      var S = l.alternate;
      S !== null && (S = S.updateQueue, c = S.lastBaseUpdate, c !== f && (c === null ? S.firstBaseUpdate = m : c.next = m, S.lastBaseUpdate = i));
    }
    if (n !== null) {
      var z = e.baseState;
      f = 0, S = m = i = null, c = n;
      do {
        var o = c.lane & -536870913, g = o !== c.lane;
        if (g ? (J & o) === o : (u & o) === o) {
          o !== 0 && o === fu && (Gf = !0), S !== null && (S = S.next = {
            lane: 0,
            tag: c.tag,
            payload: c.payload,
            callback: null,
            next: null
          });
          l: {
            var M = l, H = c;
            o = t;
            var fl = a;
            switch (H.tag) {
              case 1:
                if (M = H.payload, typeof M == "function") {
                  z = M.call(fl, z, o);
                  break l;
                }
                z = M;
                break l;
              case 3:
                M.flags = M.flags & -65537 | 128;
              case 0:
                if (M = H.payload, o = typeof M == "function" ? M.call(fl, z, o) : M, o == null) break l;
                z = R({}, z, o);
                break l;
              case 2:
                ua = !0;
            }
          }
          o = c.callback, o !== null && (l.flags |= 64, g && (l.flags |= 8192), g = e.callbacks, g === null ? e.callbacks = [o] : g.push(o));
        } else
          g = {
            lane: o,
            tag: c.tag,
            payload: c.payload,
            callback: c.callback,
            next: null
          }, S === null ? (m = S = g, i = z) : S = S.next = g, f |= o;
        if (c = c.next, c === null) {
          if (c = e.shared.pending, c === null)
            break;
          g = c, c = g.next, g.next = null, e.lastBaseUpdate = g, e.shared.pending = null;
        }
      } while (!0);
      S === null && (i = z), e.baseState = i, e.firstBaseUpdate = m, e.lastBaseUpdate = S, n === null && (e.shared.lanes = 0), da |= f, l.lanes = f, l.memoizedState = z;
    }
  }
  function x0(l, t) {
    if (typeof l != "function")
      throw Error(h(191, l));
    l.call(t);
  }
  function R0(l, t) {
    var a = l.callbacks;
    if (a !== null)
      for (l.callbacks = null, l = 0; l < a.length; l++)
        x0(a[l], t);
  }
  var du = d(null), ke = d(0);
  function C0(l, t) {
    l = Kt, p(ke, l), p(du, t), Kt = l | t.baseLanes;
  }
  function Xf() {
    p(ke, Kt), p(du, du.current);
  }
  function Qf() {
    Kt = ke.current, E(du), E(ke);
  }
  var tt = d(null), ht = null;
  function fa(l) {
    var t = l.alternate;
    p(Sl, Sl.current & 1), p(tt, l), ht === null && (t === null || du.current !== null || t.memoizedState !== null) && (ht = l);
  }
  function Zf(l) {
    p(Sl, Sl.current), p(tt, l), ht === null && (ht = l);
  }
  function q0(l) {
    l.tag === 22 ? (p(Sl, Sl.current), p(tt, l), ht === null && (ht = l)) : ca();
  }
  function ca() {
    p(Sl, Sl.current), p(tt, tt.current);
  }
  function at(l) {
    E(tt), ht === l && (ht = null), E(Sl);
  }
  var Sl = d(0);
  function Fe(l) {
    for (var t = l; t !== null; ) {
      if (t.tag === 13) {
        var a = t.memoizedState;
        if (a !== null && (a = a.dehydrated, a === null || Wc(a) || $c(a)))
          return t;
      } else if (t.tag === 19 && (t.memoizedProps.revealOrder === "forwards" || t.memoizedProps.revealOrder === "backwards" || t.memoizedProps.revealOrder === "unstable_legacy-backwards" || t.memoizedProps.revealOrder === "together")) {
        if ((t.flags & 128) !== 0) return t;
      } else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === l) break;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === l) return null;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return null;
  }
  var Bt = 0, G = null, el = null, zl = null, Ie = !1, vu = !1, Ba = !1, Pe = 0, ku = 0, yu = null, Ky = 0;
  function ml() {
    throw Error(h(321));
  }
  function Vf(l, t) {
    if (t === null) return !1;
    for (var a = 0; a < t.length && a < l.length; a++)
      if (!Pl(l[a], t[a])) return !1;
    return !0;
  }
  function Lf(l, t, a, u, e, n) {
    return Bt = n, G = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, r.H = l === null || l.memoizedState === null ? rs : nc, Ba = !1, n = a(u, e), Ba = !1, vu && (n = B0(
      t,
      a,
      u,
      e
    )), j0(l), n;
  }
  function j0(l) {
    r.H = Pu;
    var t = el !== null && el.next !== null;
    if (Bt = 0, zl = el = G = null, Ie = !1, ku = 0, yu = null, t) throw Error(h(300));
    l === null || El || (l = l.dependencies, l !== null && Ve(l) && (El = !0));
  }
  function B0(l, t, a, u) {
    G = l;
    var e = 0;
    do {
      if (vu && (yu = null), ku = 0, vu = !1, 25 <= e) throw Error(h(301));
      if (e += 1, zl = el = null, l.updateQueue != null) {
        var n = l.updateQueue;
        n.lastEffect = null, n.events = null, n.stores = null, n.memoCache != null && (n.memoCache.index = 0);
      }
      r.H = bs, n = t(a, u);
    } while (vu);
    return n;
  }
  function Jy() {
    var l = r.H, t = l.useState()[0];
    return t = typeof t.then == "function" ? Fu(t) : t, l = l.useState()[0], (el !== null ? el.memoizedState : null) !== l && (G.flags |= 1024), t;
  }
  function Kf() {
    var l = Pe !== 0;
    return Pe = 0, l;
  }
  function Jf(l, t, a) {
    t.updateQueue = l.updateQueue, t.flags &= -2053, l.lanes &= ~a;
  }
  function wf(l) {
    if (Ie) {
      for (l = l.memoizedState; l !== null; ) {
        var t = l.queue;
        t !== null && (t.pending = null), l = l.next;
      }
      Ie = !1;
    }
    Bt = 0, zl = el = G = null, vu = !1, ku = Pe = 0, yu = null;
  }
  function jl() {
    var l = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return zl === null ? G.memoizedState = zl = l : zl = zl.next = l, zl;
  }
  function rl() {
    if (el === null) {
      var l = G.alternate;
      l = l !== null ? l.memoizedState : null;
    } else l = el.next;
    var t = zl === null ? G.memoizedState : zl.next;
    if (t !== null)
      zl = t, el = l;
    else {
      if (l === null)
        throw G.alternate === null ? Error(h(467)) : Error(h(310));
      el = l, l = {
        memoizedState: el.memoizedState,
        baseState: el.baseState,
        baseQueue: el.baseQueue,
        queue: el.queue,
        next: null
      }, zl === null ? G.memoizedState = zl = l : zl = zl.next = l;
    }
    return zl;
  }
  function ln() {
    return { lastEffect: null, events: null, stores: null, memoCache: null };
  }
  function Fu(l) {
    var t = ku;
    return ku += 1, yu === null && (yu = []), l = O0(yu, l, t), t = G, (zl === null ? t.memoizedState : zl.next) === null && (t = t.alternate, r.H = t === null || t.memoizedState === null ? rs : nc), l;
  }
  function tn(l) {
    if (l !== null && typeof l == "object") {
      if (typeof l.then == "function") return Fu(l);
      if (l.$$typeof === xl) return Dl(l);
    }
    throw Error(h(438, String(l)));
  }
  function Wf(l) {
    var t = null, a = G.updateQueue;
    if (a !== null && (t = a.memoCache), t == null) {
      var u = G.alternate;
      u !== null && (u = u.updateQueue, u !== null && (u = u.memoCache, u != null && (t = {
        data: u.data.map(function(e) {
          return e.slice();
        }),
        index: 0
      })));
    }
    if (t == null && (t = { data: [], index: 0 }), a === null && (a = ln(), G.updateQueue = a), a.memoCache = t, a = t.data[t.index], a === void 0)
      for (a = t.data[t.index] = Array(l), u = 0; u < l; u++)
        a[u] = Qa;
    return t.index++, a;
  }
  function Yt(l, t) {
    return typeof t == "function" ? t(l) : t;
  }
  function an(l) {
    var t = rl();
    return $f(t, el, l);
  }
  function $f(l, t, a) {
    var u = l.queue;
    if (u === null) throw Error(h(311));
    u.lastRenderedReducer = a;
    var e = l.baseQueue, n = u.pending;
    if (n !== null) {
      if (e !== null) {
        var f = e.next;
        e.next = n.next, n.next = f;
      }
      t.baseQueue = e = n, u.pending = null;
    }
    if (n = l.baseState, e === null) l.memoizedState = n;
    else {
      t = e.next;
      var c = f = null, i = null, m = t, S = !1;
      do {
        var z = m.lane & -536870913;
        if (z !== m.lane ? (J & z) === z : (Bt & z) === z) {
          var o = m.revertLane;
          if (o === 0)
            i !== null && (i = i.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: m.action,
              hasEagerState: m.hasEagerState,
              eagerState: m.eagerState,
              next: null
            }), z === fu && (S = !0);
          else if ((Bt & o) === o) {
            m = m.next, o === fu && (S = !0);
            continue;
          } else
            z = {
              lane: 0,
              revertLane: m.revertLane,
              gesture: null,
              action: m.action,
              hasEagerState: m.hasEagerState,
              eagerState: m.eagerState,
              next: null
            }, i === null ? (c = i = z, f = n) : i = i.next = z, G.lanes |= o, da |= o;
          z = m.action, Ba && a(n, z), n = m.hasEagerState ? m.eagerState : a(n, z);
        } else
          o = {
            lane: z,
            revertLane: m.revertLane,
            gesture: m.gesture,
            action: m.action,
            hasEagerState: m.hasEagerState,
            eagerState: m.eagerState,
            next: null
          }, i === null ? (c = i = o, f = n) : i = i.next = o, G.lanes |= z, da |= z;
        m = m.next;
      } while (m !== null && m !== t);
      if (i === null ? f = n : i.next = c, !Pl(n, l.memoizedState) && (El = !0, S && (a = cu, a !== null)))
        throw a;
      l.memoizedState = n, l.baseState = f, l.baseQueue = i, u.lastRenderedState = n;
    }
    return e === null && (u.lanes = 0), [l.memoizedState, u.dispatch];
  }
  function kf(l) {
    var t = rl(), a = t.queue;
    if (a === null) throw Error(h(311));
    a.lastRenderedReducer = l;
    var u = a.dispatch, e = a.pending, n = t.memoizedState;
    if (e !== null) {
      a.pending = null;
      var f = e = e.next;
      do
        n = l(n, f.action), f = f.next;
      while (f !== e);
      Pl(n, t.memoizedState) || (El = !0), t.memoizedState = n, t.baseQueue === null && (t.baseState = n), a.lastRenderedState = n;
    }
    return [n, u];
  }
  function Y0(l, t, a) {
    var u = G, e = rl(), n = $;
    if (n) {
      if (a === void 0) throw Error(h(407));
      a = a();
    } else a = t();
    var f = !Pl(
      (el || e).memoizedState,
      a
    );
    if (f && (e.memoizedState = a, El = !0), e = e.queue, Pf(Q0.bind(null, u, e, l), [
      l
    ]), e.getSnapshot !== t || f || zl !== null && zl.memoizedState.tag & 1) {
      if (u.flags |= 2048, mu(
        9,
        { destroy: void 0 },
        X0.bind(
          null,
          u,
          e,
          a,
          t
        ),
        null
      ), il === null) throw Error(h(349));
      n || (Bt & 127) !== 0 || G0(u, t, a);
    }
    return a;
  }
  function G0(l, t, a) {
    l.flags |= 16384, l = { getSnapshot: t, value: a }, t = G.updateQueue, t === null ? (t = ln(), G.updateQueue = t, t.stores = [l]) : (a = t.stores, a === null ? t.stores = [l] : a.push(l));
  }
  function X0(l, t, a, u) {
    t.value = a, t.getSnapshot = u, Z0(t) && V0(l);
  }
  function Q0(l, t, a) {
    return a(function() {
      Z0(t) && V0(l);
    });
  }
  function Z0(l) {
    var t = l.getSnapshot;
    l = l.value;
    try {
      var a = t();
      return !Pl(l, a);
    } catch {
      return !0;
    }
  }
  function V0(l) {
    var t = Ua(l, 2);
    t !== null && wl(t, l, 2);
  }
  function Ff(l) {
    var t = jl();
    if (typeof l == "function") {
      var a = l;
      if (l = a(), Ba) {
        kt(!0);
        try {
          a();
        } finally {
          kt(!1);
        }
      }
    }
    return t.memoizedState = t.baseState = l, t.queue = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: Yt,
      lastRenderedState: l
    }, t;
  }
  function L0(l, t, a, u) {
    return l.baseState = a, $f(
      l,
      el,
      typeof u == "function" ? u : Yt
    );
  }
  function wy(l, t, a, u, e) {
    if (nn(l)) throw Error(h(485));
    if (l = t.action, l !== null) {
      var n = {
        payload: e,
        action: l,
        next: null,
        isTransition: !0,
        status: "pending",
        value: null,
        reason: null,
        listeners: [],
        then: function(f) {
          n.listeners.push(f);
        }
      };
      r.T !== null ? a(!0) : n.isTransition = !1, u(n), a = t.pending, a === null ? (n.next = t.pending = n, K0(t, n)) : (n.next = a.next, t.pending = a.next = n);
    }
  }
  function K0(l, t) {
    var a = t.action, u = t.payload, e = l.state;
    if (t.isTransition) {
      var n = r.T, f = {};
      r.T = f;
      try {
        var c = a(e, u), i = r.S;
        i !== null && i(f, c), J0(l, t, c);
      } catch (m) {
        If(l, t, m);
      } finally {
        n !== null && f.types !== null && (n.types = f.types), r.T = n;
      }
    } else
      try {
        n = a(e, u), J0(l, t, n);
      } catch (m) {
        If(l, t, m);
      }
  }
  function J0(l, t, a) {
    a !== null && typeof a == "object" && typeof a.then == "function" ? a.then(
      function(u) {
        w0(l, t, u);
      },
      function(u) {
        return If(l, t, u);
      }
    ) : w0(l, t, a);
  }
  function w0(l, t, a) {
    t.status = "fulfilled", t.value = a, W0(t), l.state = a, t = l.pending, t !== null && (a = t.next, a === t ? l.pending = null : (a = a.next, t.next = a, K0(l, a)));
  }
  function If(l, t, a) {
    var u = l.pending;
    if (l.pending = null, u !== null) {
      u = u.next;
      do
        t.status = "rejected", t.reason = a, W0(t), t = t.next;
      while (t !== u);
    }
    l.action = null;
  }
  function W0(l) {
    l = l.listeners;
    for (var t = 0; t < l.length; t++) (0, l[t])();
  }
  function $0(l, t) {
    return t;
  }
  function k0(l, t) {
    if ($) {
      var a = il.formState;
      if (a !== null) {
        l: {
          var u = G;
          if ($) {
            if (sl) {
              t: {
                for (var e = sl, n = mt; e.nodeType !== 8; ) {
                  if (!n) {
                    e = null;
                    break t;
                  }
                  if (e = ot(
                    e.nextSibling
                  ), e === null) {
                    e = null;
                    break t;
                  }
                }
                n = e.data, e = n === "F!" || n === "F" ? e : null;
              }
              if (e) {
                sl = ot(
                  e.nextSibling
                ), u = e.data === "F!";
                break l;
              }
            }
            ta(u);
          }
          u = !1;
        }
        u && (t = a[0]);
      }
    }
    return a = jl(), a.memoizedState = a.baseState = t, u = {
      pending: null,
      lanes: 0,
      dispatch: null,
      lastRenderedReducer: $0,
      lastRenderedState: t
    }, a.queue = u, a = os.bind(
      null,
      G,
      u
    ), u.dispatch = a, u = Ff(!1), n = ec.bind(
      null,
      G,
      !1,
      u.queue
    ), u = jl(), e = {
      state: t,
      dispatch: null,
      action: l,
      pending: null
    }, u.queue = e, a = wy.bind(
      null,
      G,
      e,
      n,
      a
    ), e.dispatch = a, u.memoizedState = l, [t, a, !1];
  }
  function F0(l) {
    var t = rl();
    return I0(t, el, l);
  }
  function I0(l, t, a) {
    if (t = $f(
      l,
      t,
      $0
    )[0], l = an(Yt)[0], typeof t == "object" && t !== null && typeof t.then == "function")
      try {
        var u = Fu(t);
      } catch (f) {
        throw f === iu ? Je : f;
      }
    else u = t;
    t = rl();
    var e = t.queue, n = e.dispatch;
    return a !== t.memoizedState && (G.flags |= 2048, mu(
      9,
      { destroy: void 0 },
      Wy.bind(null, e, a),
      null
    )), [u, n, l];
  }
  function Wy(l, t) {
    l.action = t;
  }
  function P0(l) {
    var t = rl(), a = el;
    if (a !== null)
      return I0(t, a, l);
    rl(), t = t.memoizedState, a = rl();
    var u = a.queue.dispatch;
    return a.memoizedState = l, [t, u, !1];
  }
  function mu(l, t, a, u) {
    return l = { tag: l, create: a, deps: u, inst: t, next: null }, t = G.updateQueue, t === null && (t = ln(), G.updateQueue = t), a = t.lastEffect, a === null ? t.lastEffect = l.next = l : (u = a.next, a.next = l, l.next = u, t.lastEffect = l), l;
  }
  function ls() {
    return rl().memoizedState;
  }
  function un(l, t, a, u) {
    var e = jl();
    G.flags |= l, e.memoizedState = mu(
      1 | t,
      { destroy: void 0 },
      a,
      u === void 0 ? null : u
    );
  }
  function en(l, t, a, u) {
    var e = rl();
    u = u === void 0 ? null : u;
    var n = e.memoizedState.inst;
    el !== null && u !== null && Vf(u, el.memoizedState.deps) ? e.memoizedState = mu(t, n, a, u) : (G.flags |= l, e.memoizedState = mu(
      1 | t,
      n,
      a,
      u
    ));
  }
  function ts(l, t) {
    un(8390656, 8, l, t);
  }
  function Pf(l, t) {
    en(2048, 8, l, t);
  }
  function $y(l) {
    G.flags |= 4;
    var t = G.updateQueue;
    if (t === null)
      t = ln(), G.updateQueue = t, t.events = [l];
    else {
      var a = t.events;
      a === null ? t.events = [l] : a.push(l);
    }
  }
  function as(l) {
    var t = rl().memoizedState;
    return $y({ ref: t, nextImpl: l }), function() {
      if ((P & 2) !== 0) throw Error(h(440));
      return t.impl.apply(void 0, arguments);
    };
  }
  function us(l, t) {
    return en(4, 2, l, t);
  }
  function es(l, t) {
    return en(4, 4, l, t);
  }
  function ns(l, t) {
    if (typeof t == "function") {
      l = l();
      var a = t(l);
      return function() {
        typeof a == "function" ? a() : t(null);
      };
    }
    if (t != null)
      return l = l(), t.current = l, function() {
        t.current = null;
      };
  }
  function fs(l, t, a) {
    a = a != null ? a.concat([l]) : null, en(4, 4, ns.bind(null, t, l), a);
  }
  function lc() {
  }
  function cs(l, t) {
    var a = rl();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    return t !== null && Vf(t, u[1]) ? u[0] : (a.memoizedState = [l, t], l);
  }
  function is(l, t) {
    var a = rl();
    t = t === void 0 ? null : t;
    var u = a.memoizedState;
    if (t !== null && Vf(t, u[1]))
      return u[0];
    if (u = l(), Ba) {
      kt(!0);
      try {
        l();
      } finally {
        kt(!1);
      }
    }
    return a.memoizedState = [u, t], u;
  }
  function tc(l, t, a) {
    return a === void 0 || (Bt & 1073741824) !== 0 && (J & 261930) === 0 ? l.memoizedState = t : (l.memoizedState = a, l = sd(), G.lanes |= l, da |= l, a);
  }
  function ss(l, t, a, u) {
    return Pl(a, t) ? a : du.current !== null ? (l = tc(l, a, u), Pl(l, t) || (El = !0), l) : (Bt & 42) === 0 || (Bt & 1073741824) !== 0 && (J & 261930) === 0 ? (El = !0, l.memoizedState = a) : (l = sd(), G.lanes |= l, da |= l, t);
  }
  function ds(l, t, a, u, e) {
    var n = _.p;
    _.p = n !== 0 && 8 > n ? n : 8;
    var f = r.T, c = {};
    r.T = c, ec(l, !1, t, a);
    try {
      var i = e(), m = r.S;
      if (m !== null && m(c, i), i !== null && typeof i == "object" && typeof i.then == "function") {
        var S = Ly(
          i,
          u
        );
        Iu(
          l,
          t,
          S,
          nt(l)
        );
      } else
        Iu(
          l,
          t,
          u,
          nt(l)
        );
    } catch (z) {
      Iu(
        l,
        t,
        { then: function() {
        }, status: "rejected", reason: z },
        nt()
      );
    } finally {
      _.p = n, f !== null && c.types !== null && (f.types = c.types), r.T = f;
    }
  }
  function ky() {
  }
  function ac(l, t, a, u) {
    if (l.tag !== 5) throw Error(h(476));
    var e = vs(l).queue;
    ds(
      l,
      e,
      t,
      C,
      a === null ? ky : function() {
        return ys(l), a(u);
      }
    );
  }
  function vs(l) {
    var t = l.memoizedState;
    if (t !== null) return t;
    t = {
      memoizedState: C,
      baseState: C,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Yt,
        lastRenderedState: C
      },
      next: null
    };
    var a = {};
    return t.next = {
      memoizedState: a,
      baseState: a,
      baseQueue: null,
      queue: {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Yt,
        lastRenderedState: a
      },
      next: null
    }, l.memoizedState = t, l = l.alternate, l !== null && (l.memoizedState = t), t;
  }
  function ys(l) {
    var t = vs(l);
    t.next === null && (t = l.alternate.memoizedState), Iu(
      l,
      t.next.queue,
      {},
      nt()
    );
  }
  function uc() {
    return Dl(oe);
  }
  function ms() {
    return rl().memoizedState;
  }
  function hs() {
    return rl().memoizedState;
  }
  function Fy(l) {
    for (var t = l.return; t !== null; ) {
      switch (t.tag) {
        case 24:
        case 3:
          var a = nt();
          l = ea(a);
          var u = na(t, l, a);
          u !== null && (wl(u, t, a), wu(u, t, a)), t = { cache: xf() }, l.payload = t;
          return;
      }
      t = t.return;
    }
  }
  function Iy(l, t, a) {
    var u = nt();
    a = {
      lane: u,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, nn(l) ? gs(t, a) : (a = Ef(l, t, a, u), a !== null && (wl(a, l, u), Ss(a, t, u)));
  }
  function os(l, t, a) {
    var u = nt();
    Iu(l, t, a, u);
  }
  function Iu(l, t, a, u) {
    var e = {
      lane: u,
      revertLane: 0,
      gesture: null,
      action: a,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if (nn(l)) gs(t, e);
    else {
      var n = l.alternate;
      if (l.lanes === 0 && (n === null || n.lanes === 0) && (n = t.lastRenderedReducer, n !== null))
        try {
          var f = t.lastRenderedState, c = n(f, a);
          if (e.hasEagerState = !0, e.eagerState = c, Pl(c, f))
            return Ge(l, t, e, 0), il === null && Ye(), !1;
        } catch {
        }
      if (a = Ef(l, t, e, u), a !== null)
        return wl(a, l, u), Ss(a, t, u), !0;
    }
    return !1;
  }
  function ec(l, t, a, u) {
    if (u = {
      lane: 2,
      revertLane: jc(),
      gesture: null,
      action: u,
      hasEagerState: !1,
      eagerState: null,
      next: null
    }, nn(l)) {
      if (t) throw Error(h(479));
    } else
      t = Ef(
        l,
        a,
        u,
        2
      ), t !== null && wl(t, l, 2);
  }
  function nn(l) {
    var t = l.alternate;
    return l === G || t !== null && t === G;
  }
  function gs(l, t) {
    vu = Ie = !0;
    var a = l.pending;
    a === null ? t.next = t : (t.next = a.next, a.next = t), l.pending = t;
  }
  function Ss(l, t, a) {
    if ((a & 4194048) !== 0) {
      var u = t.lanes;
      u &= l.pendingLanes, a |= u, t.lanes = a, Ti(l, a);
    }
  }
  var Pu = {
    readContext: Dl,
    use: tn,
    useCallback: ml,
    useContext: ml,
    useEffect: ml,
    useImperativeHandle: ml,
    useLayoutEffect: ml,
    useInsertionEffect: ml,
    useMemo: ml,
    useReducer: ml,
    useRef: ml,
    useState: ml,
    useDebugValue: ml,
    useDeferredValue: ml,
    useTransition: ml,
    useSyncExternalStore: ml,
    useId: ml,
    useHostTransitionStatus: ml,
    useFormState: ml,
    useActionState: ml,
    useOptimistic: ml,
    useMemoCache: ml,
    useCacheRefresh: ml
  };
  Pu.useEffectEvent = ml;
  var rs = {
    readContext: Dl,
    use: tn,
    useCallback: function(l, t) {
      return jl().memoizedState = [
        l,
        t === void 0 ? null : t
      ], l;
    },
    useContext: Dl,
    useEffect: ts,
    useImperativeHandle: function(l, t, a) {
      a = a != null ? a.concat([l]) : null, un(
        4194308,
        4,
        ns.bind(null, t, l),
        a
      );
    },
    useLayoutEffect: function(l, t) {
      return un(4194308, 4, l, t);
    },
    useInsertionEffect: function(l, t) {
      un(4, 2, l, t);
    },
    useMemo: function(l, t) {
      var a = jl();
      t = t === void 0 ? null : t;
      var u = l();
      if (Ba) {
        kt(!0);
        try {
          l();
        } finally {
          kt(!1);
        }
      }
      return a.memoizedState = [u, t], u;
    },
    useReducer: function(l, t, a) {
      var u = jl();
      if (a !== void 0) {
        var e = a(t);
        if (Ba) {
          kt(!0);
          try {
            a(t);
          } finally {
            kt(!1);
          }
        }
      } else e = t;
      return u.memoizedState = u.baseState = e, l = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: l,
        lastRenderedState: e
      }, u.queue = l, l = l.dispatch = Iy.bind(
        null,
        G,
        l
      ), [u.memoizedState, l];
    },
    useRef: function(l) {
      var t = jl();
      return l = { current: l }, t.memoizedState = l;
    },
    useState: function(l) {
      l = Ff(l);
      var t = l.queue, a = os.bind(null, G, t);
      return t.dispatch = a, [l.memoizedState, a];
    },
    useDebugValue: lc,
    useDeferredValue: function(l, t) {
      var a = jl();
      return tc(a, l, t);
    },
    useTransition: function() {
      var l = Ff(!1);
      return l = ds.bind(
        null,
        G,
        l.queue,
        !0,
        !1
      ), jl().memoizedState = l, [!1, l];
    },
    useSyncExternalStore: function(l, t, a) {
      var u = G, e = jl();
      if ($) {
        if (a === void 0)
          throw Error(h(407));
        a = a();
      } else {
        if (a = t(), il === null)
          throw Error(h(349));
        (J & 127) !== 0 || G0(u, t, a);
      }
      e.memoizedState = a;
      var n = { value: a, getSnapshot: t };
      return e.queue = n, ts(Q0.bind(null, u, n, l), [
        l
      ]), u.flags |= 2048, mu(
        9,
        { destroy: void 0 },
        X0.bind(
          null,
          u,
          n,
          a,
          t
        ),
        null
      ), a;
    },
    useId: function() {
      var l = jl(), t = il.identifierPrefix;
      if ($) {
        var a = pt, u = _t;
        a = (u & ~(1 << 32 - Il(u) - 1)).toString(32) + a, t = "_" + t + "R_" + a, a = Pe++, 0 < a && (t += "H" + a.toString(32)), t += "_";
      } else
        a = Ky++, t = "_" + t + "r_" + a.toString(32) + "_";
      return l.memoizedState = t;
    },
    useHostTransitionStatus: uc,
    useFormState: k0,
    useActionState: k0,
    useOptimistic: function(l) {
      var t = jl();
      t.memoizedState = t.baseState = l;
      var a = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return t.queue = a, t = ec.bind(
        null,
        G,
        !0,
        a
      ), a.dispatch = t, [l, t];
    },
    useMemoCache: Wf,
    useCacheRefresh: function() {
      return jl().memoizedState = Fy.bind(
        null,
        G
      );
    },
    useEffectEvent: function(l) {
      var t = jl(), a = { impl: l };
      return t.memoizedState = a, function() {
        if ((P & 2) !== 0)
          throw Error(h(440));
        return a.impl.apply(void 0, arguments);
      };
    }
  }, nc = {
    readContext: Dl,
    use: tn,
    useCallback: cs,
    useContext: Dl,
    useEffect: Pf,
    useImperativeHandle: fs,
    useInsertionEffect: us,
    useLayoutEffect: es,
    useMemo: is,
    useReducer: an,
    useRef: ls,
    useState: function() {
      return an(Yt);
    },
    useDebugValue: lc,
    useDeferredValue: function(l, t) {
      var a = rl();
      return ss(
        a,
        el.memoizedState,
        l,
        t
      );
    },
    useTransition: function() {
      var l = an(Yt)[0], t = rl().memoizedState;
      return [
        typeof l == "boolean" ? l : Fu(l),
        t
      ];
    },
    useSyncExternalStore: Y0,
    useId: ms,
    useHostTransitionStatus: uc,
    useFormState: F0,
    useActionState: F0,
    useOptimistic: function(l, t) {
      var a = rl();
      return L0(a, el, l, t);
    },
    useMemoCache: Wf,
    useCacheRefresh: hs
  };
  nc.useEffectEvent = as;
  var bs = {
    readContext: Dl,
    use: tn,
    useCallback: cs,
    useContext: Dl,
    useEffect: Pf,
    useImperativeHandle: fs,
    useInsertionEffect: us,
    useLayoutEffect: es,
    useMemo: is,
    useReducer: kf,
    useRef: ls,
    useState: function() {
      return kf(Yt);
    },
    useDebugValue: lc,
    useDeferredValue: function(l, t) {
      var a = rl();
      return el === null ? tc(a, l, t) : ss(
        a,
        el.memoizedState,
        l,
        t
      );
    },
    useTransition: function() {
      var l = kf(Yt)[0], t = rl().memoizedState;
      return [
        typeof l == "boolean" ? l : Fu(l),
        t
      ];
    },
    useSyncExternalStore: Y0,
    useId: ms,
    useHostTransitionStatus: uc,
    useFormState: P0,
    useActionState: P0,
    useOptimistic: function(l, t) {
      var a = rl();
      return el !== null ? L0(a, el, l, t) : (a.baseState = l, [l, a.queue.dispatch]);
    },
    useMemoCache: Wf,
    useCacheRefresh: hs
  };
  bs.useEffectEvent = as;
  function fc(l, t, a, u) {
    t = l.memoizedState, a = a(u, t), a = a == null ? t : R({}, t, a), l.memoizedState = a, l.lanes === 0 && (l.updateQueue.baseState = a);
  }
  var cc = {
    enqueueSetState: function(l, t, a) {
      l = l._reactInternals;
      var u = nt(), e = ea(u);
      e.payload = t, a != null && (e.callback = a), t = na(l, e, u), t !== null && (wl(t, l, u), wu(t, l, u));
    },
    enqueueReplaceState: function(l, t, a) {
      l = l._reactInternals;
      var u = nt(), e = ea(u);
      e.tag = 1, e.payload = t, a != null && (e.callback = a), t = na(l, e, u), t !== null && (wl(t, l, u), wu(t, l, u));
    },
    enqueueForceUpdate: function(l, t) {
      l = l._reactInternals;
      var a = nt(), u = ea(a);
      u.tag = 2, t != null && (u.callback = t), t = na(l, u, a), t !== null && (wl(t, l, a), wu(t, l, a));
    }
  };
  function zs(l, t, a, u, e, n, f) {
    return l = l.stateNode, typeof l.shouldComponentUpdate == "function" ? l.shouldComponentUpdate(u, n, f) : t.prototype && t.prototype.isPureReactComponent ? !Gu(a, u) || !Gu(e, n) : !0;
  }
  function Es(l, t, a, u) {
    l = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(a, u), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(a, u), t.state !== l && cc.enqueueReplaceState(t, t.state, null);
  }
  function Ya(l, t) {
    var a = t;
    if ("ref" in t) {
      a = {};
      for (var u in t)
        u !== "ref" && (a[u] = t[u]);
    }
    if (l = l.defaultProps) {
      a === t && (a = R({}, a));
      for (var e in l)
        a[e] === void 0 && (a[e] = l[e]);
    }
    return a;
  }
  function Ts(l) {
    Be(l);
  }
  function As(l) {
    console.error(l);
  }
  function _s(l) {
    Be(l);
  }
  function fn(l, t) {
    try {
      var a = l.onUncaughtError;
      a(t.value, { componentStack: t.stack });
    } catch (u) {
      setTimeout(function() {
        throw u;
      });
    }
  }
  function ps(l, t, a) {
    try {
      var u = l.onCaughtError;
      u(a.value, {
        componentStack: a.stack,
        errorBoundary: t.tag === 1 ? t.stateNode : null
      });
    } catch (e) {
      setTimeout(function() {
        throw e;
      });
    }
  }
  function ic(l, t, a) {
    return a = ea(a), a.tag = 3, a.payload = { element: null }, a.callback = function() {
      fn(l, t);
    }, a;
  }
  function Ms(l) {
    return l = ea(l), l.tag = 3, l;
  }
  function Os(l, t, a, u) {
    var e = a.type.getDerivedStateFromError;
    if (typeof e == "function") {
      var n = u.value;
      l.payload = function() {
        return e(n);
      }, l.callback = function() {
        ps(t, a, u);
      };
    }
    var f = a.stateNode;
    f !== null && typeof f.componentDidCatch == "function" && (l.callback = function() {
      ps(t, a, u), typeof e != "function" && (va === null ? va = /* @__PURE__ */ new Set([this]) : va.add(this));
      var c = u.stack;
      this.componentDidCatch(u.value, {
        componentStack: c !== null ? c : ""
      });
    });
  }
  function Py(l, t, a, u, e) {
    if (a.flags |= 32768, u !== null && typeof u == "object" && typeof u.then == "function") {
      if (t = a.alternate, t !== null && nu(
        t,
        a,
        e,
        !0
      ), a = tt.current, a !== null) {
        switch (a.tag) {
          case 31:
          case 13:
            return ht === null ? bn() : a.alternate === null && hl === 0 && (hl = 3), a.flags &= -257, a.flags |= 65536, a.lanes = e, u === we ? a.flags |= 16384 : (t = a.updateQueue, t === null ? a.updateQueue = /* @__PURE__ */ new Set([u]) : t.add(u), Rc(l, u, e)), !1;
          case 22:
            return a.flags |= 65536, u === we ? a.flags |= 16384 : (t = a.updateQueue, t === null ? (t = {
              transitions: null,
              markerInstances: null,
              retryQueue: /* @__PURE__ */ new Set([u])
            }, a.updateQueue = t) : (a = t.retryQueue, a === null ? t.retryQueue = /* @__PURE__ */ new Set([u]) : a.add(u)), Rc(l, u, e)), !1;
        }
        throw Error(h(435, a.tag));
      }
      return Rc(l, u, e), bn(), !1;
    }
    if ($)
      return t = tt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = e, u !== Of && (l = Error(h(422), { cause: u }), Zu(dt(l, a)))) : (u !== Of && (t = Error(h(423), {
        cause: u
      }), Zu(
        dt(t, a)
      )), l = l.current.alternate, l.flags |= 65536, e &= -e, l.lanes |= e, u = dt(u, a), e = ic(
        l.stateNode,
        u,
        e
      ), Yf(l, e), hl !== 4 && (hl = 2)), !1;
    var n = Error(h(520), { cause: u });
    if (n = dt(n, a), ce === null ? ce = [n] : ce.push(n), hl !== 4 && (hl = 2), t === null) return !0;
    u = dt(u, a), a = t;
    do {
      switch (a.tag) {
        case 3:
          return a.flags |= 65536, l = e & -e, a.lanes |= l, l = ic(a.stateNode, u, l), Yf(a, l), !1;
        case 1:
          if (t = a.type, n = a.stateNode, (a.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || n !== null && typeof n.componentDidCatch == "function" && (va === null || !va.has(n))))
            return a.flags |= 65536, e &= -e, a.lanes |= e, e = Ms(e), Os(
              e,
              l,
              a,
              u
            ), Yf(a, e), !1;
      }
      a = a.return;
    } while (a !== null);
    return !1;
  }
  var sc = Error(h(461)), El = !1;
  function Nl(l, t, a, u) {
    t.child = l === null ? H0(t, null, a, u) : ja(
      t,
      l.child,
      a,
      u
    );
  }
  function Us(l, t, a, u, e) {
    a = a.render;
    var n = t.ref;
    if ("ref" in u) {
      var f = {};
      for (var c in u)
        c !== "ref" && (f[c] = u[c]);
    } else f = u;
    return xa(t), u = Lf(
      l,
      t,
      a,
      f,
      n,
      e
    ), c = Kf(), l !== null && !El ? (Jf(l, t, e), Gt(l, t, e)) : ($ && c && pf(t), t.flags |= 1, Nl(l, t, u, e), t.child);
  }
  function Ds(l, t, a, u, e) {
    if (l === null) {
      var n = a.type;
      return typeof n == "function" && !Tf(n) && n.defaultProps === void 0 && a.compare === null ? (t.tag = 15, t.type = n, Ns(
        l,
        t,
        n,
        u,
        e
      )) : (l = Qe(
        a.type,
        null,
        u,
        t,
        t.mode,
        e
      ), l.ref = t.ref, l.return = t, t.child = l);
    }
    if (n = l.child, !Sc(l, e)) {
      var f = n.memoizedProps;
      if (a = a.compare, a = a !== null ? a : Gu, a(f, u) && l.ref === t.ref)
        return Gt(l, t, e);
    }
    return t.flags |= 1, l = Rt(n, u), l.ref = t.ref, l.return = t, t.child = l;
  }
  function Ns(l, t, a, u, e) {
    if (l !== null) {
      var n = l.memoizedProps;
      if (Gu(n, u) && l.ref === t.ref)
        if (El = !1, t.pendingProps = u = n, Sc(l, e))
          (l.flags & 131072) !== 0 && (El = !0);
        else
          return t.lanes = l.lanes, Gt(l, t, e);
    }
    return dc(
      l,
      t,
      a,
      u,
      e
    );
  }
  function Hs(l, t, a, u) {
    var e = u.children, n = l !== null ? l.memoizedState : null;
    if (l === null && t.stateNode === null && (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), u.mode === "hidden") {
      if ((t.flags & 128) !== 0) {
        if (n = n !== null ? n.baseLanes | a : a, l !== null) {
          for (u = t.child = l.child, e = 0; u !== null; )
            e = e | u.lanes | u.childLanes, u = u.sibling;
          u = e & ~n;
        } else u = 0, t.child = null;
        return xs(
          l,
          t,
          n,
          a,
          u
        );
      }
      if ((a & 536870912) !== 0)
        t.memoizedState = { baseLanes: 0, cachePool: null }, l !== null && Ke(
          t,
          n !== null ? n.cachePool : null
        ), n !== null ? C0(t, n) : Xf(), q0(t);
      else
        return u = t.lanes = 536870912, xs(
          l,
          t,
          n !== null ? n.baseLanes | a : a,
          a,
          u
        );
    } else
      n !== null ? (Ke(t, n.cachePool), C0(t, n), ca(), t.memoizedState = null) : (l !== null && Ke(t, null), Xf(), ca());
    return Nl(l, t, e, a), t.child;
  }
  function le(l, t) {
    return l !== null && l.tag === 22 || t.stateNode !== null || (t.stateNode = {
      _visibility: 1,
      _pendingMarkers: null,
      _retryCache: null,
      _transitions: null
    }), t.sibling;
  }
  function xs(l, t, a, u, e) {
    var n = Cf();
    return n = n === null ? null : { parent: bl._currentValue, pool: n }, t.memoizedState = {
      baseLanes: a,
      cachePool: n
    }, l !== null && Ke(t, null), Xf(), q0(t), l !== null && nu(l, t, u, !0), t.childLanes = e, null;
  }
  function cn(l, t) {
    return t = dn(
      { mode: t.mode, children: t.children },
      l.mode
    ), t.ref = l.ref, l.child = t, t.return = l, t;
  }
  function Rs(l, t, a) {
    return ja(t, l.child, null, a), l = cn(t, t.pendingProps), l.flags |= 2, at(t), t.memoizedState = null, l;
  }
  function l1(l, t, a) {
    var u = t.pendingProps, e = (t.flags & 128) !== 0;
    if (t.flags &= -129, l === null) {
      if ($) {
        if (u.mode === "hidden")
          return l = cn(t, u), t.lanes = 536870912, le(null, l);
        if (Zf(t), (l = sl) ? (l = Kd(
          l,
          mt
        ), l = l !== null && l.data === "&" ? l : null, l !== null && (t.memoizedState = {
          dehydrated: l,
          treeContext: Pt !== null ? { id: _t, overflow: pt } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = g0(l), a.return = t, t.child = a, Ul = t, sl = null)) : l = null, l === null) throw ta(t);
        return t.lanes = 536870912, null;
      }
      return cn(t, u);
    }
    var n = l.memoizedState;
    if (n !== null) {
      var f = n.dehydrated;
      if (Zf(t), e)
        if (t.flags & 256)
          t.flags &= -257, t = Rs(
            l,
            t,
            a
          );
        else if (t.memoizedState !== null)
          t.child = l.child, t.flags |= 128, t = null;
        else throw Error(h(558));
      else if (El || nu(l, t, a, !1), e = (a & l.childLanes) !== 0, El || e) {
        if (u = il, u !== null && (f = Ai(u, a), f !== 0 && f !== n.retryLane))
          throw n.retryLane = f, Ua(l, f), wl(u, l, f), sc;
        bn(), t = Rs(
          l,
          t,
          a
        );
      } else
        l = n.treeContext, sl = ot(f.nextSibling), Ul = t, $ = !0, la = null, mt = !1, l !== null && b0(t, l), t = cn(t, u), t.flags |= 4096;
      return t;
    }
    return l = Rt(l.child, {
      mode: u.mode,
      children: u.children
    }), l.ref = t.ref, t.child = l, l.return = t, l;
  }
  function sn(l, t) {
    var a = t.ref;
    if (a === null)
      l !== null && l.ref !== null && (t.flags |= 4194816);
    else {
      if (typeof a != "function" && typeof a != "object")
        throw Error(h(284));
      (l === null || l.ref !== a) && (t.flags |= 4194816);
    }
  }
  function dc(l, t, a, u, e) {
    return xa(t), a = Lf(
      l,
      t,
      a,
      u,
      void 0,
      e
    ), u = Kf(), l !== null && !El ? (Jf(l, t, e), Gt(l, t, e)) : ($ && u && pf(t), t.flags |= 1, Nl(l, t, a, e), t.child);
  }
  function Cs(l, t, a, u, e, n) {
    return xa(t), t.updateQueue = null, a = B0(
      t,
      u,
      a,
      e
    ), j0(l), u = Kf(), l !== null && !El ? (Jf(l, t, n), Gt(l, t, n)) : ($ && u && pf(t), t.flags |= 1, Nl(l, t, a, n), t.child);
  }
  function qs(l, t, a, u, e) {
    if (xa(t), t.stateNode === null) {
      var n = tu, f = a.contextType;
      typeof f == "object" && f !== null && (n = Dl(f)), n = new a(u, n), t.memoizedState = n.state !== null && n.state !== void 0 ? n.state : null, n.updater = cc, t.stateNode = n, n._reactInternals = t, n = t.stateNode, n.props = u, n.state = t.memoizedState, n.refs = {}, jf(t), f = a.contextType, n.context = typeof f == "object" && f !== null ? Dl(f) : tu, n.state = t.memoizedState, f = a.getDerivedStateFromProps, typeof f == "function" && (fc(
        t,
        a,
        f,
        u
      ), n.state = t.memoizedState), typeof a.getDerivedStateFromProps == "function" || typeof n.getSnapshotBeforeUpdate == "function" || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (f = n.state, typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount(), f !== n.state && cc.enqueueReplaceState(n, n.state, null), $u(t, u, n, e), Wu(), n.state = t.memoizedState), typeof n.componentDidMount == "function" && (t.flags |= 4194308), u = !0;
    } else if (l === null) {
      n = t.stateNode;
      var c = t.memoizedProps, i = Ya(a, c);
      n.props = i;
      var m = n.context, S = a.contextType;
      f = tu, typeof S == "object" && S !== null && (f = Dl(S));
      var z = a.getDerivedStateFromProps;
      S = typeof z == "function" || typeof n.getSnapshotBeforeUpdate == "function", c = t.pendingProps !== c, S || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (c || m !== f) && Es(
        t,
        n,
        u,
        f
      ), ua = !1;
      var o = t.memoizedState;
      n.state = o, $u(t, u, n, e), Wu(), m = t.memoizedState, c || o !== m || ua ? (typeof z == "function" && (fc(
        t,
        a,
        z,
        u
      ), m = t.memoizedState), (i = ua || zs(
        t,
        a,
        i,
        u,
        o,
        m,
        f
      )) ? (S || typeof n.UNSAFE_componentWillMount != "function" && typeof n.componentWillMount != "function" || (typeof n.componentWillMount == "function" && n.componentWillMount(), typeof n.UNSAFE_componentWillMount == "function" && n.UNSAFE_componentWillMount()), typeof n.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = u, t.memoizedState = m), n.props = u, n.state = m, n.context = f, u = i) : (typeof n.componentDidMount == "function" && (t.flags |= 4194308), u = !1);
    } else {
      n = t.stateNode, Bf(l, t), f = t.memoizedProps, S = Ya(a, f), n.props = S, z = t.pendingProps, o = n.context, m = a.contextType, i = tu, typeof m == "object" && m !== null && (i = Dl(m)), c = a.getDerivedStateFromProps, (m = typeof c == "function" || typeof n.getSnapshotBeforeUpdate == "function") || typeof n.UNSAFE_componentWillReceiveProps != "function" && typeof n.componentWillReceiveProps != "function" || (f !== z || o !== i) && Es(
        t,
        n,
        u,
        i
      ), ua = !1, o = t.memoizedState, n.state = o, $u(t, u, n, e), Wu();
      var g = t.memoizedState;
      f !== z || o !== g || ua || l !== null && l.dependencies !== null && Ve(l.dependencies) ? (typeof c == "function" && (fc(
        t,
        a,
        c,
        u
      ), g = t.memoizedState), (S = ua || zs(
        t,
        a,
        S,
        u,
        o,
        g,
        i
      ) || l !== null && l.dependencies !== null && Ve(l.dependencies)) ? (m || typeof n.UNSAFE_componentWillUpdate != "function" && typeof n.componentWillUpdate != "function" || (typeof n.componentWillUpdate == "function" && n.componentWillUpdate(u, g, i), typeof n.UNSAFE_componentWillUpdate == "function" && n.UNSAFE_componentWillUpdate(
        u,
        g,
        i
      )), typeof n.componentDidUpdate == "function" && (t.flags |= 4), typeof n.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof n.componentDidUpdate != "function" || f === l.memoizedProps && o === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || f === l.memoizedProps && o === l.memoizedState || (t.flags |= 1024), t.memoizedProps = u, t.memoizedState = g), n.props = u, n.state = g, n.context = i, u = S) : (typeof n.componentDidUpdate != "function" || f === l.memoizedProps && o === l.memoizedState || (t.flags |= 4), typeof n.getSnapshotBeforeUpdate != "function" || f === l.memoizedProps && o === l.memoizedState || (t.flags |= 1024), u = !1);
    }
    return n = u, sn(l, t), u = (t.flags & 128) !== 0, n || u ? (n = t.stateNode, a = u && typeof a.getDerivedStateFromError != "function" ? null : n.render(), t.flags |= 1, l !== null && u ? (t.child = ja(
      t,
      l.child,
      null,
      e
    ), t.child = ja(
      t,
      null,
      a,
      e
    )) : Nl(l, t, a, e), t.memoizedState = n.state, l = t.child) : l = Gt(
      l,
      t,
      e
    ), l;
  }
  function js(l, t, a, u) {
    return Na(), t.flags |= 256, Nl(l, t, a, u), t.child;
  }
  var vc = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0,
    hydrationErrors: null
  };
  function yc(l) {
    return { baseLanes: l, cachePool: p0() };
  }
  function mc(l, t, a) {
    return l = l !== null ? l.childLanes & ~a : 0, t && (l |= et), l;
  }
  function Bs(l, t, a) {
    var u = t.pendingProps, e = !1, n = (t.flags & 128) !== 0, f;
    if ((f = n) || (f = l !== null && l.memoizedState === null ? !1 : (Sl.current & 2) !== 0), f && (e = !0, t.flags &= -129), f = (t.flags & 32) !== 0, t.flags &= -33, l === null) {
      if ($) {
        if (e ? fa(t) : ca(), (l = sl) ? (l = Kd(
          l,
          mt
        ), l = l !== null && l.data !== "&" ? l : null, l !== null && (t.memoizedState = {
          dehydrated: l,
          treeContext: Pt !== null ? { id: _t, overflow: pt } : null,
          retryLane: 536870912,
          hydrationErrors: null
        }, a = g0(l), a.return = t, t.child = a, Ul = t, sl = null)) : l = null, l === null) throw ta(t);
        return $c(l) ? t.lanes = 32 : t.lanes = 536870912, null;
      }
      var c = u.children;
      return u = u.fallback, e ? (ca(), e = t.mode, c = dn(
        { mode: "hidden", children: c },
        e
      ), u = Da(
        u,
        e,
        a,
        null
      ), c.return = t, u.return = t, c.sibling = u, t.child = c, u = t.child, u.memoizedState = yc(a), u.childLanes = mc(
        l,
        f,
        a
      ), t.memoizedState = vc, le(null, u)) : (fa(t), hc(t, c));
    }
    var i = l.memoizedState;
    if (i !== null && (c = i.dehydrated, c !== null)) {
      if (n)
        t.flags & 256 ? (fa(t), t.flags &= -257, t = oc(
          l,
          t,
          a
        )) : t.memoizedState !== null ? (ca(), t.child = l.child, t.flags |= 128, t = null) : (ca(), c = u.fallback, e = t.mode, u = dn(
          { mode: "visible", children: u.children },
          e
        ), c = Da(
          c,
          e,
          a,
          null
        ), c.flags |= 2, u.return = t, c.return = t, u.sibling = c, t.child = u, ja(
          t,
          l.child,
          null,
          a
        ), u = t.child, u.memoizedState = yc(a), u.childLanes = mc(
          l,
          f,
          a
        ), t.memoizedState = vc, t = le(null, u));
      else if (fa(t), $c(c)) {
        if (f = c.nextSibling && c.nextSibling.dataset, f) var m = f.dgst;
        f = m, u = Error(h(419)), u.stack = "", u.digest = f, Zu({ value: u, source: null, stack: null }), t = oc(
          l,
          t,
          a
        );
      } else if (El || nu(l, t, a, !1), f = (a & l.childLanes) !== 0, El || f) {
        if (f = il, f !== null && (u = Ai(f, a), u !== 0 && u !== i.retryLane))
          throw i.retryLane = u, Ua(l, u), wl(f, l, u), sc;
        Wc(c) || bn(), t = oc(
          l,
          t,
          a
        );
      } else
        Wc(c) ? (t.flags |= 192, t.child = l.child, t = null) : (l = i.treeContext, sl = ot(
          c.nextSibling
        ), Ul = t, $ = !0, la = null, mt = !1, l !== null && b0(t, l), t = hc(
          t,
          u.children
        ), t.flags |= 4096);
      return t;
    }
    return e ? (ca(), c = u.fallback, e = t.mode, i = l.child, m = i.sibling, u = Rt(i, {
      mode: "hidden",
      children: u.children
    }), u.subtreeFlags = i.subtreeFlags & 65011712, m !== null ? c = Rt(
      m,
      c
    ) : (c = Da(
      c,
      e,
      a,
      null
    ), c.flags |= 2), c.return = t, u.return = t, u.sibling = c, t.child = u, le(null, u), u = t.child, c = l.child.memoizedState, c === null ? c = yc(a) : (e = c.cachePool, e !== null ? (i = bl._currentValue, e = e.parent !== i ? { parent: i, pool: i } : e) : e = p0(), c = {
      baseLanes: c.baseLanes | a,
      cachePool: e
    }), u.memoizedState = c, u.childLanes = mc(
      l,
      f,
      a
    ), t.memoizedState = vc, le(l.child, u)) : (fa(t), a = l.child, l = a.sibling, a = Rt(a, {
      mode: "visible",
      children: u.children
    }), a.return = t, a.sibling = null, l !== null && (f = t.deletions, f === null ? (t.deletions = [l], t.flags |= 16) : f.push(l)), t.child = a, t.memoizedState = null, a);
  }
  function hc(l, t) {
    return t = dn(
      { mode: "visible", children: t },
      l.mode
    ), t.return = l, l.child = t;
  }
  function dn(l, t) {
    return l = lt(22, l, null, t), l.lanes = 0, l;
  }
  function oc(l, t, a) {
    return ja(t, l.child, null, a), l = hc(
      t,
      t.pendingProps.children
    ), l.flags |= 2, t.memoizedState = null, l;
  }
  function Ys(l, t, a) {
    l.lanes |= t;
    var u = l.alternate;
    u !== null && (u.lanes |= t), Nf(l.return, t, a);
  }
  function gc(l, t, a, u, e, n) {
    var f = l.memoizedState;
    f === null ? l.memoizedState = {
      isBackwards: t,
      rendering: null,
      renderingStartTime: 0,
      last: u,
      tail: a,
      tailMode: e,
      treeForkCount: n
    } : (f.isBackwards = t, f.rendering = null, f.renderingStartTime = 0, f.last = u, f.tail = a, f.tailMode = e, f.treeForkCount = n);
  }
  function Gs(l, t, a) {
    var u = t.pendingProps, e = u.revealOrder, n = u.tail;
    u = u.children;
    var f = Sl.current, c = (f & 2) !== 0;
    if (c ? (f = f & 1 | 2, t.flags |= 128) : f &= 1, p(Sl, f), Nl(l, t, u, a), u = $ ? Qu : 0, !c && l !== null && (l.flags & 128) !== 0)
      l: for (l = t.child; l !== null; ) {
        if (l.tag === 13)
          l.memoizedState !== null && Ys(l, a, t);
        else if (l.tag === 19)
          Ys(l, a, t);
        else if (l.child !== null) {
          l.child.return = l, l = l.child;
          continue;
        }
        if (l === t) break l;
        for (; l.sibling === null; ) {
          if (l.return === null || l.return === t)
            break l;
          l = l.return;
        }
        l.sibling.return = l.return, l = l.sibling;
      }
    switch (e) {
      case "forwards":
        for (a = t.child, e = null; a !== null; )
          l = a.alternate, l !== null && Fe(l) === null && (e = a), a = a.sibling;
        a = e, a === null ? (e = t.child, t.child = null) : (e = a.sibling, a.sibling = null), gc(
          t,
          !1,
          e,
          a,
          n,
          u
        );
        break;
      case "backwards":
      case "unstable_legacy-backwards":
        for (a = null, e = t.child, t.child = null; e !== null; ) {
          if (l = e.alternate, l !== null && Fe(l) === null) {
            t.child = e;
            break;
          }
          l = e.sibling, e.sibling = a, a = e, e = l;
        }
        gc(
          t,
          !0,
          a,
          null,
          n,
          u
        );
        break;
      case "together":
        gc(
          t,
          !1,
          null,
          null,
          void 0,
          u
        );
        break;
      default:
        t.memoizedState = null;
    }
    return t.child;
  }
  function Gt(l, t, a) {
    if (l !== null && (t.dependencies = l.dependencies), da |= t.lanes, (a & t.childLanes) === 0)
      if (l !== null) {
        if (nu(
          l,
          t,
          a,
          !1
        ), (a & t.childLanes) === 0)
          return null;
      } else return null;
    if (l !== null && t.child !== l.child)
      throw Error(h(153));
    if (t.child !== null) {
      for (l = t.child, a = Rt(l, l.pendingProps), t.child = a, a.return = t; l.sibling !== null; )
        l = l.sibling, a = a.sibling = Rt(l, l.pendingProps), a.return = t;
      a.sibling = null;
    }
    return t.child;
  }
  function Sc(l, t) {
    return (l.lanes & t) !== 0 ? !0 : (l = l.dependencies, !!(l !== null && Ve(l)));
  }
  function t1(l, t, a) {
    switch (t.tag) {
      case 3:
        ql(t, t.stateNode.containerInfo), aa(t, bl, l.memoizedState.cache), Na();
        break;
      case 27:
      case 5:
        Mu(t);
        break;
      case 4:
        ql(t, t.stateNode.containerInfo);
        break;
      case 10:
        aa(
          t,
          t.type,
          t.memoizedProps.value
        );
        break;
      case 31:
        if (t.memoizedState !== null)
          return t.flags |= 128, Zf(t), null;
        break;
      case 13:
        var u = t.memoizedState;
        if (u !== null)
          return u.dehydrated !== null ? (fa(t), t.flags |= 128, null) : (a & t.child.childLanes) !== 0 ? Bs(l, t, a) : (fa(t), l = Gt(
            l,
            t,
            a
          ), l !== null ? l.sibling : null);
        fa(t);
        break;
      case 19:
        var e = (l.flags & 128) !== 0;
        if (u = (a & t.childLanes) !== 0, u || (nu(
          l,
          t,
          a,
          !1
        ), u = (a & t.childLanes) !== 0), e) {
          if (u)
            return Gs(
              l,
              t,
              a
            );
          t.flags |= 128;
        }
        if (e = t.memoizedState, e !== null && (e.rendering = null, e.tail = null, e.lastEffect = null), p(Sl, Sl.current), u) break;
        return null;
      case 22:
        return t.lanes = 0, Hs(
          l,
          t,
          a,
          t.pendingProps
        );
      case 24:
        aa(t, bl, l.memoizedState.cache);
    }
    return Gt(l, t, a);
  }
  function Xs(l, t, a) {
    if (l !== null)
      if (l.memoizedProps !== t.pendingProps)
        El = !0;
      else {
        if (!Sc(l, a) && (t.flags & 128) === 0)
          return El = !1, t1(
            l,
            t,
            a
          );
        El = (l.flags & 131072) !== 0;
      }
    else
      El = !1, $ && (t.flags & 1048576) !== 0 && r0(t, Qu, t.index);
    switch (t.lanes = 0, t.tag) {
      case 16:
        l: {
          var u = t.pendingProps;
          if (l = Ca(t.elementType), t.type = l, typeof l == "function")
            Tf(l) ? (u = Ya(l, u), t.tag = 1, t = qs(
              null,
              t,
              l,
              u,
              a
            )) : (t.tag = 0, t = dc(
              null,
              t,
              l,
              u,
              a
            ));
          else {
            if (l != null) {
              var e = l.$$typeof;
              if (e === ft) {
                t.tag = 11, t = Us(
                  null,
                  t,
                  l,
                  u,
                  a
                );
                break l;
              } else if (e === W) {
                t.tag = 14, t = Ds(
                  null,
                  t,
                  l,
                  u,
                  a
                );
                break l;
              }
            }
            throw t = Dt(l) || l, Error(h(306, t, ""));
          }
        }
        return t;
      case 0:
        return dc(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 1:
        return u = t.type, e = Ya(
          u,
          t.pendingProps
        ), qs(
          l,
          t,
          u,
          e,
          a
        );
      case 3:
        l: {
          if (ql(
            t,
            t.stateNode.containerInfo
          ), l === null) throw Error(h(387));
          u = t.pendingProps;
          var n = t.memoizedState;
          e = n.element, Bf(l, t), $u(t, u, null, a);
          var f = t.memoizedState;
          if (u = f.cache, aa(t, bl, u), u !== n.cache && Hf(
            t,
            [bl],
            a,
            !0
          ), Wu(), u = f.element, n.isDehydrated)
            if (n = {
              element: u,
              isDehydrated: !1,
              cache: f.cache
            }, t.updateQueue.baseState = n, t.memoizedState = n, t.flags & 256) {
              t = js(
                l,
                t,
                u,
                a
              );
              break l;
            } else if (u !== e) {
              e = dt(
                Error(h(424)),
                t
              ), Zu(e), t = js(
                l,
                t,
                u,
                a
              );
              break l;
            } else
              for (l = t.stateNode.containerInfo, l.nodeType === 9 ? l = l.body : l = l.nodeName === "HTML" ? l.ownerDocument.body : l, sl = ot(l.firstChild), Ul = t, $ = !0, la = null, mt = !0, a = H0(
                t,
                null,
                u,
                a
              ), t.child = a; a; )
                a.flags = a.flags & -3 | 4096, a = a.sibling;
          else {
            if (Na(), u === e) {
              t = Gt(
                l,
                t,
                a
              );
              break l;
            }
            Nl(l, t, u, a);
          }
          t = t.child;
        }
        return t;
      case 26:
        return sn(l, t), l === null ? (a = Fd(
          t.type,
          null,
          t.pendingProps,
          null
        )) ? t.memoizedState = a : $ || (a = t.type, l = t.pendingProps, u = Mn(
          V.current
        ).createElement(a), u[Ol] = t, u[Ql] = l, Hl(u, a, l), pl(u), t.stateNode = u) : t.memoizedState = Fd(
          t.type,
          l.memoizedProps,
          t.pendingProps,
          l.memoizedState
        ), null;
      case 27:
        return Mu(t), l === null && $ && (u = t.stateNode = Wd(
          t.type,
          t.pendingProps,
          V.current
        ), Ul = t, mt = !0, e = sl, oa(t.type) ? (kc = e, sl = ot(u.firstChild)) : sl = e), Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), sn(l, t), l === null && (t.flags |= 4194304), t.child;
      case 5:
        return l === null && $ && ((e = u = sl) && (u = H1(
          u,
          t.type,
          t.pendingProps,
          mt
        ), u !== null ? (t.stateNode = u, Ul = t, sl = ot(u.firstChild), mt = !1, e = !0) : e = !1), e || ta(t)), Mu(t), e = t.type, n = t.pendingProps, f = l !== null ? l.memoizedProps : null, u = n.children, Kc(e, n) ? u = null : f !== null && Kc(e, f) && (t.flags |= 32), t.memoizedState !== null && (e = Lf(
          l,
          t,
          Jy,
          null,
          null,
          a
        ), oe._currentValue = e), sn(l, t), Nl(l, t, u, a), t.child;
      case 6:
        return l === null && $ && ((l = a = sl) && (a = x1(
          a,
          t.pendingProps,
          mt
        ), a !== null ? (t.stateNode = a, Ul = t, sl = null, l = !0) : l = !1), l || ta(t)), null;
      case 13:
        return Bs(l, t, a);
      case 4:
        return ql(
          t,
          t.stateNode.containerInfo
        ), u = t.pendingProps, l === null ? t.child = ja(
          t,
          null,
          u,
          a
        ) : Nl(l, t, u, a), t.child;
      case 11:
        return Us(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 7:
        return Nl(
          l,
          t,
          t.pendingProps,
          a
        ), t.child;
      case 8:
        return Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 12:
        return Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 10:
        return u = t.pendingProps, aa(t, t.type, u.value), Nl(l, t, u.children, a), t.child;
      case 9:
        return e = t.type._context, u = t.pendingProps.children, xa(t), e = Dl(e), u = u(e), t.flags |= 1, Nl(l, t, u, a), t.child;
      case 14:
        return Ds(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 15:
        return Ns(
          l,
          t,
          t.type,
          t.pendingProps,
          a
        );
      case 19:
        return Gs(l, t, a);
      case 31:
        return l1(l, t, a);
      case 22:
        return Hs(
          l,
          t,
          a,
          t.pendingProps
        );
      case 24:
        return xa(t), u = Dl(bl), l === null ? (e = Cf(), e === null && (e = il, n = xf(), e.pooledCache = n, n.refCount++, n !== null && (e.pooledCacheLanes |= a), e = n), t.memoizedState = { parent: u, cache: e }, jf(t), aa(t, bl, e)) : ((l.lanes & a) !== 0 && (Bf(l, t), $u(t, null, null, a), Wu()), e = l.memoizedState, n = t.memoizedState, e.parent !== u ? (e = { parent: u, cache: u }, t.memoizedState = e, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = e), aa(t, bl, u)) : (u = n.cache, aa(t, bl, u), u !== e.cache && Hf(
          t,
          [bl],
          a,
          !0
        ))), Nl(
          l,
          t,
          t.pendingProps.children,
          a
        ), t.child;
      case 29:
        throw t.pendingProps;
    }
    throw Error(h(156, t.tag));
  }
  function Xt(l) {
    l.flags |= 4;
  }
  function rc(l, t, a, u, e) {
    if ((t = (l.mode & 32) !== 0) && (t = !1), t) {
      if (l.flags |= 16777216, (e & 335544128) === e)
        if (l.stateNode.complete) l.flags |= 8192;
        else if (md()) l.flags |= 8192;
        else
          throw qa = we, qf;
    } else l.flags &= -16777217;
  }
  function Qs(l, t) {
    if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0)
      l.flags &= -16777217;
    else if (l.flags |= 16777216, !av(t))
      if (md()) l.flags |= 8192;
      else
        throw qa = we, qf;
  }
  function vn(l, t) {
    t !== null && (l.flags |= 4), l.flags & 16384 && (t = l.tag !== 22 ? zi() : 536870912, l.lanes |= t, Su |= t);
  }
  function te(l, t) {
    if (!$)
      switch (l.tailMode) {
        case "hidden":
          t = l.tail;
          for (var a = null; t !== null; )
            t.alternate !== null && (a = t), t = t.sibling;
          a === null ? l.tail = null : a.sibling = null;
          break;
        case "collapsed":
          a = l.tail;
          for (var u = null; a !== null; )
            a.alternate !== null && (u = a), a = a.sibling;
          u === null ? t || l.tail === null ? l.tail = null : l.tail.sibling = null : u.sibling = null;
      }
  }
  function dl(l) {
    var t = l.alternate !== null && l.alternate.child === l.child, a = 0, u = 0;
    if (t)
      for (var e = l.child; e !== null; )
        a |= e.lanes | e.childLanes, u |= e.subtreeFlags & 65011712, u |= e.flags & 65011712, e.return = l, e = e.sibling;
    else
      for (e = l.child; e !== null; )
        a |= e.lanes | e.childLanes, u |= e.subtreeFlags, u |= e.flags, e.return = l, e = e.sibling;
    return l.subtreeFlags |= u, l.childLanes = a, t;
  }
  function a1(l, t, a) {
    var u = t.pendingProps;
    switch (Mf(t), t.tag) {
      case 16:
      case 15:
      case 0:
      case 11:
      case 7:
      case 8:
      case 12:
      case 9:
      case 14:
        return dl(t), null;
      case 1:
        return dl(t), null;
      case 3:
        return a = t.stateNode, u = null, l !== null && (u = l.memoizedState.cache), t.memoizedState.cache !== u && (t.flags |= 2048), jt(bl), gl(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (l === null || l.child === null) && (eu(t) ? Xt(t) : l === null || l.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, Uf())), dl(t), null;
      case 26:
        var e = t.type, n = t.memoizedState;
        return l === null ? (Xt(t), n !== null ? (dl(t), Qs(t, n)) : (dl(t), rc(
          t,
          e,
          null,
          u,
          a
        ))) : n ? n !== l.memoizedState ? (Xt(t), dl(t), Qs(t, n)) : (dl(t), t.flags &= -16777217) : (l = l.memoizedProps, l !== u && Xt(t), dl(t), rc(
          t,
          e,
          l,
          u,
          a
        )), null;
      case 27:
        if (Ee(t), a = V.current, e = t.type, l !== null && t.stateNode != null)
          l.memoizedProps !== u && Xt(t);
        else {
          if (!u) {
            if (t.stateNode === null)
              throw Error(h(166));
            return dl(t), null;
          }
          l = O.current, eu(t) ? z0(t) : (l = Wd(e, u, a), t.stateNode = l, Xt(t));
        }
        return dl(t), null;
      case 5:
        if (Ee(t), e = t.type, l !== null && t.stateNode != null)
          l.memoizedProps !== u && Xt(t);
        else {
          if (!u) {
            if (t.stateNode === null)
              throw Error(h(166));
            return dl(t), null;
          }
          if (n = O.current, eu(t))
            z0(t);
          else {
            var f = Mn(
              V.current
            );
            switch (n) {
              case 1:
                n = f.createElementNS(
                  "http://www.w3.org/2000/svg",
                  e
                );
                break;
              case 2:
                n = f.createElementNS(
                  "http://www.w3.org/1998/Math/MathML",
                  e
                );
                break;
              default:
                switch (e) {
                  case "svg":
                    n = f.createElementNS(
                      "http://www.w3.org/2000/svg",
                      e
                    );
                    break;
                  case "math":
                    n = f.createElementNS(
                      "http://www.w3.org/1998/Math/MathML",
                      e
                    );
                    break;
                  case "script":
                    n = f.createElement("div"), n.innerHTML = "<script><\/script>", n = n.removeChild(
                      n.firstChild
                    );
                    break;
                  case "select":
                    n = typeof u.is == "string" ? f.createElement("select", {
                      is: u.is
                    }) : f.createElement("select"), u.multiple ? n.multiple = !0 : u.size && (n.size = u.size);
                    break;
                  default:
                    n = typeof u.is == "string" ? f.createElement(e, { is: u.is }) : f.createElement(e);
                }
            }
            n[Ol] = t, n[Ql] = u;
            l: for (f = t.child; f !== null; ) {
              if (f.tag === 5 || f.tag === 6)
                n.appendChild(f.stateNode);
              else if (f.tag !== 4 && f.tag !== 27 && f.child !== null) {
                f.child.return = f, f = f.child;
                continue;
              }
              if (f === t) break l;
              for (; f.sibling === null; ) {
                if (f.return === null || f.return === t)
                  break l;
                f = f.return;
              }
              f.sibling.return = f.return, f = f.sibling;
            }
            t.stateNode = n;
            l: switch (Hl(n, e, u), e) {
              case "button":
              case "input":
              case "select":
              case "textarea":
                u = !!u.autoFocus;
                break l;
              case "img":
                u = !0;
                break l;
              default:
                u = !1;
            }
            u && Xt(t);
          }
        }
        return dl(t), rc(
          t,
          t.type,
          l === null ? null : l.memoizedProps,
          t.pendingProps,
          a
        ), null;
      case 6:
        if (l && t.stateNode != null)
          l.memoizedProps !== u && Xt(t);
        else {
          if (typeof u != "string" && t.stateNode === null)
            throw Error(h(166));
          if (l = V.current, eu(t)) {
            if (l = t.stateNode, a = t.memoizedProps, u = null, e = Ul, e !== null)
              switch (e.tag) {
                case 27:
                case 5:
                  u = e.memoizedProps;
              }
            l[Ol] = t, l = !!(l.nodeValue === a || u !== null && u.suppressHydrationWarning === !0 || Bd(l.nodeValue, a)), l || ta(t, !0);
          } else
            l = Mn(l).createTextNode(
              u
            ), l[Ol] = t, t.stateNode = l;
        }
        return dl(t), null;
      case 31:
        if (a = t.memoizedState, l === null || l.memoizedState !== null) {
          if (u = eu(t), a !== null) {
            if (l === null) {
              if (!u) throw Error(h(318));
              if (l = t.memoizedState, l = l !== null ? l.dehydrated : null, !l) throw Error(h(557));
              l[Ol] = t;
            } else
              Na(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            dl(t), l = !1;
          } else
            a = Uf(), l !== null && l.memoizedState !== null && (l.memoizedState.hydrationErrors = a), l = !0;
          if (!l)
            return t.flags & 256 ? (at(t), t) : (at(t), null);
          if ((t.flags & 128) !== 0)
            throw Error(h(558));
        }
        return dl(t), null;
      case 13:
        if (u = t.memoizedState, l === null || l.memoizedState !== null && l.memoizedState.dehydrated !== null) {
          if (e = eu(t), u !== null && u.dehydrated !== null) {
            if (l === null) {
              if (!e) throw Error(h(318));
              if (e = t.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(h(317));
              e[Ol] = t;
            } else
              Na(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
            dl(t), e = !1;
          } else
            e = Uf(), l !== null && l.memoizedState !== null && (l.memoizedState.hydrationErrors = e), e = !0;
          if (!e)
            return t.flags & 256 ? (at(t), t) : (at(t), null);
        }
        return at(t), (t.flags & 128) !== 0 ? (t.lanes = a, t) : (a = u !== null, l = l !== null && l.memoizedState !== null, a && (u = t.child, e = null, u.alternate !== null && u.alternate.memoizedState !== null && u.alternate.memoizedState.cachePool !== null && (e = u.alternate.memoizedState.cachePool.pool), n = null, u.memoizedState !== null && u.memoizedState.cachePool !== null && (n = u.memoizedState.cachePool.pool), n !== e && (u.flags |= 2048)), a !== l && a && (t.child.flags |= 8192), vn(t, t.updateQueue), dl(t), null);
      case 4:
        return gl(), l === null && Xc(t.stateNode.containerInfo), dl(t), null;
      case 10:
        return jt(t.type), dl(t), null;
      case 19:
        if (E(Sl), u = t.memoizedState, u === null) return dl(t), null;
        if (e = (t.flags & 128) !== 0, n = u.rendering, n === null)
          if (e) te(u, !1);
          else {
            if (hl !== 0 || l !== null && (l.flags & 128) !== 0)
              for (l = t.child; l !== null; ) {
                if (n = Fe(l), n !== null) {
                  for (t.flags |= 128, te(u, !1), l = n.updateQueue, t.updateQueue = l, vn(t, l), t.subtreeFlags = 0, l = a, a = t.child; a !== null; )
                    o0(a, l), a = a.sibling;
                  return p(
                    Sl,
                    Sl.current & 1 | 2
                  ), $ && Ct(t, u.treeForkCount), t.child;
                }
                l = l.sibling;
              }
            u.tail !== null && kl() > gn && (t.flags |= 128, e = !0, te(u, !1), t.lanes = 4194304);
          }
        else {
          if (!e)
            if (l = Fe(n), l !== null) {
              if (t.flags |= 128, e = !0, l = l.updateQueue, t.updateQueue = l, vn(t, l), te(u, !0), u.tail === null && u.tailMode === "hidden" && !n.alternate && !$)
                return dl(t), null;
            } else
              2 * kl() - u.renderingStartTime > gn && a !== 536870912 && (t.flags |= 128, e = !0, te(u, !1), t.lanes = 4194304);
          u.isBackwards ? (n.sibling = t.child, t.child = n) : (l = u.last, l !== null ? l.sibling = n : t.child = n, u.last = n);
        }
        return u.tail !== null ? (l = u.tail, u.rendering = l, u.tail = l.sibling, u.renderingStartTime = kl(), l.sibling = null, a = Sl.current, p(
          Sl,
          e ? a & 1 | 2 : a & 1
        ), $ && Ct(t, u.treeForkCount), l) : (dl(t), null);
      case 22:
      case 23:
        return at(t), Qf(), u = t.memoizedState !== null, l !== null ? l.memoizedState !== null !== u && (t.flags |= 8192) : u && (t.flags |= 8192), u ? (a & 536870912) !== 0 && (t.flags & 128) === 0 && (dl(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : dl(t), a = t.updateQueue, a !== null && vn(t, a.retryQueue), a = null, l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), u = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (u = t.memoizedState.cachePool.pool), u !== a && (t.flags |= 2048), l !== null && E(Ra), null;
      case 24:
        return a = null, l !== null && (a = l.memoizedState.cache), t.memoizedState.cache !== a && (t.flags |= 2048), jt(bl), dl(t), null;
      case 25:
        return null;
      case 30:
        return null;
    }
    throw Error(h(156, t.tag));
  }
  function u1(l, t) {
    switch (Mf(t), t.tag) {
      case 1:
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 3:
        return jt(bl), gl(), l = t.flags, (l & 65536) !== 0 && (l & 128) === 0 ? (t.flags = l & -65537 | 128, t) : null;
      case 26:
      case 27:
      case 5:
        return Ee(t), null;
      case 31:
        if (t.memoizedState !== null) {
          if (at(t), t.alternate === null)
            throw Error(h(340));
          Na();
        }
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 13:
        if (at(t), l = t.memoizedState, l !== null && l.dehydrated !== null) {
          if (t.alternate === null)
            throw Error(h(340));
          Na();
        }
        return l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 19:
        return E(Sl), null;
      case 4:
        return gl(), null;
      case 10:
        return jt(t.type), null;
      case 22:
      case 23:
        return at(t), Qf(), l !== null && E(Ra), l = t.flags, l & 65536 ? (t.flags = l & -65537 | 128, t) : null;
      case 24:
        return jt(bl), null;
      case 25:
        return null;
      default:
        return null;
    }
  }
  function Zs(l, t) {
    switch (Mf(t), t.tag) {
      case 3:
        jt(bl), gl();
        break;
      case 26:
      case 27:
      case 5:
        Ee(t);
        break;
      case 4:
        gl();
        break;
      case 31:
        t.memoizedState !== null && at(t);
        break;
      case 13:
        at(t);
        break;
      case 19:
        E(Sl);
        break;
      case 10:
        jt(t.type);
        break;
      case 22:
      case 23:
        at(t), Qf(), l !== null && E(Ra);
        break;
      case 24:
        jt(bl);
    }
  }
  function ae(l, t) {
    try {
      var a = t.updateQueue, u = a !== null ? a.lastEffect : null;
      if (u !== null) {
        var e = u.next;
        a = e;
        do {
          if ((a.tag & l) === l) {
            u = void 0;
            var n = a.create, f = a.inst;
            u = n(), f.destroy = u;
          }
          a = a.next;
        } while (a !== e);
      }
    } catch (c) {
      al(t, t.return, c);
    }
  }
  function ia(l, t, a) {
    try {
      var u = t.updateQueue, e = u !== null ? u.lastEffect : null;
      if (e !== null) {
        var n = e.next;
        u = n;
        do {
          if ((u.tag & l) === l) {
            var f = u.inst, c = f.destroy;
            if (c !== void 0) {
              f.destroy = void 0, e = t;
              var i = a, m = c;
              try {
                m();
              } catch (S) {
                al(
                  e,
                  i,
                  S
                );
              }
            }
          }
          u = u.next;
        } while (u !== n);
      }
    } catch (S) {
      al(t, t.return, S);
    }
  }
  function Vs(l) {
    var t = l.updateQueue;
    if (t !== null) {
      var a = l.stateNode;
      try {
        R0(t, a);
      } catch (u) {
        al(l, l.return, u);
      }
    }
  }
  function Ls(l, t, a) {
    a.props = Ya(
      l.type,
      l.memoizedProps
    ), a.state = l.memoizedState;
    try {
      a.componentWillUnmount();
    } catch (u) {
      al(l, t, u);
    }
  }
  function ue(l, t) {
    try {
      var a = l.ref;
      if (a !== null) {
        switch (l.tag) {
          case 26:
          case 27:
          case 5:
            var u = l.stateNode;
            break;
          case 30:
            u = l.stateNode;
            break;
          default:
            u = l.stateNode;
        }
        typeof a == "function" ? l.refCleanup = a(u) : a.current = u;
      }
    } catch (e) {
      al(l, t, e);
    }
  }
  function Mt(l, t) {
    var a = l.ref, u = l.refCleanup;
    if (a !== null)
      if (typeof u == "function")
        try {
          u();
        } catch (e) {
          al(l, t, e);
        } finally {
          l.refCleanup = null, l = l.alternate, l != null && (l.refCleanup = null);
        }
      else if (typeof a == "function")
        try {
          a(null);
        } catch (e) {
          al(l, t, e);
        }
      else a.current = null;
  }
  function Ks(l) {
    var t = l.type, a = l.memoizedProps, u = l.stateNode;
    try {
      l: switch (t) {
        case "button":
        case "input":
        case "select":
        case "textarea":
          a.autoFocus && u.focus();
          break l;
        case "img":
          a.src ? u.src = a.src : a.srcSet && (u.srcset = a.srcSet);
      }
    } catch (e) {
      al(l, l.return, e);
    }
  }
  function bc(l, t, a) {
    try {
      var u = l.stateNode;
      p1(u, l.type, a, t), u[Ql] = t;
    } catch (e) {
      al(l, l.return, e);
    }
  }
  function Js(l) {
    return l.tag === 5 || l.tag === 3 || l.tag === 26 || l.tag === 27 && oa(l.type) || l.tag === 4;
  }
  function zc(l) {
    l: for (; ; ) {
      for (; l.sibling === null; ) {
        if (l.return === null || Js(l.return)) return null;
        l = l.return;
      }
      for (l.sibling.return = l.return, l = l.sibling; l.tag !== 5 && l.tag !== 6 && l.tag !== 18; ) {
        if (l.tag === 27 && oa(l.type) || l.flags & 2 || l.child === null || l.tag === 4) continue l;
        l.child.return = l, l = l.child;
      }
      if (!(l.flags & 2)) return l.stateNode;
    }
  }
  function Ec(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      l = l.stateNode, t ? (a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a).insertBefore(l, t) : (t = a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a, t.appendChild(l), a = a._reactRootContainer, a != null || t.onclick !== null || (t.onclick = Ht));
    else if (u !== 4 && (u === 27 && oa(l.type) && (a = l.stateNode, t = null), l = l.child, l !== null))
      for (Ec(l, t, a), l = l.sibling; l !== null; )
        Ec(l, t, a), l = l.sibling;
  }
  function yn(l, t, a) {
    var u = l.tag;
    if (u === 5 || u === 6)
      l = l.stateNode, t ? a.insertBefore(l, t) : a.appendChild(l);
    else if (u !== 4 && (u === 27 && oa(l.type) && (a = l.stateNode), l = l.child, l !== null))
      for (yn(l, t, a), l = l.sibling; l !== null; )
        yn(l, t, a), l = l.sibling;
  }
  function ws(l) {
    var t = l.stateNode, a = l.memoizedProps;
    try {
      for (var u = l.type, e = t.attributes; e.length; )
        t.removeAttributeNode(e[0]);
      Hl(t, u, a), t[Ol] = l, t[Ql] = a;
    } catch (n) {
      al(l, l.return, n);
    }
  }
  var Qt = !1, Tl = !1, Tc = !1, Ws = typeof WeakSet == "function" ? WeakSet : Set, Ml = null;
  function e1(l, t) {
    if (l = l.containerInfo, Vc = Rn, l = f0(l), of(l)) {
      if ("selectionStart" in l)
        var a = {
          start: l.selectionStart,
          end: l.selectionEnd
        };
      else
        l: {
          a = (a = l.ownerDocument) && a.defaultView || window;
          var u = a.getSelection && a.getSelection();
          if (u && u.rangeCount !== 0) {
            a = u.anchorNode;
            var e = u.anchorOffset, n = u.focusNode;
            u = u.focusOffset;
            try {
              a.nodeType, n.nodeType;
            } catch {
              a = null;
              break l;
            }
            var f = 0, c = -1, i = -1, m = 0, S = 0, z = l, o = null;
            t: for (; ; ) {
              for (var g; z !== a || e !== 0 && z.nodeType !== 3 || (c = f + e), z !== n || u !== 0 && z.nodeType !== 3 || (i = f + u), z.nodeType === 3 && (f += z.nodeValue.length), (g = z.firstChild) !== null; )
                o = z, z = g;
              for (; ; ) {
                if (z === l) break t;
                if (o === a && ++m === e && (c = f), o === n && ++S === u && (i = f), (g = z.nextSibling) !== null) break;
                z = o, o = z.parentNode;
              }
              z = g;
            }
            a = c === -1 || i === -1 ? null : { start: c, end: i };
          } else a = null;
        }
      a = a || { start: 0, end: 0 };
    } else a = null;
    for (Lc = { focusedElem: l, selectionRange: a }, Rn = !1, Ml = t; Ml !== null; )
      if (t = Ml, l = t.child, (t.subtreeFlags & 1028) !== 0 && l !== null)
        l.return = t, Ml = l;
      else
        for (; Ml !== null; ) {
          switch (t = Ml, n = t.alternate, l = t.flags, t.tag) {
            case 0:
              if ((l & 4) !== 0 && (l = t.updateQueue, l = l !== null ? l.events : null, l !== null))
                for (a = 0; a < l.length; a++)
                  e = l[a], e.ref.impl = e.nextImpl;
              break;
            case 11:
            case 15:
              break;
            case 1:
              if ((l & 1024) !== 0 && n !== null) {
                l = void 0, a = t, e = n.memoizedProps, n = n.memoizedState, u = a.stateNode;
                try {
                  var M = Ya(
                    a.type,
                    e
                  );
                  l = u.getSnapshotBeforeUpdate(
                    M,
                    n
                  ), u.__reactInternalSnapshotBeforeUpdate = l;
                } catch (H) {
                  al(
                    a,
                    a.return,
                    H
                  );
                }
              }
              break;
            case 3:
              if ((l & 1024) !== 0) {
                if (l = t.stateNode.containerInfo, a = l.nodeType, a === 9)
                  wc(l);
                else if (a === 1)
                  switch (l.nodeName) {
                    case "HEAD":
                    case "HTML":
                    case "BODY":
                      wc(l);
                      break;
                    default:
                      l.textContent = "";
                  }
              }
              break;
            case 5:
            case 26:
            case 27:
            case 6:
            case 4:
            case 17:
              break;
            default:
              if ((l & 1024) !== 0) throw Error(h(163));
          }
          if (l = t.sibling, l !== null) {
            l.return = t.return, Ml = l;
            break;
          }
          Ml = t.return;
        }
  }
  function $s(l, t, a) {
    var u = a.flags;
    switch (a.tag) {
      case 0:
      case 11:
      case 15:
        Vt(l, a), u & 4 && ae(5, a);
        break;
      case 1:
        if (Vt(l, a), u & 4)
          if (l = a.stateNode, t === null)
            try {
              l.componentDidMount();
            } catch (f) {
              al(a, a.return, f);
            }
          else {
            var e = Ya(
              a.type,
              t.memoizedProps
            );
            t = t.memoizedState;
            try {
              l.componentDidUpdate(
                e,
                t,
                l.__reactInternalSnapshotBeforeUpdate
              );
            } catch (f) {
              al(
                a,
                a.return,
                f
              );
            }
          }
        u & 64 && Vs(a), u & 512 && ue(a, a.return);
        break;
      case 3:
        if (Vt(l, a), u & 64 && (l = a.updateQueue, l !== null)) {
          if (t = null, a.child !== null)
            switch (a.child.tag) {
              case 27:
              case 5:
                t = a.child.stateNode;
                break;
              case 1:
                t = a.child.stateNode;
            }
          try {
            R0(l, t);
          } catch (f) {
            al(a, a.return, f);
          }
        }
        break;
      case 27:
        t === null && u & 4 && ws(a);
      case 26:
      case 5:
        Vt(l, a), t === null && u & 4 && Ks(a), u & 512 && ue(a, a.return);
        break;
      case 12:
        Vt(l, a);
        break;
      case 31:
        Vt(l, a), u & 4 && Is(l, a);
        break;
      case 13:
        Vt(l, a), u & 4 && Ps(l, a), u & 64 && (l = a.memoizedState, l !== null && (l = l.dehydrated, l !== null && (a = m1.bind(
          null,
          a
        ), R1(l, a))));
        break;
      case 22:
        if (u = a.memoizedState !== null || Qt, !u) {
          t = t !== null && t.memoizedState !== null || Tl, e = Qt;
          var n = Tl;
          Qt = u, (Tl = t) && !n ? Lt(
            l,
            a,
            (a.subtreeFlags & 8772) !== 0
          ) : Vt(l, a), Qt = e, Tl = n;
        }
        break;
      case 30:
        break;
      default:
        Vt(l, a);
    }
  }
  function ks(l) {
    var t = l.alternate;
    t !== null && (l.alternate = null, ks(t)), l.child = null, l.deletions = null, l.sibling = null, l.tag === 5 && (t = l.stateNode, t !== null && Fn(t)), l.stateNode = null, l.return = null, l.dependencies = null, l.memoizedProps = null, l.memoizedState = null, l.pendingProps = null, l.stateNode = null, l.updateQueue = null;
  }
  var yl = null, Vl = !1;
  function Zt(l, t, a) {
    for (a = a.child; a !== null; )
      Fs(l, t, a), a = a.sibling;
  }
  function Fs(l, t, a) {
    if (Fl && typeof Fl.onCommitFiberUnmount == "function")
      try {
        Fl.onCommitFiberUnmount(Ou, a);
      } catch {
      }
    switch (a.tag) {
      case 26:
        Tl || Mt(a, t), Zt(
          l,
          t,
          a
        ), a.memoizedState ? a.memoizedState.count-- : a.stateNode && (a = a.stateNode, a.parentNode.removeChild(a));
        break;
      case 27:
        Tl || Mt(a, t);
        var u = yl, e = Vl;
        oa(a.type) && (yl = a.stateNode, Vl = !1), Zt(
          l,
          t,
          a
        ), ye(a.stateNode), yl = u, Vl = e;
        break;
      case 5:
        Tl || Mt(a, t);
      case 6:
        if (u = yl, e = Vl, yl = null, Zt(
          l,
          t,
          a
        ), yl = u, Vl = e, yl !== null)
          if (Vl)
            try {
              (yl.nodeType === 9 ? yl.body : yl.nodeName === "HTML" ? yl.ownerDocument.body : yl).removeChild(a.stateNode);
            } catch (n) {
              al(
                a,
                t,
                n
              );
            }
          else
            try {
              yl.removeChild(a.stateNode);
            } catch (n) {
              al(
                a,
                t,
                n
              );
            }
        break;
      case 18:
        yl !== null && (Vl ? (l = yl, Vd(
          l.nodeType === 9 ? l.body : l.nodeName === "HTML" ? l.ownerDocument.body : l,
          a.stateNode
        ), pu(l)) : Vd(yl, a.stateNode));
        break;
      case 4:
        u = yl, e = Vl, yl = a.stateNode.containerInfo, Vl = !0, Zt(
          l,
          t,
          a
        ), yl = u, Vl = e;
        break;
      case 0:
      case 11:
      case 14:
      case 15:
        ia(2, a, t), Tl || ia(4, a, t), Zt(
          l,
          t,
          a
        );
        break;
      case 1:
        Tl || (Mt(a, t), u = a.stateNode, typeof u.componentWillUnmount == "function" && Ls(
          a,
          t,
          u
        )), Zt(
          l,
          t,
          a
        );
        break;
      case 21:
        Zt(
          l,
          t,
          a
        );
        break;
      case 22:
        Tl = (u = Tl) || a.memoizedState !== null, Zt(
          l,
          t,
          a
        ), Tl = u;
        break;
      default:
        Zt(
          l,
          t,
          a
        );
    }
  }
  function Is(l, t) {
    if (t.memoizedState === null && (l = t.alternate, l !== null && (l = l.memoizedState, l !== null))) {
      l = l.dehydrated;
      try {
        pu(l);
      } catch (a) {
        al(t, t.return, a);
      }
    }
  }
  function Ps(l, t) {
    if (t.memoizedState === null && (l = t.alternate, l !== null && (l = l.memoizedState, l !== null && (l = l.dehydrated, l !== null))))
      try {
        pu(l);
      } catch (a) {
        al(t, t.return, a);
      }
  }
  function n1(l) {
    switch (l.tag) {
      case 31:
      case 13:
      case 19:
        var t = l.stateNode;
        return t === null && (t = l.stateNode = new Ws()), t;
      case 22:
        return l = l.stateNode, t = l._retryCache, t === null && (t = l._retryCache = new Ws()), t;
      default:
        throw Error(h(435, l.tag));
    }
  }
  function mn(l, t) {
    var a = n1(l);
    t.forEach(function(u) {
      if (!a.has(u)) {
        a.add(u);
        var e = h1.bind(null, l, u);
        u.then(e, e);
      }
    });
  }
  function Ll(l, t) {
    var a = t.deletions;
    if (a !== null)
      for (var u = 0; u < a.length; u++) {
        var e = a[u], n = l, f = t, c = f;
        l: for (; c !== null; ) {
          switch (c.tag) {
            case 27:
              if (oa(c.type)) {
                yl = c.stateNode, Vl = !1;
                break l;
              }
              break;
            case 5:
              yl = c.stateNode, Vl = !1;
              break l;
            case 3:
            case 4:
              yl = c.stateNode.containerInfo, Vl = !0;
              break l;
          }
          c = c.return;
        }
        if (yl === null) throw Error(h(160));
        Fs(n, f, e), yl = null, Vl = !1, n = e.alternate, n !== null && (n.return = null), e.return = null;
      }
    if (t.subtreeFlags & 13886)
      for (t = t.child; t !== null; )
        ld(t, l), t = t.sibling;
  }
  var bt = null;
  function ld(l, t) {
    var a = l.alternate, u = l.flags;
    switch (l.tag) {
      case 0:
      case 11:
      case 14:
      case 15:
        Ll(t, l), Kl(l), u & 4 && (ia(3, l, l.return), ae(3, l), ia(5, l, l.return));
        break;
      case 1:
        Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Mt(a, a.return)), u & 64 && Qt && (l = l.updateQueue, l !== null && (u = l.callbacks, u !== null && (a = l.shared.hiddenCallbacks, l.shared.hiddenCallbacks = a === null ? u : a.concat(u))));
        break;
      case 26:
        var e = bt;
        if (Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Mt(a, a.return)), u & 4) {
          var n = a !== null ? a.memoizedState : null;
          if (u = l.memoizedState, a === null)
            if (u === null)
              if (l.stateNode === null) {
                l: {
                  u = l.type, a = l.memoizedProps, e = e.ownerDocument || e;
                  t: switch (u) {
                    case "title":
                      n = e.getElementsByTagName("title")[0], (!n || n[Nu] || n[Ol] || n.namespaceURI === "http://www.w3.org/2000/svg" || n.hasAttribute("itemprop")) && (n = e.createElement(u), e.head.insertBefore(
                        n,
                        e.querySelector("head > title")
                      )), Hl(n, u, a), n[Ol] = l, pl(n), u = n;
                      break l;
                    case "link":
                      var f = lv(
                        "link",
                        "href",
                        e
                      ).get(u + (a.href || ""));
                      if (f) {
                        for (var c = 0; c < f.length; c++)
                          if (n = f[c], n.getAttribute("href") === (a.href == null || a.href === "" ? null : a.href) && n.getAttribute("rel") === (a.rel == null ? null : a.rel) && n.getAttribute("title") === (a.title == null ? null : a.title) && n.getAttribute("crossorigin") === (a.crossOrigin == null ? null : a.crossOrigin)) {
                            f.splice(c, 1);
                            break t;
                          }
                      }
                      n = e.createElement(u), Hl(n, u, a), e.head.appendChild(n);
                      break;
                    case "meta":
                      if (f = lv(
                        "meta",
                        "content",
                        e
                      ).get(u + (a.content || ""))) {
                        for (c = 0; c < f.length; c++)
                          if (n = f[c], n.getAttribute("content") === (a.content == null ? null : "" + a.content) && n.getAttribute("name") === (a.name == null ? null : a.name) && n.getAttribute("property") === (a.property == null ? null : a.property) && n.getAttribute("http-equiv") === (a.httpEquiv == null ? null : a.httpEquiv) && n.getAttribute("charset") === (a.charSet == null ? null : a.charSet)) {
                            f.splice(c, 1);
                            break t;
                          }
                      }
                      n = e.createElement(u), Hl(n, u, a), e.head.appendChild(n);
                      break;
                    default:
                      throw Error(h(468, u));
                  }
                  n[Ol] = l, pl(n), u = n;
                }
                l.stateNode = u;
              } else
                tv(
                  e,
                  l.type,
                  l.stateNode
                );
            else
              l.stateNode = Pd(
                e,
                u,
                l.memoizedProps
              );
          else
            n !== u ? (n === null ? a.stateNode !== null && (a = a.stateNode, a.parentNode.removeChild(a)) : n.count--, u === null ? tv(
              e,
              l.type,
              l.stateNode
            ) : Pd(
              e,
              u,
              l.memoizedProps
            )) : u === null && l.stateNode !== null && bc(
              l,
              l.memoizedProps,
              a.memoizedProps
            );
        }
        break;
      case 27:
        Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Mt(a, a.return)), a !== null && u & 4 && bc(
          l,
          l.memoizedProps,
          a.memoizedProps
        );
        break;
      case 5:
        if (Ll(t, l), Kl(l), u & 512 && (Tl || a === null || Mt(a, a.return)), l.flags & 32) {
          e = l.stateNode;
          try {
            Wa(e, "");
          } catch (M) {
            al(l, l.return, M);
          }
        }
        u & 4 && l.stateNode != null && (e = l.memoizedProps, bc(
          l,
          e,
          a !== null ? a.memoizedProps : e
        )), u & 1024 && (Tc = !0);
        break;
      case 6:
        if (Ll(t, l), Kl(l), u & 4) {
          if (l.stateNode === null)
            throw Error(h(162));
          u = l.memoizedProps, a = l.stateNode;
          try {
            a.nodeValue = u;
          } catch (M) {
            al(l, l.return, M);
          }
        }
        break;
      case 3:
        if (Dn = null, e = bt, bt = On(t.containerInfo), Ll(t, l), bt = e, Kl(l), u & 4 && a !== null && a.memoizedState.isDehydrated)
          try {
            pu(t.containerInfo);
          } catch (M) {
            al(l, l.return, M);
          }
        Tc && (Tc = !1, td(l));
        break;
      case 4:
        u = bt, bt = On(
          l.stateNode.containerInfo
        ), Ll(t, l), Kl(l), bt = u;
        break;
      case 12:
        Ll(t, l), Kl(l);
        break;
      case 31:
        Ll(t, l), Kl(l), u & 4 && (u = l.updateQueue, u !== null && (l.updateQueue = null, mn(l, u)));
        break;
      case 13:
        Ll(t, l), Kl(l), l.child.flags & 8192 && l.memoizedState !== null != (a !== null && a.memoizedState !== null) && (on = kl()), u & 4 && (u = l.updateQueue, u !== null && (l.updateQueue = null, mn(l, u)));
        break;
      case 22:
        e = l.memoizedState !== null;
        var i = a !== null && a.memoizedState !== null, m = Qt, S = Tl;
        if (Qt = m || e, Tl = S || i, Ll(t, l), Tl = S, Qt = m, Kl(l), u & 8192)
          l: for (t = l.stateNode, t._visibility = e ? t._visibility & -2 : t._visibility | 1, e && (a === null || i || Qt || Tl || Ga(l)), a = null, t = l; ; ) {
            if (t.tag === 5 || t.tag === 26) {
              if (a === null) {
                i = a = t;
                try {
                  if (n = i.stateNode, e)
                    f = n.style, typeof f.setProperty == "function" ? f.setProperty("display", "none", "important") : f.display = "none";
                  else {
                    c = i.stateNode;
                    var z = i.memoizedProps.style, o = z != null && z.hasOwnProperty("display") ? z.display : null;
                    c.style.display = o == null || typeof o == "boolean" ? "" : ("" + o).trim();
                  }
                } catch (M) {
                  al(i, i.return, M);
                }
              }
            } else if (t.tag === 6) {
              if (a === null) {
                i = t;
                try {
                  i.stateNode.nodeValue = e ? "" : i.memoizedProps;
                } catch (M) {
                  al(i, i.return, M);
                }
              }
            } else if (t.tag === 18) {
              if (a === null) {
                i = t;
                try {
                  var g = i.stateNode;
                  e ? Ld(g, !0) : Ld(i.stateNode, !1);
                } catch (M) {
                  al(i, i.return, M);
                }
              }
            } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === l) && t.child !== null) {
              t.child.return = t, t = t.child;
              continue;
            }
            if (t === l) break l;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === l) break l;
              a === t && (a = null), t = t.return;
            }
            a === t && (a = null), t.sibling.return = t.return, t = t.sibling;
          }
        u & 4 && (u = l.updateQueue, u !== null && (a = u.retryQueue, a !== null && (u.retryQueue = null, mn(l, a))));
        break;
      case 19:
        Ll(t, l), Kl(l), u & 4 && (u = l.updateQueue, u !== null && (l.updateQueue = null, mn(l, u)));
        break;
      case 30:
        break;
      case 21:
        break;
      default:
        Ll(t, l), Kl(l);
    }
  }
  function Kl(l) {
    var t = l.flags;
    if (t & 2) {
      try {
        for (var a, u = l.return; u !== null; ) {
          if (Js(u)) {
            a = u;
            break;
          }
          u = u.return;
        }
        if (a == null) throw Error(h(160));
        switch (a.tag) {
          case 27:
            var e = a.stateNode, n = zc(l);
            yn(l, n, e);
            break;
          case 5:
            var f = a.stateNode;
            a.flags & 32 && (Wa(f, ""), a.flags &= -33);
            var c = zc(l);
            yn(l, c, f);
            break;
          case 3:
          case 4:
            var i = a.stateNode.containerInfo, m = zc(l);
            Ec(
              l,
              m,
              i
            );
            break;
          default:
            throw Error(h(161));
        }
      } catch (S) {
        al(l, l.return, S);
      }
      l.flags &= -3;
    }
    t & 4096 && (l.flags &= -4097);
  }
  function td(l) {
    if (l.subtreeFlags & 1024)
      for (l = l.child; l !== null; ) {
        var t = l;
        td(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), l = l.sibling;
      }
  }
  function Vt(l, t) {
    if (t.subtreeFlags & 8772)
      for (t = t.child; t !== null; )
        $s(l, t.alternate, t), t = t.sibling;
  }
  function Ga(l) {
    for (l = l.child; l !== null; ) {
      var t = l;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          ia(4, t, t.return), Ga(t);
          break;
        case 1:
          Mt(t, t.return);
          var a = t.stateNode;
          typeof a.componentWillUnmount == "function" && Ls(
            t,
            t.return,
            a
          ), Ga(t);
          break;
        case 27:
          ye(t.stateNode);
        case 26:
        case 5:
          Mt(t, t.return), Ga(t);
          break;
        case 22:
          t.memoizedState === null && Ga(t);
          break;
        case 30:
          Ga(t);
          break;
        default:
          Ga(t);
      }
      l = l.sibling;
    }
  }
  function Lt(l, t, a) {
    for (a = a && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
      var u = t.alternate, e = l, n = t, f = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          Lt(
            e,
            n,
            a
          ), ae(4, n);
          break;
        case 1:
          if (Lt(
            e,
            n,
            a
          ), u = n, e = u.stateNode, typeof e.componentDidMount == "function")
            try {
              e.componentDidMount();
            } catch (m) {
              al(u, u.return, m);
            }
          if (u = n, e = u.updateQueue, e !== null) {
            var c = u.stateNode;
            try {
              var i = e.shared.hiddenCallbacks;
              if (i !== null)
                for (e.shared.hiddenCallbacks = null, e = 0; e < i.length; e++)
                  x0(i[e], c);
            } catch (m) {
              al(u, u.return, m);
            }
          }
          a && f & 64 && Vs(n), ue(n, n.return);
          break;
        case 27:
          ws(n);
        case 26:
        case 5:
          Lt(
            e,
            n,
            a
          ), a && u === null && f & 4 && Ks(n), ue(n, n.return);
          break;
        case 12:
          Lt(
            e,
            n,
            a
          );
          break;
        case 31:
          Lt(
            e,
            n,
            a
          ), a && f & 4 && Is(e, n);
          break;
        case 13:
          Lt(
            e,
            n,
            a
          ), a && f & 4 && Ps(e, n);
          break;
        case 22:
          n.memoizedState === null && Lt(
            e,
            n,
            a
          ), ue(n, n.return);
          break;
        case 30:
          break;
        default:
          Lt(
            e,
            n,
            a
          );
      }
      t = t.sibling;
    }
  }
  function Ac(l, t) {
    var a = null;
    l !== null && l.memoizedState !== null && l.memoizedState.cachePool !== null && (a = l.memoizedState.cachePool.pool), l = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (l = t.memoizedState.cachePool.pool), l !== a && (l != null && l.refCount++, a != null && Vu(a));
  }
  function _c(l, t) {
    l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && Vu(l));
  }
  function zt(l, t, a, u) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; )
        ad(
          l,
          t,
          a,
          u
        ), t = t.sibling;
  }
  function ad(l, t, a, u) {
    var e = t.flags;
    switch (t.tag) {
      case 0:
      case 11:
      case 15:
        zt(
          l,
          t,
          a,
          u
        ), e & 2048 && ae(9, t);
        break;
      case 1:
        zt(
          l,
          t,
          a,
          u
        );
        break;
      case 3:
        zt(
          l,
          t,
          a,
          u
        ), e & 2048 && (l = null, t.alternate !== null && (l = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== l && (t.refCount++, l != null && Vu(l)));
        break;
      case 12:
        if (e & 2048) {
          zt(
            l,
            t,
            a,
            u
          ), l = t.stateNode;
          try {
            var n = t.memoizedProps, f = n.id, c = n.onPostCommit;
            typeof c == "function" && c(
              f,
              t.alternate === null ? "mount" : "update",
              l.passiveEffectDuration,
              -0
            );
          } catch (i) {
            al(t, t.return, i);
          }
        } else
          zt(
            l,
            t,
            a,
            u
          );
        break;
      case 31:
        zt(
          l,
          t,
          a,
          u
        );
        break;
      case 13:
        zt(
          l,
          t,
          a,
          u
        );
        break;
      case 23:
        break;
      case 22:
        n = t.stateNode, f = t.alternate, t.memoizedState !== null ? n._visibility & 2 ? zt(
          l,
          t,
          a,
          u
        ) : ee(l, t) : n._visibility & 2 ? zt(
          l,
          t,
          a,
          u
        ) : (n._visibility |= 2, hu(
          l,
          t,
          a,
          u,
          (t.subtreeFlags & 10256) !== 0 || !1
        )), e & 2048 && Ac(f, t);
        break;
      case 24:
        zt(
          l,
          t,
          a,
          u
        ), e & 2048 && _c(t.alternate, t);
        break;
      default:
        zt(
          l,
          t,
          a,
          u
        );
    }
  }
  function hu(l, t, a, u, e) {
    for (e = e && ((t.subtreeFlags & 10256) !== 0 || !1), t = t.child; t !== null; ) {
      var n = l, f = t, c = a, i = u, m = f.flags;
      switch (f.tag) {
        case 0:
        case 11:
        case 15:
          hu(
            n,
            f,
            c,
            i,
            e
          ), ae(8, f);
          break;
        case 23:
          break;
        case 22:
          var S = f.stateNode;
          f.memoizedState !== null ? S._visibility & 2 ? hu(
            n,
            f,
            c,
            i,
            e
          ) : ee(
            n,
            f
          ) : (S._visibility |= 2, hu(
            n,
            f,
            c,
            i,
            e
          )), e && m & 2048 && Ac(
            f.alternate,
            f
          );
          break;
        case 24:
          hu(
            n,
            f,
            c,
            i,
            e
          ), e && m & 2048 && _c(f.alternate, f);
          break;
        default:
          hu(
            n,
            f,
            c,
            i,
            e
          );
      }
      t = t.sibling;
    }
  }
  function ee(l, t) {
    if (t.subtreeFlags & 10256)
      for (t = t.child; t !== null; ) {
        var a = l, u = t, e = u.flags;
        switch (u.tag) {
          case 22:
            ee(a, u), e & 2048 && Ac(
              u.alternate,
              u
            );
            break;
          case 24:
            ee(a, u), e & 2048 && _c(u.alternate, u);
            break;
          default:
            ee(a, u);
        }
        t = t.sibling;
      }
  }
  var ne = 8192;
  function ou(l, t, a) {
    if (l.subtreeFlags & ne)
      for (l = l.child; l !== null; )
        ud(
          l,
          t,
          a
        ), l = l.sibling;
  }
  function ud(l, t, a) {
    switch (l.tag) {
      case 26:
        ou(
          l,
          t,
          a
        ), l.flags & ne && l.memoizedState !== null && K1(
          a,
          bt,
          l.memoizedState,
          l.memoizedProps
        );
        break;
      case 5:
        ou(
          l,
          t,
          a
        );
        break;
      case 3:
      case 4:
        var u = bt;
        bt = On(l.stateNode.containerInfo), ou(
          l,
          t,
          a
        ), bt = u;
        break;
      case 22:
        l.memoizedState === null && (u = l.alternate, u !== null && u.memoizedState !== null ? (u = ne, ne = 16777216, ou(
          l,
          t,
          a
        ), ne = u) : ou(
          l,
          t,
          a
        ));
        break;
      default:
        ou(
          l,
          t,
          a
        );
    }
  }
  function ed(l) {
    var t = l.alternate;
    if (t !== null && (l = t.child, l !== null)) {
      t.child = null;
      do
        t = l.sibling, l.sibling = null, l = t;
      while (l !== null);
    }
  }
  function fe(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          Ml = u, fd(
            u,
            l
          );
        }
      ed(l);
    }
    if (l.subtreeFlags & 10256)
      for (l = l.child; l !== null; )
        nd(l), l = l.sibling;
  }
  function nd(l) {
    switch (l.tag) {
      case 0:
      case 11:
      case 15:
        fe(l), l.flags & 2048 && ia(9, l, l.return);
        break;
      case 3:
        fe(l);
        break;
      case 12:
        fe(l);
        break;
      case 22:
        var t = l.stateNode;
        l.memoizedState !== null && t._visibility & 2 && (l.return === null || l.return.tag !== 13) ? (t._visibility &= -3, hn(l)) : fe(l);
        break;
      default:
        fe(l);
    }
  }
  function hn(l) {
    var t = l.deletions;
    if ((l.flags & 16) !== 0) {
      if (t !== null)
        for (var a = 0; a < t.length; a++) {
          var u = t[a];
          Ml = u, fd(
            u,
            l
          );
        }
      ed(l);
    }
    for (l = l.child; l !== null; ) {
      switch (t = l, t.tag) {
        case 0:
        case 11:
        case 15:
          ia(8, t, t.return), hn(t);
          break;
        case 22:
          a = t.stateNode, a._visibility & 2 && (a._visibility &= -3, hn(t));
          break;
        default:
          hn(t);
      }
      l = l.sibling;
    }
  }
  function fd(l, t) {
    for (; Ml !== null; ) {
      var a = Ml;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          ia(8, a, t);
          break;
        case 23:
        case 22:
          if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
            var u = a.memoizedState.cachePool.pool;
            u != null && u.refCount++;
          }
          break;
        case 24:
          Vu(a.memoizedState.cache);
      }
      if (u = a.child, u !== null) u.return = a, Ml = u;
      else
        l: for (a = l; Ml !== null; ) {
          u = Ml;
          var e = u.sibling, n = u.return;
          if (ks(u), u === a) {
            Ml = null;
            break l;
          }
          if (e !== null) {
            e.return = n, Ml = e;
            break l;
          }
          Ml = n;
        }
    }
  }
  var f1 = {
    getCacheForType: function(l) {
      var t = Dl(bl), a = t.data.get(l);
      return a === void 0 && (a = l(), t.data.set(l, a)), a;
    },
    cacheSignal: function() {
      return Dl(bl).controller.signal;
    }
  }, c1 = typeof WeakMap == "function" ? WeakMap : Map, P = 0, il = null, L = null, J = 0, tl = 0, ut = null, sa = !1, gu = !1, pc = !1, Kt = 0, hl = 0, da = 0, Xa = 0, Mc = 0, et = 0, Su = 0, ce = null, Jl = null, Oc = !1, on = 0, cd = 0, gn = 1 / 0, Sn = null, va = null, Al = 0, ya = null, ru = null, Jt = 0, Uc = 0, Dc = null, id = null, ie = 0, Nc = null;
  function nt() {
    return (P & 2) !== 0 && J !== 0 ? J & -J : r.T !== null ? jc() : _i();
  }
  function sd() {
    if (et === 0)
      if ((J & 536870912) === 0 || $) {
        var l = _e;
        _e <<= 1, (_e & 3932160) === 0 && (_e = 262144), et = l;
      } else et = 536870912;
    return l = tt.current, l !== null && (l.flags |= 32), et;
  }
  function wl(l, t, a) {
    (l === il && (tl === 2 || tl === 9) || l.cancelPendingCommit !== null) && (bu(l, 0), ma(
      l,
      J,
      et,
      !1
    )), Du(l, a), ((P & 2) === 0 || l !== il) && (l === il && ((P & 2) === 0 && (Xa |= a), hl === 4 && ma(
      l,
      J,
      et,
      !1
    )), Ot(l));
  }
  function dd(l, t, a) {
    if ((P & 6) !== 0) throw Error(h(327));
    var u = !a && (t & 127) === 0 && (t & l.expiredLanes) === 0 || Uu(l, t), e = u ? d1(l, t) : xc(l, t, !0), n = u;
    do {
      if (e === 0) {
        gu && !u && ma(l, t, 0, !1);
        break;
      } else {
        if (a = l.current.alternate, n && !i1(a)) {
          e = xc(l, t, !1), n = !1;
          continue;
        }
        if (e === 2) {
          if (n = t, l.errorRecoveryDisabledLanes & n)
            var f = 0;
          else
            f = l.pendingLanes & -536870913, f = f !== 0 ? f : f & 536870912 ? 536870912 : 0;
          if (f !== 0) {
            t = f;
            l: {
              var c = l;
              e = ce;
              var i = c.current.memoizedState.isDehydrated;
              if (i && (bu(c, f).flags |= 256), f = xc(
                c,
                f,
                !1
              ), f !== 2) {
                if (pc && !i) {
                  c.errorRecoveryDisabledLanes |= n, Xa |= n, e = 4;
                  break l;
                }
                n = Jl, Jl = e, n !== null && (Jl === null ? Jl = n : Jl.push.apply(
                  Jl,
                  n
                ));
              }
              e = f;
            }
            if (n = !1, e !== 2) continue;
          }
        }
        if (e === 1) {
          bu(l, 0), ma(l, t, 0, !0);
          break;
        }
        l: {
          switch (u = l, n = e, n) {
            case 0:
            case 1:
              throw Error(h(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              ma(
                u,
                t,
                et,
                !sa
              );
              break l;
            case 2:
              Jl = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(h(329));
          }
          if ((t & 62914560) === t && (e = on + 300 - kl(), 10 < e)) {
            if (ma(
              u,
              t,
              et,
              !sa
            ), Me(u, 0, !0) !== 0) break l;
            Jt = t, u.timeoutHandle = Qd(
              vd.bind(
                null,
                u,
                a,
                Jl,
                Sn,
                Oc,
                t,
                et,
                Xa,
                Su,
                sa,
                n,
                "Throttled",
                -0,
                0
              ),
              e
            );
            break l;
          }
          vd(
            u,
            a,
            Jl,
            Sn,
            Oc,
            t,
            et,
            Xa,
            Su,
            sa,
            n,
            null,
            -0,
            0
          );
        }
      }
      break;
    } while (!0);
    Ot(l);
  }
  function vd(l, t, a, u, e, n, f, c, i, m, S, z, o, g) {
    if (l.timeoutHandle = -1, z = t.subtreeFlags, z & 8192 || (z & 16785408) === 16785408) {
      z = {
        stylesheets: null,
        count: 0,
        imgCount: 0,
        imgBytes: 0,
        suspenseyImages: [],
        waitingForImages: !0,
        waitingForViewTransition: !1,
        unsuspend: Ht
      }, ud(
        t,
        n,
        z
      );
      var M = (n & 62914560) === n ? on - kl() : (n & 4194048) === n ? cd - kl() : 0;
      if (M = J1(
        z,
        M
      ), M !== null) {
        Jt = n, l.cancelPendingCommit = M(
          bd.bind(
            null,
            l,
            t,
            n,
            a,
            u,
            e,
            f,
            c,
            i,
            S,
            z,
            null,
            o,
            g
          )
        ), ma(l, n, f, !m);
        return;
      }
    }
    bd(
      l,
      t,
      n,
      a,
      u,
      e,
      f,
      c,
      i
    );
  }
  function i1(l) {
    for (var t = l; ; ) {
      var a = t.tag;
      if ((a === 0 || a === 11 || a === 15) && t.flags & 16384 && (a = t.updateQueue, a !== null && (a = a.stores, a !== null)))
        for (var u = 0; u < a.length; u++) {
          var e = a[u], n = e.getSnapshot;
          e = e.value;
          try {
            if (!Pl(n(), e)) return !1;
          } catch {
            return !1;
          }
        }
      if (a = t.child, t.subtreeFlags & 16384 && a !== null)
        a.return = t, t = a;
      else {
        if (t === l) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === l) return !0;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
    }
    return !0;
  }
  function ma(l, t, a, u) {
    t &= ~Mc, t &= ~Xa, l.suspendedLanes |= t, l.pingedLanes &= ~t, u && (l.warmLanes |= t), u = l.expirationTimes;
    for (var e = t; 0 < e; ) {
      var n = 31 - Il(e), f = 1 << n;
      u[n] = -1, e &= ~f;
    }
    a !== 0 && Ei(l, a, t);
  }
  function rn() {
    return (P & 6) === 0 ? (se(0), !1) : !0;
  }
  function Hc() {
    if (L !== null) {
      if (tl === 0)
        var l = L.return;
      else
        l = L, qt = Ha = null, wf(l), su = null, Ku = 0, l = L;
      for (; l !== null; )
        Zs(l.alternate, l), l = l.return;
      L = null;
    }
  }
  function bu(l, t) {
    var a = l.timeoutHandle;
    a !== -1 && (l.timeoutHandle = -1, U1(a)), a = l.cancelPendingCommit, a !== null && (l.cancelPendingCommit = null, a()), Jt = 0, Hc(), il = l, L = a = Rt(l.current, null), J = t, tl = 0, ut = null, sa = !1, gu = Uu(l, t), pc = !1, Su = et = Mc = Xa = da = hl = 0, Jl = ce = null, Oc = !1, (t & 8) !== 0 && (t |= t & 32);
    var u = l.entangledLanes;
    if (u !== 0)
      for (l = l.entanglements, u &= t; 0 < u; ) {
        var e = 31 - Il(u), n = 1 << e;
        t |= l[e], u &= ~n;
      }
    return Kt = t, Ye(), a;
  }
  function yd(l, t) {
    G = null, r.H = Pu, t === iu || t === Je ? (t = U0(), tl = 3) : t === qf ? (t = U0(), tl = 4) : tl = t === sc ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, ut = t, L === null && (hl = 1, fn(
      l,
      dt(t, l.current)
    ));
  }
  function md() {
    var l = tt.current;
    return l === null ? !0 : (J & 4194048) === J ? ht === null : (J & 62914560) === J || (J & 536870912) !== 0 ? l === ht : !1;
  }
  function hd() {
    var l = r.H;
    return r.H = Pu, l === null ? Pu : l;
  }
  function od() {
    var l = r.A;
    return r.A = f1, l;
  }
  function bn() {
    hl = 4, sa || (J & 4194048) !== J && tt.current !== null || (gu = !0), (da & 134217727) === 0 && (Xa & 134217727) === 0 || il === null || ma(
      il,
      J,
      et,
      !1
    );
  }
  function xc(l, t, a) {
    var u = P;
    P |= 2;
    var e = hd(), n = od();
    (il !== l || J !== t) && (Sn = null, bu(l, t)), t = !1;
    var f = hl;
    l: do
      try {
        if (tl !== 0 && L !== null) {
          var c = L, i = ut;
          switch (tl) {
            case 8:
              Hc(), f = 6;
              break l;
            case 3:
            case 2:
            case 9:
            case 6:
              tt.current === null && (t = !0);
              var m = tl;
              if (tl = 0, ut = null, zu(l, c, i, m), a && gu) {
                f = 0;
                break l;
              }
              break;
            default:
              m = tl, tl = 0, ut = null, zu(l, c, i, m);
          }
        }
        s1(), f = hl;
        break;
      } catch (S) {
        yd(l, S);
      }
    while (!0);
    return t && l.shellSuspendCounter++, qt = Ha = null, P = u, r.H = e, r.A = n, L === null && (il = null, J = 0, Ye()), f;
  }
  function s1() {
    for (; L !== null; ) gd(L);
  }
  function d1(l, t) {
    var a = P;
    P |= 2;
    var u = hd(), e = od();
    il !== l || J !== t ? (Sn = null, gn = kl() + 500, bu(l, t)) : gu = Uu(
      l,
      t
    );
    l: do
      try {
        if (tl !== 0 && L !== null) {
          t = L;
          var n = ut;
          t: switch (tl) {
            case 1:
              tl = 0, ut = null, zu(l, t, n, 1);
              break;
            case 2:
            case 9:
              if (M0(n)) {
                tl = 0, ut = null, Sd(t);
                break;
              }
              t = function() {
                tl !== 2 && tl !== 9 || il !== l || (tl = 7), Ot(l);
              }, n.then(t, t);
              break l;
            case 3:
              tl = 7;
              break l;
            case 4:
              tl = 5;
              break l;
            case 7:
              M0(n) ? (tl = 0, ut = null, Sd(t)) : (tl = 0, ut = null, zu(l, t, n, 7));
              break;
            case 5:
              var f = null;
              switch (L.tag) {
                case 26:
                  f = L.memoizedState;
                case 5:
                case 27:
                  var c = L;
                  if (f ? av(f) : c.stateNode.complete) {
                    tl = 0, ut = null;
                    var i = c.sibling;
                    if (i !== null) L = i;
                    else {
                      var m = c.return;
                      m !== null ? (L = m, zn(m)) : L = null;
                    }
                    break t;
                  }
              }
              tl = 0, ut = null, zu(l, t, n, 5);
              break;
            case 6:
              tl = 0, ut = null, zu(l, t, n, 6);
              break;
            case 8:
              Hc(), hl = 6;
              break l;
            default:
              throw Error(h(462));
          }
        }
        v1();
        break;
      } catch (S) {
        yd(l, S);
      }
    while (!0);
    return qt = Ha = null, r.H = u, r.A = e, P = a, L !== null ? 0 : (il = null, J = 0, Ye(), hl);
  }
  function v1() {
    for (; L !== null && !Cv(); )
      gd(L);
  }
  function gd(l) {
    var t = Xs(l.alternate, l, Kt);
    l.memoizedProps = l.pendingProps, t === null ? zn(l) : L = t;
  }
  function Sd(l) {
    var t = l, a = t.alternate;
    switch (t.tag) {
      case 15:
      case 0:
        t = Cs(
          a,
          t,
          t.pendingProps,
          t.type,
          void 0,
          J
        );
        break;
      case 11:
        t = Cs(
          a,
          t,
          t.pendingProps,
          t.type.render,
          t.ref,
          J
        );
        break;
      case 5:
        wf(t);
      default:
        Zs(a, t), t = L = o0(t, Kt), t = Xs(a, t, Kt);
    }
    l.memoizedProps = l.pendingProps, t === null ? zn(l) : L = t;
  }
  function zu(l, t, a, u) {
    qt = Ha = null, wf(t), su = null, Ku = 0;
    var e = t.return;
    try {
      if (Py(
        l,
        e,
        t,
        a,
        J
      )) {
        hl = 1, fn(
          l,
          dt(a, l.current)
        ), L = null;
        return;
      }
    } catch (n) {
      if (e !== null) throw L = e, n;
      hl = 1, fn(
        l,
        dt(a, l.current)
      ), L = null;
      return;
    }
    t.flags & 32768 ? ($ || u === 1 ? l = !0 : gu || (J & 536870912) !== 0 ? l = !1 : (sa = l = !0, (u === 2 || u === 9 || u === 3 || u === 6) && (u = tt.current, u !== null && u.tag === 13 && (u.flags |= 16384))), rd(t, l)) : zn(t);
  }
  function zn(l) {
    var t = l;
    do {
      if ((t.flags & 32768) !== 0) {
        rd(
          t,
          sa
        );
        return;
      }
      l = t.return;
      var a = a1(
        t.alternate,
        t,
        Kt
      );
      if (a !== null) {
        L = a;
        return;
      }
      if (t = t.sibling, t !== null) {
        L = t;
        return;
      }
      L = t = l;
    } while (t !== null);
    hl === 0 && (hl = 5);
  }
  function rd(l, t) {
    do {
      var a = u1(l.alternate, l);
      if (a !== null) {
        a.flags &= 32767, L = a;
        return;
      }
      if (a = l.return, a !== null && (a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null), !t && (l = l.sibling, l !== null)) {
        L = l;
        return;
      }
      L = l = a;
    } while (l !== null);
    hl = 6, L = null;
  }
  function bd(l, t, a, u, e, n, f, c, i) {
    l.cancelPendingCommit = null;
    do
      En();
    while (Al !== 0);
    if ((P & 6) !== 0) throw Error(h(327));
    if (t !== null) {
      if (t === l.current) throw Error(h(177));
      if (n = t.lanes | t.childLanes, n |= zf, Lv(
        l,
        a,
        n,
        f,
        c,
        i
      ), l === il && (L = il = null, J = 0), ru = t, ya = l, Jt = a, Uc = n, Dc = e, id = u, (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? (l.callbackNode = null, l.callbackPriority = 0, o1(Te, function() {
        return _d(), null;
      })) : (l.callbackNode = null, l.callbackPriority = 0), u = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || u) {
        u = r.T, r.T = null, e = _.p, _.p = 2, f = P, P |= 4;
        try {
          e1(l, t, a);
        } finally {
          P = f, _.p = e, r.T = u;
        }
      }
      Al = 1, zd(), Ed(), Td();
    }
  }
  function zd() {
    if (Al === 1) {
      Al = 0;
      var l = ya, t = ru, a = (t.flags & 13878) !== 0;
      if ((t.subtreeFlags & 13878) !== 0 || a) {
        a = r.T, r.T = null;
        var u = _.p;
        _.p = 2;
        var e = P;
        P |= 4;
        try {
          ld(t, l);
          var n = Lc, f = f0(l.containerInfo), c = n.focusedElem, i = n.selectionRange;
          if (f !== c && c && c.ownerDocument && n0(
            c.ownerDocument.documentElement,
            c
          )) {
            if (i !== null && of(c)) {
              var m = i.start, S = i.end;
              if (S === void 0 && (S = m), "selectionStart" in c)
                c.selectionStart = m, c.selectionEnd = Math.min(
                  S,
                  c.value.length
                );
              else {
                var z = c.ownerDocument || document, o = z && z.defaultView || window;
                if (o.getSelection) {
                  var g = o.getSelection(), M = c.textContent.length, H = Math.min(i.start, M), fl = i.end === void 0 ? H : Math.min(i.end, M);
                  !g.extend && H > fl && (f = fl, fl = H, H = f);
                  var v = e0(
                    c,
                    H
                  ), s = e0(
                    c,
                    fl
                  );
                  if (v && s && (g.rangeCount !== 1 || g.anchorNode !== v.node || g.anchorOffset !== v.offset || g.focusNode !== s.node || g.focusOffset !== s.offset)) {
                    var y = z.createRange();
                    y.setStart(v.node, v.offset), g.removeAllRanges(), H > fl ? (g.addRange(y), g.extend(s.node, s.offset)) : (y.setEnd(s.node, s.offset), g.addRange(y));
                  }
                }
              }
            }
            for (z = [], g = c; g = g.parentNode; )
              g.nodeType === 1 && z.push({
                element: g,
                left: g.scrollLeft,
                top: g.scrollTop
              });
            for (typeof c.focus == "function" && c.focus(), c = 0; c < z.length; c++) {
              var b = z[c];
              b.element.scrollLeft = b.left, b.element.scrollTop = b.top;
            }
          }
          Rn = !!Vc, Lc = Vc = null;
        } finally {
          P = e, _.p = u, r.T = a;
        }
      }
      l.current = t, Al = 2;
    }
  }
  function Ed() {
    if (Al === 2) {
      Al = 0;
      var l = ya, t = ru, a = (t.flags & 8772) !== 0;
      if ((t.subtreeFlags & 8772) !== 0 || a) {
        a = r.T, r.T = null;
        var u = _.p;
        _.p = 2;
        var e = P;
        P |= 4;
        try {
          $s(l, t.alternate, t);
        } finally {
          P = e, _.p = u, r.T = a;
        }
      }
      Al = 3;
    }
  }
  function Td() {
    if (Al === 4 || Al === 3) {
      Al = 0, qv();
      var l = ya, t = ru, a = Jt, u = id;
      (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? Al = 5 : (Al = 0, ru = ya = null, Ad(l, l.pendingLanes));
      var e = l.pendingLanes;
      if (e === 0 && (va = null), $n(a), t = t.stateNode, Fl && typeof Fl.onCommitFiberRoot == "function")
        try {
          Fl.onCommitFiberRoot(
            Ou,
            t,
            void 0,
            (t.current.flags & 128) === 128
          );
        } catch {
        }
      if (u !== null) {
        t = r.T, e = _.p, _.p = 2, r.T = null;
        try {
          for (var n = l.onRecoverableError, f = 0; f < u.length; f++) {
            var c = u[f];
            n(c.value, {
              componentStack: c.stack
            });
          }
        } finally {
          r.T = t, _.p = e;
        }
      }
      (Jt & 3) !== 0 && En(), Ot(l), e = l.pendingLanes, (a & 261930) !== 0 && (e & 42) !== 0 ? l === Nc ? ie++ : (ie = 0, Nc = l) : ie = 0, se(0);
    }
  }
  function Ad(l, t) {
    (l.pooledCacheLanes &= t) === 0 && (t = l.pooledCache, t != null && (l.pooledCache = null, Vu(t)));
  }
  function En() {
    return zd(), Ed(), Td(), _d();
  }
  function _d() {
    if (Al !== 5) return !1;
    var l = ya, t = Uc;
    Uc = 0;
    var a = $n(Jt), u = r.T, e = _.p;
    try {
      _.p = 32 > a ? 32 : a, r.T = null, a = Dc, Dc = null;
      var n = ya, f = Jt;
      if (Al = 0, ru = ya = null, Jt = 0, (P & 6) !== 0) throw Error(h(331));
      var c = P;
      if (P |= 4, nd(n.current), ad(
        n,
        n.current,
        f,
        a
      ), P = c, se(0, !1), Fl && typeof Fl.onPostCommitFiberRoot == "function")
        try {
          Fl.onPostCommitFiberRoot(Ou, n);
        } catch {
        }
      return !0;
    } finally {
      _.p = e, r.T = u, Ad(l, t);
    }
  }
  function pd(l, t, a) {
    t = dt(a, t), t = ic(l.stateNode, t, 2), l = na(l, t, 2), l !== null && (Du(l, 2), Ot(l));
  }
  function al(l, t, a) {
    if (l.tag === 3)
      pd(l, l, a);
    else
      for (; t !== null; ) {
        if (t.tag === 3) {
          pd(
            t,
            l,
            a
          );
          break;
        } else if (t.tag === 1) {
          var u = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof u.componentDidCatch == "function" && (va === null || !va.has(u))) {
            l = dt(a, l), a = Ms(2), u = na(t, a, 2), u !== null && (Os(
              a,
              u,
              t,
              l
            ), Du(u, 2), Ot(u));
            break;
          }
        }
        t = t.return;
      }
  }
  function Rc(l, t, a) {
    var u = l.pingCache;
    if (u === null) {
      u = l.pingCache = new c1();
      var e = /* @__PURE__ */ new Set();
      u.set(t, e);
    } else
      e = u.get(t), e === void 0 && (e = /* @__PURE__ */ new Set(), u.set(t, e));
    e.has(a) || (pc = !0, e.add(a), l = y1.bind(null, l, t, a), t.then(l, l));
  }
  function y1(l, t, a) {
    var u = l.pingCache;
    u !== null && u.delete(t), l.pingedLanes |= l.suspendedLanes & a, l.warmLanes &= ~a, il === l && (J & a) === a && (hl === 4 || hl === 3 && (J & 62914560) === J && 300 > kl() - on ? (P & 2) === 0 && bu(l, 0) : Mc |= a, Su === J && (Su = 0)), Ot(l);
  }
  function Md(l, t) {
    t === 0 && (t = zi()), l = Ua(l, t), l !== null && (Du(l, t), Ot(l));
  }
  function m1(l) {
    var t = l.memoizedState, a = 0;
    t !== null && (a = t.retryLane), Md(l, a);
  }
  function h1(l, t) {
    var a = 0;
    switch (l.tag) {
      case 31:
      case 13:
        var u = l.stateNode, e = l.memoizedState;
        e !== null && (a = e.retryLane);
        break;
      case 19:
        u = l.stateNode;
        break;
      case 22:
        u = l.stateNode._retryCache;
        break;
      default:
        throw Error(h(314));
    }
    u !== null && u.delete(t), Md(l, a);
  }
  function o1(l, t) {
    return Kn(l, t);
  }
  var Tn = null, Eu = null, Cc = !1, An = !1, qc = !1, ha = 0;
  function Ot(l) {
    l !== Eu && l.next === null && (Eu === null ? Tn = Eu = l : Eu = Eu.next = l), An = !0, Cc || (Cc = !0, S1());
  }
  function se(l, t) {
    if (!qc && An) {
      qc = !0;
      do
        for (var a = !1, u = Tn; u !== null; ) {
          if (l !== 0) {
            var e = u.pendingLanes;
            if (e === 0) var n = 0;
            else {
              var f = u.suspendedLanes, c = u.pingedLanes;
              n = (1 << 31 - Il(42 | l) + 1) - 1, n &= e & ~(f & ~c), n = n & 201326741 ? n & 201326741 | 1 : n ? n | 2 : 0;
            }
            n !== 0 && (a = !0, Nd(u, n));
          } else
            n = J, n = Me(
              u,
              u === il ? n : 0,
              u.cancelPendingCommit !== null || u.timeoutHandle !== -1
            ), (n & 3) === 0 || Uu(u, n) || (a = !0, Nd(u, n));
          u = u.next;
        }
      while (a);
      qc = !1;
    }
  }
  function g1() {
    Od();
  }
  function Od() {
    An = Cc = !1;
    var l = 0;
    ha !== 0 && O1() && (l = ha);
    for (var t = kl(), a = null, u = Tn; u !== null; ) {
      var e = u.next, n = Ud(u, t);
      n === 0 ? (u.next = null, a === null ? Tn = e : a.next = e, e === null && (Eu = a)) : (a = u, (l !== 0 || (n & 3) !== 0) && (An = !0)), u = e;
    }
    Al !== 0 && Al !== 5 || se(l), ha !== 0 && (ha = 0);
  }
  function Ud(l, t) {
    for (var a = l.suspendedLanes, u = l.pingedLanes, e = l.expirationTimes, n = l.pendingLanes & -62914561; 0 < n; ) {
      var f = 31 - Il(n), c = 1 << f, i = e[f];
      i === -1 ? ((c & a) === 0 || (c & u) !== 0) && (e[f] = Vv(c, t)) : i <= t && (l.expiredLanes |= c), n &= ~c;
    }
    if (t = il, a = J, a = Me(
      l,
      l === t ? a : 0,
      l.cancelPendingCommit !== null || l.timeoutHandle !== -1
    ), u = l.callbackNode, a === 0 || l === t && (tl === 2 || tl === 9) || l.cancelPendingCommit !== null)
      return u !== null && u !== null && Jn(u), l.callbackNode = null, l.callbackPriority = 0;
    if ((a & 3) === 0 || Uu(l, a)) {
      if (t = a & -a, t === l.callbackPriority) return t;
      switch (u !== null && Jn(u), $n(a)) {
        case 2:
        case 8:
          a = ri;
          break;
        case 32:
          a = Te;
          break;
        case 268435456:
          a = bi;
          break;
        default:
          a = Te;
      }
      return u = Dd.bind(null, l), a = Kn(a, u), l.callbackPriority = t, l.callbackNode = a, t;
    }
    return u !== null && u !== null && Jn(u), l.callbackPriority = 2, l.callbackNode = null, 2;
  }
  function Dd(l, t) {
    if (Al !== 0 && Al !== 5)
      return l.callbackNode = null, l.callbackPriority = 0, null;
    var a = l.callbackNode;
    if (En() && l.callbackNode !== a)
      return null;
    var u = J;
    return u = Me(
      l,
      l === il ? u : 0,
      l.cancelPendingCommit !== null || l.timeoutHandle !== -1
    ), u === 0 ? null : (dd(l, u, t), Ud(l, kl()), l.callbackNode != null && l.callbackNode === a ? Dd.bind(null, l) : null);
  }
  function Nd(l, t) {
    if (En()) return null;
    dd(l, t, !0);
  }
  function S1() {
    D1(function() {
      (P & 6) !== 0 ? Kn(
        Si,
        g1
      ) : Od();
    });
  }
  function jc() {
    if (ha === 0) {
      var l = fu;
      l === 0 && (l = Ae, Ae <<= 1, (Ae & 261888) === 0 && (Ae = 256)), ha = l;
    }
    return ha;
  }
  function Hd(l) {
    return l == null || typeof l == "symbol" || typeof l == "boolean" ? null : typeof l == "function" ? l : Ne("" + l);
  }
  function xd(l, t) {
    var a = t.ownerDocument.createElement("input");
    return a.name = t.name, a.value = t.value, l.id && a.setAttribute("form", l.id), t.parentNode.insertBefore(a, t), l = new FormData(l), a.parentNode.removeChild(a), l;
  }
  function r1(l, t, a, u, e) {
    if (t === "submit" && a && a.stateNode === e) {
      var n = Hd(
        (e[Ql] || null).action
      ), f = u.submitter;
      f && (t = (t = f[Ql] || null) ? Hd(t.formAction) : f.getAttribute("formAction"), t !== null && (n = t, f = null));
      var c = new Ce(
        "action",
        "action",
        null,
        u,
        e
      );
      l.push({
        event: c,
        listeners: [
          {
            instance: null,
            listener: function() {
              if (u.defaultPrevented) {
                if (ha !== 0) {
                  var i = f ? xd(e, f) : new FormData(e);
                  ac(
                    a,
                    {
                      pending: !0,
                      data: i,
                      method: e.method,
                      action: n
                    },
                    null,
                    i
                  );
                }
              } else
                typeof n == "function" && (c.preventDefault(), i = f ? xd(e, f) : new FormData(e), ac(
                  a,
                  {
                    pending: !0,
                    data: i,
                    method: e.method,
                    action: n
                  },
                  n,
                  i
                ));
            },
            currentTarget: e
          }
        ]
      });
    }
  }
  for (var Bc = 0; Bc < bf.length; Bc++) {
    var Yc = bf[Bc], b1 = Yc.toLowerCase(), z1 = Yc[0].toUpperCase() + Yc.slice(1);
    rt(
      b1,
      "on" + z1
    );
  }
  rt(s0, "onAnimationEnd"), rt(d0, "onAnimationIteration"), rt(v0, "onAnimationStart"), rt("dblclick", "onDoubleClick"), rt("focusin", "onFocus"), rt("focusout", "onBlur"), rt(jy, "onTransitionRun"), rt(By, "onTransitionStart"), rt(Yy, "onTransitionCancel"), rt(y0, "onTransitionEnd"), Ja("onMouseEnter", ["mouseout", "mouseover"]), Ja("onMouseLeave", ["mouseout", "mouseover"]), Ja("onPointerEnter", ["pointerout", "pointerover"]), Ja("onPointerLeave", ["pointerout", "pointerover"]), _a(
    "onChange",
    "change click focusin focusout input keydown keyup selectionchange".split(" ")
  ), _a(
    "onSelect",
    "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(
      " "
    )
  ), _a("onBeforeInput", [
    "compositionend",
    "keypress",
    "textInput",
    "paste"
  ]), _a(
    "onCompositionEnd",
    "compositionend focusout keydown keypress keyup mousedown".split(" ")
  ), _a(
    "onCompositionStart",
    "compositionstart focusout keydown keypress keyup mousedown".split(" ")
  ), _a(
    "onCompositionUpdate",
    "compositionupdate focusout keydown keypress keyup mousedown".split(" ")
  );
  var de = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(
    " "
  ), E1 = new Set(
    "beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(de)
  );
  function Rd(l, t) {
    t = (t & 4) !== 0;
    for (var a = 0; a < l.length; a++) {
      var u = l[a], e = u.event;
      u = u.listeners;
      l: {
        var n = void 0;
        if (t)
          for (var f = u.length - 1; 0 <= f; f--) {
            var c = u[f], i = c.instance, m = c.currentTarget;
            if (c = c.listener, i !== n && e.isPropagationStopped())
              break l;
            n = c, e.currentTarget = m;
            try {
              n(e);
            } catch (S) {
              Be(S);
            }
            e.currentTarget = null, n = i;
          }
        else
          for (f = 0; f < u.length; f++) {
            if (c = u[f], i = c.instance, m = c.currentTarget, c = c.listener, i !== n && e.isPropagationStopped())
              break l;
            n = c, e.currentTarget = m;
            try {
              n(e);
            } catch (S) {
              Be(S);
            }
            e.currentTarget = null, n = i;
          }
      }
    }
  }
  function K(l, t) {
    var a = t[kn];
    a === void 0 && (a = t[kn] = /* @__PURE__ */ new Set());
    var u = l + "__bubble";
    a.has(u) || (Cd(t, l, 2, !1), a.add(u));
  }
  function Gc(l, t, a) {
    var u = 0;
    t && (u |= 4), Cd(
      a,
      l,
      u,
      t
    );
  }
  var _n = "_reactListening" + Math.random().toString(36).slice(2);
  function Xc(l) {
    if (!l[_n]) {
      l[_n] = !0, Oi.forEach(function(a) {
        a !== "selectionchange" && (E1.has(a) || Gc(a, !1, l), Gc(a, !0, l));
      });
      var t = l.nodeType === 9 ? l : l.ownerDocument;
      t === null || t[_n] || (t[_n] = !0, Gc("selectionchange", !1, t));
    }
  }
  function Cd(l, t, a, u) {
    switch (sv(t)) {
      case 2:
        var e = $1;
        break;
      case 8:
        e = k1;
        break;
      default:
        e = ti;
    }
    a = e.bind(
      null,
      t,
      a,
      l
    ), e = void 0, !nf || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (e = !0), u ? e !== void 0 ? l.addEventListener(t, a, {
      capture: !0,
      passive: e
    }) : l.addEventListener(t, a, !0) : e !== void 0 ? l.addEventListener(t, a, {
      passive: e
    }) : l.addEventListener(t, a, !1);
  }
  function Qc(l, t, a, u, e) {
    var n = u;
    if ((t & 1) === 0 && (t & 2) === 0 && u !== null)
      l: for (; ; ) {
        if (u === null) return;
        var f = u.tag;
        if (f === 3 || f === 4) {
          var c = u.stateNode.containerInfo;
          if (c === e) break;
          if (f === 4)
            for (f = u.return; f !== null; ) {
              var i = f.tag;
              if ((i === 3 || i === 4) && f.stateNode.containerInfo === e)
                return;
              f = f.return;
            }
          for (; c !== null; ) {
            if (f = Va(c), f === null) return;
            if (i = f.tag, i === 5 || i === 6 || i === 26 || i === 27) {
              u = n = f;
              continue l;
            }
            c = c.parentNode;
          }
        }
        u = u.return;
      }
    Gi(function() {
      var m = n, S = uf(a), z = [];
      l: {
        var o = m0.get(l);
        if (o !== void 0) {
          var g = Ce, M = l;
          switch (l) {
            case "keypress":
              if (xe(a) === 0) break l;
            case "keydown":
            case "keyup":
              g = hy;
              break;
            case "focusin":
              M = "focus", g = df;
              break;
            case "focusout":
              M = "blur", g = df;
              break;
            case "beforeblur":
            case "afterblur":
              g = df;
              break;
            case "click":
              if (a.button === 2) break l;
            case "auxclick":
            case "dblclick":
            case "mousedown":
            case "mousemove":
            case "mouseup":
            case "mouseout":
            case "mouseover":
            case "contextmenu":
              g = Zi;
              break;
            case "drag":
            case "dragend":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "dragstart":
            case "drop":
              g = ay;
              break;
            case "touchcancel":
            case "touchend":
            case "touchmove":
            case "touchstart":
              g = Sy;
              break;
            case s0:
            case d0:
            case v0:
              g = ny;
              break;
            case y0:
              g = by;
              break;
            case "scroll":
            case "scrollend":
              g = ly;
              break;
            case "wheel":
              g = Ey;
              break;
            case "copy":
            case "cut":
            case "paste":
              g = cy;
              break;
            case "gotpointercapture":
            case "lostpointercapture":
            case "pointercancel":
            case "pointerdown":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "pointerup":
              g = Li;
              break;
            case "toggle":
            case "beforetoggle":
              g = Ay;
          }
          var H = (t & 4) !== 0, fl = !H && (l === "scroll" || l === "scrollend"), v = H ? o !== null ? o + "Capture" : null : o;
          H = [];
          for (var s = m, y; s !== null; ) {
            var b = s;
            if (y = b.stateNode, b = b.tag, b !== 5 && b !== 26 && b !== 27 || y === null || v === null || (b = xu(s, v), b != null && H.push(
              ve(s, b, y)
            )), fl) break;
            s = s.return;
          }
          0 < H.length && (o = new g(
            o,
            M,
            null,
            a,
            S
          ), z.push({ event: o, listeners: H }));
        }
      }
      if ((t & 7) === 0) {
        l: {
          if (o = l === "mouseover" || l === "pointerover", g = l === "mouseout" || l === "pointerout", o && a !== af && (M = a.relatedTarget || a.fromElement) && (Va(M) || M[Za]))
            break l;
          if ((g || o) && (o = S.window === S ? S : (o = S.ownerDocument) ? o.defaultView || o.parentWindow : window, g ? (M = a.relatedTarget || a.toElement, g = m, M = M ? Va(M) : null, M !== null && (fl = Z(M), H = M.tag, M !== fl || H !== 5 && H !== 27 && H !== 6) && (M = null)) : (g = null, M = m), g !== M)) {
            if (H = Zi, b = "onMouseLeave", v = "onMouseEnter", s = "mouse", (l === "pointerout" || l === "pointerover") && (H = Li, b = "onPointerLeave", v = "onPointerEnter", s = "pointer"), fl = g == null ? o : Hu(g), y = M == null ? o : Hu(M), o = new H(
              b,
              s + "leave",
              g,
              a,
              S
            ), o.target = fl, o.relatedTarget = y, b = null, Va(S) === m && (H = new H(
              v,
              s + "enter",
              M,
              a,
              S
            ), H.target = y, H.relatedTarget = fl, b = H), fl = b, g && M)
              t: {
                for (H = T1, v = g, s = M, y = 0, b = v; b; b = H(b))
                  y++;
                b = 0;
                for (var N = s; N; N = H(N))
                  b++;
                for (; 0 < y - b; )
                  v = H(v), y--;
                for (; 0 < b - y; )
                  s = H(s), b--;
                for (; y--; ) {
                  if (v === s || s !== null && v === s.alternate) {
                    H = v;
                    break t;
                  }
                  v = H(v), s = H(s);
                }
                H = null;
              }
            else H = null;
            g !== null && qd(
              z,
              o,
              g,
              H,
              !1
            ), M !== null && fl !== null && qd(
              z,
              fl,
              M,
              H,
              !0
            );
          }
        }
        l: {
          if (o = m ? Hu(m) : window, g = o.nodeName && o.nodeName.toLowerCase(), g === "select" || g === "input" && o.type === "file")
            var F = Ii;
          else if (ki(o))
            if (Pi)
              F = Ry;
            else {
              F = Hy;
              var U = Ny;
            }
          else
            g = o.nodeName, !g || g.toLowerCase() !== "input" || o.type !== "checkbox" && o.type !== "radio" ? m && tf(m.elementType) && (F = Ii) : F = xy;
          if (F && (F = F(l, m))) {
            Fi(
              z,
              F,
              a,
              S
            );
            break l;
          }
          U && U(l, o, m), l === "focusout" && m && o.type === "number" && m.memoizedProps.value != null && lf(o, "number", o.value);
        }
        switch (U = m ? Hu(m) : window, l) {
          case "focusin":
            (ki(U) || U.contentEditable === "true") && (Ia = U, gf = m, Xu = null);
            break;
          case "focusout":
            Xu = gf = Ia = null;
            break;
          case "mousedown":
            Sf = !0;
            break;
          case "contextmenu":
          case "mouseup":
          case "dragend":
            Sf = !1, c0(z, a, S);
            break;
          case "selectionchange":
            if (qy) break;
          case "keydown":
          case "keyup":
            c0(z, a, S);
        }
        var Q;
        if (yf)
          l: {
            switch (l) {
              case "compositionstart":
                var w = "onCompositionStart";
                break l;
              case "compositionend":
                w = "onCompositionEnd";
                break l;
              case "compositionupdate":
                w = "onCompositionUpdate";
                break l;
            }
            w = void 0;
          }
        else
          Fa ? Wi(l, a) && (w = "onCompositionEnd") : l === "keydown" && a.keyCode === 229 && (w = "onCompositionStart");
        w && (Ki && a.locale !== "ko" && (Fa || w !== "onCompositionStart" ? w === "onCompositionEnd" && Fa && (Q = Xi()) : (It = S, ff = "value" in It ? It.value : It.textContent, Fa = !0)), U = pn(m, w), 0 < U.length && (w = new Vi(
          w,
          l,
          null,
          a,
          S
        ), z.push({ event: w, listeners: U }), Q ? w.data = Q : (Q = $i(a), Q !== null && (w.data = Q)))), (Q = py ? My(l, a) : Oy(l, a)) && (w = pn(m, "onBeforeInput"), 0 < w.length && (U = new Vi(
          "onBeforeInput",
          "beforeinput",
          null,
          a,
          S
        ), z.push({
          event: U,
          listeners: w
        }), U.data = Q)), r1(
          z,
          l,
          m,
          a,
          S
        );
      }
      Rd(z, t);
    });
  }
  function ve(l, t, a) {
    return {
      instance: l,
      listener: t,
      currentTarget: a
    };
  }
  function pn(l, t) {
    for (var a = t + "Capture", u = []; l !== null; ) {
      var e = l, n = e.stateNode;
      if (e = e.tag, e !== 5 && e !== 26 && e !== 27 || n === null || (e = xu(l, a), e != null && u.unshift(
        ve(l, e, n)
      ), e = xu(l, t), e != null && u.push(
        ve(l, e, n)
      )), l.tag === 3) return u;
      l = l.return;
    }
    return [];
  }
  function T1(l) {
    if (l === null) return null;
    do
      l = l.return;
    while (l && l.tag !== 5 && l.tag !== 27);
    return l || null;
  }
  function qd(l, t, a, u, e) {
    for (var n = t._reactName, f = []; a !== null && a !== u; ) {
      var c = a, i = c.alternate, m = c.stateNode;
      if (c = c.tag, i !== null && i === u) break;
      c !== 5 && c !== 26 && c !== 27 || m === null || (i = m, e ? (m = xu(a, n), m != null && f.unshift(
        ve(a, m, i)
      )) : e || (m = xu(a, n), m != null && f.push(
        ve(a, m, i)
      ))), a = a.return;
    }
    f.length !== 0 && l.push({ event: t, listeners: f });
  }
  var A1 = /\r\n?/g, _1 = /\u0000|\uFFFD/g;
  function jd(l) {
    return (typeof l == "string" ? l : "" + l).replace(A1, `
`).replace(_1, "");
  }
  function Bd(l, t) {
    return t = jd(t), jd(l) === t;
  }
  function nl(l, t, a, u, e, n) {
    switch (a) {
      case "children":
        typeof u == "string" ? t === "body" || t === "textarea" && u === "" || Wa(l, u) : (typeof u == "number" || typeof u == "bigint") && t !== "body" && Wa(l, "" + u);
        break;
      case "className":
        Ue(l, "class", u);
        break;
      case "tabIndex":
        Ue(l, "tabindex", u);
        break;
      case "dir":
      case "role":
      case "viewBox":
      case "width":
      case "height":
        Ue(l, a, u);
        break;
      case "style":
        Bi(l, u, n);
        break;
      case "data":
        if (t !== "object") {
          Ue(l, "data", u);
          break;
        }
      case "src":
      case "href":
        if (u === "" && (t !== "a" || a !== "href")) {
          l.removeAttribute(a);
          break;
        }
        if (u == null || typeof u == "function" || typeof u == "symbol" || typeof u == "boolean") {
          l.removeAttribute(a);
          break;
        }
        u = Ne("" + u), l.setAttribute(a, u);
        break;
      case "action":
      case "formAction":
        if (typeof u == "function") {
          l.setAttribute(
            a,
            "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')"
          );
          break;
        } else
          typeof n == "function" && (a === "formAction" ? (t !== "input" && nl(l, t, "name", e.name, e, null), nl(
            l,
            t,
            "formEncType",
            e.formEncType,
            e,
            null
          ), nl(
            l,
            t,
            "formMethod",
            e.formMethod,
            e,
            null
          ), nl(
            l,
            t,
            "formTarget",
            e.formTarget,
            e,
            null
          )) : (nl(l, t, "encType", e.encType, e, null), nl(l, t, "method", e.method, e, null), nl(l, t, "target", e.target, e, null)));
        if (u == null || typeof u == "symbol" || typeof u == "boolean") {
          l.removeAttribute(a);
          break;
        }
        u = Ne("" + u), l.setAttribute(a, u);
        break;
      case "onClick":
        u != null && (l.onclick = Ht);
        break;
      case "onScroll":
        u != null && K("scroll", l);
        break;
      case "onScrollEnd":
        u != null && K("scrollend", l);
        break;
      case "dangerouslySetInnerHTML":
        if (u != null) {
          if (typeof u != "object" || !("__html" in u))
            throw Error(h(61));
          if (a = u.__html, a != null) {
            if (e.children != null) throw Error(h(60));
            l.innerHTML = a;
          }
        }
        break;
      case "multiple":
        l.multiple = u && typeof u != "function" && typeof u != "symbol";
        break;
      case "muted":
        l.muted = u && typeof u != "function" && typeof u != "symbol";
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "defaultValue":
      case "defaultChecked":
      case "innerHTML":
      case "ref":
        break;
      case "autoFocus":
        break;
      case "xlinkHref":
        if (u == null || typeof u == "function" || typeof u == "boolean" || typeof u == "symbol") {
          l.removeAttribute("xlink:href");
          break;
        }
        a = Ne("" + u), l.setAttributeNS(
          "http://www.w3.org/1999/xlink",
          "xlink:href",
          a
        );
        break;
      case "contentEditable":
      case "spellCheck":
      case "draggable":
      case "value":
      case "autoReverse":
      case "externalResourcesRequired":
      case "focusable":
      case "preserveAlpha":
        u != null && typeof u != "function" && typeof u != "symbol" ? l.setAttribute(a, "" + u) : l.removeAttribute(a);
        break;
      case "inert":
      case "allowFullScreen":
      case "async":
      case "autoPlay":
      case "controls":
      case "default":
      case "defer":
      case "disabled":
      case "disablePictureInPicture":
      case "disableRemotePlayback":
      case "formNoValidate":
      case "hidden":
      case "loop":
      case "noModule":
      case "noValidate":
      case "open":
      case "playsInline":
      case "readOnly":
      case "required":
      case "reversed":
      case "scoped":
      case "seamless":
      case "itemScope":
        u && typeof u != "function" && typeof u != "symbol" ? l.setAttribute(a, "") : l.removeAttribute(a);
        break;
      case "capture":
      case "download":
        u === !0 ? l.setAttribute(a, "") : u !== !1 && u != null && typeof u != "function" && typeof u != "symbol" ? l.setAttribute(a, u) : l.removeAttribute(a);
        break;
      case "cols":
      case "rows":
      case "size":
      case "span":
        u != null && typeof u != "function" && typeof u != "symbol" && !isNaN(u) && 1 <= u ? l.setAttribute(a, u) : l.removeAttribute(a);
        break;
      case "rowSpan":
      case "start":
        u == null || typeof u == "function" || typeof u == "symbol" || isNaN(u) ? l.removeAttribute(a) : l.setAttribute(a, u);
        break;
      case "popover":
        K("beforetoggle", l), K("toggle", l), Oe(l, "popover", u);
        break;
      case "xlinkActuate":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:actuate",
          u
        );
        break;
      case "xlinkArcrole":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:arcrole",
          u
        );
        break;
      case "xlinkRole":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:role",
          u
        );
        break;
      case "xlinkShow":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:show",
          u
        );
        break;
      case "xlinkTitle":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:title",
          u
        );
        break;
      case "xlinkType":
        Nt(
          l,
          "http://www.w3.org/1999/xlink",
          "xlink:type",
          u
        );
        break;
      case "xmlBase":
        Nt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:base",
          u
        );
        break;
      case "xmlLang":
        Nt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:lang",
          u
        );
        break;
      case "xmlSpace":
        Nt(
          l,
          "http://www.w3.org/XML/1998/namespace",
          "xml:space",
          u
        );
        break;
      case "is":
        Oe(l, "is", u);
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        (!(2 < a.length) || a[0] !== "o" && a[0] !== "O" || a[1] !== "n" && a[1] !== "N") && (a = Iv.get(a) || a, Oe(l, a, u));
    }
  }
  function Zc(l, t, a, u, e, n) {
    switch (a) {
      case "style":
        Bi(l, u, n);
        break;
      case "dangerouslySetInnerHTML":
        if (u != null) {
          if (typeof u != "object" || !("__html" in u))
            throw Error(h(61));
          if (a = u.__html, a != null) {
            if (e.children != null) throw Error(h(60));
            l.innerHTML = a;
          }
        }
        break;
      case "children":
        typeof u == "string" ? Wa(l, u) : (typeof u == "number" || typeof u == "bigint") && Wa(l, "" + u);
        break;
      case "onScroll":
        u != null && K("scroll", l);
        break;
      case "onScrollEnd":
        u != null && K("scrollend", l);
        break;
      case "onClick":
        u != null && (l.onclick = Ht);
        break;
      case "suppressContentEditableWarning":
      case "suppressHydrationWarning":
      case "innerHTML":
      case "ref":
        break;
      case "innerText":
      case "textContent":
        break;
      default:
        if (!Ui.hasOwnProperty(a))
          l: {
            if (a[0] === "o" && a[1] === "n" && (e = a.endsWith("Capture"), t = a.slice(2, e ? a.length - 7 : void 0), n = l[Ql] || null, n = n != null ? n[a] : null, typeof n == "function" && l.removeEventListener(t, n, e), typeof u == "function")) {
              typeof n != "function" && n !== null && (a in l ? l[a] = null : l.hasAttribute(a) && l.removeAttribute(a)), l.addEventListener(t, u, e);
              break l;
            }
            a in l ? l[a] = u : u === !0 ? l.setAttribute(a, "") : Oe(l, a, u);
          }
    }
  }
  function Hl(l, t, a) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "img":
        K("error", l), K("load", l);
        var u = !1, e = !1, n;
        for (n in a)
          if (a.hasOwnProperty(n)) {
            var f = a[n];
            if (f != null)
              switch (n) {
                case "src":
                  u = !0;
                  break;
                case "srcSet":
                  e = !0;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  throw Error(h(137, t));
                default:
                  nl(l, t, n, f, a, null);
              }
          }
        e && nl(l, t, "srcSet", a.srcSet, a, null), u && nl(l, t, "src", a.src, a, null);
        return;
      case "input":
        K("invalid", l);
        var c = n = f = e = null, i = null, m = null;
        for (u in a)
          if (a.hasOwnProperty(u)) {
            var S = a[u];
            if (S != null)
              switch (u) {
                case "name":
                  e = S;
                  break;
                case "type":
                  f = S;
                  break;
                case "checked":
                  i = S;
                  break;
                case "defaultChecked":
                  m = S;
                  break;
                case "value":
                  n = S;
                  break;
                case "defaultValue":
                  c = S;
                  break;
                case "children":
                case "dangerouslySetInnerHTML":
                  if (S != null)
                    throw Error(h(137, t));
                  break;
                default:
                  nl(l, t, u, S, a, null);
              }
          }
        Ri(
          l,
          n,
          c,
          i,
          m,
          f,
          e,
          !1
        );
        return;
      case "select":
        K("invalid", l), u = f = n = null;
        for (e in a)
          if (a.hasOwnProperty(e) && (c = a[e], c != null))
            switch (e) {
              case "value":
                n = c;
                break;
              case "defaultValue":
                f = c;
                break;
              case "multiple":
                u = c;
              default:
                nl(l, t, e, c, a, null);
            }
        t = n, a = f, l.multiple = !!u, t != null ? wa(l, !!u, t, !1) : a != null && wa(l, !!u, a, !0);
        return;
      case "textarea":
        K("invalid", l), n = e = u = null;
        for (f in a)
          if (a.hasOwnProperty(f) && (c = a[f], c != null))
            switch (f) {
              case "value":
                u = c;
                break;
              case "defaultValue":
                e = c;
                break;
              case "children":
                n = c;
                break;
              case "dangerouslySetInnerHTML":
                if (c != null) throw Error(h(91));
                break;
              default:
                nl(l, t, f, c, a, null);
            }
        qi(l, u, e, n);
        return;
      case "option":
        for (i in a)
          a.hasOwnProperty(i) && (u = a[i], u != null) && (i === "selected" ? l.selected = u && typeof u != "function" && typeof u != "symbol" : nl(l, t, i, u, a, null));
        return;
      case "dialog":
        K("beforetoggle", l), K("toggle", l), K("cancel", l), K("close", l);
        break;
      case "iframe":
      case "object":
        K("load", l);
        break;
      case "video":
      case "audio":
        for (u = 0; u < de.length; u++)
          K(de[u], l);
        break;
      case "image":
        K("error", l), K("load", l);
        break;
      case "details":
        K("toggle", l);
        break;
      case "embed":
      case "source":
      case "link":
        K("error", l), K("load", l);
      case "area":
      case "base":
      case "br":
      case "col":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "track":
      case "wbr":
      case "menuitem":
        for (m in a)
          if (a.hasOwnProperty(m) && (u = a[m], u != null))
            switch (m) {
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(h(137, t));
              default:
                nl(l, t, m, u, a, null);
            }
        return;
      default:
        if (tf(t)) {
          for (S in a)
            a.hasOwnProperty(S) && (u = a[S], u !== void 0 && Zc(
              l,
              t,
              S,
              u,
              a,
              void 0
            ));
          return;
        }
    }
    for (c in a)
      a.hasOwnProperty(c) && (u = a[c], u != null && nl(l, t, c, u, a, null));
  }
  function p1(l, t, a, u) {
    switch (t) {
      case "div":
      case "span":
      case "svg":
      case "path":
      case "a":
      case "g":
      case "p":
      case "li":
        break;
      case "input":
        var e = null, n = null, f = null, c = null, i = null, m = null, S = null;
        for (g in a) {
          var z = a[g];
          if (a.hasOwnProperty(g) && z != null)
            switch (g) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                i = z;
              default:
                u.hasOwnProperty(g) || nl(l, t, g, null, u, z);
            }
        }
        for (var o in u) {
          var g = u[o];
          if (z = a[o], u.hasOwnProperty(o) && (g != null || z != null))
            switch (o) {
              case "type":
                n = g;
                break;
              case "name":
                e = g;
                break;
              case "checked":
                m = g;
                break;
              case "defaultChecked":
                S = g;
                break;
              case "value":
                f = g;
                break;
              case "defaultValue":
                c = g;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (g != null)
                  throw Error(h(137, t));
                break;
              default:
                g !== z && nl(
                  l,
                  t,
                  o,
                  g,
                  u,
                  z
                );
            }
        }
        Pn(
          l,
          f,
          c,
          i,
          m,
          S,
          n,
          e
        );
        return;
      case "select":
        g = f = c = o = null;
        for (n in a)
          if (i = a[n], a.hasOwnProperty(n) && i != null)
            switch (n) {
              case "value":
                break;
              case "multiple":
                g = i;
              default:
                u.hasOwnProperty(n) || nl(
                  l,
                  t,
                  n,
                  null,
                  u,
                  i
                );
            }
        for (e in u)
          if (n = u[e], i = a[e], u.hasOwnProperty(e) && (n != null || i != null))
            switch (e) {
              case "value":
                o = n;
                break;
              case "defaultValue":
                c = n;
                break;
              case "multiple":
                f = n;
              default:
                n !== i && nl(
                  l,
                  t,
                  e,
                  n,
                  u,
                  i
                );
            }
        t = c, a = f, u = g, o != null ? wa(l, !!a, o, !1) : !!u != !!a && (t != null ? wa(l, !!a, t, !0) : wa(l, !!a, a ? [] : "", !1));
        return;
      case "textarea":
        g = o = null;
        for (c in a)
          if (e = a[c], a.hasOwnProperty(c) && e != null && !u.hasOwnProperty(c))
            switch (c) {
              case "value":
                break;
              case "children":
                break;
              default:
                nl(l, t, c, null, u, e);
            }
        for (f in u)
          if (e = u[f], n = a[f], u.hasOwnProperty(f) && (e != null || n != null))
            switch (f) {
              case "value":
                o = e;
                break;
              case "defaultValue":
                g = e;
                break;
              case "children":
                break;
              case "dangerouslySetInnerHTML":
                if (e != null) throw Error(h(91));
                break;
              default:
                e !== n && nl(l, t, f, e, u, n);
            }
        Ci(l, o, g);
        return;
      case "option":
        for (var M in a)
          o = a[M], a.hasOwnProperty(M) && o != null && !u.hasOwnProperty(M) && (M === "selected" ? l.selected = !1 : nl(
            l,
            t,
            M,
            null,
            u,
            o
          ));
        for (i in u)
          o = u[i], g = a[i], u.hasOwnProperty(i) && o !== g && (o != null || g != null) && (i === "selected" ? l.selected = o && typeof o != "function" && typeof o != "symbol" : nl(
            l,
            t,
            i,
            o,
            u,
            g
          ));
        return;
      case "img":
      case "link":
      case "area":
      case "base":
      case "br":
      case "col":
      case "embed":
      case "hr":
      case "keygen":
      case "meta":
      case "param":
      case "source":
      case "track":
      case "wbr":
      case "menuitem":
        for (var H in a)
          o = a[H], a.hasOwnProperty(H) && o != null && !u.hasOwnProperty(H) && nl(l, t, H, null, u, o);
        for (m in u)
          if (o = u[m], g = a[m], u.hasOwnProperty(m) && o !== g && (o != null || g != null))
            switch (m) {
              case "children":
              case "dangerouslySetInnerHTML":
                if (o != null)
                  throw Error(h(137, t));
                break;
              default:
                nl(
                  l,
                  t,
                  m,
                  o,
                  u,
                  g
                );
            }
        return;
      default:
        if (tf(t)) {
          for (var fl in a)
            o = a[fl], a.hasOwnProperty(fl) && o !== void 0 && !u.hasOwnProperty(fl) && Zc(
              l,
              t,
              fl,
              void 0,
              u,
              o
            );
          for (S in u)
            o = u[S], g = a[S], !u.hasOwnProperty(S) || o === g || o === void 0 && g === void 0 || Zc(
              l,
              t,
              S,
              o,
              u,
              g
            );
          return;
        }
    }
    for (var v in a)
      o = a[v], a.hasOwnProperty(v) && o != null && !u.hasOwnProperty(v) && nl(l, t, v, null, u, o);
    for (z in u)
      o = u[z], g = a[z], !u.hasOwnProperty(z) || o === g || o == null && g == null || nl(l, t, z, o, u, g);
  }
  function Yd(l) {
    switch (l) {
      case "css":
      case "script":
      case "font":
      case "img":
      case "image":
      case "input":
      case "link":
        return !0;
      default:
        return !1;
    }
  }
  function M1() {
    if (typeof performance.getEntriesByType == "function") {
      for (var l = 0, t = 0, a = performance.getEntriesByType("resource"), u = 0; u < a.length; u++) {
        var e = a[u], n = e.transferSize, f = e.initiatorType, c = e.duration;
        if (n && c && Yd(f)) {
          for (f = 0, c = e.responseEnd, u += 1; u < a.length; u++) {
            var i = a[u], m = i.startTime;
            if (m > c) break;
            var S = i.transferSize, z = i.initiatorType;
            S && Yd(z) && (i = i.responseEnd, f += S * (i < c ? 1 : (c - m) / (i - m)));
          }
          if (--u, t += 8 * (n + f) / (e.duration / 1e3), l++, 10 < l) break;
        }
      }
      if (0 < l) return t / l / 1e6;
    }
    return navigator.connection && (l = navigator.connection.downlink, typeof l == "number") ? l : 5;
  }
  var Vc = null, Lc = null;
  function Mn(l) {
    return l.nodeType === 9 ? l : l.ownerDocument;
  }
  function Gd(l) {
    switch (l) {
      case "http://www.w3.org/2000/svg":
        return 1;
      case "http://www.w3.org/1998/Math/MathML":
        return 2;
      default:
        return 0;
    }
  }
  function Xd(l, t) {
    if (l === 0)
      switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
    return l === 1 && t === "foreignObject" ? 0 : l;
  }
  function Kc(l, t) {
    return l === "textarea" || l === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
  }
  var Jc = null;
  function O1() {
    var l = window.event;
    return l && l.type === "popstate" ? l === Jc ? !1 : (Jc = l, !0) : (Jc = null, !1);
  }
  var Qd = typeof setTimeout == "function" ? setTimeout : void 0, U1 = typeof clearTimeout == "function" ? clearTimeout : void 0, Zd = typeof Promise == "function" ? Promise : void 0, D1 = typeof queueMicrotask == "function" ? queueMicrotask : typeof Zd < "u" ? function(l) {
    return Zd.resolve(null).then(l).catch(N1);
  } : Qd;
  function N1(l) {
    setTimeout(function() {
      throw l;
    });
  }
  function oa(l) {
    return l === "head";
  }
  function Vd(l, t) {
    var a = t, u = 0;
    do {
      var e = a.nextSibling;
      if (l.removeChild(a), e && e.nodeType === 8)
        if (a = e.data, a === "/$" || a === "/&") {
          if (u === 0) {
            l.removeChild(e), pu(t);
            return;
          }
          u--;
        } else if (a === "$" || a === "$?" || a === "$~" || a === "$!" || a === "&")
          u++;
        else if (a === "html")
          ye(l.ownerDocument.documentElement);
        else if (a === "head") {
          a = l.ownerDocument.head, ye(a);
          for (var n = a.firstChild; n; ) {
            var f = n.nextSibling, c = n.nodeName;
            n[Nu] || c === "SCRIPT" || c === "STYLE" || c === "LINK" && n.rel.toLowerCase() === "stylesheet" || a.removeChild(n), n = f;
          }
        } else
          a === "body" && ye(l.ownerDocument.body);
      a = e;
    } while (a);
    pu(t);
  }
  function Ld(l, t) {
    var a = l;
    l = 0;
    do {
      var u = a.nextSibling;
      if (a.nodeType === 1 ? t ? (a._stashedDisplay = a.style.display, a.style.display = "none") : (a.style.display = a._stashedDisplay || "", a.getAttribute("style") === "" && a.removeAttribute("style")) : a.nodeType === 3 && (t ? (a._stashedText = a.nodeValue, a.nodeValue = "") : a.nodeValue = a._stashedText || ""), u && u.nodeType === 8)
        if (a = u.data, a === "/$") {
          if (l === 0) break;
          l--;
        } else
          a !== "$" && a !== "$?" && a !== "$~" && a !== "$!" || l++;
      a = u;
    } while (a);
  }
  function wc(l) {
    var t = l.firstChild;
    for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
      var a = t;
      switch (t = t.nextSibling, a.nodeName) {
        case "HTML":
        case "HEAD":
        case "BODY":
          wc(a), Fn(a);
          continue;
        case "SCRIPT":
        case "STYLE":
          continue;
        case "LINK":
          if (a.rel.toLowerCase() === "stylesheet") continue;
      }
      l.removeChild(a);
    }
  }
  function H1(l, t, a, u) {
    for (; l.nodeType === 1; ) {
      var e = a;
      if (l.nodeName.toLowerCase() !== t.toLowerCase()) {
        if (!u && (l.nodeName !== "INPUT" || l.type !== "hidden"))
          break;
      } else if (u) {
        if (!l[Nu])
          switch (t) {
            case "meta":
              if (!l.hasAttribute("itemprop")) break;
              return l;
            case "link":
              if (n = l.getAttribute("rel"), n === "stylesheet" && l.hasAttribute("data-precedence"))
                break;
              if (n !== e.rel || l.getAttribute("href") !== (e.href == null || e.href === "" ? null : e.href) || l.getAttribute("crossorigin") !== (e.crossOrigin == null ? null : e.crossOrigin) || l.getAttribute("title") !== (e.title == null ? null : e.title))
                break;
              return l;
            case "style":
              if (l.hasAttribute("data-precedence")) break;
              return l;
            case "script":
              if (n = l.getAttribute("src"), (n !== (e.src == null ? null : e.src) || l.getAttribute("type") !== (e.type == null ? null : e.type) || l.getAttribute("crossorigin") !== (e.crossOrigin == null ? null : e.crossOrigin)) && n && l.hasAttribute("async") && !l.hasAttribute("itemprop"))
                break;
              return l;
            default:
              return l;
          }
      } else if (t === "input" && l.type === "hidden") {
        var n = e.name == null ? null : "" + e.name;
        if (e.type === "hidden" && l.getAttribute("name") === n)
          return l;
      } else return l;
      if (l = ot(l.nextSibling), l === null) break;
    }
    return null;
  }
  function x1(l, t, a) {
    if (t === "") return null;
    for (; l.nodeType !== 3; )
      if ((l.nodeType !== 1 || l.nodeName !== "INPUT" || l.type !== "hidden") && !a || (l = ot(l.nextSibling), l === null)) return null;
    return l;
  }
  function Kd(l, t) {
    for (; l.nodeType !== 8; )
      if ((l.nodeType !== 1 || l.nodeName !== "INPUT" || l.type !== "hidden") && !t || (l = ot(l.nextSibling), l === null)) return null;
    return l;
  }
  function Wc(l) {
    return l.data === "$?" || l.data === "$~";
  }
  function $c(l) {
    return l.data === "$!" || l.data === "$?" && l.ownerDocument.readyState !== "loading";
  }
  function R1(l, t) {
    var a = l.ownerDocument;
    if (l.data === "$~") l._reactRetry = t;
    else if (l.data !== "$?" || a.readyState !== "loading")
      t();
    else {
      var u = function() {
        t(), a.removeEventListener("DOMContentLoaded", u);
      };
      a.addEventListener("DOMContentLoaded", u), l._reactRetry = u;
    }
  }
  function ot(l) {
    for (; l != null; l = l.nextSibling) {
      var t = l.nodeType;
      if (t === 1 || t === 3) break;
      if (t === 8) {
        if (t = l.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F")
          break;
        if (t === "/$" || t === "/&") return null;
      }
    }
    return l;
  }
  var kc = null;
  function Jd(l) {
    l = l.nextSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === "/$" || a === "/&") {
          if (t === 0)
            return ot(l.nextSibling);
          t--;
        } else
          a !== "$" && a !== "$!" && a !== "$?" && a !== "$~" && a !== "&" || t++;
      }
      l = l.nextSibling;
    }
    return null;
  }
  function wd(l) {
    l = l.previousSibling;
    for (var t = 0; l; ) {
      if (l.nodeType === 8) {
        var a = l.data;
        if (a === "$" || a === "$!" || a === "$?" || a === "$~" || a === "&") {
          if (t === 0) return l;
          t--;
        } else a !== "/$" && a !== "/&" || t++;
      }
      l = l.previousSibling;
    }
    return null;
  }
  function Wd(l, t, a) {
    switch (t = Mn(a), l) {
      case "html":
        if (l = t.documentElement, !l) throw Error(h(452));
        return l;
      case "head":
        if (l = t.head, !l) throw Error(h(453));
        return l;
      case "body":
        if (l = t.body, !l) throw Error(h(454));
        return l;
      default:
        throw Error(h(451));
    }
  }
  function ye(l) {
    for (var t = l.attributes; t.length; )
      l.removeAttributeNode(t[0]);
    Fn(l);
  }
  var gt = /* @__PURE__ */ new Map(), $d = /* @__PURE__ */ new Set();
  function On(l) {
    return typeof l.getRootNode == "function" ? l.getRootNode() : l.nodeType === 9 ? l : l.ownerDocument;
  }
  var wt = _.d;
  _.d = {
    f: C1,
    r: q1,
    D: j1,
    C: B1,
    L: Y1,
    m: G1,
    X: Q1,
    S: X1,
    M: Z1
  };
  function C1() {
    var l = wt.f(), t = rn();
    return l || t;
  }
  function q1(l) {
    var t = La(l);
    t !== null && t.tag === 5 && t.type === "form" ? ys(t) : wt.r(l);
  }
  var Tu = typeof document > "u" ? null : document;
  function kd(l, t, a) {
    var u = Tu;
    if (u && typeof t == "string" && t) {
      var e = it(t);
      e = 'link[rel="' + l + '"][href="' + e + '"]', typeof a == "string" && (e += '[crossorigin="' + a + '"]'), $d.has(e) || ($d.add(e), l = { rel: l, crossOrigin: a, href: t }, u.querySelector(e) === null && (t = u.createElement("link"), Hl(t, "link", l), pl(t), u.head.appendChild(t)));
    }
  }
  function j1(l) {
    wt.D(l), kd("dns-prefetch", l, null);
  }
  function B1(l, t) {
    wt.C(l, t), kd("preconnect", l, t);
  }
  function Y1(l, t, a) {
    wt.L(l, t, a);
    var u = Tu;
    if (u && l && t) {
      var e = 'link[rel="preload"][as="' + it(t) + '"]';
      t === "image" && a && a.imageSrcSet ? (e += '[imagesrcset="' + it(
        a.imageSrcSet
      ) + '"]', typeof a.imageSizes == "string" && (e += '[imagesizes="' + it(
        a.imageSizes
      ) + '"]')) : e += '[href="' + it(l) + '"]';
      var n = e;
      switch (t) {
        case "style":
          n = Au(l);
          break;
        case "script":
          n = _u(l);
      }
      gt.has(n) || (l = R(
        {
          rel: "preload",
          href: t === "image" && a && a.imageSrcSet ? void 0 : l,
          as: t
        },
        a
      ), gt.set(n, l), u.querySelector(e) !== null || t === "style" && u.querySelector(me(n)) || t === "script" && u.querySelector(he(n)) || (t = u.createElement("link"), Hl(t, "link", l), pl(t), u.head.appendChild(t)));
    }
  }
  function G1(l, t) {
    wt.m(l, t);
    var a = Tu;
    if (a && l) {
      var u = t && typeof t.as == "string" ? t.as : "script", e = 'link[rel="modulepreload"][as="' + it(u) + '"][href="' + it(l) + '"]', n = e;
      switch (u) {
        case "audioworklet":
        case "paintworklet":
        case "serviceworker":
        case "sharedworker":
        case "worker":
        case "script":
          n = _u(l);
      }
      if (!gt.has(n) && (l = R({ rel: "modulepreload", href: l }, t), gt.set(n, l), a.querySelector(e) === null)) {
        switch (u) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            if (a.querySelector(he(n)))
              return;
        }
        u = a.createElement("link"), Hl(u, "link", l), pl(u), a.head.appendChild(u);
      }
    }
  }
  function X1(l, t, a) {
    wt.S(l, t, a);
    var u = Tu;
    if (u && l) {
      var e = Ka(u).hoistableStyles, n = Au(l);
      t = t || "default";
      var f = e.get(n);
      if (!f) {
        var c = { loading: 0, preload: null };
        if (f = u.querySelector(
          me(n)
        ))
          c.loading = 5;
        else {
          l = R(
            { rel: "stylesheet", href: l, "data-precedence": t },
            a
          ), (a = gt.get(n)) && Fc(l, a);
          var i = f = u.createElement("link");
          pl(i), Hl(i, "link", l), i._p = new Promise(function(m, S) {
            i.onload = m, i.onerror = S;
          }), i.addEventListener("load", function() {
            c.loading |= 1;
          }), i.addEventListener("error", function() {
            c.loading |= 2;
          }), c.loading |= 4, Un(f, t, u);
        }
        f = {
          type: "stylesheet",
          instance: f,
          count: 1,
          state: c
        }, e.set(n, f);
      }
    }
  }
  function Q1(l, t) {
    wt.X(l, t);
    var a = Tu;
    if (a && l) {
      var u = Ka(a).hoistableScripts, e = _u(l), n = u.get(e);
      n || (n = a.querySelector(he(e)), n || (l = R({ src: l, async: !0 }, t), (t = gt.get(e)) && Ic(l, t), n = a.createElement("script"), pl(n), Hl(n, "link", l), a.head.appendChild(n)), n = {
        type: "script",
        instance: n,
        count: 1,
        state: null
      }, u.set(e, n));
    }
  }
  function Z1(l, t) {
    wt.M(l, t);
    var a = Tu;
    if (a && l) {
      var u = Ka(a).hoistableScripts, e = _u(l), n = u.get(e);
      n || (n = a.querySelector(he(e)), n || (l = R({ src: l, async: !0, type: "module" }, t), (t = gt.get(e)) && Ic(l, t), n = a.createElement("script"), pl(n), Hl(n, "link", l), a.head.appendChild(n)), n = {
        type: "script",
        instance: n,
        count: 1,
        state: null
      }, u.set(e, n));
    }
  }
  function Fd(l, t, a, u) {
    var e = (e = V.current) ? On(e) : null;
    if (!e) throw Error(h(446));
    switch (l) {
      case "meta":
      case "title":
        return null;
      case "style":
        return typeof a.precedence == "string" && typeof a.href == "string" ? (t = Au(a.href), a = Ka(
          e
        ).hoistableStyles, u = a.get(t), u || (u = {
          type: "style",
          instance: null,
          count: 0,
          state: null
        }, a.set(t, u)), u) : { type: "void", instance: null, count: 0, state: null };
      case "link":
        if (a.rel === "stylesheet" && typeof a.href == "string" && typeof a.precedence == "string") {
          l = Au(a.href);
          var n = Ka(
            e
          ).hoistableStyles, f = n.get(l);
          if (f || (e = e.ownerDocument || e, f = {
            type: "stylesheet",
            instance: null,
            count: 0,
            state: { loading: 0, preload: null }
          }, n.set(l, f), (n = e.querySelector(
            me(l)
          )) && !n._p && (f.instance = n, f.state.loading = 5), gt.has(l) || (a = {
            rel: "preload",
            as: "style",
            href: a.href,
            crossOrigin: a.crossOrigin,
            integrity: a.integrity,
            media: a.media,
            hrefLang: a.hrefLang,
            referrerPolicy: a.referrerPolicy
          }, gt.set(l, a), n || V1(
            e,
            l,
            a,
            f.state
          ))), t && u === null)
            throw Error(h(528, ""));
          return f;
        }
        if (t && u !== null)
          throw Error(h(529, ""));
        return null;
      case "script":
        return t = a.async, a = a.src, typeof a == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = _u(a), a = Ka(
          e
        ).hoistableScripts, u = a.get(t), u || (u = {
          type: "script",
          instance: null,
          count: 0,
          state: null
        }, a.set(t, u)), u) : { type: "void", instance: null, count: 0, state: null };
      default:
        throw Error(h(444, l));
    }
  }
  function Au(l) {
    return 'href="' + it(l) + '"';
  }
  function me(l) {
    return 'link[rel="stylesheet"][' + l + "]";
  }
  function Id(l) {
    return R({}, l, {
      "data-precedence": l.precedence,
      precedence: null
    });
  }
  function V1(l, t, a, u) {
    l.querySelector('link[rel="preload"][as="style"][' + t + "]") ? u.loading = 1 : (t = l.createElement("link"), u.preload = t, t.addEventListener("load", function() {
      return u.loading |= 1;
    }), t.addEventListener("error", function() {
      return u.loading |= 2;
    }), Hl(t, "link", a), pl(t), l.head.appendChild(t));
  }
  function _u(l) {
    return '[src="' + it(l) + '"]';
  }
  function he(l) {
    return "script[async]" + l;
  }
  function Pd(l, t, a) {
    if (t.count++, t.instance === null)
      switch (t.type) {
        case "style":
          var u = l.querySelector(
            'style[data-href~="' + it(a.href) + '"]'
          );
          if (u)
            return t.instance = u, pl(u), u;
          var e = R({}, a, {
            "data-href": a.href,
            "data-precedence": a.precedence,
            href: null,
            precedence: null
          });
          return u = (l.ownerDocument || l).createElement(
            "style"
          ), pl(u), Hl(u, "style", e), Un(u, a.precedence, l), t.instance = u;
        case "stylesheet":
          e = Au(a.href);
          var n = l.querySelector(
            me(e)
          );
          if (n)
            return t.state.loading |= 4, t.instance = n, pl(n), n;
          u = Id(a), (e = gt.get(e)) && Fc(u, e), n = (l.ownerDocument || l).createElement("link"), pl(n);
          var f = n;
          return f._p = new Promise(function(c, i) {
            f.onload = c, f.onerror = i;
          }), Hl(n, "link", u), t.state.loading |= 4, Un(n, a.precedence, l), t.instance = n;
        case "script":
          return n = _u(a.src), (e = l.querySelector(
            he(n)
          )) ? (t.instance = e, pl(e), e) : (u = a, (e = gt.get(n)) && (u = R({}, a), Ic(u, e)), l = l.ownerDocument || l, e = l.createElement("script"), pl(e), Hl(e, "link", u), l.head.appendChild(e), t.instance = e);
        case "void":
          return null;
        default:
          throw Error(h(443, t.type));
      }
    else
      t.type === "stylesheet" && (t.state.loading & 4) === 0 && (u = t.instance, t.state.loading |= 4, Un(u, a.precedence, l));
    return t.instance;
  }
  function Un(l, t, a) {
    for (var u = a.querySelectorAll(
      'link[rel="stylesheet"][data-precedence],style[data-precedence]'
    ), e = u.length ? u[u.length - 1] : null, n = e, f = 0; f < u.length; f++) {
      var c = u[f];
      if (c.dataset.precedence === t) n = c;
      else if (n !== e) break;
    }
    n ? n.parentNode.insertBefore(l, n.nextSibling) : (t = a.nodeType === 9 ? a.head : a, t.insertBefore(l, t.firstChild));
  }
  function Fc(l, t) {
    l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.title == null && (l.title = t.title);
  }
  function Ic(l, t) {
    l.crossOrigin == null && (l.crossOrigin = t.crossOrigin), l.referrerPolicy == null && (l.referrerPolicy = t.referrerPolicy), l.integrity == null && (l.integrity = t.integrity);
  }
  var Dn = null;
  function lv(l, t, a) {
    if (Dn === null) {
      var u = /* @__PURE__ */ new Map(), e = Dn = /* @__PURE__ */ new Map();
      e.set(a, u);
    } else
      e = Dn, u = e.get(a), u || (u = /* @__PURE__ */ new Map(), e.set(a, u));
    if (u.has(l)) return u;
    for (u.set(l, null), a = a.getElementsByTagName(l), e = 0; e < a.length; e++) {
      var n = a[e];
      if (!(n[Nu] || n[Ol] || l === "link" && n.getAttribute("rel") === "stylesheet") && n.namespaceURI !== "http://www.w3.org/2000/svg") {
        var f = n.getAttribute(t) || "";
        f = l + f;
        var c = u.get(f);
        c ? c.push(n) : u.set(f, [n]);
      }
    }
    return u;
  }
  function tv(l, t, a) {
    l = l.ownerDocument || l, l.head.insertBefore(
      a,
      t === "title" ? l.querySelector("head > title") : null
    );
  }
  function L1(l, t, a) {
    if (a === 1 || t.itemProp != null) return !1;
    switch (l) {
      case "meta":
      case "title":
        return !0;
      case "style":
        if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "")
          break;
        return !0;
      case "link":
        if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError)
          break;
        return t.rel === "stylesheet" ? (l = t.disabled, typeof t.precedence == "string" && l == null) : !0;
      case "script":
        if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string")
          return !0;
    }
    return !1;
  }
  function av(l) {
    return !(l.type === "stylesheet" && (l.state.loading & 3) === 0);
  }
  function K1(l, t, a, u) {
    if (a.type === "stylesheet" && (typeof u.media != "string" || matchMedia(u.media).matches !== !1) && (a.state.loading & 4) === 0) {
      if (a.instance === null) {
        var e = Au(u.href), n = t.querySelector(
          me(e)
        );
        if (n) {
          t = n._p, t !== null && typeof t == "object" && typeof t.then == "function" && (l.count++, l = Nn.bind(l), t.then(l, l)), a.state.loading |= 4, a.instance = n, pl(n);
          return;
        }
        n = t.ownerDocument || t, u = Id(u), (e = gt.get(e)) && Fc(u, e), n = n.createElement("link"), pl(n);
        var f = n;
        f._p = new Promise(function(c, i) {
          f.onload = c, f.onerror = i;
        }), Hl(n, "link", u), a.instance = n;
      }
      l.stylesheets === null && (l.stylesheets = /* @__PURE__ */ new Map()), l.stylesheets.set(a, t), (t = a.state.preload) && (a.state.loading & 3) === 0 && (l.count++, a = Nn.bind(l), t.addEventListener("load", a), t.addEventListener("error", a));
    }
  }
  var Pc = 0;
  function J1(l, t) {
    return l.stylesheets && l.count === 0 && xn(l, l.stylesheets), 0 < l.count || 0 < l.imgCount ? function(a) {
      var u = setTimeout(function() {
        if (l.stylesheets && xn(l, l.stylesheets), l.unsuspend) {
          var n = l.unsuspend;
          l.unsuspend = null, n();
        }
      }, 6e4 + t);
      0 < l.imgBytes && Pc === 0 && (Pc = 62500 * M1());
      var e = setTimeout(
        function() {
          if (l.waitingForImages = !1, l.count === 0 && (l.stylesheets && xn(l, l.stylesheets), l.unsuspend)) {
            var n = l.unsuspend;
            l.unsuspend = null, n();
          }
        },
        (l.imgBytes > Pc ? 50 : 800) + t
      );
      return l.unsuspend = a, function() {
        l.unsuspend = null, clearTimeout(u), clearTimeout(e);
      };
    } : null;
  }
  function Nn() {
    if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
      if (this.stylesheets) xn(this, this.stylesheets);
      else if (this.unsuspend) {
        var l = this.unsuspend;
        this.unsuspend = null, l();
      }
    }
  }
  var Hn = null;
  function xn(l, t) {
    l.stylesheets = null, l.unsuspend !== null && (l.count++, Hn = /* @__PURE__ */ new Map(), t.forEach(w1, l), Hn = null, Nn.call(l));
  }
  function w1(l, t) {
    if (!(t.state.loading & 4)) {
      var a = Hn.get(l);
      if (a) var u = a.get(null);
      else {
        a = /* @__PURE__ */ new Map(), Hn.set(l, a);
        for (var e = l.querySelectorAll(
          "link[data-precedence],style[data-precedence]"
        ), n = 0; n < e.length; n++) {
          var f = e[n];
          (f.nodeName === "LINK" || f.getAttribute("media") !== "not all") && (a.set(f.dataset.precedence, f), u = f);
        }
        u && a.set(null, u);
      }
      e = t.instance, f = e.getAttribute("data-precedence"), n = a.get(f) || u, n === u && a.set(null, e), a.set(f, e), this.count++, u = Nn.bind(this), e.addEventListener("load", u), e.addEventListener("error", u), n ? n.parentNode.insertBefore(e, n.nextSibling) : (l = l.nodeType === 9 ? l.head : l, l.insertBefore(e, l.firstChild)), t.state.loading |= 4;
    }
  }
  var oe = {
    $$typeof: xl,
    Provider: null,
    Consumer: null,
    _currentValue: C,
    _currentValue2: C,
    _threadCount: 0
  };
  function W1(l, t, a, u, e, n, f, c, i) {
    this.tag = 1, this.containerInfo = l, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = wn(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = wn(0), this.hiddenUpdates = wn(null), this.identifierPrefix = u, this.onUncaughtError = e, this.onCaughtError = n, this.onRecoverableError = f, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = i, this.incompleteTransitions = /* @__PURE__ */ new Map();
  }
  function uv(l, t, a, u, e, n, f, c, i, m, S, z) {
    return l = new W1(
      l,
      t,
      a,
      f,
      i,
      m,
      S,
      z,
      c
    ), t = 1, n === !0 && (t |= 24), n = lt(3, null, null, t), l.current = n, n.stateNode = l, t = xf(), t.refCount++, l.pooledCache = t, t.refCount++, n.memoizedState = {
      element: u,
      isDehydrated: a,
      cache: t
    }, jf(n), l;
  }
  function ev(l) {
    return l ? (l = tu, l) : tu;
  }
  function nv(l, t, a, u, e, n) {
    e = ev(e), u.context === null ? u.context = e : u.pendingContext = e, u = ea(t), u.payload = { element: a }, n = n === void 0 ? null : n, n !== null && (u.callback = n), a = na(l, u, t), a !== null && (wl(a, l, t), wu(a, l, t));
  }
  function fv(l, t) {
    if (l = l.memoizedState, l !== null && l.dehydrated !== null) {
      var a = l.retryLane;
      l.retryLane = a !== 0 && a < t ? a : t;
    }
  }
  function li(l, t) {
    fv(l, t), (l = l.alternate) && fv(l, t);
  }
  function cv(l) {
    if (l.tag === 13 || l.tag === 31) {
      var t = Ua(l, 67108864);
      t !== null && wl(t, l, 67108864), li(l, 67108864);
    }
  }
  function iv(l) {
    if (l.tag === 13 || l.tag === 31) {
      var t = nt();
      t = Wn(t);
      var a = Ua(l, t);
      a !== null && wl(a, l, t), li(l, t);
    }
  }
  var Rn = !0;
  function $1(l, t, a, u) {
    var e = r.T;
    r.T = null;
    var n = _.p;
    try {
      _.p = 2, ti(l, t, a, u);
    } finally {
      _.p = n, r.T = e;
    }
  }
  function k1(l, t, a, u) {
    var e = r.T;
    r.T = null;
    var n = _.p;
    try {
      _.p = 8, ti(l, t, a, u);
    } finally {
      _.p = n, r.T = e;
    }
  }
  function ti(l, t, a, u) {
    if (Rn) {
      var e = ai(u);
      if (e === null)
        Qc(
          l,
          t,
          u,
          Cn,
          a
        ), dv(l, u);
      else if (I1(
        e,
        l,
        t,
        a,
        u
      ))
        u.stopPropagation();
      else if (dv(l, u), t & 4 && -1 < F1.indexOf(l)) {
        for (; e !== null; ) {
          var n = La(e);
          if (n !== null)
            switch (n.tag) {
              case 3:
                if (n = n.stateNode, n.current.memoizedState.isDehydrated) {
                  var f = Aa(n.pendingLanes);
                  if (f !== 0) {
                    var c = n;
                    for (c.pendingLanes |= 2, c.entangledLanes |= 2; f; ) {
                      var i = 1 << 31 - Il(f);
                      c.entanglements[1] |= i, f &= ~i;
                    }
                    Ot(n), (P & 6) === 0 && (gn = kl() + 500, se(0));
                  }
                }
                break;
              case 31:
              case 13:
                c = Ua(n, 2), c !== null && wl(c, n, 2), rn(), li(n, 2);
            }
          if (n = ai(u), n === null && Qc(
            l,
            t,
            u,
            Cn,
            a
          ), n === e) break;
          e = n;
        }
        e !== null && u.stopPropagation();
      } else
        Qc(
          l,
          t,
          u,
          null,
          a
        );
    }
  }
  function ai(l) {
    return l = uf(l), ui(l);
  }
  var Cn = null;
  function ui(l) {
    if (Cn = null, l = Va(l), l !== null) {
      var t = Z(l);
      if (t === null) l = null;
      else {
        var a = t.tag;
        if (a === 13) {
          if (l = ol(t), l !== null) return l;
          l = null;
        } else if (a === 31) {
          if (l = _l(t), l !== null) return l;
          l = null;
        } else if (a === 3) {
          if (t.stateNode.current.memoizedState.isDehydrated)
            return t.tag === 3 ? t.stateNode.containerInfo : null;
          l = null;
        } else t !== l && (l = null);
      }
    }
    return Cn = l, null;
  }
  function sv(l) {
    switch (l) {
      case "beforetoggle":
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "toggle":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return 2;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return 8;
      case "message":
        switch (jv()) {
          case Si:
            return 2;
          case ri:
            return 8;
          case Te:
          case Bv:
            return 32;
          case bi:
            return 268435456;
          default:
            return 32;
        }
      default:
        return 32;
    }
  }
  var ei = !1, ga = null, Sa = null, ra = null, ge = /* @__PURE__ */ new Map(), Se = /* @__PURE__ */ new Map(), ba = [], F1 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(
    " "
  );
  function dv(l, t) {
    switch (l) {
      case "focusin":
      case "focusout":
        ga = null;
        break;
      case "dragenter":
      case "dragleave":
        Sa = null;
        break;
      case "mouseover":
      case "mouseout":
        ra = null;
        break;
      case "pointerover":
      case "pointerout":
        ge.delete(t.pointerId);
        break;
      case "gotpointercapture":
      case "lostpointercapture":
        Se.delete(t.pointerId);
    }
  }
  function re(l, t, a, u, e, n) {
    return l === null || l.nativeEvent !== n ? (l = {
      blockedOn: t,
      domEventName: a,
      eventSystemFlags: u,
      nativeEvent: n,
      targetContainers: [e]
    }, t !== null && (t = La(t), t !== null && cv(t)), l) : (l.eventSystemFlags |= u, t = l.targetContainers, e !== null && t.indexOf(e) === -1 && t.push(e), l);
  }
  function I1(l, t, a, u, e) {
    switch (t) {
      case "focusin":
        return ga = re(
          ga,
          l,
          t,
          a,
          u,
          e
        ), !0;
      case "dragenter":
        return Sa = re(
          Sa,
          l,
          t,
          a,
          u,
          e
        ), !0;
      case "mouseover":
        return ra = re(
          ra,
          l,
          t,
          a,
          u,
          e
        ), !0;
      case "pointerover":
        var n = e.pointerId;
        return ge.set(
          n,
          re(
            ge.get(n) || null,
            l,
            t,
            a,
            u,
            e
          )
        ), !0;
      case "gotpointercapture":
        return n = e.pointerId, Se.set(
          n,
          re(
            Se.get(n) || null,
            l,
            t,
            a,
            u,
            e
          )
        ), !0;
    }
    return !1;
  }
  function vv(l) {
    var t = Va(l.target);
    if (t !== null) {
      var a = Z(t);
      if (a !== null) {
        if (t = a.tag, t === 13) {
          if (t = ol(a), t !== null) {
            l.blockedOn = t, pi(l.priority, function() {
              iv(a);
            });
            return;
          }
        } else if (t === 31) {
          if (t = _l(a), t !== null) {
            l.blockedOn = t, pi(l.priority, function() {
              iv(a);
            });
            return;
          }
        } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
          l.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
          return;
        }
      }
    }
    l.blockedOn = null;
  }
  function qn(l) {
    if (l.blockedOn !== null) return !1;
    for (var t = l.targetContainers; 0 < t.length; ) {
      var a = ai(l.nativeEvent);
      if (a === null) {
        a = l.nativeEvent;
        var u = new a.constructor(
          a.type,
          a
        );
        af = u, a.target.dispatchEvent(u), af = null;
      } else
        return t = La(a), t !== null && cv(t), l.blockedOn = a, !1;
      t.shift();
    }
    return !0;
  }
  function yv(l, t, a) {
    qn(l) && a.delete(t);
  }
  function P1() {
    ei = !1, ga !== null && qn(ga) && (ga = null), Sa !== null && qn(Sa) && (Sa = null), ra !== null && qn(ra) && (ra = null), ge.forEach(yv), Se.forEach(yv);
  }
  function jn(l, t) {
    l.blockedOn === t && (l.blockedOn = null, ei || (ei = !0, A.unstable_scheduleCallback(
      A.unstable_NormalPriority,
      P1
    )));
  }
  var Bn = null;
  function mv(l) {
    Bn !== l && (Bn = l, A.unstable_scheduleCallback(
      A.unstable_NormalPriority,
      function() {
        Bn === l && (Bn = null);
        for (var t = 0; t < l.length; t += 3) {
          var a = l[t], u = l[t + 1], e = l[t + 2];
          if (typeof u != "function") {
            if (ui(u || a) === null)
              continue;
            break;
          }
          var n = La(a);
          n !== null && (l.splice(t, 3), t -= 3, ac(
            n,
            {
              pending: !0,
              data: e,
              method: a.method,
              action: u
            },
            u,
            e
          ));
        }
      }
    ));
  }
  function pu(l) {
    function t(i) {
      return jn(i, l);
    }
    ga !== null && jn(ga, l), Sa !== null && jn(Sa, l), ra !== null && jn(ra, l), ge.forEach(t), Se.forEach(t);
    for (var a = 0; a < ba.length; a++) {
      var u = ba[a];
      u.blockedOn === l && (u.blockedOn = null);
    }
    for (; 0 < ba.length && (a = ba[0], a.blockedOn === null); )
      vv(a), a.blockedOn === null && ba.shift();
    if (a = (l.ownerDocument || l).$$reactFormReplay, a != null)
      for (u = 0; u < a.length; u += 3) {
        var e = a[u], n = a[u + 1], f = e[Ql] || null;
        if (typeof n == "function")
          f || mv(a);
        else if (f) {
          var c = null;
          if (n && n.hasAttribute("formAction")) {
            if (e = n, f = n[Ql] || null)
              c = f.formAction;
            else if (ui(e) !== null) continue;
          } else c = f.action;
          typeof c == "function" ? a[u + 1] = c : (a.splice(u, 3), u -= 3), mv(a);
        }
      }
  }
  function hv() {
    function l(n) {
      n.canIntercept && n.info === "react-transition" && n.intercept({
        handler: function() {
          return new Promise(function(f) {
            return e = f;
          });
        },
        focusReset: "manual",
        scroll: "manual"
      });
    }
    function t() {
      e !== null && (e(), e = null), u || setTimeout(a, 20);
    }
    function a() {
      if (!u && !navigation.transition) {
        var n = navigation.currentEntry;
        n && n.url != null && navigation.navigate(n.url, {
          state: n.getState(),
          info: "react-transition",
          history: "replace"
        });
      }
    }
    if (typeof navigation == "object") {
      var u = !1, e = null;
      return navigation.addEventListener("navigate", l), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(a, 100), function() {
        u = !0, navigation.removeEventListener("navigate", l), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), e !== null && (e(), e = null);
      };
    }
  }
  function ni(l) {
    this._internalRoot = l;
  }
  Yn.prototype.render = ni.prototype.render = function(l) {
    var t = this._internalRoot;
    if (t === null) throw Error(h(409));
    var a = t.current, u = nt();
    nv(a, u, l, t, null, null);
  }, Yn.prototype.unmount = ni.prototype.unmount = function() {
    var l = this._internalRoot;
    if (l !== null) {
      this._internalRoot = null;
      var t = l.containerInfo;
      nv(l.current, 2, null, l, null, null), rn(), t[Za] = null;
    }
  };
  function Yn(l) {
    this._internalRoot = l;
  }
  Yn.prototype.unstable_scheduleHydration = function(l) {
    if (l) {
      var t = _i();
      l = { blockedOn: null, target: l, priority: t };
      for (var a = 0; a < ba.length && t !== 0 && t < ba[a].priority; a++) ;
      ba.splice(a, 0, l), a === 0 && vv(l);
    }
  };
  var ov = j.version;
  if (ov !== "19.2.5")
    throw Error(
      h(
        527,
        ov,
        "19.2.5"
      )
    );
  _.findDOMNode = function(l) {
    var t = l._reactInternals;
    if (t === void 0)
      throw typeof l.render == "function" ? Error(h(188)) : (l = Object.keys(l).join(","), Error(h(268, l)));
    return l = T(t), l = l !== null ? k(l) : null, l = l === null ? null : l.stateNode, l;
  };
  var lm = {
    bundleType: 0,
    version: "19.2.5",
    rendererPackageName: "react-dom",
    currentDispatcherRef: r,
    reconcilerVersion: "19.2.5"
  };
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Gn = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Gn.isDisabled && Gn.supportsFiber)
      try {
        Ou = Gn.inject(
          lm
        ), Fl = Gn;
      } catch {
      }
  }
  return ze.createRoot = function(l, t) {
    if (!q(l)) throw Error(h(299));
    var a = !1, u = "", e = Ts, n = As, f = _s;
    return t != null && (t.unstable_strictMode === !0 && (a = !0), t.identifierPrefix !== void 0 && (u = t.identifierPrefix), t.onUncaughtError !== void 0 && (e = t.onUncaughtError), t.onCaughtError !== void 0 && (n = t.onCaughtError), t.onRecoverableError !== void 0 && (f = t.onRecoverableError)), t = uv(
      l,
      1,
      !1,
      null,
      null,
      a,
      u,
      null,
      e,
      n,
      f,
      hv
    ), l[Za] = t.current, Xc(l), new ni(t);
  }, ze.hydrateRoot = function(l, t, a) {
    if (!q(l)) throw Error(h(299));
    var u = !1, e = "", n = Ts, f = As, c = _s, i = null;
    return a != null && (a.unstable_strictMode === !0 && (u = !0), a.identifierPrefix !== void 0 && (e = a.identifierPrefix), a.onUncaughtError !== void 0 && (n = a.onUncaughtError), a.onCaughtError !== void 0 && (f = a.onCaughtError), a.onRecoverableError !== void 0 && (c = a.onRecoverableError), a.formState !== void 0 && (i = a.formState)), t = uv(
      l,
      1,
      !0,
      t,
      a ?? null,
      u,
      e,
      i,
      n,
      f,
      c,
      hv
    ), t.context = ev(null), a = t.current, u = nt(), u = Wn(u), e = ea(u), e.callback = null, na(a, e, u), a = u, t.current.lanes = a, Du(t, a), Ot(t), l[Za] = t.current, Xc(l), new Yn(t);
  }, ze.version = "19.2.5", ze;
}
var pv;
function ym() {
  if (pv) return ii.exports;
  pv = 1;
  function A() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function"))
      try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A);
      } catch (j) {
        console.error(j);
      }
  }
  return A(), ii.exports = vm(), ii.exports;
}
var mm = ym();
const hm = (A) => A.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), om = (A) => A.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (j, X, h) => h ? h.toUpperCase() : X.toLowerCase()
), Mv = (A) => {
  const j = om(A);
  return j.charAt(0).toUpperCase() + j.slice(1);
}, xv = (...A) => A.filter((j, X, h) => !!j && j.trim() !== "" && h.indexOf(j) === X).join(" ").trim(), gm = (A) => {
  for (const j in A)
    if (j.startsWith("aria-") || j === "role" || j === "title")
      return !0;
};
var Sm = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const rm = Wt.forwardRef(
  ({
    color: A = "currentColor",
    size: j = 24,
    strokeWidth: X = 2,
    absoluteStrokeWidth: h,
    className: q = "",
    children: Z,
    iconNode: ol,
    ..._l
  }, D) => Wt.createElement(
    "svg",
    {
      ref: D,
      ...Sm,
      width: j,
      height: j,
      stroke: A,
      strokeWidth: h ? Number(X) * 24 / Number(j) : X,
      className: xv("lucide", q),
      ...!Z && !gm(_l) && { "aria-hidden": "true" },
      ..._l
    },
    [
      ...ol.map(([T, k]) => Wt.createElement(T, k)),
      ...Array.isArray(Z) ? Z : [Z]
    ]
  )
);
const Xn = (A, j) => {
  const X = Wt.forwardRef(
    ({ className: h, ...q }, Z) => Wt.createElement(rm, {
      ref: Z,
      iconNode: j,
      className: xv(
        `lucide-${hm(Mv(A))}`,
        `lucide-${A}`,
        h
      ),
      ...q
    })
  );
  return X.displayName = Mv(A), X;
};
const bm = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]], Ov = Xn("check", bm);
const zm = [
  ["path", { d: "M21.54 15H17a2 2 0 0 0-2 2v4.54", key: "1djwo0" }],
  [
    "path",
    {
      d: "M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",
      key: "1tzkfa"
    }
  ],
  ["path", { d: "M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05", key: "14pb5j" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
], Em = Xn("earth", zm);
const Tm = [
  ["path", { d: "M10 8h.01", key: "1r9ogq" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M14 8h.01", key: "1primd" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }],
  ["path", { d: "M18 8h.01", key: "emo2bl" }],
  ["path", { d: "M6 8h.01", key: "x9i8wu" }],
  ["path", { d: "M7 16h10", key: "wp8him" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }]
], Am = Xn("keyboard", Tm);
const _m = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ],
  ["path", { d: "M20 2v4", key: "1rf3ol" }],
  ["path", { d: "M22 4h-4", key: "gwowj6" }],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
], pm = Xn("sparkles", _m), yi = am(
  void 0,
  "",
  ""
), mi = um(
  void 0,
  void 0,
  "",
  ""
), Uv = [
  {
    value: "alt_option",
    label: "Alt / Option",
    description: "Windows: Alt | Mac: Option",
    keyHint: "⌥"
  },
  {
    value: "cmd_ctrl",
    label: "Cmd / Ctrl",
    description: "Windows: Ctrl | Mac: Cmd",
    keyHint: "⌘"
  }
];
function Dv({
  icon: A,
  title: j,
  description: X,
  children: h
}) {
  return /* @__PURE__ */ x.jsxs("section", { className: "rounded-[2rem] border border-slate-200/80 bg-white/90 p-6 shadow-[0_18px_60px_rgba(15,23,42,0.08)] backdrop-blur", children: [
    /* @__PURE__ */ x.jsxs("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ x.jsx("div", { className: "flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 text-white shadow-lg shadow-slate-950/10", children: A }),
      /* @__PURE__ */ x.jsxs("div", { className: "min-w-0", children: [
        /* @__PURE__ */ x.jsx("h2", { className: "text-lg font-black tracking-tight text-slate-950", children: j }),
        /* @__PURE__ */ x.jsx("p", { className: "mt-1 text-sm leading-6 text-slate-600", children: X })
      ] })
    ] }),
    /* @__PURE__ */ x.jsx("div", { className: "mt-5", children: h })
  ] });
}
function Nv({ title: A, helper: j }) {
  return /* @__PURE__ */ x.jsxs("div", { className: "space-y-1", children: [
    /* @__PURE__ */ x.jsx("div", { className: "text-xs font-bold uppercase tracking-[0.24em] text-slate-400", children: A }),
    /* @__PURE__ */ x.jsx("div", { className: "text-sm text-slate-500", children: j })
  ] });
}
function Mm() {
  const [A, j] = Wt.useState({
    modifier: "alt_option",
    appUrl: yi,
    apiBaseUrl: mi,
    saved: !1
  }), X = Wt.useMemo(
    () => Uv.find((q) => q.value === A.modifier),
    [A.modifier]
  );
  Wt.useEffect(() => {
    chrome.storage.sync.get(["flow_reader_modifier", "flow_reader_app_url", "flow_reader_api_base_url"]).then((q) => {
      j((Z) => ({
        ...Z,
        modifier: q.flow_reader_modifier || "alt_option",
        appUrl: q.flow_reader_app_url || yi,
        apiBaseUrl: q.flow_reader_api_base_url || mi
      }));
    });
  }, []), Wt.useEffect(() => {
    if (!A.saved)
      return;
    const q = window.setTimeout(() => {
      j((Z) => ({ ...Z, saved: !1 }));
    }, 1800);
    return () => window.clearTimeout(q);
  }, [A.saved]);
  const h = async () => {
    await chrome.storage.sync.set({
      flow_reader_modifier: A.modifier,
      flow_reader_app_url: A.appUrl.trim(),
      flow_reader_api_base_url: A.apiBaseUrl.trim()
    }), j((q) => ({ ...q, saved: !0 }));
  };
  return /* @__PURE__ */ x.jsx("div", { className: "min-h-screen bg-gradient-to-b from-slate-50 via-white to-indigo-50 px-4 py-8 text-slate-900", children: /* @__PURE__ */ x.jsxs("div", { className: "mx-auto flex max-w-2xl flex-col gap-4", children: [
    /* @__PURE__ */ x.jsxs("header", { className: "overflow-hidden rounded-[2rem] border border-slate-200/80 bg-white shadow-[0_18px_60px_rgba(15,23,42,0.08)]", children: [
      /* @__PURE__ */ x.jsx("div", { className: "bg-gradient-to-r from-indigo-600 via-violet-600 to-sky-500 px-6 py-6 text-white", children: /* @__PURE__ */ x.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ x.jsx("div", { className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/20", children: /* @__PURE__ */ x.jsx(pm, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ x.jsxs("div", { children: [
          /* @__PURE__ */ x.jsx("p", { className: "text-xs font-bold uppercase tracking-[0.3em] text-white/80", children: "AI English Study" }),
          /* @__PURE__ */ x.jsx("h1", { className: "mt-1 text-2xl font-black tracking-tight", children: "설정" })
        ] })
      ] }) }),
      /* @__PURE__ */ x.jsxs("div", { className: "px-6 py-5", children: [
        /* @__PURE__ */ x.jsx("p", { className: "max-w-2xl text-sm leading-6 text-slate-600", children: "단축키와 웹앱 주소를 저장하면 확장앱이 바로 동작합니다. 저장 후 열려 있는 탭에도 설정이 자동 반영됩니다." }),
        /* @__PURE__ */ x.jsxs("div", { className: "mt-4 flex flex-wrap gap-2 text-xs font-semibold", children: [
          /* @__PURE__ */ x.jsxs("span", { className: "rounded-full bg-indigo-50 px-3 py-1 text-indigo-700 ring-1 ring-indigo-100", children: [
            "기본 웹앱: ",
            yi
          ] }),
          /* @__PURE__ */ x.jsxs("span", { className: "rounded-full bg-sky-50 px-3 py-1 text-sky-700 ring-1 ring-sky-100", children: [
            "기본 서버: ",
            mi
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ x.jsx(
      Dv,
      {
        icon: /* @__PURE__ */ x.jsx(Am, { className: "h-5 w-5" }),
        title: "단어 조회 단축키",
        description: "선택한 키를 누른 상태에서 단어 위에 마우스를 올리면 뜻이 표시됩니다.",
        children: /* @__PURE__ */ x.jsx("div", { className: "grid gap-3 sm:grid-cols-2", children: Uv.map((q) => {
          const Z = A.modifier === q.value;
          return /* @__PURE__ */ x.jsxs(
            "label",
            {
              className: `flex cursor-pointer items-center gap-4 rounded-3xl border p-4 transition ${Z ? "border-indigo-300 bg-indigo-50/80 shadow-sm" : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"}`,
              children: [
                /* @__PURE__ */ x.jsx(
                  "input",
                  {
                    type: "radio",
                    name: "modifier",
                    value: q.value,
                    checked: Z,
                    onChange: () => j((ol) => ({ ...ol, modifier: q.value })),
                    className: "sr-only"
                  }
                ),
                /* @__PURE__ */ x.jsx(
                  "div",
                  {
                    className: `flex h-11 w-11 items-center justify-center rounded-2xl text-lg font-black ${Z ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600"}`,
                    children: q.keyHint
                  }
                ),
                /* @__PURE__ */ x.jsxs("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ x.jsxs("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ x.jsx("span", { className: "font-bold text-slate-950", children: q.label }),
                    Z ? /* @__PURE__ */ x.jsx(Ov, { className: "h-4 w-4 text-indigo-600" }) : null
                  ] }),
                  /* @__PURE__ */ x.jsx("p", { className: "text-sm text-slate-500", children: q.description })
                ] })
              ]
            },
            q.value
          );
        }) })
      }
    ),
    /* @__PURE__ */ x.jsx(
      Dv,
      {
        icon: /* @__PURE__ */ x.jsx(Em, { className: "h-5 w-5" }),
        title: "주소 설정",
        description: "팝업의 ‘내 단어장 열기’와 서버 요청 주소를 각각 맞게 저장하세요.",
        children: /* @__PURE__ */ x.jsxs("div", { className: "grid gap-4 md:grid-cols-2", children: [
          /* @__PURE__ */ x.jsxs("label", { className: "block space-y-2", children: [
            /* @__PURE__ */ x.jsx(Nv, { title: "App URL", helper: "팝업 버튼이 여기를 엽니다." }),
            /* @__PURE__ */ x.jsx(
              "input",
              {
                type: "url",
                value: A.appUrl,
                onChange: (q) => j((Z) => ({ ...Z, appUrl: q.target.value })),
                placeholder: "https://your-app.example.com",
                className: "h-12 w-full rounded-2xl border border-slate-200 bg-white px-4 font-mono text-sm outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:ring-4 focus:ring-indigo-100"
              }
            )
          ] }),
          /* @__PURE__ */ x.jsxs("label", { className: "block space-y-2", children: [
            /* @__PURE__ */ x.jsx(Nv, { title: "API Base URL", helper: "확장앱이 서버에 요청을 보냅니다." }),
            /* @__PURE__ */ x.jsx(
              "input",
              {
                type: "url",
                value: A.apiBaseUrl,
                onChange: (q) => j((Z) => ({ ...Z, apiBaseUrl: q.target.value })),
                placeholder: "http://localhost:3000",
                className: "h-12 w-full rounded-2xl border border-slate-200 bg-white px-4 font-mono text-sm outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:ring-4 focus:ring-indigo-100"
              }
            )
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ x.jsxs(
      "button",
      {
        onClick: h,
        className: `inline-flex h-12 w-full items-center justify-center gap-2 rounded-full px-5 text-sm font-bold text-white shadow-lg transition ${A.saved ? "bg-emerald-500 shadow-emerald-500/30" : "bg-gradient-to-r from-indigo-600 via-violet-600 to-sky-600 shadow-indigo-500/25 hover:brightness-105"}`,
        children: [
          A.saved ? /* @__PURE__ */ x.jsx(Ov, { className: "h-4 w-4" }) : null,
          A.saved ? "저장되었습니다" : "설정 저장"
        ]
      }
    ),
    /* @__PURE__ */ x.jsxs("div", { className: "rounded-3xl border border-indigo-100 bg-indigo-50/70 p-4 text-sm text-indigo-900", children: [
      /* @__PURE__ */ x.jsx("strong", { children: "현재 선택:" }),
      " ",
      X ? X.label : "미선택",
      /* @__PURE__ */ x.jsx("div", { className: "mt-2 text-xs leading-5 text-indigo-700", children: "저장 후 확장앱 팝업과 단어 조회 동작에 바로 반영됩니다." })
    ] })
  ] }) });
}
const Hv = document.getElementById("root");
Hv && mm.createRoot(Hv).render(/* @__PURE__ */ x.jsx(Mm, {}));
export {
  Mm as default
};
