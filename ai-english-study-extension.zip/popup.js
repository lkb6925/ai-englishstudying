import { r as c, a as d, b as l } from "./app-config-DuchQk2N.js";
const s = c(
  void 0,
  "",
  ""
), o = d(
  void 0,
  void 0,
  "",
  ""
), u = l(
  void 0,
  "",
  ""
);
function r(e) {
  const t = document.getElementById("modifier-text"), n = document.querySelector(".key-icon");
  !t || !n || (t.textContent = e === "cmd_ctrl" ? "Cmd / Ctrl + 마우스 올리기" : "Alt / Option + 마우스 올리기", n.textContent = e === "cmd_ctrl" ? "⌘" : "⌥");
}
function i(e) {
  const t = document.getElementById("api-base-url");
  t && (t.textContent = `API: ${e}`);
}
function a(e) {
  const t = document.getElementById("wordbook-btn");
  t && t.addEventListener("click", () => {
    chrome.tabs.create({ url: e.replace(/\/$/, "") + "/wordbook" });
  });
}
async function m() {
  const e = await chrome.runtime.sendMessage({
    type: "FLOW_GET_RUNTIME_CONFIG"
  });
  if (!e?.ok || !e.data || !("modifier" in e.data))
    throw new Error("Runtime config was unavailable.");
  return e.data;
}
async function p() {
  try {
    const t = await m();
    r(t.modifier), i(t.apiBaseUrl || o), a(t.appUrl || s);
  } catch (t) {
    console.warn("AI English Study popup failed to load runtime config.", t), r("alt_option"), i(o), a(u.replace(/\/wordbook$/, ""));
  }
  document.getElementById("options-btn")?.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}
p();
