import { g } from "./app-config-DuchQk2N.js";
class f {
  constructor(e) {
    this.options = e, this.modifierMode = "alt_option", this.modifierPressed = !1, this.hoverTimer = null, this.handleKeyDown = (t) => {
      if (this.modifierMode === "cmd_ctrl") {
        this.modifierPressed = t.metaKey || t.ctrlKey;
        return;
      }
      this.modifierPressed = t.altKey;
    }, this.handleKeyUp = () => {
      this.modifierPressed = !1, this.options.onModifierReleased();
    }, this.handleMouseMove = (t) => {
      if (!this.modifierPressed)
        return;
      const o = t.target;
      o instanceof Element && (this.hoverTimer !== null && window.clearTimeout(this.hoverTimer), this.hoverTimer = window.setTimeout(() => {
        this.options.onHoverIntent(o, t.clientX, t.clientY);
      }, this.options.hoverDebounceMs));
    }, this.handleAuthBridgeMessage = (t) => {
      if (t.source !== window || !this.options.trustedAuthBridgeOrigins.includes(t.origin) || typeof t.data != "object" || t.data === null) return;
      const o = t.data;
      if (!(o.source !== "tap-and-know-auth" || o.type !== "SUPABASE_JWT" && o.type !== "SUPABASE_LOGOUT")) {
        if (o.type === "SUPABASE_JWT") {
          if (typeof o.token != "string" || o.token.length === 0)
            return;
          this.options.onAuthBridgeEvent({ type: "jwt", token: o.token });
          return;
        }
        this.options.onAuthBridgeEvent({ type: "logout" });
      }
    };
  }
  setModifierMode(e) {
    this.modifierMode = e;
  }
  start() {
    window.addEventListener("keydown", this.handleKeyDown), window.addEventListener("keyup", this.handleKeyUp), window.addEventListener("mousemove", this.handleMouseMove), window.addEventListener("message", this.handleAuthBridgeMessage);
  }
}
class w {
  constructor() {
    this.overlayHost = null, this.shadowRootRef = null;
  }
  clear() {
    this.shadowRootRef && (this.shadowRootRef.innerHTML = "");
  }
  render(e) {
    const t = this.ensureOverlayRoot();
    t.innerHTML = "";
    const o = document.createElement("style");
    o.textContent = `
      :host { all: initial; }
      .popup {
        pointer-events: auto;
        position: fixed;
        width: 300px;
        max-width: calc(100vw - 24px);
        border-radius: 16px;
        background: #18181b;
        border: 1px solid rgba(255,255,255,0.12);
        padding: 14px 16px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(99,102,241,0.2);
        font-family: 'Pretendard Variable', 'Pretendard', system-ui, sans-serif;
        animation: fadeIn 0.15s ease;
      }
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(4px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .word {
        font-size: 16px;
        font-weight: 900;
        color: #f4f4f5;
        margin: 0 0 8px 0;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .badge {
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        padding: 2px 8px;
        border-radius: 999px;
        background: rgba(99,102,241,0.2);
        color: #818cf8;
        border: 1px solid rgba(99,102,241,0.35);
      }
      .divider {
        height: 1px;
        background: rgba(255,255,255,0.08);
        margin: 8px 0;
      }
      .meanings {
        margin: 0;
        padding: 0;
        list-style: none;
      }
      .meaning-item {
        font-size: 13px;
        color: #a1a1aa;
        line-height: 1.6;
        padding: 3px 0;
        display: flex;
        gap: 8px;
      }
      .meaning-item::before {
        content: '•';
        color: #6366f1;
        flex-shrink: 0;
      }
      .fomo {
        margin-top: 10px;
        padding: 8px 10px;
        border-radius: 8px;
        background: rgba(239,68,68,0.1);
        border: 1px solid rgba(239,68,68,0.25);
        font-size: 12px;
        font-weight: 700;
        color: #fca5a5;
      }
      .loading {
        font-size: 13px;
        color: #52525b;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .spinner {
        width: 12px;
        height: 12px;
        border: 2px solid rgba(99,102,241,0.3);
        border-top-color: #6366f1;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
      }
      @keyframes spin { to { transform: rotate(360deg); } }
    `, t.appendChild(o);
    const n = document.createElement("div");
    n.className = "popup";
    const r = window.innerWidth, c = window.innerHeight;
    let a = e.x + 12, s = e.y + 12;
    a + 300 > r && (a = e.x - 312), s + 160 > c && (s = e.y - 170), n.style.left = `${a}px`, n.style.top = `${s}px`;
    const d = e.meanings.length === 1 && e.meanings[0] === "조회 중...";
    n.innerHTML = `
      <p class="word">
        ${e.word}
        <span class="badge">AI English Study</span>
      </p>
      <div class="divider"></div>
      ${d ? '<div class="loading"><div class="spinner"></div> AI가 문맥을 분석 중...</div>' : `<ul class="meanings">${e.meanings.map((h) => `<li class="meaning-item">${h}</li>`).join("")}</ul>`}
      ${e.fomoMessage ? `<div class="fomo">${e.fomoMessage}</div>` : ""}
    `, t.appendChild(n);
  }
  ensureOverlayRoot() {
    if (this.overlayHost && this.shadowRootRef)
      return this.shadowRootRef;
    const e = document.createElement("div");
    e.id = "ai-english-study-overlay-host", Object.assign(e.style, {
      position: "fixed",
      left: "0",
      top: "0",
      zIndex: "2147483647",
      pointerEvents: "none"
    }), document.documentElement.appendChild(e);
    const t = e.attachShadow({ mode: "open" });
    return this.overlayHost = e, this.shadowRootRef = t, t;
  }
}
class y {
  constructor(e = "flow-reader:ext:", t = 100) {
    this.storageKeyPrefix = e, this.maxEntries = t;
  }
  get(e) {
    const t = this.getStorageKey(e);
    try {
      const o = window.localStorage.getItem(t);
      if (!o) return null;
      const n = JSON.parse(o);
      return !Array.isArray(n.meanings) || typeof n.expiresAt != "number" || n.expiresAt < Date.now() ? (window.localStorage.removeItem(t), null) : n;
    } catch {
      return window.localStorage.removeItem(t), null;
    }
  }
  set(e, t) {
    try {
      this.pruneExpiredEntries(), this.trimToCapacity(), window.localStorage.setItem(this.getStorageKey(e), JSON.stringify(t));
    } catch {
    }
  }
  getStorageKey(e) {
    return `${this.storageKeyPrefix}${e}`;
  }
  collectRecords() {
    const e = [], t = [];
    for (let o = 0; o < window.localStorage.length; o += 1) {
      const n = window.localStorage.key(o);
      !n || !n.startsWith(this.storageKeyPrefix) || t.push(n);
    }
    for (const o of t) {
      const n = window.localStorage.getItem(o);
      if (n)
        try {
          const r = JSON.parse(n);
          if (!Array.isArray(r.meanings) || typeof r.expiresAt != "number") {
            window.localStorage.removeItem(o);
            continue;
          }
          e.push({ storageKey: o, entry: r });
        } catch {
          window.localStorage.removeItem(o);
        }
    }
    return e;
  }
  pruneExpiredEntries() {
    const e = Date.now();
    for (const t of this.collectRecords())
      t.entry.expiresAt < e && window.localStorage.removeItem(t.storageKey);
  }
  trimToCapacity() {
    const e = this.collectRecords().sort(
      (t, o) => t.entry.expiresAt - o.entry.expiresAt
    );
    for (; e.length >= this.maxEntries; ) {
      const t = e.shift();
      if (!t)
        return;
      window.localStorage.removeItem(t.storageKey);
    }
  }
}
function x(i) {
  const e = ["gmail.", "bank", "docs.", "localhost"], t = i.toLowerCase();
  return e.some((o) => t.includes(o));
}
async function p(i) {
  const t = new TextEncoder().encode(i), o = await crypto.subtle.digest("SHA-256", t);
  return Array.from(new Uint8Array(o)).map((n) => n.toString(16).padStart(2, "0")).join("");
}
class v {
  constructor(e) {
    this.options = e, this.recentRequestTimestamps = [], this.lastLookupKey = null, this.overlay = new w(), this.cache = new y();
  }
  async lookupFromElement(e, t, o) {
    const n = this.extractWord(e), r = this.extractContext(e);
    if (!n || !r)
      return;
    const c = n.toLowerCase().trim(), a = await p(r), s = `${c}:${a}`;
    if (this.lastLookupKey === s)
      return;
    if (x(window.location.hostname)) {
      this.renderOverlay({
        word: n,
        meanings: ["이 페이지에서는 개인정보 보호를 위해 조회가 비활성화됩니다."],
        x: t,
        y: o,
        fomoMessage: null
      });
      return;
    }
    if (!this.canRequest()) {
      this.renderOverlay({
        word: n,
        meanings: ["요청이 너무 많습니다. 잠시 후 다시 시도해 주세요."],
        x: t,
        y: o,
        fomoMessage: null
      });
      return;
    }
    this.lastLookupKey = s;
    const d = this.cache.get(s);
    if (d) {
      this.renderOverlay({
        word: n,
        meanings: d.meanings,
        x: t,
        y: o,
        fomoMessage: null
      });
      return;
    }
    this.renderOverlay({ word: n, meanings: ["조회 중..."], x: t, y: o, fomoMessage: null });
    const h = await p(window.location.pathname);
    let u;
    try {
      u = await chrome.runtime.sendMessage({
        type: "FLOW_LOOKUP",
        payload: {
          word: n,
          sentence: r,
          term: n,
          context: r,
          sourceDomain: window.location.hostname,
          sourcePathHash: h
        }
      });
    } catch (m) {
      this.lastLookupKey = null, this.renderOverlay({
        word: n,
        meanings: ["조회 요청을 보내지 못했습니다. 잠시 후 다시 시도해 주세요."],
        x: t,
        y: o,
        fomoMessage: null
      }), console.warn("AI English Study lookup request failed.", m);
      return;
    }
    const l = this.extractLookupResult(u, n, t, o);
    if (!l) {
      this.lastLookupKey = null;
      return;
    }
    this.cache.set(s, {
      meanings: l.meanings,
      expiresAt: Date.now() + this.options.cacheTtlMs
    }), this.renderOverlay({
      word: n,
      meanings: l.meanings,
      x: t,
      y: o,
      fomoMessage: l.guestStats?.fomoMessage ?? null
    });
  }
  clearOverlay() {
    this.overlay.clear(), this.lastLookupKey = null;
  }
  extractLookupResult(e, t, o, n) {
    return e.ok ? "meanings" in e.data ? e.data : null : (this.renderOverlay({
      word: t,
      meanings: [e.error.message || "조회에 실패했습니다."],
      x: o,
      y: n,
      fomoMessage: null
    }), null);
  }
  extractWord(e) {
    return (e.textContent?.trim() ?? "").match(/[A-Za-z][A-Za-z'-]*/)?.[0] ?? "";
  }
  extractContext(e) {
    return ([
      e.closest("p, li, h1, h2, h3, h4, h5, h6, article")?.textContent ?? "",
      e.closest("p, div, article, section")?.textContent ?? "",
      e.closest("label, button, span")?.textContent ?? "",
      e.textContent ?? ""
    ].map((n) => n.replace(/\s+/g, " ").trim()).find((n) => n.length > 0) ?? "").slice(0, 300);
  }
  canRequest() {
    const e = Date.now(), t = e - 6e4;
    return this.recentRequestTimestamps = this.recentRequestTimestamps.filter(
      (o) => o > t
    ), this.recentRequestTimestamps.length >= this.options.maxRequestsPerMinute ? !1 : (this.recentRequestTimestamps.push(e), !0);
  }
  renderOverlay(e) {
    this.overlay.render(e);
  }
}
const M = 200, E = 10, k = 1440 * 60 * 1e3, A = g(
  void 0,
  "",
  ""
);
class b {
  constructor() {
    this.eventManager = new f({
      trustedAuthBridgeOrigins: A,
      hoverDebounceMs: M,
      onHoverIntent: (e, t, o) => {
        this.lookupCoordinator.lookupFromElement(e, t, o);
      },
      onModifierReleased: () => {
        this.lookupCoordinator.clearOverlay();
      },
      onAuthBridgeEvent: (e) => {
        this.persistAuthBridgeEvent(e);
      }
    }), this.lookupCoordinator = new v({
      cacheTtlMs: k,
      maxRequestsPerMinute: E
    });
  }
  async start() {
    this.eventManager.setModifierMode(await this.loadModifierFromBackground()), chrome.runtime.onMessage.addListener((e) => {
      if (e?.type === "FLOW_MODIFIER_CHANGED") {
        const t = e.payload?.modifier;
        (t === "alt_option" || t === "cmd_ctrl") && this.eventManager.setModifierMode(t);
      }
    }), this.eventManager.start();
  }
  async loadModifierFromBackground() {
    try {
      const e = await chrome.runtime.sendMessage({
        type: "FLOW_GET_MODIFIER"
      });
      if (e.ok && "modifier" in e.data)
        return e.data.modifier;
    } catch (e) {
      console.warn("AI English Study modifier load failed, using default.", e);
    }
    return "alt_option";
  }
  async persistAuthBridgeEvent(e) {
    if (e.type === "jwt") {
      await chrome.runtime.sendMessage({
        type: "FLOW_SET_JWT",
        payload: { token: e.token }
      });
      return;
    }
    await chrome.runtime.sendMessage({
      type: "FLOW_CLEAR_JWT"
    });
  }
}
const R = new b();
R.start();
